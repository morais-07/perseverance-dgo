CHASSIS HÍBRIDO PARAMÉTRICO - COMO ABRIR
Design Generativo e Otimização 2026/27 - M1
Autor: Rafael Morais


O QUE ESTÁ NESTA PASTA

  Chassis_Hibrido_Parametrico.f3d   Modelo do chassis, com os parâmetros
  PainelParametros\                 Add-in com o painel de sliders
  README.txt                        Estas instruções

O ficheiro .f3d não pode conter o add-in, por isso o painel vem à parte.
O modelo funciona sem o painel. O painel só torna as experiências mais rápidas.

Se recebeu a pasta num ZIP, extraia-a primeiro.
Não mude o nome da pasta PainelParametros nem dos ficheiros que estão dentro dela.


1. ABRIR O MODELO

  1. Abra o Autodesk Fusion.
  2. Vá a File > Open e escolha "Open from my computer".
  3. Selecione Chassis_Hibrido_Parametrico.f3d.
  4. Espere até o modelo aparecer. O Fusion guarda uma cópia na nuvem, no projeto
     que estiver ativo.


2. ALTERAR PARÂMETROS SEM O PAINEL

  1. No separador Solid, vá a Modify > Change Parameters.
  2. Na coluna Expression, escreva o novo valor e confirme.

  Os parâmetros mais usados estão nos favoritos, no topo da lista.
  Os parâmetros calculados têm uma fórmula na coluna Expression.

  Valores de base:
    comprimento = 1706 mm
    largura     = 1146 mm
    altura      = 460 mm


3. INSTALAR O PAINEL DE SLIDERS

  1. Com o modelo aberto, carregue em Shift+S, ou vá a
     Utilities > Add-Ins > Scripts and Add-Ins.
  2. Se a janela tiver separadores, escolha o separador Add-Ins.
  3. Carregue no + verde, ou em "Script or add-in from device".
  4. Selecione a pasta PainelParametros.
  5. Selecione "PainelParametros" na lista e carregue em Run.

  O painel "Parametros" abre à direita. Se o fechar, volta a abri-lo em
  Utilities > Add-Ins > Painel de parametros.


4. USAR O PAINEL

  Arraste um slider e largue-o. O modelo recalcula, normalmente em cerca de
  0,5 s, e o painel indica se o modelo ficou saudável.

  Cada slider mostra a faixa válida e o valor original.
  Um valor fora da faixa é ajustado ao limite.

  Filtrar e "só ★"  Mostram só os parâmetros que interessam.
  Modo rápido       Desliga temporariamente detalhes pesados.
  Confirmar         Aceita os valores atuais e volta a ligar os detalhes.
  Cancelar          Repõe os valores de quando abriu o painel ou do último
                    Confirmar.
  Medir             Mostra quanto tempo demora cada operação do modelo.

  Os parâmetros calculados não têm slider. Mudam sozinhos.


LIMITES

  As faixas válidas foram testadas com um parâmetro de cada vez, em outubro de
  2026. Alterar muitos parâmetros ao mesmo tempo pode degradar o modelo. Se isso
  acontecer, use Cancelar no painel ou Ctrl+Z.


SE ALGO NÃO FUNCIONAR

  Aparece "Abre um design primeiro":
    Abra o modelo .f3d e volte a carregar em Run.

  O add-in não aparece na lista:
    Confirme que selecionou a pasta PainelParametros e não a pasta que a contém.

  Os sliders não mostram os parâmetros:
    Confirme que o documento ativo é o do chassis.


APOIO DE IA

  O painel de sliders e os testes de robustez foram feitos com o apoio do
  Claude Code (Anthropic).
