# PainelParametros.py
# Add-in para Fusion: palette HTML com um slider por User Parameter mestre.
#  - O slider so envia o valor quando o largas (evento "change"), com debounce no HTML.
#  - Varias alteracoes seguidas vao num unico Design.modifyParameters = um so recalculo.
#  - Os sliders ficam limitados a faixa valida encontrada no teste de robustez (faixas.json).
#  - Modo rapido: suprime as features mais pesadas (config.json) enquanto experimentas;
#    Confirmar volta a ativa-las. Cancelar repoe as expressoes de quando abriste o painel.
#  - "Medir" mede o tempo de calculo de cada item da timeline.
# Os eventos da palette (incomingFromHTML) ja chegam na thread principal do Fusion.

import adsk.core
import adsk.fusion
import traceback
import json
import os
import time

CMD_ID = 'painel_parametros_cmd'
PALETTE_ID = 'painel_parametros_palette'
PASTA = os.path.dirname(os.path.abspath(__file__))
F_FAIXAS = os.path.join(PASTA, 'faixas.json')
F_CONFIG = os.path.join(PASTA, 'config.json')
F_TEMPOS = os.path.join(PASTA, 'tempos.csv')

_app = None
_ui = None
_handlers = []
_snapshot = {}       # expressoes quando o painel abriu (ou no ultimo Confirmar)
_suprimidas = []     # (componente, nome) suprimidas pelo modo rapido


def _design():
    return adsk.fusion.Design.cast(_app.activeProduct)


def _ler(fich, omissao):
    try:
        with open(fich, encoding='utf-8') as f:
            return json.load(f)
    except:
        return omissao


def _fator(design, unidade):
    """Valor interno de 1 unidade (ex.: 1 mm = 0.1 cm)."""
    if not unidade:
        return 1.0
    return design.unitsManager.evaluateExpression('1 %s' % unidade, unidade)


def _itens_timeline(design):
    """Todos os itens da timeline, por ordem, incluindo os que estao dentro de grupos."""
    tl = design.timeline
    for g in range(tl.timelineGroups.count):
        tl.timelineGroups.item(g).isCollapsed = False  # dentro de grupos fechados algumas operacoes falham
    return [tl.item(i) for i in range(tl.count) if not tl.item(i).isGroup]


def _comp(item):
    try:
        return item.entity.parentComponent.name
    except:
        return ''


def _problemas(design):
    """Avisos e erros. Itens 'por calcular' (estado 3, a jusante de features suprimidas no modo
    rapido) nao contam como problema."""
    H = adsk.fusion.FeatureHealthStates
    out = []
    for it in _itens_timeline(design):
        try:
            if it.isSuppressed or it.healthState not in (H.WarningFeatureHealthState, H.ErrorFeatureHealthState):
                continue
            out.append({'item': it.name, 'componente': _comp(it),
                        'estado': 'erro' if it.healthState == H.ErrorFeatureHealthState else 'aviso'})
        except:
            pass
    return out


def _estado():
    design = _design()
    faixas = _ler(F_FAIXAS, {})
    cfg = _ler(F_CONFIG, {})
    params = []
    for p in design.userParameters:
        try:
            if p.dependencyParameters.count > 0:
                continue  # derivados nao tem slider
        except:
            pass
        k = _fator(design, p.unit)
        v = p.value / k
        fx = faixas.get(p.name)
        if fx:
            lo, hi, testado = fx['min'], fx['max'], True
        else:
            lo, hi = sorted([v * 0.5, v * 1.5]) if v else (-1, 1)
            testado = False
        params.append({'nome': p.name, 'unidade': p.unit, 'valor': v, 'min': min(lo, v), 'max': max(hi, v),
                       'testado': testado, 'favorito': p.isFavorite, 'comentario': p.comment,
                       'original': _snapshot.get(p.name, p.expression)})
    return {'params': params, 'modo_rapido': bool(_suprimidas),
            'pesadas': cfg.get('features_pesadas', []), 'problemas': _problemas(design)}


def _aplicar(alteracoes):
    """alteracoes: {nome: valor_em_unidades_do_parametro}. Um unico recalculo."""
    design = _design()
    faixas = _ler(F_FAIXAS, {})
    ps, vs, recusados = [], [], []
    for nome, v in alteracoes.items():
        p = design.userParameters.itemByName(nome)
        if p is None:
            continue
        fx = faixas.get(nome)
        if fx and not (fx['min'] - 1e-9 <= v <= fx['max'] + 1e-9):
            recusados.append(nome)
            continue
        ps.append(p)
        vs.append(adsk.core.ValueInput.createByString(('%.6g %s' % (v, p.unit)).strip()))
    t0 = time.perf_counter()
    if ps:
        try:
            design.modifyParameters(ps, vs)
        except AttributeError:  # versoes antigas do Fusion: um recalculo por parametro
            for p, v in zip(ps, vs):
                p.expression = v.stringValue
    dt = time.perf_counter() - t0
    try:
        with open(F_TEMPOS, 'a', encoding='utf-8') as f:
            f.write('%s;%s;%.3f;%d\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), '+'.join(p.name for p in ps), dt, bool(_suprimidas)))
    except:
        pass
    return {'segundos': round(dt, 3), 'recusados': recusados, 'problemas': _problemas(design)}


def _suprimir(ligar):
    """Modo rapido: suprime/ativa as features pesadas listadas em config.json."""
    global _suprimidas
    design = _design()
    cfg = _ler(F_CONFIG, {})
    alvo = {(f['componente'], f['nome']) for f in cfg.get('features_pesadas', [])}
    t0 = time.perf_counter()
    if ligar:
        for it in _itens_timeline(design):
            chave = (_comp(it), it.name)
            if chave in alvo and not it.isSuppressed:
                it.isSuppressed = True
                _suprimidas.append(chave)
    else:
        # reativa pela ordem inversa
        itens = {(_comp(it), it.name): it for it in _itens_timeline(design)}
        for chave in reversed(_suprimidas):
            it = itens.get(chave)
            if it is not None and it.isSuppressed:
                it.isSuppressed = False
        _suprimidas = []
    return {'segundos': round(time.perf_counter() - t0, 3), 'problemas': _problemas(design)}


def _repor():
    design = _design()
    ps, vs = [], []
    for nome, expr in _snapshot.items():
        p = design.userParameters.itemByName(nome)
        if p is not None and p.expression != expr:
            ps.append(p)
            vs.append(adsk.core.ValueInput.createByString(expr))
    t0 = time.perf_counter()
    if ps:
        design.modifyParameters(ps, vs)
    if _suprimidas:
        _suprimir(False)
    return {'segundos': round(time.perf_counter() - t0, 3), 'repostos': [p.name for p in ps],
            'problemas': _problemas(design)}


def _medir():
    """Tempo de calculo de cada item: volta ao inicio da timeline e avanca item a item."""
    design = _design()
    itens = _itens_timeline(design)
    tl = design.timeline
    tempos = []
    try:
        tl.moveToBeginning()
        for it in itens:
            if it.isSuppressed:
                continue
            t0 = time.perf_counter()
            it.rollTo(False)
            tempos.append({'nome': it.name, 'componente': _comp(it), 'segundos': round(time.perf_counter() - t0, 4)})
    finally:
        tl.moveToEnd()
    total = sum(t['segundos'] for t in tempos)
    tempos.sort(key=lambda t: -t['segundos'])
    for t in tempos:
        t['percent'] = round(100 * t['segundos'] / total, 1) if total else 0
    return {'total': round(total, 3), 'itens': tempos[:15]}


def _tirar_snapshot():
    global _snapshot
    _snapshot = {p.name: p.expression for p in _design().userParameters}


class HTMLHandler(adsk.core.HTMLEventHandler):
    def notify(self, args):
        try:
            dados = json.loads(args.data) if args.data else {}
            acao = args.action
            if acao == 'estado':
                r = _estado()
            elif acao == 'aplicar':
                r = _aplicar(dados.get('alteracoes', {}))
            elif acao == 'modo_rapido':
                r = _suprimir(bool(dados.get('ligar')))
            elif acao == 'confirmar':
                r = _suprimir(False) if _suprimidas else {'problemas': _problemas(_design())}
                _tirar_snapshot()
            elif acao == 'cancelar':
                r = _repor()
            elif acao == 'medir':
                r = _medir()
            else:
                return
            args.returnData = json.dumps({'ok': True, 'r': r})
        except Exception:
            args.returnData = json.dumps({'ok': False, 'erro': traceback.format_exc()})


class FechadoHandler(adsk.core.UserInterfaceGeneralEventHandler):
    def notify(self, args):
        try:
            if _suprimidas:  # nunca deixar features suprimidas por esquecimento
                _suprimir(False)
        except:
            pass


def _mostrar():
    pal = _ui.palettes.itemById(PALETTE_ID)
    if pal is None:
        url = 'file:///' + os.path.join(PASTA, 'painel.html').replace('\\', '/')
        pal = _ui.palettes.add(PALETTE_ID, 'Parametros', url, True, True, True, 380, 700, True)
        pal.dockingState = adsk.core.PaletteDockingStates.PaletteDockStateRight
        h = HTMLHandler()
        pal.incomingFromHTML.add(h)
        _handlers.append(h)
        hc = FechadoHandler()
        pal.closed.add(hc)
        _handlers.append(hc)
    _tirar_snapshot()
    pal.isVisible = True


class ExecutarHandler(adsk.core.CommandEventHandler):
    def notify(self, args):
        try:
            if _design() is None:
                _ui.messageBox('Abre um design primeiro.')
                return
            _mostrar()
        except:
            _ui.messageBox(traceback.format_exc())


class CriadoHandler(adsk.core.CommandCreatedEventHandler):
    def notify(self, args):
        h = ExecutarHandler()
        args.command.execute.add(h)
        _handlers.append(h)


def run(context):
    global _app, _ui
    try:
        _app = adsk.core.Application.get()
        _ui = _app.userInterface
        cmd = _ui.commandDefinitions.itemById(CMD_ID)
        if cmd:
            cmd.deleteMe()
        cmd = _ui.commandDefinitions.addButtonDefinition(CMD_ID, 'Painel de parametros',
                                                         'Sliders rapidos para os User Parameters')
        h = CriadoHandler()
        cmd.commandCreated.add(h)
        _handlers.append(h)
        painel = _ui.allToolbarPanels.itemById('SolidScriptsAddinsPanel')
        if painel and not painel.controls.itemById(CMD_ID):
            painel.controls.addCommand(cmd)
        if _design():
            _mostrar()
    except:
        if _ui:
            _ui.messageBox(traceback.format_exc())


def stop(context):
    try:
        if _suprimidas:
            _suprimir(False)
        pal = _ui.palettes.itemById(PALETTE_ID)
        if pal:
            pal.deleteMe()
        painel = _ui.allToolbarPanels.itemById('SolidScriptsAddinsPanel')
        if painel and painel.controls.itemById(CMD_ID):
            painel.controls.itemById(CMD_ID).deleteMe()
        cmd = _ui.commandDefinitions.itemById(CMD_ID)
        if cmd:
            cmd.deleteMe()
    except:
        if _ui:
            _ui.messageBox(traceback.format_exc())
