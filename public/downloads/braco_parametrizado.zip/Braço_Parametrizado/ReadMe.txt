As diferentes configurações do braço podem ser selecionadas no menu "tabelas de configuração".

Os fatores de escala associados às diferentes variáveis podem ser observados no menu "Parâmetros". 

As variáveis de controlo são "user parameters" no entanto as relações e a forma como afetam cada dimensão de cada esboço e operação estão na expressão nos parâmetros do modelo, dentro de cada componente. Com exceção dos componentes 4 e 5, que convergiram no componente 3.