# Verificação 3D com o Intact.Simulation (Grasshopper, Rhino 8)

O nível 2 do filtro: as finalistas da análise 2D vão ao Intact. Se a finalista A falhar,
experimenta-se a seguinte mais leve que passa no 2D (no explorador ou em `diag\populacoes\<planeta>.csv`).

## 1. Preparar (uma vez)
1. Instalar o Intact.Simulation for Rhino Grasshopper e ativar a licença (trial ou académica).
2. Rhino em milímetros. Não é preciso importar o STEP: a peça é gerada pelo componente.

## 2. Montar a definição no Grasshopper
1. Criar um componente **Python 3 Script** e colar o conteúdo de `gh_intact.py`.
2. Entradas (botão direito → "+", nomes exatos): `planeta` (Panel com texto), `variante`
   (Panel: "A", "B" ou um código), `caso` (Number Slider inteiro, 0 a 8).
3. Saídas: `peca`, `face_fixa`, `face_carga`, `F_dir`, `F_N`, `M_eixo`, `M_Nmm`,
   `E_MPa`, `nu`, `rho_tmm3`, `sy_MPa`, `perigo_max`, `casos`, `info`.
4. Blocos do Intact e ligações:

| Bloco do Intact | Entrada | Liga a |
|---|---|---|
| Custom Ductile Material | densidade, E, Poisson, cedência | `rho_tmm3`, `E_MPa`, `nu`, `sy_MPa` |
| Component | Geometry / Materials | `peca` / material acima |
| FixedRestraint | Geometry | `face_fixa` |
| Vector Force | Geometry / direção / magnitude | `face_carga` / `F_dir` / `F_N` |
| Torque | Geometry / eixo / valor | `face_carga` / `M_eixo` / `M_Nmm` |
| Solver Settings | nº de elementos | começar com o valor por defeito e subir até o resultado estabilizar |
| Stress Solver | C / R / L / SS | Component / FixedRestraint / (Vector Force + Torque, com Shift) / Solver Settings |
| Visualize | simulação | saída `Ss` do Stress Solver; escolher **Danger Level** |

5. Ligar `info` a um Panel: mostra o caso, a força, o momento e o critério.

## 3. Correr e decidir
1. Carregar em **solve** no Stress Solver (ou pôr `SM = True` para correr sozinho).
2. Ver o **Danger Level** máximo (0 a 1). A variante **passa** se o máximo, longe das faces
   de ligação, ficar **abaixo de `perigo_max`** (= 1 / FS exigido, por ex. 0,5 em Marte).
   Os picos colados às faces de ligação são artificiais (encastramento perfeito / carga rígida).
3. FS 3D = 1 / Danger Level máximo. Anotar por caso.
4. Repetir para todos os casos (`caso` = 0, 1, 2…). O pior caso decide.
5. Confirmar a convergência: subir o nº de elementos ~2× e ver se o máximo muda menos de 5–10 %.

## 4. Notas
- **Unidades:** o Rhino está em mm, por isso o Intact tem de usar o sistema **MMS** (mm, t, s:
  força em N, tensão em MPa, densidade em t/mm³, momento em N·mm). Em cada bloco do Intact:
  botão direito → unidades → MMS. O componente já entrega tudo nestas unidades.
- **Material:** a cedência já vem reduzida pela temperatura do planeta (ex.: Ti-6Al-4V
  em Vénus a 465 °C), por isso o Danger Level já é o do planeta.
- **Caso 'embate':** a força é aplicada em toda a face exterior mais próxima do impacto,
  o que é uma aproximação (menos concentrada do que a realidade).
- **O que esperar:** a análise 2D com a correção de Bleich deve ser conservadora para o
  tubo fechado e para as nervuras; para a treliça é conservadora porque ignora a ajuda das
  diagonais na torção. Se o Intact der FS muito acima do 2D, há margem para escolher
  variantes mais leves; se der abaixo, passa-se à seguinte da lista.

## 5. Modo automático (gh_maestro.py): um planeta inteiro sozinho
1. Mantém a definição acima a funcionar (gh_intact + blocos do Intact + Visualize em Danger Level).
2. Novo componente **Python 3 Script** com o conteúdo de `gh_maestro.py`.
   Entradas: `correr` (Boolean Toggle), `planeta` (Panel, ex. Lua), `N` (Panel ou slider, 10),
   `v` (saída V do Visualize; botão direito em v → **List Access**), `montar` (Boolean Toggle True).
   Saídas: `estado`, `resultados` (cada uma num Panel).
3. Põe `correr` = True. O maestro escolhe as N variantes mais leves que passam no 2D e corre
   todos os casos de cada uma (o gh_intact passa a dizer "[AUTOMÁTICO]" no Panel `info`).
4. Critério: passa em 3D se, em todos os casos, o percentil 99,9 % do Danger Level < 1 / FS exigido
   (o máximo absoluto é um pico artificial nas ligações; fica no CSV para o relatório).
5. No fim: `diag\intact\<planeta>_casos.csv`, `_resumo.csv`, `_top3.csv` e, com `montar` = True,
   as 3 melhores montadas em cópias da suspensão (camada Montagem) e exportadas em STEP
   (`diag\intact\<planeta>_<id>_suspensao.stp`). Se a montagem falhar a partir do Grasshopper,
   corre `rhino_montar_top3.py` no Editor de Scripts.
6. Se o Visualize voltar a ficar vermelho a meio, escolhe outra vez Danger Level: o maestro continua.
7. Para outro planeta: muda o Panel `planeta`, põe `correr` em False e outra vez em True.
