# Hipóteses do projeto e a sua justificação

Para o relatório da M1. Cada valor está marcado como:
- **Dado:** valor publicado, com a fonte indicada.
- **Hipótese:** escolha de projeto justificada, mas que deve ser assumida como hipótese no relatório.
- **A confirmar:** valor típico de literatura, a confirmar numa ficha técnica.

## 1. Planetas (planetas.py)

| Grandeza | Valor usado | Estado | Justificação / fonte |
|---|---|---|---|
| Gravidade: Mercúrio 3,70; Vénus 8,87; Lua 1,62; Marte 3,71 m/s² | igual | Dado | NASA Planetary Fact Sheet (3,7 / 8,9 / 1,6 / 3,7 m/s²) |
| Gravidade: Titã 1,35; Europa 1,31; Io 1,80 m/s² | igual | Dado | valores padrão das luas (fichas NASA) |
| Vénus: 465 °C, 92 bar | 440–465 °C | Dado | NASA Fact Sheet: 464 °C, 92 bar |
| Mercúrio: +430 °C de dia, −180 °C de noite | −180 / 430 °C | Dado | NASA, litografia de Mercúrio |
| Europa: nunca acima de −160 °C | −190 / −150 °C | Dado | ALMA, mapa térmico de Europa (phys.org, 2018) |
| Titã: 94 K (−179 °C), ~1,5 atm | −180 / −178 °C | Dado | Ohio State, "Giant Moons" (94 K, ~1,6 atm) |
| Lua: −173 / +127 °C | igual | Dado | valores típicos dia/noite lunares |
| Massa do rover igual em todos (1025 kg, Perseverance) | 1025 kg | Hipótese | isola o efeito do planeta |
| Fator de queda 1 + h/d (h altura do buraco, d curso de paragem) | 3,5 a 11 | Hipótese | energia mgh absorvida em d. Terreno mole (Titã) → d grande; gelo duro (Europa) → d pequeno |
| Rocha sob a aresta da roda | 2,0 a 4,0 × W | Hipótese | terreno rochoso → carga concentrada; seixos arredondados em Titã (Huygens) → menor |
| Atrito lateral μ | 0,4 a 0,6 | Hipótese apoiada | regolito e rocha ~0,6. **Europa corrigido de 0,15 para 0,5:** o gelo a ~−100 °C tem μ ≈ 0,5 (atrito seco) e só é escorregadio perto de −7 °C (μ ≈ 0,01) (Weber et al., AMOLF) |
| Aterragem: F = m (g + v²/2d), d = 0,10 m | — | Hipótese | curso que absorve o toque (roda + suspensão) |
| Velocidade de toque, Marte | 0,75 m/s | Dado | Perseverance: velocidade final de descida de ~2,7 km/h (NASA Photojournal PIA24319) |
| Velocidade de toque, outros | 1,0 a 2,0 m/s | Hipótese | retrofoguetes; abaixo do limite de projeto do Apollo LM (3,05 m/s na vertical, NASA TN D-6850) |
| FS exigido por planeta (à cedência) | 2,0 a 2,5 | Hipótese | a NASA-STD-5001 pede ~1,25 à cedência para estruturas metálicas só analisadas (sem ensaio). Usa-se mais porque o modelo 2D é simplificado e o terreno incerto: 2,0 onde é bem conhecido (Lua, Marte), 2,5 onde é pouco conhecido (Europa, Io, Vénus) |
| Cargas de lançamento | não consideradas | Hipótese | a suspensão viaja travada (launch locks), como no Perseverance |
| Fadiga | não considerada nos planetas | Limitação | só nos cenários antigos A–D em Marte |

## 2. Materiais (gerador_variantes.py, planetas.py)

| Material | À temperatura ambiente | Correção a quente | Estado |
|---|---|---|---|
| Al 7075-T6 | ρ 2810, E 71,7 GPa, σy 503 MPa | 0,90 a 100 °C; 0,70 a 150 °C; não serve acima de 175 °C | A confirmar (MMPDS): o 7075 perde resistência com o tempo de exposição acima de ~120 °C |
| Ti-6Al-4V (CNC) | ρ 4430, E 113,8 GPa, σy 880 MPa | 0,83 a 200 °C; 0,68 a 400 °C; 0,62 a 500 °C | Dado apoiado: Ti-6Al-4V (DLD) 1000 → 845 (200 °C) → 705 (400 °C) → 600 MPa (500 °C), ou seja 0,85 / 0,70 / 0,60 (PMC8585263) |
| Ti-6Al-4V (L-PBF + HIP) | σy 850 MPa | igual ao CNC | A confirmar |
| AlSi10Mg (L-PBF) | σy 200 MPa | excluído abaixo de −150 °C (alongamento baixo → frágil) | Hipótese |
| Inconel 718 | ρ 8190, E 200 GPa, σy 1030 MPa | 0,92 a 400 °C; 0,90 a 500 °C | A confirmar |

## 3. Modelo de cálculo (filtro 2D)

| Ponto | Escolha | Estado |
|---|---|---|
| Peça tratada como viga curva (eixo médio, Winkler-Bach nas curvas) | — | Clássico (Roark) |
| **Correção de Bleich** nos banzos finos de vigas curvas (tubo fechado, secção em I) | fatores α e γ deduzidos numericamente (faixa de placa sobre fundação elástica) | γ coincide com os valores tabelados de Bleich/Roark. Acrescentada a 28/10 porque a teoria simples era otimista no canto interior das curvas |
| Encurvadura local das paredes do tubo | placa simplesmente apoiada, k = 4 | Clássico |
| Torção: tubo fechado (Bredt), secções abertas (soma de retângulos, Roark) | — | Clássico |
| Diagonais da treliça: tração/compressão + Euler (encastramento ignorado) | — | Conservador |
| Verificação final | Intact.Simulation (elementos finitos 3D) nas finalistas | Pendente (licença) |

## 4. Degradação por planeta (01/11) — `degradacao.py`

Regra geral: os **genes descrevem a secção estrutural**; o planeta acrescenta uma **pele sacrificial** δ em cada face exposta (tubo: só a pele exterior; treliça e nervuras: todas as faces). O FS 2D é calculado com a **peça gasta (fim de vida)** e a massa conta a **peça nova**. A resistência do material é multiplicada por k (soma-se à perda a quente). O 3D (Intact) usa o material com k; a geometria 3D é a nova (o desgaste não é modelado em 3D, ligeiramente otimista).

| Planeta | Condição | δ [mm/face] | k | Regra extra | Estado |
|---|---|---|---|---|---|
| Lua | regolito abrasivo (grãos vítreos aguçados), ΔT 300 °C | 0,50 | 0,95 | — | Hipótese apoiada (desgaste por pó lunar: NASA) |
| Mercúrio | regolito + ciclo térmico −180/+430 °C | 0,50 | 0,85 | r_cantos ≥ 0,30; curvas do C ≥ 40 mm | Hipótese (fadiga térmica) |
| Marte | poeira fina (abrasão eólica lenta), rochas aguçadas | 0,25 | 1,00 | parede do tubo ≥ 4 mm (perfuração) | Hipótese apoiada (rodas do Curiosity furadas por rochas) |
| Vénus | ácido sulfúrico / enxofre a 465 °C, 92 bar, fluência | 1,00 | 0,85 | — | Hipótese apoiada (ensaios GEER, NASA Glenn) |
| Europa | gelo duro a −160 °C, radiação de Júpiter | 0,30 | 0,90 | curvas do C ≥ 30 mm | Hipótese |
| Io | geada de enxofre/SO2, partículas vulcânicas, radiação | 0,50 | 0,90 | curvas do C ≥ 30 mm | Hipótese |
| Titã | metano/azoto inertes, areia orgânica mole | 0,10 | 1,00 | — | Referência benigna |

Mercúrio passa a ser gerado com 400 variantes (com 150 só 1 passava: o ciclo térmico deixa muito poucas soluções).

## Fontes
- NASA Planetary Fact Sheet — https://nssdc.gsfc.nasa.gov/planetary/factsheet/index.html
- NASA, Mercury lithograph — https://www.nasa.gov/wp-content/uploads/2009/12/mercury_lithograph.pdf
- ALMA, temperatura de Europa — https://phys.org/news/2018-10-alma-europa-temperature.html
- Ohio State, Giant Moons — https://www.astronomy.ohio-state.edu/gaudi.1/Ast2291/Docs/GiantMoons.pdf
- NASA Photojournal PIA24319 (Perseverance) — https://science.nasa.gov/photojournal/perseverance-touches-down-on-mars-illustration/
- NASA TN D-6850, Apollo LM landing gear — https://www.nasa.gov/wp-content/uploads/static/history/alsj/tnD6850LMLandingGearSubsytem.pdf
- Weber et al., Molecular insight into the slipperiness of ice (AMOLF) — https://ir.amolf.nl/pub/10003/16396OA.pdf
- Ti-6Al-4V a alta temperatura — https://pmc.ncbi.nlm.nih.gov/articles/PMC8585263
- Fatores de segurança NASA-STD-5001 (tabela resumo) — https://uasal.github.io/spacehardwarehandbook-public/attachments/SO_FOS_Table-V1_0.pdf
- NASA, desgaste por pó lunar (STRIVES, IAC 2023) — https://ntrs.nasa.gov/api/citations/20230014154/downloads/IAC%202023_WearResistant_STRIVES-3.pdf
- Rodas do Curiosity danificadas por rochas — https://spectrum.ieee.org/if-necessary-mars-rover-curiosity-could-rip-its-own-wheels-off-to-stay-mobile
- Mercury Lander, estudo para o Decadal Survey — https://arxiv.org/pdf/2107.06795
- NASA GEER, ensaios de materiais em condições de Vénus — https://ntrs.nasa.gov/api/citations/20240000270/downloads/GEER_LPSC_2024_pdf.pdf
- Europa Lander, ambiente de radiação — https://ntrs.nasa.gov/citations/20190027381
