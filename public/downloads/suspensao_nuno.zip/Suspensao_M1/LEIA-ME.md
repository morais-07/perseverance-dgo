# Entrega M1 · Nuno Mourinha (119610) · Suspensão e rodas

DGO 2026/27 · Perseverance Rover · Tema do M1: **um rover para cada planeta**.

A massa do rover fica fixa (1025 kg). Para 7 destinos (Lua, Mercúrio, Marte, Vénus, Europa, Titã e Io), as cargas, o material, a família de forma e a degradação térmica mudam, e com elas a forma da suspensão. As peças geradas são o joelho traseiro, o joelho do meio, as 4 barras e a roda. Fluxo: STEP → sketch paramétrico → populações (LHS) → filtro 2D → 3D no Rhino/Grasshopper + Intact → montagem final.

## Resultado principal: suspensão completa (2 lados)

| Planeta | Massa (kg) | vs original (352,2 kg) |
|---|---|---|
| Titã | 171,2 | −51 % |
| Lua | 188,5 | −46 % |
| Europa | 202,9 | −42 % |
| Io | 220,4 | −37 % |
| Marte | 222,7 | −37 % |
| Mercúrio | 330,5 | −6 % |
| Vénus | 474,9 | +35 % |

- FS mínimo das peças usadas: 2,18 (critério FS ≥ 2,0).
- Critério 3D: percentil 99,9 do *Danger Level* < 1/FS.
- Em Marte e em Mercúrio a barra esquerda é a original, porque nenhuma variante passou no 3D.

## Conteúdo da pasta

| Pasta | O que tem |
|---|---|
| `01_apresentacao` | Slides do M1 (`.pptx` e `.pdf`) |
| `02_geometria_original` | `suspensao_v1.step`: assembly de um lado, exportado do Fusion, de onde sai toda a geometria. `suspensao_total_original.step`: montagem da suspensão completa original |
| `03_codigo/joelho_traseiro` | Pipeline do joelho traseiro, a primeira peça e o modelo para as outras (ordem de execução no `LEIA-ME.md` da pasta) |
| `03_codigo/pecas/nucleo` | Partilhado por todas as peças: planetas, cargas, materiais e degradação |
| `03_codigo/pecas/joelho_meio`, `barras`, `rodas` | Gerador (populações + filtro 2D), peça 3D e construção no Rhino de cada peça |
| `03_codigo/pecas/grasshopper` | Maestro do Grasshopper, ligação ao Intact, registo das peças, seletor e montagem final |
| `04_rhino_grasshopper` | `pecas.gh` (ciclo de todas as peças) e `joelho_traseiro.gh` |
| `05_modelos_finais/um_lado_suspensao` | Um lado da suspensão por planeta (`<planeta>_suspensao_1.stp`) |
| `05_modelos_finais/suspensao_completa_7_planetas.zip` | Suspensão completa (2 lados) por planeta, em STEP |
| `06_resultados` | `resumo_suspensoes.csv` (todas as peças, planetas e massas; a versão usada é a suspensão 1), as tabelas por planeta e as figuras da apresentação |
| `ONDE_TROCAR_CAMINHOS.md` | Lista dos caminhos absolutos a trocar (scripts e `.gh`), linha a linha |
| `07_documentacao` | `HIPOTESES.md` (hipóteses de planetas, materiais e modelo, com fontes) e `GUIA_INTACT.md` |

## Notas

- O código é uma cópia do usado no projeto. Alguns scripts e os 2 ficheiros `.gh` têm caminhos absolutos para `C:\Mestrado\designD\m1\`. **Onde e como os trocar para correr noutro computador está em `ONDE_TROCAR_CAMINHOS.md`.**
- Software: Python 3 (numpy, scipy, matplotlib), Rhino 8 + Grasshopper (Python 3) e Intact.Simulation for Grasshopper.
- Limitações: a fadiga mecânica não foi considerada (só a degradação térmica), não houve verificação de interferências na montagem, e as falhas de simulação do Intact contam como chumbo.
- Utilização de IA: o Claude (Anthropic) foi usado como copiloto na escrita dos scripts Python e na preparação dos slides. A definição do problema, as escolhas de planetas, critérios e materiais, a modelação, as simulações e a validação são do autor.
