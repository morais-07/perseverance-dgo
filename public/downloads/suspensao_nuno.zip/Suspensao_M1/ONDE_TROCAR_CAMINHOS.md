# Onde trocar os caminhos (referências a pastas)

Os scripts desta entrega são cópias dos usados no projeto. Alguns têm **caminhos absolutos** para a pasta onde o trabalho foi feito:

```
C:\Mestrado\designD\m1\
```

Para correr noutro computador, basta trocar esse início de caminho pela pasta onde a entrega foi descompactada, nos sítios indicados abaixo. Só é preciso mudar o texto entre aspas `r"..."`. O resto do código não muda.

## 1. Correspondência entre as pastas

Na entrega, duas pastas têm nomes diferentes dos do projeto original:

| No código (projeto original) | Nesta entrega |
|---|---|
| `C:\Mestrado\designD\m1\joelho_traseiro_STEP` | `03_codigo\joelho_traseiro` |
| `C:\Mestrado\designD\m1\pecas\gh` | `03_codigo\pecas\grasshopper` |
| `C:\Mestrado\designD\m1\pecas\nucleo`, `...\barras`, `...\rodas`, `...\joelho_meio` | `03_codigo\pecas\nucleo`, `...\barras`, `...\rodas`, `...\joelho_meio` |
| `C:\Mestrado\designD\m1\joelho_traseiro_STEP\step\suspensao_v1.step` | `02_geometria_original\suspensao_v1.step` |

**Exemplo:** se a entrega estiver em `D:\Aulas\ENTREGA_M1_Nuno\`, então

`PASTA = r"C:\Mestrado\designD\m1\joelho_traseiro_STEP"`

passa a

`PASTA = r"D:\Aulas\ENTREGA_M1_Nuno\03_codigo\joelho_traseiro"`.

> **Alternativa mais simples:** pôr as pastas exatamente com os nomes e no sítio do projeto original (`C:\Mestrado\designD\m1\joelho_traseiro_STEP\` e `C:\Mestrado\designD\m1\pecas\gh\`, etc.). Assim não é preciso trocar nada.

## 2. Scripts Python (abrir com um editor de texto e mudar a linha indicada)

| Ficheiro (em `03_codigo\`) | Linha | Variável |
|---|---|---|
| `joelho_traseiro\gh_intact.py` | 41 | `PASTA` → pasta `joelho_traseiro` |
| `joelho_traseiro\gh_joelho.py` | 33 | `PASTA` → pasta `joelho_traseiro` |
| `joelho_traseiro\gh_maestro.py` | 39 | `PASTA` → pasta `joelho_traseiro` |
| `pecas\barras\rhino_barra.py` | 21–23 | `AQUI` → `pecas\barras` · `NUCLEO` → `pecas\nucleo` · `STEP` → `suspensao_v1.step` |
| `pecas\rodas\rhino_roda.py` | 21–23 | `AQUI` → `pecas\rodas` · `NUCLEO` → `pecas\nucleo` · `STEP` → `suspensao_v1.step` |
| `pecas\joelho_meio\rhino_meio.py` | 27–29 | `AQUI` → `pecas\joelho_meio` · `NUCLEO` → `pecas\nucleo` · `STEP` → `suspensao_v1.step` |
| `pecas\grasshopper\gh_intact_peca.py` | 26 | `GH_PASTA` → pasta `pecas\grasshopper` |
| `pecas\grasshopper\gh_maestro_peca.py` | 34 | `GH_PASTA` → pasta `pecas\grasshopper` |
| `pecas\grasshopper\pecas_registo.py` | 20 | `BASE` → pasta `pecas` |
| `pecas\grasshopper\pecas_registo.py` | 50 | `SAIDA_TRASEIRO` → `joelho_traseiro\diag\intact` |
| `pecas\grasshopper\montagem_final.py` | 33 | `GH` → pasta `pecas\grasshopper` (só usado se o script não souber a própria pasta) |
| `pecas\grasshopper\montagem_final.py` | 40 | `TRASEIRO` → pasta `joelho_traseiro` |
| `pecas\grasshopper\seletor_suspensao.py` | 12 e 42 | Caminho do próprio script e `BASE` → pasta `pecas` |

Os outros scripts (leitura do STEP, sketch, análise, geradores de populações, núcleo) usam **caminhos relativos**. Basta corrê-los a partir da pasta onde estão, por exemplo:

```
cd 03_codigo\joelho_traseiro
python leitor_step.py ..\..\02_geometria_original\suspensao_v1.step
```

A ordem de execução de cada peça está no `LEIA-ME.md` da pasta respetiva.

## 3. Ficheiros do Grasshopper (`04_rhino_grasshopper\`)

Cada `.gh` tem dois componentes Python (**Py3**). Cada um só carrega um script do disco. Para trocar o caminho:

1. Abrir o `.gh` no Grasshopper.
2. Fazer duplo clique no componente **Py3**.
3. Mudar a linha `p = r"..."`.
4. Fechar o editor e gravar o `.gh`.

| Ficheiro | Componente | Linha atual |
|---|---|---|
| `pecas.gh` | Intact (componente grande com as saídas `peca`, `face_fixa`, …) | `p = r"C:\Mestrado\designD\m1\pecas\gh\gh_intact_peca.py"` |
| `pecas.gh` | Maestro (entradas `correr`, `planeta`, `N`, …) | `p = r"C:\Mestrado\designD\m1\pecas\gh\gh_maestro_peca.py"` |
| `joelho_traseiro.gh` | Intact | `p = r"C:\Mestrado\designD\m1\joelho_traseiro_STEP\gh_intact.py"` |
| `joelho_traseiro.gh` | Maestro | `p = r"C:\Mestrado\designD\m1\joelho_traseiro_STEP\gh_maestro.py"` |

**Exemplo** (entrega em `D:\Aulas\ENTREGA_M1_Nuno\`):

`p = r"D:\Aulas\ENTREGA_M1_Nuno\03_codigo\pecas\grasshopper\gh_intact_peca.py"`

## 4. Notas

- As pastas `diag\` (resultados intermédios: populações, filtro 2D, resultados do Intact) são criadas pelos próprios scripts quando estes correm. Não vêm nesta entrega.
- Os resultados finais estão em `05_modelos_finais` e `06_resultados`.
- Software: Python 3.10+ (numpy, scipy, matplotlib), Rhino 8 + Grasshopper e Intact.Simulation for Grasshopper.
