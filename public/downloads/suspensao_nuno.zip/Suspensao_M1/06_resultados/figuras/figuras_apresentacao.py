# -*- coding: utf-8 -*-
"""Figuras da apresentação M1 (joelho do meio). Corre em m1\pecas\joelho_meio\:  python figuras_apresentacao.py
Saída: diag\figuras\F3_esforcos.png, F3_winkler.png, F4_genes.png, F4_planetas.png, F5_dispersao.png, F6_danger.png"""
import os, sys, csv, json, ast
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import gerador_meio as gm

OUT = os.path.join(AQUI, 'diag', 'figuras'); os.makedirs(OUT, exist_ok=True)
plt.rcParams.update({'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.titleweight': 'bold', 'figure.dpi': 100, 'savefig.dpi': 200})
VERDE, VERDE_E = '#7bc96f', '#2e7d32'
AZUL, AZUL_E = '#3b7dd8', '#123a6b'
CINZA, VERM, LAR = '#b8b8b8', '#d62728', '#ff7f0e'
PLANETAS = ['Lua', 'Mercúrio', 'Marte', 'Europa', 'Titã', 'Io', 'Vénus']
COR_PL = {'Lua': '#8c8c8c', 'Mercúrio': '#b07d48', 'Marte': '#c1440e', 'Europa': '#4a90c2',
          'Titã': '#d4a017', 'Io': '#9bb31d', 'Vénus': '#8e44ad'}
NOME_FAM = {'fechada': 'tubo oco', 'trelica': 'treliça', 'isogrid': 'nervuras'}
G = json.load(open(os.path.join(AQUI, 'dados', 'geometria_meio.json'), encoding='utf-8'))
C10 = json.load(open(os.path.join(AQUI, 'diag', 'contornos_top10.json'), encoding='utf-8'))


def ler(p):
    with open(p, encoding='utf-8-sig') as f:
        return list(csv.DictReader(f, delimiter=';'))


def num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return np.nan


POP = {pl: ler(os.path.join(AQUI, 'diag', 'populacoes', pl + '.csv')) for pl in PLANETAS}
RES3D = {pl: ler(os.path.join(AQUI, 'diag', 'intact', pl + '_resumo.csv')) for pl in PLANETAS}
# melhor 3D = mais leve (massa_3d) que passa
MELHOR = {}
for pl in PLANETAS:
    ok = [r for r in RES3D[pl] if r['passa_3d'] == 'True']
    MELHOR[pl] = min(ok, key=lambda r: num(r['massa_3d']))


def verdes(ax, alpha=1.0):
    for k in ('verde_cubo', 'verde_bossa'):
        ax.add_patch(Polygon(np.array(G[k]), closed=True, fc=VERDE, ec=VERDE_E, lw=1.2, alpha=alpha, zorder=1))


def braco(ax, c, fc=AZUL, ec=AZUL_E):
    a = np.array(ast.literal_eval(c['bordo_cima']) if isinstance(c['bordo_cima'], str) else c['bordo_cima'])
    b = np.array(ast.literal_eval(c['bordo_baixo']) if isinstance(c['bordo_baixo'], str) else c['bordo_baixo'])
    ax.add_patch(Polygon(np.r_[a, b[::-1]], closed=True, fc=fc, ec=ec, lw=1.2, alpha=0.9, zorder=2))
    e = np.array(ast.literal_eval(c['eixo']) if isinstance(c['eixo'], str) else c['eixo'])
    ax.plot(e[:, 0], e[:, 1], '--', c='white', lw=0.9, zorder=3)


def original(ax):
    o = np.array(G['braco_original'])
    ax.plot(np.r_[o[:, 0], o[0, 0]], np.r_[o[:, 1], o[0, 1]], '--', c='#555', lw=1, zorder=4)


def enquadrar(ax):
    ax.set_xlim(-305, 95); ax.set_ylim(-100, 220); ax.set_aspect('equal')
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_visible(False)


def genes(pid, pl):
    r = [x for x in POP[pl] if x['id'] == pid][0]
    return {k: float(r[k]) for k in ('largura', 'prof', 'conicidade', 'ang', 'curva') if r.get(k)}, r


# ---------------------------------------------------------------- F3 esforços N, V, M
def f3():
    g, r = genes('MAR-057', 'Marte')
    e = gm.eixo(g); nomes, R = gm.esforcos(e, 'Marte')
    i = nomes.index('queda_lat+@meio')
    s = e['s']; pr = e['projeto']
    fig, axs = plt.subplots(1, 2, figsize=(14, 5.2), gridspec_kw={'width_ratios': [1, 1.25]})
    ax = axs[0]
    verdes(ax); braco(ax, C10['MAR-057'])
    X = e['X']
    for k in range(0, len(X), 10):
        ax.plot(*X[k], 'o', c='k', ms=3, zorder=5)
        ax.annotate(f's={s[k]:.0f}', X[k], xytext=(6, -10), textcoords='offset points', fontsize=8)
    ax.annotate('pino da barra do meio\n(carga entra aqui)', G['raiz_2D'], xytext=(-300, 205), fontsize=9,
                arrowprops=dict(arrowstyle='->', lw=0.8))
    ax.text(-60, -80, 'cubo da roda (encastramento)', fontsize=9, ha='left')
    enquadrar(ax); ax.set_title('Viga curva em consola: eixo médio s (MAR-057)')
    ax = axs[1]
    ax.axvspan(s[pr].min(), s[pr].max(), color=AZUL, alpha=0.08, lw=0)
    ax.text(s[pr].mean(), 0.97, 'zona de projeto', transform=ax.get_xaxis_transform(), ha='center', va='top',
            fontsize=9, color=AZUL_E)
    ax.plot(s, R['M'][i] / 1e3, c=VERM, lw=2.2, label='M  momento fletor [N·m]')
    ax.plot(s, R['N'][i], c=AZUL, lw=2, label='N  esforço normal [N]')
    ax.plot(s, R['V'][i], c=LAR, lw=2, label='V  esforço transverso [N]')
    k = int(np.argmin(np.abs(s - float(r['s_critico_mm']))))
    ax.axvline(s[k], c='k', ls=':', lw=1)
    ax.annotate('estação crítica\nFS = %.2f' % float(r['FS_min']), (s[k], R['M'][i][k] / 1e3), xytext=(25, 40),
                textcoords='offset points', fontsize=9, arrowprops=dict(arrowstyle='->', lw=0.8))
    ax.axhline(0, c='#999', lw=0.6)
    ax.set_xlabel('s ao longo do eixo médio [mm]'); ax.set_title('Esforços internos — caso queda_lat+@meio (Marte)')
    ax.legend(frameon=False, loc='upper left', bbox_to_anchor=(0.0, 0.8), fontsize=9)
    fig.tight_layout(); fig.savefig(os.path.join(OUT, 'F3_esforcos.png')); plt.close(fig)


# ---------------------------------------------------------------- F3 Winkler-Bach
def f3w():
    g, r = genes('MAR-057', 'Marte')
    e = gm.eixo(g)
    kap = np.abs(e['kap'][e['projeto']]).max()
    rho = 1 / kap; t = g['largura']
    ri, ro = rho - t / 2, rho + t / 2
    rn = t / np.log(ro / ri); ecc = rho - rn
    rr = np.linspace(ri, ro, 200); y = rr - rho
    M = 1.0; A = t; I = t ** 3 / 12
    s_lin = -M * y / I * 1e3
    s_wb = -M * (rr - rn) / (A * ecc * rr) * 1e3
    fig, axs = plt.subplots(1, 2, figsize=(13, 4.8), gridspec_kw={'width_ratios': [1, 1.3]})
    ax = axs[0]
    th = np.linspace(np.radians(200), np.radians(250), 60)
    for R_, st in ((ri, '-'), (ro, '-'), (rho, '--'), (rn, ':')):
        ax.plot(R_ * np.cos(th), R_ * np.sin(th), st, c={ri: VERM, ro: AZUL_E, rho: '#444', rn: LAR}[R_], lw=2 if st == '-' else 1.4)
    ax.fill(np.r_[ri*np.cos(th), ro*np.cos(th[::-1])], np.r_[ri*np.sin(th), ro*np.sin(th[::-1])], fc=AZUL, alpha=0.15, lw=0)
    ax.plot(0, 0, 'k+', ms=10); ax.text(2, 2, 'centro de curvatura', fontsize=8)
    ax.text(rn*np.cos(th[5]), rn*np.sin(th[5]), ' eixo neutro', color=LAR, fontsize=8)
    ax.plot([0, rho * np.cos(th[30])], [0, rho * np.sin(th[30])], c='#999', lw=0.8)
    ax.text(rho * np.cos(th[30]) / 2 + 3, rho * np.sin(th[30]) / 2, 'ρ = %.0f mm' % rho, fontsize=10)
    ax.text(ri * np.cos(th[-1]) + 2, ri * np.sin(th[-1]) - 2, 'fibra interior', color=VERM, fontsize=9)
    ax.text(ro * np.cos(th[0]) - 10, ro * np.sin(th[0]) - 12, 'fibra exterior', color=AZUL_E, fontsize=9)
    ax.set_aspect('equal'); ax.axis('off')
    ax.set_title('Cotovelo do braço: ρ/t = %.1f  (< 5 → viga curva)' % (rho / t))
    ax = axs[1]
    ax.plot(s_lin, y, c='#777', lw=2, ls='--', label='viga reta (σ = M·y/I)')
    ax.plot(s_wb, y, c=VERM, lw=2.4, label='Winkler-Bach (viga curva)')
    ax.axhline(rn - rho, c=LAR, ls=':', lw=1.2); ax.text(s_wb.max() * 0.02, rn - rho + 0.8, 'eixo neutro desloca-se para dentro', color=LAR, fontsize=9)
    ax.axvline(0, c='#999', lw=0.6)
    f = s_wb[0] / s_lin[0]
    ax.annotate('fibra interior: ×%.2f' % f, (s_wb[0], y[0]), xytext=(-230, 45), textcoords='offset points',
                fontsize=10, color=VERM, arrowprops=dict(arrowstyle='->', color=VERM))
    ax.set_xlabel('tensão normal por unidade de momento [relativa]'); ax.set_ylabel('posição na secção [mm]  (− interior / + exterior)')
    ax.set_yticks(np.round([y[0], 0, y[-1]], 0))
    ax.set_title('Distribuição de tensões na secção'); ax.legend(frameon=False, loc='upper right', fontsize=9)
    fig.tight_layout(); fig.savefig(os.path.join(OUT, 'F3_winkler.png')); plt.close(fig)


# ---------------------------------------------------------------- F4 genes
def f4g():
    g, r = genes('MAR-057', 'Marte')
    fig, ax = plt.subplots(figsize=(8.5, 6.5))
    verdes(ax, 0.55); original(ax); braco(ax, C10['MAR-057'])
    A, B = gm.A_PT, gm.B_PT
    th = np.radians(g['ang']); h = g['curva'] * np.linalg.norm(B - A)
    P1 = A + h * np.array([np.cos(th), np.sin(th)]); P2 = B - h * np.array([1, 0])
    ax.plot(*np.c_[A, P1], c='k', lw=1); ax.plot(*np.c_[P2, B], c='k', lw=1)
    for P, n in ((A, 'A (bossa)'), (B, 'B (cubo)'), (P1, 'P1'), (P2, 'P2')):
        ax.plot(*P, 's' if n[0] in 'AB' else 'o', c='k', ms=6, zorder=6)
        ax.annotate(n, P, xytext=(6, 6), textcoords='offset points', fontsize=10, weight='bold')
    ax.annotate('ang = %.0f°\n(direção de saída em A)' % g['ang'], (A + P1) / 2, xytext=(-150, -60), textcoords='offset points', fontsize=10,
                arrowprops=dict(arrowstyle='->', lw=0.8))
    ax.annotate('curva = %.2f\n(abertura do arco = |AP1|/|AB|)' % g['curva'], P2, xytext=(-30, -70), textcoords='offset points',
                fontsize=10, arrowprops=dict(arrowstyle='->', lw=0.8))
    e = gm.eixo(g); k = 40
    a = e['X'][k] + 0.5 * g['largura'] * e['nrm'][k]; b = e['X'][k] - 0.5 * g['largura'] * e['nrm'][k]
    ax.annotate('', a, b, arrowprops=dict(arrowstyle='<->', color=VERM, lw=1.5))
    ax.text(*(a + 8), 'largura = %.0f mm' % g['largura'], color=VERM, fontsize=10, weight='bold')
    ax.text(-300, -95, 'Fora do plano: prof = %.0f mm, conicidade = %+.2f\nFamília (tubo / treliça / nervuras): parede, cantos, painéis…\nMaterial: Al 7075 · Ti-6Al-4V CNC · Ti L-PBF'
            % (g['prof'], g['conicidade']), fontsize=9.5, va='bottom', color='#333')
    enquadrar(ax); ax.set_ylim(-110, 220)
    ax.set_title('Genes de uma variante: eixo = Bézier cúbica A→P1→P2→B')
    fig.tight_layout(); fig.savefig(os.path.join(OUT, 'F4_genes.png')); plt.close(fig)


# ---------------------------------------------------------------- F4 planetas
def f4p():
    fig, axs = plt.subplots(2, 4, figsize=(16, 8.6))
    axs = axs.ravel()
    for ax, pl in zip(axs, PLANETAS):
        m = MELHOR[pl]; c = C10[m['id']]
        verdes(ax); original(ax); braco(ax, c, fc=COR_PL[pl], ec='#222')
        enquadrar(ax)
        mat = m['material'].replace(' (CNC)', ' CNC').replace(' (L-PBF+HIP)', ' L-PBF').replace('-T6', '')
        ax.set_title(f"{pl} — {m['id']}", fontsize=12.5, color=COR_PL[pl], pad=28)
        ax.text(0.5, 1.02, f"{NOME_FAM[c['familia']]} · {mat} · braço {num(m['massa_braco_3d']):.2f} kg · FS 3D {num(m['FS_3d']):.2f}",
                transform=ax.transAxes, ha='center', va='bottom', fontsize=9.5)
    ax = axs[-1]; ax.axis('off')
    ax.add_patch(Polygon([[0.05, 0.62], [0.2, 0.62], [0.2, 0.7], [0.05, 0.7]], fc=VERDE, ec=VERDE_E, transform=ax.transAxes))
    ax.text(0.25, 0.66, 'preservar (STEP)', transform=ax.transAxes, va='center')
    ax.add_patch(Polygon([[0.05, 0.47], [0.2, 0.47], [0.2, 0.55], [0.05, 0.55]], fc=AZUL, ec=AZUL_E, transform=ax.transAxes))
    ax.text(0.25, 0.51, 'braço gerado (cor do planeta)', transform=ax.transAxes, va='center')
    ax.plot([0.05, 0.2], [0.38, 0.38], '--', c='#555', transform=ax.transAxes)
    ax.text(0.25, 0.38, 'braço original\n(1,53 kg Al)', transform=ax.transAxes, va='center')
    fig.suptitle('Joelho do meio — a melhor variante validada em 3D, por planeta', fontsize=15, weight='bold')
    fig.tight_layout(rect=(0, 0, 1, 0.95)); fig.savefig(os.path.join(OUT, 'F4_planetas.png')); plt.close(fig)


# ---------------------------------------------------------------- F5 dispersão
def f5():
    fig, axs = plt.subplots(2, 4, figsize=(17, 8.4), sharey=False)
    axs = axs.ravel()
    tot = dict(n=0, val=0, ok=0)
    for ax, pl in zip(axs, PLANETAS):
        P = POP[pl]
        v = [r for r in P if not np.isnan(num(r['FS_min']))]
        x = np.array([num(r['massa_braco_kg']) for r in v]); y = np.array([num(r['FS_min']) for r in v])
        ok = np.array([r['passa'] == '1' for r in v])
        tot['n'] += len(P); tot['val'] += len(v); tot['ok'] += ok.sum()
        ax.scatter(x[~ok], y[~ok], s=10, c=CINZA, alpha=0.6, lw=0, label='chumba FS < 2')
        ax.scatter(x[ok], y[ok], s=14, c=COR_PL[pl], alpha=0.75, lw=0, label='passa 2D')
        ids3 = {r['id']: r for r in RES3D[pl]}
        for r in v:
            if r['id'] in ids3:
                ax.scatter(num(r['massa_braco_kg']), num(r['FS_min']), s=60, facecolors='none', edgecolors='k', lw=1)
        m = MELHOR[pl]; r2 = [r for r in v if r['id'] == m['id']][0]
        ax.scatter(num(r2['massa_braco_kg']), num(r2['FS_min']), s=220, marker='*', c='gold', ec='k', lw=1, zorder=5)
        ax.axhline(2.0, c=VERM, ls='--', lw=1)
        ax.axvline(1.53 if True else 0, c='#555', ls=':', lw=1)
        ax.set_xscale('log'); ax.set_yscale('log')
        ax.set_xlim(0.1, 12); ax.set_ylim(0.2, 40)
        ax.set_title(f"{pl}: {len(P)} geradas · {len(v)} válidas · {ok.sum()} passam", fontsize=10.5, color=COR_PL[pl])
        ax.set_xlabel('massa do braço [kg]', fontsize=9); ax.set_ylabel('FS mínimo (2D)', fontsize=9)
    ax = axs[-1]; ax.axis('off')
    hs = [plt.Line2D([], [], ls='', marker='o', c=CINZA, label='chumba (FS < 2)'),
          plt.Line2D([], [], ls='', marker='o', c=AZUL, label='passa no filtro 2D (cor do planeta)'),
          plt.Line2D([], [], ls='', marker='o', mfc='none', mec='k', ms=9, label='10 mais leves → 3D (Intact)'),
          plt.Line2D([], [], ls='', marker='*', c='gold', mec='k', ms=16, label='escolhida (mais leve que passa 3D)'),
          plt.Line2D([], [], ls='--', c=VERM, label='FS mínimo = 2,0'),
          plt.Line2D([], [], ls=':', c='#555', label='braço original 1,53 kg')]
    ax.legend(handles=hs, loc='center', frameon=False, fontsize=11)
    ax.text(0.5, 0.06, f"{tot['n']} geradas → {tot['val']} válidas\n→ {tot['ok']} passam 2D → 70 no Intact (3D)",
            transform=ax.transAxes, ha='center', fontsize=10, wrap=True)
    fig.suptitle('Espaço de soluções — joelho do meio (massa × fator de segurança)', fontsize=15, weight='bold')
    fig.tight_layout(rect=(0, 0, 1, 0.95)); fig.savefig(os.path.join(OUT, 'F5_dispersao.png')); plt.close(fig)
    print('F5 totais', tot)


# ---------------------------------------------------------------- F6 Danger Level
def f6():
    p = np.genfromtxt(os.path.join(AQUI, 'diag', 'intact', 'pontos_MAR-057_0.csv'), delimiter=';', names=True,
                      encoding='utf-8-sig')
    X = np.c_[p['x'], p['y'], p['z']]; d = p['danger']; zona = p['zona']
    Xc = X - X.mean(0); _, _, Vt = np.linalg.svd(Xc, full_matrices=False)
    UV = Xc @ Vt[:2].T
    o = np.argsort(d)
    cs_ = [r for r in ler(os.path.join(AQUI, 'diag', 'intact', 'Marte_casos.csv')) if r['id'] == 'MAR-057' and r['nome_caso'] == 'queda_lat+@meio']
    p999 = num(cs_[0]['p999']) if cs_ else np.percentile(d, 99.9)
    fig, axs = plt.subplots(1, 2, figsize=(14, 5.6), gridspec_kw={'width_ratios': [1.25, 1]})
    ax = axs[0]
    sc_ = ax.scatter(UV[o, 0], UV[o, 1], c=d[o], cmap='turbo', vmin=0, vmax=0.5, s=7, lw=0)
    cb = fig.colorbar(sc_, ax=ax, shrink=0.85); cb.set_label('Danger Level (Intact) = σ_vM / σ_cedência')
    k = np.argmax(d); ax.annotate('máximo %.3f' % d[k], UV[k], xytext=(40, -60), textcoords='offset points',
                                   arrowprops=dict(arrowstyle='->'), fontsize=10)
    ax.set_aspect('equal'); ax.axis('off')
    ax.set_title('MAR-057 (Marte) · caso queda_lat+@meio\nDanger Level no braço (Intact)', fontsize=12)
    ax = axs[1]
    ax.hist(d, bins=60, color=COR_PL['Marte'], alpha=0.85)
    ax.axvline(p999, c='k', lw=1.8); ax.text(p999, ax.get_ylim()[1] * 0.9, ' p99,9 = %.3f\n → FS 3D = %.2f' % (p999, 1 / p999), fontsize=10)
    ax.axvline(0.5, c=VERM, ls='--', lw=1.8); ax.text(0.5, ax.get_ylim()[1] * 0.6, ' limite 1/FS = 0,5', color=VERM, fontsize=10)
    ax.set_xlim(0, 0.6)
    ax.set_xlabel('Danger Level'); ax.set_ylabel('nº de pontos')
    ax.set_title('Critério: p99,9 do Danger Level < 1/FS')
    fig.tight_layout(); fig.savefig(os.path.join(OUT, 'F6_danger.png')); plt.close(fig)


if __name__ == '__main__':
    for f in (f3, f3w, f4g, f4p, f5, f6):
        f(); print('ok', f.__name__)
