# r: numpy, scipy, matplotlib
"""
==============================================================================
 RODA - CONSTRUÇÃO 3D NO RHINO (RhinoCommon) + MONTAGEM DAS 3 RODAS
==============================================================================
A geometria vem de peca_roda.descrever() (referencial da roda traseira do STEP):
  1. aro + garras: região plana (perfil com dentes + círculo R_i) extrudida ao longo de U
     chevron: loft reto de 3 perfis (borda interior / meio / borda exterior, dentes rodados
     nas bordas) e depois tira-se o cilindro R_i
  2. raios: perfis (linhas + arcos) extrudidos de u = 72 a 72 + b; disco: coroa com 24 faces
  3. união -> sólido. Face FIXA = raízes planas dos raios (r = R_HUB); face de CARGA = topo
     da garra de baixo.
construir(planeta, vid, tol) -> dict(peca, face_fixa, face_carga, centro_carga, desc, volume, estado)
montar(planeta)               -> suspensão do STEP com as 3 rodas trocadas pela variante (+ cubo verde) + STEP
==============================================================================
"""
import os
import sys
import csv

AQUI = r"C:\Mestrado\designD\m1\pecas\rodas"
NUCLEO = r"C:\Mestrado\designD\m1\pecas\nucleo"
STEP = r"C:\Mestrado\designD\m1\joelho_traseiro_STEP\step\suspensao_v1.step"
for _p in (AQUI, NUCLEO):
    if _p not in sys.path:
        sys.path.insert(0, _p)
import numpy as np
import Rhino
import Rhino.Geometry as rg
import scriptcontext as sc
import gerador_rodas as gr
import peca_roda as pr

FOLGA_MM = 600.0
FILA0 = 41                 # filas de montagem: joelho do meio 1-7, barras 9-39, rodas 41-47
_LOG = []


def _log(*a):
    _LOG.append(" ".join(str(x) for x in a))


def _lista(tipo, itens):
    from System.Collections.Generic import List
    l = List[tipo]()
    for i in itens:
        l.Add(i)
    return l


def _pt3(P):
    return rg.Point3d(float(P[0]), float(P[1]), float(P[2]))


def _vec(V):
    return rg.Vector3d(float(V[0]), float(V[1]), float(V[2]))


def _p(u, xy):
    return _pt3(pr.g3(u, xy[0], xy[1]))


def _curva(seg, u):
    """Segmentos 2D -> curva fechada no plano u = const."""
    pc = rg.PolyCurve()
    for s in seg:
        if s[0] == 'linha':
            pc.Append(rg.Line(_p(u, s[1]), _p(u, s[2])))
        else:
            pc.Append(rg.Arc(_p(u, s[1]), _p(u, s[2]), _p(u, s[3])))
    pc.MakeClosed(0.001)
    return pc.ToNurbsCurve()


def _seg_curva(s, u):
    """Um segmento 2D (linha/arco) -> curva NURBS aberta no plano u = const."""
    if s[0] == 'linha':
        return rg.LineCurve(_p(u, s[1]), _p(u, s[2])).ToNurbsCurve()
    return rg.ArcCurve(rg.Arc(_p(u, s[1]), _p(u, s[2]), _p(u, s[3]))).ToNurbsCurve()


def _chevron_por_segmentos(d, tol, n=16):
    """02/11: aro chevron = em cada metade (borda->meio, meio->borda) N_SEC perfis intermédios com a
    rotação dos dentes a variar linearmente (hélice); cada segmento do perfil liga-se por superfície
    regrada ao mesmo segmento dos perfis seguintes; tampas planas nas bordas; junta.
    - o topo de cada garra é uma face própria (uma por metade);
    - com 16 passos a corda entre perfis rodados fica a ~0,02 mm do círculo (com 1 passo o aro de 4 mm
      ficava comido ~5 mm a meio de cada metade: massa -30 %)."""
    G, g, fam = d['G'], d['genes'], d['familia']
    dth = d['chevron_dtheta']
    metades = [(d['u_in'], d['u_c'], dth, 0.0), (d['u_c'], d['u_out'], 0.0, dth)]
    pecas = []
    for ua, ub, ra, rb in metades:
        us = np.linspace(ua, ub, n + 1)
        perfis = [pr.perfil_aro(G, g, fam, rot=float(r)) for r in np.linspace(ra, rb, n + 1)]
        m = len(perfis[0])
        for i in range(m):
            crv = [_seg_curva(p[i], float(u)) for u, p in zip(us, perfis)]
            lf = rg.Brep.CreateFromLoft(_lista(rg.Curve, crv), rg.Point3d.Unset, rg.Point3d.Unset,
                                        rg.LoftType.Straight, False)
            if not lf:
                return None
            pecas.extend(list(lf))
    for u, rot in ((d['u_in'], dth), (d['u_out'], dth)):
        tampa = rg.Brep.CreatePlanarBreps(_curva(pr.perfil_aro(G, g, fam, rot=rot), u), tol)
        if not tampa:
            return None
        pecas.extend(list(tampa))
    j = rg.Brep.JoinBreps(_lista(rg.Brep, pecas), tol)
    if not j or len(j) != 1:
        return None
    return _solido(j[0], tol)


def _poligono(pts, u):
    P = [_p(u, q) for q in pts]
    P.append(P[0])
    return rg.PolylineCurve(_lista(rg.Point3d, P))


def _circulo(r, u):
    return rg.Circle(rg.Plane(_pt3(pr.g3(u, 0.0, 0.0)), _vec(pr.V), _vec(pr.W)), r).ToNurbsCurve()


def _solido(b, tol):
    if b is None:
        return None
    if not b.IsSolid:
        c = b.CapPlanarHoles(tol)
        b = c if c is not None else b
    if b.IsSolid and b.SolidOrientation == rg.BrepSolidOrientation.Inward:
        b.Flip()
    return b if b.IsSolid else None


def _extrudir_regiao(curvas, u0, comp, tol):
    """Região plana (1.ª curva = fronteira exterior, as outras = buracos) extrudida +U."""
    pl = rg.Brep.CreatePlanarBreps(_lista(rg.Curve, curvas), tol)
    if not pl:
        return None
    face = pl[0].Faces[0]
    caminho = rg.LineCurve(_pt3(pr.g3(u0, 0, 0)), _pt3(pr.g3(u0 + comp, 0, 0)))
    return _solido(face.CreateExtrusion(caminho, True), tol)


def _diferenca(corpo, ferr, tol, nome):
    V0 = corpo.GetVolume()
    r = rg.Brep.CreateBooleanDifference(_lista(rg.Brep, [corpo]), _lista(rg.Brep, [f for f in ferr if f]), tol)
    if r:
        novo = max(r, key=lambda x: x.GetVolume())
        if novo.IsSolid and novo.GetVolume() < V0 - 1.0:
            return novo, True
    _log("AVISO: {} falhou (Boolean)".format(nome))
    return corpo, False


def construir(planeta, vid, tol=0.01):
    del _LOG[:]
    planeta = pr.nome_planeta(planeta)
    d = pr.descrever(planeta, vid)
    estado = []
    # 1. aro + garras
    if d['tipo_garra'] == 'chevron':
        secs = [(d['u_in'], d['aro_borda']), (d['u_c'], d['aro']), (d['u_out'], d['aro_borda'])]
        aro = _chevron_por_segmentos(d, tol)
        estado.append("chevron em hélice (2 x 16 perfis)" if aro is not None else "chevron: loft de 3 curvas")
        if aro is None:                                  # recurso: o loft antigo
            _log("AVISO: chevron por segmentos falhou -> loft de 3 curvas")
            crv = [_curva(s, u) for u, s in secs]
            lf = rg.Brep.CreateFromLoft(_lista(rg.Curve, crv), rg.Point3d.Unset, rg.Point3d.Unset,
                                        rg.LoftType.Straight, False)
            aro = _solido(lf[0] if lf else None, tol)
        if aro is None:
            raise Exception("{}: o loft do chevron não fechou".format(vid))
        cil = rg.Cylinder(rg.Circle(rg.Plane(_pt3(pr.g3(d['u_in'] - 5, 0, 0)), _vec(pr.V), _vec(pr.W)), d['R_i']),
                          d['L'] + 10).ToBrep(True, True)
        aro, ok = _diferenca(aro, [cil], tol, "interior do aro")
        if not ok:
            raise Exception("{}: não consegui esvaziar o aro".format(vid))
        estado.append("aro chevron (loft)")
    else:
        aro = _extrudir_regiao([_curva(d['aro'], d['u_in']), _circulo(d['R_i'], d['u_in'])], d['u_in'], d['L'], tol)
        if aro is None:
            raise Exception("{}: a extrusão do aro não fechou".format(vid))
        estado.append("aro extrudido")
    # 2. raios / disco
    u0, u1 = d['u_raios']
    pecas = []
    if d['tipo_raio'] == 'disco':
        disco = _extrudir_regiao([_circulo(d['disco_r_ext'], u0), _poligono(d['disco_interior'], u0)], u0, u1 - u0, tol)
        pecas.append(disco)
    else:
        for seg in d['raios']:
            c = _curva(seg, u0)
            srf = rg.Surface.CreateExtrusion(c, _vec(pr.U * (u1 - u0)))
            pecas.append(_solido(srf.ToBrep(), tol) if srf is not None else None)
    falhas = sum(1 for p in pecas if p is None)
    if falhas:
        raise Exception("{}: {} raio(s) não fecharam".format(vid, falhas))
    un = rg.Brep.CreateBooleanUnion(_lista(rg.Brep, [aro] + pecas), tol)
    if not un or len(un) != 1:
        raise Exception("{}: a união aro + raios deu {} corpos".format(vid, len(un) if un else 0))
    corpo = un[0]
    if corpo.SolidOrientation == rg.BrepSolidOrientation.Inward:
        corpo.Flip()
    estado.append("{} {}".format(len(pecas), "disco" if d['tipo_raio'] == 'disco' else "raios"))
    # 02/11: os raios (e o loft do chevron) vêm de UMA curva fechada -> a parede lateral é UMA face
    # com quinas; partir nas quinas para a raiz do raio / topo da garra serem faces próprias
    try:
        n_antes = corpo.Faces.Count
        corpo.Faces.SplitKinkyFaces(0.175, True)           # ~10 graus (cantos verdadeiros >> 10°;
                                                            # as tiras da hélice do chevron dobram ~1,5°)
        if corpo.Faces.Count != n_antes:
            estado.append("faces {}->{}".format(n_antes, corpo.Faces.Count))
    except Exception as e_:
        _log("AVISO: SplitKinkyFaces falhou: {}".format(e_))
    # 3. faces de ligação
    fixa, carga = [], []
    yb = -d['R_ext']
    for fc in corpo.Faces:
        fb = fc.DuplicateFace(False)
        amp = rg.AreaMassProperties.Compute(fb)
        if amp is None:
            continue
        c = np.array([amp.Centroid.X, amp.Centroid.Y, amp.Centroid.Z])
        u, x, y = (float(t[0]) for t in pr.local(c))
        r = np.hypot(x, y)
        if fc.IsPlanar(0.1) and abs(r - d['R_hub']) < 0.6 and u0 - 0.5 <= u <= u1 + 0.5:
            fixa.append((amp.Area, fb, amp.Centroid))
        elif abs(y - yb) < 2.0 and abs(x) <= d['carga_meia_x'] + 1.0 and abs(u - d['u_c']) <= d['L'] / 2 + 0.5:
            carga.append((amp.Area, fb, amp.Centroid))
    if fixa and not carga:
        # 02/11: chevron (garras em V muito inclinadas) -> o centroide do topo fica abaixo de R_ext.
        # Carga = faces que passam pelo ponto mais baixo da roda, a meio da largura (contacto com o chão).
        P0 = _pt3(pr.g3(d['u_c'], 0.0, -d['R_ext']))
        for fc in corpo.Faces:
            fb = fc.DuplicateFace(False)
            q = fb.ClosestPoint(P0)
            if q.DistanceTo(P0) < 1.0:
                amp = rg.AreaMassProperties.Compute(fb)
                if amp is not None:
                    carga.append((amp.Area, fb, amp.Centroid))
        if carga:
            estado.append("carga pelo ponto de contacto ({} faces)".format(len(carga)))
    if not fixa or not carga:
        cand = []
        for fc in corpo.Faces:
            amp = rg.AreaMassProperties.Compute(fc.DuplicateFace(False))
            if amp is None:
                continue
            u, x, y = (float(t[0]) for t in pr.local(np.array([amp.Centroid.X, amp.Centroid.Y, amp.Centroid.Z])))
            if y < yb + 15:
                cand.append("u{:.0f} x{:.1f} y{:.1f} A{:.0f}".format(u, x, y, amp.Area))
        raise Exception("{}: não encontrei as faces de ligação (fixa {}, carga {}) [faces em baixo: {}]".format(
            vid, len(fixa), len(carga), "; ".join(cand[:12])))

    def junta(lst):
        b = lst[0][1].DuplicateBrep()
        for _, f, _ in lst[1:]:
            b.Append(f)
        return b
    A = sum(x[0] for x in carga)
    cc = np.sum([x[0] * np.array([x[2].X, x[2].Y, x[2].Z]) for x in carga], axis=0) / A
    return dict(peca=corpo, face_fixa=junta(fixa), face_carga=junta(carga), centro_carga=cc,
                desc=d, volume=corpo.GetVolume(), estado="; ".join(estado),
                n_faces=(len(fixa), len(carga)), log=list(_LOG))


def cubo_verde(tol=0.01):
    """Anel Ø200/Ø140 x 40 encostado à flange (referencial da roda traseira)."""
    u0 = gr.U_FLANGE
    return _extrudir_regiao([_circulo(gr.R_HUB, u0), _circulo(gr.R_FURO, u0)], u0, gr.H_HUB, tol)


# ==============================================================================
# MONTAGEM: as 3 rodas do STEP trocadas pela variante (+ cubo verde) + STEP
# ==============================================================================
def _brep(g, xf):
    b = None
    if isinstance(g, rg.Brep):
        b = g.DuplicateBrep()
    elif isinstance(g, rg.Extrusion):
        b = g.ToBrep()
    elif isinstance(g, rg.Mesh):
        b = g.DuplicateMesh()
    if b is not None:
        b.Transform(xf)
    return b


def pecas_da_suspensao(nome):
    nome = nome.lower()
    out = []

    def descer(idef, xf, alvo):
        for o in idef.GetObjects():
            g = o.Geometry
            j = alvo or nome in (o.Attributes.Name or "").lower()
            if isinstance(g, rg.InstanceReferenceGeometry):
                sub = sc.doc.InstanceDefinitions.FindId(g.ParentIdefId)
                descer(sub, xf * g.Xform, j or nome in (sub.Name or "").lower())
            else:
                b = _brep(g, xf)
                if b is not None:
                    out.append((j, b))

    cfg = Rhino.DocObjects.ObjectEnumeratorSettings()
    cfg.HiddenObjects = True
    cfg.LockedObjects = True
    for o in sc.doc.Objects.GetObjectList(cfg):
        if o.IsDeleted:
            continue
        lay = sc.doc.Layers[o.Attributes.LayerIndex].FullPath
        if lay.startswith(("Joelho_completo", "Montagem", "Intact", "Teste_", "Suspensao_")):
            continue
        g = o.Geometry
        j = nome in (o.Attributes.Name or "").lower()
        if isinstance(g, rg.InstanceReferenceGeometry):
            idef = sc.doc.InstanceDefinitions.FindId(g.ParentIdefId)
            descer(idef, g.Xform, j or nome in (idef.Name or "").lower())
        else:
            b = _brep(g, rg.Transform.Identity)
            if b is not None:
                out.append((j, b))
    return out


def _camada(nome, cor):
    import rhinoscriptsyntax as rs
    if not rs.IsLayer(nome):
        rs.AddLayer(nome, cor)
    return sc.doc.Layers.FindByFullPath(nome, -1)


def para_roda(nome_roda):
    """Transformação: referencial da roda traseira -> roda 'nome_roda' (flange própria)."""
    import peca_roda as pr_
    cs_ = pr_.cs
    r = cs_.RODAS[nome_roda]
    o = r['C'] + (pr_.FLANGE[nome_roda] - pr_.FLANGE['traseira']) * r['u']
    a = rg.Plane(_pt3(pr_.C0), _vec(pr_.V), _vec(pr_.W))
    b = rg.Plane(_pt3(o), _vec(r['v']), _vec(r['w']))
    return rg.Transform.PlaneToPlane(a, b)


def rodas_do_step(pecas):
    """(peças que são rodas: perto de um dos 3 centros, resto)."""
    import peca_roda as pr_
    centros = [_pt3(r['C']) for r in pr_.cs.RODAS.values()]
    sim, resto = [], []
    for j, b in pecas:
        c = b.GetBoundingBox(True).Center
        if j and min(c.DistanceTo(q) for q in centros) < 120:
            sim.append(b)
        else:
            resto.append(b)
    return sim, resto


def montar(planeta, exportar=True):
    import rhinoscriptsyntax as rs
    planeta = pr.nome_planeta(planeta)
    tol = sc.doc.ModelAbsoluteTolerance
    fich = os.path.join(pr.SAIDA, planeta + "_top3.csv")
    if not os.path.exists(fich):
        raise Exception("Falta {}: corre primeiro o maestro para {}".format(fich, planeta))
    top = list(csv.DictReader(open(fich, encoding="utf-8-sig"), delimiter=";"))
    if not top:
        return "nenhuma variante de {} passou em 3D: nada para montar".format(planeta)
    pecas = pecas_da_suspensao(pr.NOME_STEP)
    if not any(j for j, _ in pecas) and os.path.exists(STEP):
        rs.Command('_-Import "{}" _Enter'.format(STEP), echo=False)
        pecas = pecas_da_suspensao(pr.NOME_STEP)
    rodas, resto = rodas_do_step(pecas)
    if not rodas:
        raise Exception('Não encontrei as rodas ("roda") no Rhino: importa o STEP da suspensão.')
    cubo = cubo_verde(tol)
    bb = rg.BoundingBox.Empty
    for _, b in pecas:
        bb.Union(b.GetBoundingBox(True))
    passo_x = bb.Max.X - bb.Min.X + FOLGA_MM
    passo_y = bb.Max.Y - bb.Min.Y + FOLGA_MM
    fila = FILA0 + pr.PLANETAS.index(planeta)
    msgs = []
    rs.EnableRedraw(False)
    try:
        _camada("Montagem_rodas", (120, 120, 120))
        _camada("Montagem_rodas::" + planeta, (120, 120, 120))
        for lugar, lin in enumerate(top, 1):
            vid = lin["id"]
            var = construir(planeta, vid, tol)["peca"]
            mover = rg.Transform.Translation(rg.Vector3d(passo_x * lugar, -passo_y * fila, 0.0))
            base = "Montagem_rodas::{}::{}_{}".format(planeta, lugar, vid)
            lay_s = _camada(base + "::suspensao", (150, 150, 150))
            lay_v = _camada(base + "::roda_variante", (60, 110, 200))
            lay_g = _camada(base + "::cubo_verde", (60, 180, 60))
            ids = []

            def junta(geo, lay, nm, xf):
                g = geo.Duplicate()
                g.Transform(xf)
                g.Transform(mover)
                a = Rhino.DocObjects.ObjectAttributes()
                a.LayerIndex = lay
                a.Name = nm
                ids.append(sc.doc.Objects.AddMesh(g, a) if isinstance(g, rg.Mesh) else sc.doc.Objects.AddBrep(g, a))

            for k, b in enumerate(resto):
                junta(b, lay_s, "suspensao_{}".format(k + 1), rg.Transform.Identity)
            for nr in pr.cs.RODAS:
                xf = para_roda(nr)
                junta(var, lay_v, "roda_{}_{}".format(nr, vid), xf)
                if cubo is not None:
                    junta(cubo, lay_g, "cubo_{}_{}".format(nr, vid), xf)
            rs.AddObjectsToGroup(ids, rs.AddGroup("montagem_rodas_{}_{}".format(planeta, vid)))
            txt = "{}. {} ({} kg, FS 3D {})".format(lugar, vid, lin.get("massa_3d"), lin.get("FS_3d"))
            if exportar:
                destino = os.path.join(pr.SAIDA, "{}_{}_suspensao.stp".format(planeta, vid))
                rs.UnselectAllObjects()
                rs.SelectObjects(ids)
                rs.Command('_-Export "{}" _Enter _Enter'.format(destino), echo=False)
                rs.UnselectAllObjects()
                txt += " -> " + os.path.basename(destino)
            msgs.append(txt)
    finally:
        rs.EnableRedraw(True)
    return "{} montagens de {} (rodas): {}".format(len(msgs), planeta, "; ".join(msgs))
