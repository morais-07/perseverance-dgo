"""
==============================================================================
 RODA - DESCRIÇÃO 3D DE UMA VARIANTE (sem Rhino: só numpy)
==============================================================================
Ponte entre a geração 2D (gerador_rodas.py) e o construtor Rhino (rhino_roda.py).
Construída no referencial da RODA TRASEIRA do STEP (roda:1):
   P = C + u U + x V + y W     (U = eixo para fora, V = marcha, W = vertical)
   no plano (x, y): ângulo -90° = em baixo (contacto com o solo)
Peça 3D (= zona de PROJETO, como no joelho do meio e nas barras):
  - aro + garras: perfil plano (círculo R_i por dentro, R_o com dentes por fora)
      extrudido de u = -167,8 até -167,8 + L      (garra reta / em ponta: topos PLANOS)
      chevron (Marte): loft reto por 3 secções (borda int., meio, borda ext.) com os
      dentes rodados nas bordas -> garras em V (topos regrados)
  - raios: perfis planos (linhas / arcos) extrudidos de u = 72 (flange) até 72 + b
      raiz PLANA em r = R_HUB (= face FIXA, encosta ao cubo verde)
      ponta cortada a meio do aro (fica dentro do aro depois da união)
  - disco (Vénus): coroa com 24 faces planas por dentro (r = R_HUB) = face FIXA
  - face de CARGA: topo da garra de baixo (-90°)
O cubo verde (anel Ø200/Ø140 x 40) só entra na montagem; a sua massa entra em V_VERDE.

API (igual à das outras peças) + POR_VARIANTE = True: lista_casos e dist_ligacoes
recebem a variante (o contacto e a garra carregada dependem da largura).
==============================================================================
"""
import os, sys, csv
import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__))
if AQUI not in sys.path:
    sys.path.insert(0, AQUI)
_NUC = os.path.normpath(os.path.join(AQUI, '..', 'nucleo'))
if _NUC not in sys.path:
    sys.path.insert(1, _NUC)
import gerador_rodas as gr
import cargas_suspensao as cs
import planetas as pl

PECA = 'roda'
NOME_STEP = 'roda'
PLANETAS = list(gr.FAMILIA)
NOME_FAM = gr.NOME_FAM
V_VERDE = gr.V_VERDE
SAIDA = os.path.join(AQUI, 'diag', 'intact')
POR_VARIANTE = True
N_FLATS_DISCO = 24

_R = cs.RODAS['traseira']
C0 = np.asarray(_R['C'], float)
U = np.asarray(_R['u'], float)
V = np.asarray(_R['v'], float)
W = np.asarray(_R['w'], float)
U3 = U


def _flange(nome_roda):
    """Face exterior da flange do joelho (u, mm) para cada roda (traseira/frente 72,0; meio 69,8)."""
    r = cs.RODAS[nome_roda]
    best = None
    for c in cs._pecas[r['joelho']]['cilindros']:
        if c['tipo'] == 'veio' and abs(abs(np.dot(c['eixo_global'], r['u'])) - 1) < 0.01:
            u = (np.array(c['centro_global_mm']) - r['C']) @ r['u'] + c['comprimento_mm'] / 2
            best = u if best is None else max(best, u)
    return float(best)


FLANGE = {n: _flange(n) for n in cs.RODAS}


def nome_planeta(v):
    import unicodedata
    tira = lambda s: unicodedata.normalize('NFKD', str(s)).encode('ascii', 'ignore').decode().strip().lower()
    for n in PLANETAS:
        if tira(n) == tira(v):
            return n
    raise Exception('Planeta desconhecido: {!r}. Usa um destes: {}'.format(v, ', '.join(PLANETAS)))


def g3(u, x, y):
    """Local (u, x, y) -> global."""
    u = np.asarray(u, float); x = np.asarray(x, float); y = np.asarray(y, float)
    return C0 + u[..., None] * U + x[..., None] * V + y[..., None] * W


def local(P):
    D = np.atleast_2d(P) - C0
    return D @ U, D @ V, D @ W


# ------------------------------------------------------------------------------
# população / candidatos / material
# ------------------------------------------------------------------------------
_POP = {}


def ler_populacao(planeta):
    f = os.path.join(AQUI, 'diag', 'populacoes', planeta + '.csv')
    t = os.path.getmtime(f)
    if planeta not in _POP or _POP[planeta][0] != t:
        _POP[planeta] = (t, list(csv.DictReader(open(f, encoding='utf-8-sig'), delimiter=';')))
    return _POP[planeta][1]


def linha(planeta, vid):
    for l in ler_populacao(planeta):
        if l['id'].upper() == vid.upper():
            return l
    raise Exception('Não encontrei {} em rodas/diag/populacoes/{}.csv'.format(vid, planeta))


def genes_de_linha(l):
    g = {}
    for k in gr.GENES[l['familia']]:
        g[k] = int(float(l[k])) if k in gr.INTEIROS else float(l[k])
    return g


def material(planeta, nome_mat):
    return gr.materiais(planeta)[nome_mat]


def FS_req(planeta):
    return float(pl.PLANETAS[planeta]['FS'])


_PREV = {}


def candidatos(planeta, n):
    """As n mais leves que passam no 2D, ordenadas pela massa 3D PREVISTA."""
    pop = [l for l in ler_populacao(planeta) if l.get('passa') == '1' and l.get('massa_kg')]
    pop.sort(key=lambda l: float(l['massa_kg']))
    out = []
    for l in pop[:max(4 * n, 20)]:
        k = (planeta, l['id'])
        if k not in _PREV:
            try:
                _PREV[k] = massa_prevista(planeta, l['id'])['massa_3d_prevista']
            except Exception:
                _PREV[k] = None
        if _PREV[k] is not None:
            out.append((_PREV[k], l['id']))
    out.sort()
    return [v for _, v in out[:n]]


# ------------------------------------------------------------------------------
# perfis 2D (plano x-y) — segmentos ('linha', p0, p1) / ('arco', p0, pm, p1)
# ------------------------------------------------------------------------------
def _pol(r, a):
    return np.array([r * np.cos(a), r * np.sin(a)])


def perfil_aro(G, g, fam, rot=0.0):
    """Fronteira exterior (aro com dentes), sentido anti-horário. rot [rad] roda os dentes."""
    gn = G['gn']
    n_g = int(g['n_garras'])
    e = gn['e_garra']
    e_t = gr.PONTA_TOPO if gr.TIPO_GARRA[fam] == 'ponta' else e
    Ro = G['R_o']
    seg = []
    dentes = []
    for k in range(n_g):
        th = np.radians(-90 + k * 360.0 / n_g) + rot
        er, et = np.array([np.cos(th), np.sin(th)]), np.array([-np.sin(th), np.cos(th)])
        d = np.sqrt(Ro ** 2 - (e / 2) ** 2)
        dentes.append([d * er - e / 2 * et, gr.R_EXT * er - e_t / 2 * et,
                       gr.R_EXT * er + e_t / 2 * et, d * er + e / 2 * et])
    for k in range(n_g):
        b0, t0, t1, b1 = dentes[k]
        seg += [('linha', b0, t0), ('linha', t0, t1), ('linha', t1, b1)]
        nb = dentes[(k + 1) % n_g][0]
        a0, a1 = np.arctan2(b1[1], b1[0]), np.arctan2(nb[1], nb[0])
        if a1 < a0:
            a1 += 2 * np.pi
        seg.append(('arco', b1, _pol(Ro, (a0 + a1) / 2), nb))
    return seg


def perfil_raio_seg(G, g, fam, j):
    """Segmentos do raio j: lado 1 (raiz->ponta), arco da ponta, lado 2 (ponta->raiz), raiz."""
    L1, L2 = gr.lados_raio(G, g, fam, j, n_arc=25)
    r_tip = G['R_i'] + G['gn']['t_aro'] / 2
    curvo = gr.TIPO_RAIO[fam] == 'curvo'
    m = len(L1) // 2
    b1, b2 = L1[-1], L2[-1]
    a1, a2 = np.arctan2(b1[1], b1[0]), np.arctan2(b2[1], b2[0])
    if a2 - a1 > np.pi:
        a2 -= 2 * np.pi
    elif a1 - a2 > np.pi:
        a2 += 2 * np.pi
    seg = [('arco', L1[0], L1[m], L1[-1]) if curvo else ('linha', L1[0], L1[-1]),
           ('arco', b1, _pol(r_tip, (a1 + a2) / 2), b2),
           ('arco', L2[-1], L2[m], L2[0]) if curvo else ('linha', L2[-1], L2[0]),
           ('linha', L2[0], L1[0])]
    return seg


def poligono_disco_interior():
    """24 faces planas tangentes a r = R_HUB (vértices em R_HUB / cos(7,5°))."""
    n = N_FLATS_DISCO
    rv = gr.R_HUB / np.cos(np.pi / n)
    return [_pol(rv, np.radians(-90) + (k + 0.5) * 2 * np.pi / n) for k in range(n)]


def amostrar_seg(seg, n_arc=40):
    pts = []
    for s in seg:
        if s[0] == 'linha':
            pts.append(s[1])
        else:
            p0, pm, p1 = s[1], s[2], s[3]
            # circunferência pelos 3 pontos
            ax, ay = p0; bx, by = pm; cx, cy = p1
            d = 2 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by))
            ux = ((ax ** 2 + ay ** 2) * (by - cy) + (bx ** 2 + by ** 2) * (cy - ay) + (cx ** 2 + cy ** 2) * (ay - by)) / d
            uy = ((ax ** 2 + ay ** 2) * (cx - bx) + (bx ** 2 + by ** 2) * (ax - cx) + (cx ** 2 + cy ** 2) * (bx - ax)) / d
            O = np.array([ux, uy]); R = np.linalg.norm(p0 - O)
            t0, tm, t1 = (np.arctan2(*(q - O)[::-1]) for q in (p0, pm, p1))
            # escolhe o sentido que passa por pm
            def entre(a, b, c):
                return (c - a) % (2 * np.pi) <= (b - a) % (2 * np.pi)
            if entre(t0, t1, tm):
                span = (t1 - t0) % (2 * np.pi)
            else:
                span = -((t0 - t1) % (2 * np.pi))
            for f in np.linspace(0, 1, n_arc)[:-1]:
                pts.append(O + R * np.array([np.cos(t0 + f * span), np.sin(t0 + f * span)]))
    return np.array(pts)


def area_pol(P):
    return 0.5 * abs(np.sum(P[:, 0] * np.roll(P[:, 1], -1) - np.roll(P[:, 0], -1) * P[:, 1]))


# ------------------------------------------------------------------------------
# descrição
# ------------------------------------------------------------------------------
def descrever(planeta, vid):
    l = linha(planeta, vid)
    g = genes_de_linha(l)
    fam = l['familia']
    nm = l['material']
    r = gr.avaliar(planeta, g, nm, fam=fam)
    if not r.get('valido'):
        raise Exception('{} não é válida: {}'.format(vid, r.get('motivo')))
    G = r['G']; gn = G['gn']
    tg, tr = gr.TIPO_GARRA[fam], gr.TIPO_RAIO[fam]
    d = dict(peca=PECA, planeta=planeta, id=l['id'], familia=fam, recurso=l.get('recurso') == '1', material=nm,
             genes=g, genes_novos=gn, G=G, tipo_garra=tg, tipo_raio=tr, C=C0, U=U, V=V, W=W,
             u_in=gr.U_IN, u_out=G['u_out'], u_c=G['u_c'], L=G['L'], R_i=G['R_i'], R_o=G['R_o'], R_ext=gr.R_EXT,
             u_raios=(gr.U_FLANGE, gr.U_FLANGE + G['b_ax']), R_hub=gr.R_HUB, R_furo=gr.R_FURO,
             cubo_u=(gr.U_FLANGE, gr.U_FLANGE + gr.H_HUB),
             massa_2d=float(l['massa_kg']), massa_braco_2d=float(l['massa_proj_kg']), FS_2d=float(l['FS_min']),
             avisos=[])
    d['aro'] = perfil_aro(G, g, fam)
    if tg == 'chevron':
        dth = (G['L'] / 2) * np.tan(np.radians(g['alfa'])) / G['R_o']
        d['aro_borda'] = perfil_aro(G, g, fam, rot=dth)      # dentes rodados nas duas bordas -> V
        d['chevron_dtheta'] = float(dth)
    if tr == 'disco':
        d['disco_interior'] = poligono_disco_interior()
        d['disco_r_ext'] = G['R_i'] + gn['t_aro'] / 2
        d['raios'] = []
    else:
        d['raios'] = [perfil_raio_seg(G, g, fam, j) for j in range(int(g['n_raios']))]
    # garra carregada (em baixo): meia-largura tangencial do topo, para dist_ligacoes
    e_t = gr.PONTA_TOPO if tg == 'ponta' else gn['e_garra']
    d['carga_meia_x'] = e_t / 2 + (gr.R_EXT * d.get('chevron_dtheta', 0.0))
    return d


def volume_previsto(d):
    """Volume [mm3] da zona de projeto (aro+garras U raios/disco), analítico/numérico."""
    A_aro = area_pol(amostrar_seg(d['aro'])) - np.pi * d['R_i'] ** 2
    Vt = A_aro * d['L']
    b = d['u_raios'][1] - d['u_raios'][0]
    if d['tipo_raio'] == 'disco':
        Vt += (np.pi * d['R_i'] ** 2 - area_pol(np.array(d['disco_interior']))) * b
    else:
        G, g = d['G'], d['genes']
        for j in range(int(g['n_raios'])):
            P = gr.perfil_raio(G, g, d['familia'], j, n_arc=60, r_tip=d['R_i'])   # só até ao aro
            Vt += area_pol(P) * b
    return float(Vt)


def massa_prevista(planeta, vid):
    d = descrever(planeta, vid)
    Vp = volume_previsto(d)
    rho = material(planeta, d['material'])['rho'] * 1e-9
    return dict(id=vid, material=d['material'], massa_2d=d['massa_2d'], massa_proj_2d=d['massa_braco_2d'],
                massa_proj_3d_prevista=Vp * rho, massa_3d_prevista=(Vp + V_VERDE) * rho, FS_2d=d['FS_2d'])


# ------------------------------------------------------------------------------
# casos 3D (reduzidos por linearidade) e distâncias às ligações
# ------------------------------------------------------------------------------
def _casos_globais(planeta, vid=None):
    if vid:
        l = linha(planeta, vid)
        L = float(l['largura']) * gr.L0
    else:
        L = gr.L0
    u_c = gr.U_IN + L / 2
    out = []
    for nome, Fu, Fw, Fv, onde in gr.casos(planeta):
        F = Fu * U + Fw * W + Fv * V
        uP = u_c + {'plano': 0.0, 'aresta_ext': L / 2, 'aresta_int': -L / 2}[onde]
        P = C0 + uP * U - gr.R_EXT * W
        out.append((nome, F, np.cross(P, F)))
    return out


def lista_casos(planeta, gravar=False, vid=None):
    todos = _casos_globais(planeta, vid)
    grupos = []
    for nome, F, M0 in todos:
        f = np.linalg.norm(F)
        chave = np.r_[F / f, M0 / f]
        for gr_ in grupos:
            if (np.allclose(gr_['chave'], chave, rtol=1e-6, atol=1e-6 * max(1.0, np.abs(chave).max())) or
                    np.allclose(gr_['chave'], -chave, rtol=1e-6, atol=1e-6 * max(1.0, np.abs(chave).max()))):   # 02/11: carga simétrica (-F, -M) = mesmo Danger Level (elasticidade linear)
                gr_['membros'].append((nome, f)); break
        else:
            grupos.append(dict(chave=chave, membros=[(nome, f)], F=F, M0=M0, f=f))
    out = []
    for gq in grupos:
        nome_max, fmax = max(gq['membros'], key=lambda x: x[1])
        esc = fmax / gq['f']
        eq = [m for m in gq['membros'] if m[0] != nome_max]
        rot = nome_max
        if eq:
            rot = 'vertical_max' if abs(gq['chave'][2]) > 0.999 else nome_max + '*'
            eq = [(nome_max, fmax)] + eq
        ordem = (1 if eq else 0, [x[0] for x in todos].index(nome_max))
        out.append((ordem, (rot, gq['F'] * esc, gq['M0'] * esc, eq)))
    out = [c for _, c in sorted(out, key=lambda x: x[0])]
    if gravar:
        os.makedirs(SAIDA, exist_ok=True)
        with open(os.path.join(SAIDA, planeta + '_casos_equivalentes.csv'), 'w', encoding='utf-8-sig') as fh:
            fh.write('planeta;caso_3D;F_N;casos_2D_proporcionais (% da força)\n')
            for nome, F, M0, eq in out:
                fh.write('{};{};{:.1f};{}\n'.format(planeta, nome, np.linalg.norm(F),
                         ', '.join('{} ({:.0f} %)'.format(n_, 100 * f_ / np.linalg.norm(F)) for n_, f_ in eq)))
    return out


def n_casos(planeta):
    return len(lista_casos(planeta))


_DESC = {}


def dist_ligacoes(P, planeta=None, vid=None):
    """(distância à face FIXA = raízes dos raios em r = R_HUB, distância à face de CARGA =
    topo da garra de baixo) [mm]. Sem variante: só a fixa é exata (carga = contacto nominal)."""
    u, x, y = local(P)
    r = np.hypot(x, y)
    df = np.maximum(r - gr.R_HUB, 0.0)
    if planeta and vid:
        k = (planeta, vid)
        if k not in _DESC:
            _DESC[k] = descrever(planeta, vid)
        d = _DESC[k]
        u_c, Lh, mx = d['u_c'], d['L'] / 2, d['carga_meia_x']
    else:
        u_c, Lh, mx = 0.0, gr.L0 / 2, 3.0
    du = np.maximum(np.abs(u - u_c) - Lh, 0.0)
    dx = np.maximum(np.abs(x) - mx, 0.0)
    dy = np.abs(-y - gr.R_EXT)
    dc = np.sqrt(du ** 2 + dx ** 2 + dy ** 2)
    return df, dc


# ------------------------------------------------------------------------------
# teste fora do Rhino
# ------------------------------------------------------------------------------
if __name__ == '__main__':
    import time
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    linhas = []
    print('Flange por roda (u, mm):', {k: round(v, 1) for k, v in FLANGE.items()})
    fig, axs = plt.subplots(1, len(PLANETAS), figsize=(3 * len(PLANETAS), 3.6))
    for ax, p in zip(axs, PLANETAS):
        t0 = time.time()
        ids = candidatos(p, 5)
        cs_ = lista_casos(p, gravar=True)
        for vid in ids:
            m = massa_prevista(p, vid)
            d = descrever(p, vid)
            n_c = len(lista_casos(p, vid=vid))
            linhas.append(dict(planeta=p, id=vid, familia=d['familia'], material=m['material'],
                               massa_2d=round(m['massa_2d'], 3), massa_3d_prevista=round(m['massa_3d_prevista'], 3),
                               razao=round(m['massa_3d_prevista'] / m['massa_2d'], 3), FS_2d=m['FS_2d'],
                               casos_3d=n_c, avisos='; '.join(d['avisos'])))
        print('{:9s} {} casos 3D (de {}) | 5 candidatas {} | {:.1f} s'.format(
            p, len(cs_), len(gr.casos(p)), ids, time.time() - t0))
        # vista do perfil da 1.ª candidata (como o Rhino a vai construir)
        d = descrever(p, ids[0])
        A = amostrar_seg(d['aro'])
        ax.fill(A[:, 0], A[:, 1], color='#2E86C1')
        th = np.linspace(0, 2 * np.pi, 200)
        ax.fill(d['R_i'] * np.cos(th), d['R_i'] * np.sin(th), color='white')
        if d['tipo_raio'] == 'disco':
            Pi = np.array(d['disco_interior'])
            ax.fill(d['disco_r_ext'] * np.cos(th), d['disco_r_ext'] * np.sin(th), color='#5DADE2', alpha=.8)
            ax.fill(Pi[:, 0], Pi[:, 1], color='white', ec='r', lw=1)
        for sgm in d['raios']:
            P = amostrar_seg(sgm)
            ax.fill(P[:, 0], P[:, 1], color='#5DADE2', ec='k', lw=.4)
            ax.plot([sgm[-1][1][0], sgm[-1][2][0]], [sgm[-1][1][1], sgm[-1][2][1]], 'r-', lw=2)
        b = [s for s in d['aro'] if s[0] == 'linha'][1]
        ax.plot([b[1][0], b[2][0]], [b[1][1], b[2][1]], 'm-', lw=3)
        mp = massa_prevista(p, ids[0])
        ax.set_title('{} {}\n2D {:.2f} / 3D prev. {:.2f} kg\nvermelho = fixa, magenta = carga'.format(
            p, ids[0], mp['massa_2d'], mp['massa_3d_prevista']), fontsize=7)
        ax.set_aspect('equal'); ax.axis('off')
    fig.tight_layout(); fig.savefig(os.path.join(AQUI, 'diag', 'teste_3d.png'), dpi=110); plt.close(fig)
    gr.gravar_csv(os.path.join(AQUI, 'diag', 'candidatas_3d_rodas.csv'), linhas)
    r = np.array([l['razao'] for l in linhas])
    print('massa 3D prevista / 2D: min {:.3f} med {:.3f} max {:.3f}'.format(r.min(), np.median(r), r.max()))
    print('[OK] diag/candidatas_3d_rodas.csv, diag/teste_3d.png, diag/intact/*_casos_equivalentes.csv')
