"""
==============================================================================
 GERADOR DE VARIANTES 2D - RODA (uma peça: as 3 rodas do lado são iguais)
==============================================================================
STEP: a roda é uma MALHA facetada = anel maciço Ø506,7 x 335,6 mm, aro de
20,8 mm, sem raios (10 880 cm3 = 30,6 kg em Al 7075).  -> parametrizada de raiz.

Zonas (referencial da roda: u = eixo para FORA, v = marcha, w = vertical):
  VERDE     cubo em anel Ø200/Ø140 x 40 mm aparafusado à flange do joelho (face exterior da
            flange em u = +72 mm; Ø182,9 no traseiro / Ø177,4 no do meio).
  OBSTÁCULO tudo o que está dentro do aro com u < 72 mm: joelho + motor da roda.
            -> os raios só podem estar na fatia u = 72 ... borda exterior.
  PROJETO   aro (casca) + garras + raios (ou disco) até ao diâmetro exterior
            FIXO Ø506,7 (a cinemática e a altura ao solo não mudam).
  A borda INTERIOR do aro fica fixa (u = -167,8): uma roda mais larga cresce para fora.

Gramática (família por planeta = ambiente -> forma):
  Lua, Mercúrio  raios CURVOS: ciclo térmico de 300 / 610 °C -> o aro e o cubo dilatam
                 de forma diferente; um raio reto fica preso (sigma = E alfa dT R/L),
                 um raio curvo dobra (flexível).
  Marte          garras em CHEVRON (tração na areia, como o Curiosity/Perseverance) +
                 aro >= 4 mm (perfuração por rochas aguçadas: lição do Curiosity).
  Europa         garras em PONTA (morder o gelo duro).
  Titã           roda LARGA (1,0-1,25 x) + garras ALTAS (areia orgânica mole).
  Io             raios retos + aro >= 4 mm (lava rugosa com arestas vivas).
  Vénus          DISCO fechado (sem raios): corrosão de 1 mm em TODAS as faces mata
                 os raios finos; o disco tem menos faces expostas por rigidez.
  Regra de recurso (como nas barras): se a família dá < 5 que passam -> raios retos.

Análise (por caso de carga da roda = os do joelho traseiro, sem 'embate'):
  1. aro entre raios (anel em flexão, vão = passo dos raios):  M = P p/8
  2. aro em CONSOLA AXIAL: os raios estão do lado de fora, a carga no meio ou na
     aresta interior -> M = P a, secção = faixa do aro (largura = passo dos raios)
     + garras como NERVURAS axiais (secção em T)
  3. garra em consola: tração (subir_rocha) numa só garra -> M = F h
  4. raio: compressão (+ Euler K = 0,7, + excentricidade do raio curvo) + flexão fora
     do plano (momento lateral F_u R + F_w a repartido por n/2 raios) + flexão no plano
     (binário da tração) + TÉRMICA (dT = 0,15 x amplitude do planeta, HIPÓTESE)
  5. disco: compressão / encurvadura de placa, flexão de placa, corte da torção, térmica
Degradação: genes = peça GASTA (FS); peça NOVA: aro +delta (x2 em Vénus/Io: corrosão
  nas 2 faces), garra +delta na altura e +2 delta na espessura, raios/disco +2 delta.

Uso:   python gerador_rodas.py
Saída: diag/populacoes/<planeta>.csv, diag/<planeta>_top10.csv, diag/dispersao.png,
       diag/resumo_rodas.csv, diag/mais_leves_rodas.png
==============================================================================
"""
import os, sys, csv
import numpy as np
from scipy.stats import qmc

AQUI = os.path.dirname(os.path.abspath(__file__))
_NUC = os.path.normpath(os.path.join(AQUI, '..', 'nucleo'))
if _NUC not in sys.path:
    sys.path.insert(0, _NUC)
if AQUI not in sys.path:
    sys.path.insert(0, AQUI)
import cargas_suspensao as cs
import planetas as pl
import degradacao as dg
import materiais as mt

PECA = 'roda'
SIGLA = 'R'
PREFIXO = {'Lua': 'LUA', 'Mercúrio': 'MER', 'Marte': 'MAR', 'Europa': 'EUR',
           'Titã': 'TIT', 'Io': 'IO', 'Vénus': 'VÉN'}
FAMILIA = {'Lua': 'curvos', 'Mercúrio': 'curvos', 'Marte': 'chevron', 'Europa': 'ponta',
           'Titã': 'larga', 'Io': 'retos', 'Vénus': 'disco'}
NOME_FAM = {'curvos': 'raios curvos', 'chevron': 'garras chevron', 'ponta': 'garras em ponta',
            'larga': 'larga + garras altas', 'retos': 'raios retos', 'disco': 'disco fechado'}
RECURSO = 'retos'
MIN_PASSAM = 5
N_POP = {'Mercúrio': 800, 'Vénus': 800, 'Europa': 800, 'Io': 800}
N_POP_DEF = 400
SEMENTE = 31
TOP = 10

# ---- geometria do STEP / da montagem ----
_R = cs.RODAS['traseira']
R_EXT = float(_R['R'])                  # 253,36: raio exterior (ponta das garras) FIXO
L0 = float(_R['L'])                     # 335,61: largura original
U_IN = -L0 / 2                          # borda interior do aro (fixa)
U_FLANGE = 72.0                         # face exterior da flange do joelho (u, mm)
R_HUB = 100.0                           # cubo verde: Ø200 (flange Ø182,9)
H_HUB = 40.0                            # espessura axial do cubo (raios até 40 mm de profundidade)
R_FURO = 70.0                           # cubo em ANEL Ø200/Ø140 sobre a flange Ø182,9 (HIPÓTESE)
V_VERDE = np.pi * (R_HUB ** 2 - R_FURO ** 2) * H_HUB
V_STEP = float(cs._pecas['roda:1']['volume_mm3'])
L_CONTACTO = 50.0                       # mm: comprimento da mancha de contacto (espalhamento)
K_GRAD = 0.15                           # dT entre aro e cubo = 0,15 x (Tmax - Tmin)  HIPÓTESE
ALFA = {'Al 7075-T6 (CNC)': 23.4e-6, 'Ti-6Al-4V (CNC)': 8.6e-6, 'Ti-6Al-4V (L-PBF+HIP)': 8.6e-6,
        'AlSi10Mg (L-PBF)': 21.0e-6, 'Inconel 718 (CNC)': 13.0e-6}
PAREDE_MIN = {'CNC': 3.0, 'L-PBF': 1.5}
ARO_MIN_TERRENO = {'Io': 4.0}           # + degradacao.parede_min (Marte 4 mm)
FACES_ARO = {'Vénus': 2, 'Io': 2}       # corrosão química nas 2 faces do aro
PONTA_TOPO = 2.0                        # mm: patamar no topo da garra em ponta
K_EULER = 0.7

# genes por família (peça GASTA). Inteiros: n_garras, n_raios
BASE = dict(t_aro=(1.5, 16.0), n_garras=(12, 48), e_garra=(2.0, 12.0), largura=(0.80, 1.00))
RAIOS = dict(n_raios=(4, 12), t_raio=(4.0, 30.0), b_raio=(6.0, 40.0))
GENES = {
    'curvos':  dict(BASE, h_garra=(6.0, 20.0), **RAIOS, curv=(0.04, 0.20)),
    'retos':   dict(BASE, h_garra=(6.0, 20.0), **RAIOS),
    'chevron': dict(BASE, h_garra=(6.0, 20.0), **RAIOS, alfa=(15.0, 35.0)),
    'ponta':   dict(BASE, h_garra=(4.0, 15.0), **RAIOS),
    'larga':   dict(BASE, h_garra=(15.0, 30.0), **RAIOS, largura=(1.00, 1.25)),
    'disco':   dict(BASE, h_garra=(4.0, 15.0), t_disco=(2.0, 30.0)),
}
INTEIROS = {'n_garras', 'n_raios'}
TIPO_RAIO = {'curvos': 'curvo', 'retos': 'reto', 'chevron': 'reto', 'ponta': 'reto', 'larga': 'reto',
             'disco': 'disco'}
TIPO_GARRA = {'curvos': 'reta', 'retos': 'reta', 'chevron': 'chevron', 'ponta': 'ponta', 'larga': 'reta',
              'disco': 'reta'}


def materiais(planeta):
    out = {}
    for nome, base in mt.MATERIAIS.items():
        m, _ = pl.material_no_planeta(nome, base, planeta)
        if m is not None:
            out[nome] = dg.material_gasto(m, planeta)
    return out


def casos(planeta):
    """[(nome, Fu, Fw, Fv, onde)] na roda (sem 'embate', que é aplicado no joelho)."""
    return [(n,) + tuple(c) for n, c in cs.casos_locais(planeta).items() if c[3] != 'joelho']


def dT(planeta):
    T = pl.PLANETAS[planeta]['T']
    return K_GRAD * (max(T) - min(T))


def nova(g, fam, planeta):
    """Dimensões da peça NOVA (genes = peça gasta + pele sacrificial)."""
    dl = dg.de(planeta)['delta']
    n = dict(g)
    n['t_aro'] = g['t_aro'] + FACES_ARO.get(planeta, 1) * dl
    n['h_garra'] = g['h_garra'] + dl
    n['e_garra'] = g['e_garra'] + 2 * dl
    for k in ('t_raio', 'b_raio', 't_disco'):
        if k in g:
            n[k] = g[k] + 2 * dl
    return n


def geometria(g, fam, planeta):
    """Raios e posições da peça NOVA (o exterior Ø506,7 é fixo)."""
    gn = nova(g, fam, planeta)
    L = g['largura'] * L0
    R_o = R_EXT - gn['h_garra']                 # superfície exterior do aro
    R_i = R_o - gn['t_aro']                     # superfície interior do aro
    u_out = U_IN + L
    u_c = U_IN + L / 2                          # meio da largura (contacto 'plano')
    b = gn['t_disco'] if fam == 'disco' else gn['b_raio']
    u_s = U_FLANGE + b / 2                      # plano médio dos raios / disco
    return dict(gn=gn, L=L, R_o=R_o, R_i=R_i, R_m=R_o - gn['t_aro'] / 2, u_out=u_out, u_c=u_c, u_s=u_s,
                b_ax=b, Ls=R_i - R_HUB)


def arco_raio(Ls, curv):
    """Raio curvo: arco tangente ao raio da roda na raiz, flecha s = curv x corda.
    Devolve (flecha, comprimento do arco / corda)."""
    s = curv * Ls
    if s <= 0:
        return 0.0, 1.0
    beta = 4 * np.arctan(2 * curv)              # ângulo do arco para s/c = tan(beta/4)/2
    return s, (beta / 2) / np.sin(beta / 2)


# ------------------------------------------------------------------------------
# avaliação
# ------------------------------------------------------------------------------
def _seccao_T(bf, tf, nr, er_base, er_topo, h):
    """Faixa do aro (bf x tf, z em [-tf, 0]) + nr nervuras trapezoidais (base er_base,
    topo er_topo, altura h, z em [0, h]). -> (A, I, c_max)."""
    A1 = bf * tf; z1 = -tf / 2; I1 = bf * tf ** 3 / 12
    a, b_ = er_base, er_topo
    A2 = nr * (a + b_) / 2 * h
    if A2 > 0:
        z2 = h * (a + 2 * b_) / (3 * (a + b_))
        I2 = nr * h ** 3 * (a ** 2 + 4 * a * b_ + b_ ** 2) / (36 * (a + b_))
    else:
        z2, I2 = 0.0, 0.0
    A = A1 + A2
    zc = (A1 * z1 + A2 * z2) / A
    I = I1 + A1 * (z1 - zc) ** 2 + I2 + A2 * (z2 - zc) ** 2
    return A, I, max(h - zc if A2 > 0 else -zc, zc + tf)


def avaliar(planeta, g, nome_mat, mats=None, fam=None):
    mats = mats or materiais(planeta)
    mat = mats[nome_mat]
    fam = fam or FAMILIA[planeta]
    m = dg.de(planeta)
    proc = 'L-PBF' if 'L-PBF' in nome_mat else 'CNC'
    pmin = PAREDE_MIN[proc]
    G = geometria(g, fam, planeta)
    gn = G['gn']
    E, sy = mat['E'], mat['sy']
    tr, tg = TIPO_RAIO[fam], TIPO_GARRA[fam]
    # ---------- regras / validade ----------
    t_min = max(pmin, m['parede_min'] or 0, ARO_MIN_TERRENO.get(planeta, 0))
    if g['t_aro'] < t_min:
        return dict(valido=False, motivo='aro abaixo do mínimo ({:.1f} mm)'.format(t_min))
    if g['e_garra'] < pmin:
        return dict(valido=False, motivo='garra abaixo do mínimo de fabrico')
    if G['Ls'] < 40:
        return dict(valido=False, motivo='sem espaço para os raios')
    if G['b_ax'] > H_HUB or U_FLANGE + G['b_ax'] > G['u_out'] - 2:
        return dict(valido=False, motivo='raios não cabem entre a flange e a borda')
    n_g = int(g['n_garras'])
    alfa = np.radians(g.get('alfa', 0.0))
    if n_g * gn['e_garra'] / np.cos(alfa) > 0.5 * 2 * np.pi * G['R_o']:
        return dict(valido=False, motivo='garras demasiado juntas')
    if tr != 'disco':
        n_r = int(g['n_raios'])
        if min(g['t_raio'], g['b_raio']) < pmin:
            return dict(valido=False, motivo='raio abaixo do mínimo de fabrico')
        if n_r * gn['t_raio'] > 0.8 * 2 * np.pi * R_HUB:
            return dict(valido=False, motivo='raios não cabem no cubo')
    elif g['t_disco'] < pmin:
        return dict(valido=False, motivo='disco abaixo do mínimo de fabrico')

    # ---------- secções gastas ----------
    t, h, e, L = g['t_aro'], g['h_garra'], g['e_garra'], G['L']
    e_topo = PONTA_TOPO if tg == 'ponta' else e
    p_g = 2 * np.pi * G['R_o'] / n_g
    L_g = L / np.cos(alfa)
    alpha_t = ALFA[nome_mat]
    DT = dT(planeta)
    Ls = G['Ls']
    if tr != 'disco':
        tr_, br_ = g['t_raio'], g['b_raio']
        A_r = tr_ * br_
        Z_in, Z_out = br_ * tr_ ** 2 / 6, tr_ * br_ ** 2 / 6
        I_in = br_ * tr_ ** 3 / 12
        Imin = min(I_in, tr_ * br_ ** 3 / 12)
        Pcr = np.pi ** 2 * E * Imin / (K_EULER * Ls) ** 2
        s_f, f_arc = arco_raio(Ls, g.get('curv', 0.0)) if tr == 'curvo' else (0.0, 1.0)
        # força térmica: o aro dilata alfa dT R_i em relação ao cubo; o raio curvo dobra
        dlt = alpha_t * DT * G['R_i']
        F_th = dlt / (Ls / (E * A_r) + 0.5 * s_f ** 2 * Ls / (E * I_in))
        p_s = 2 * np.pi * G['R_i'] / n_r
        b_eff_axial = lambda a: min(p_s, 2 * a + L_CONTACTO)
    else:
        td = g['t_disco']
        Pcr = None
        b_eff_axial = lambda a: min(np.pi * G['R_m'], 2 * a + L_CONTACTO)
        p_s = 0.0
    nomes, FS_c, comp_c = [], [], []
    for nome, Fu, Fw, Fv, onde in casos(planeta):
        Fu, Fw, Fv = abs(Fu), abs(Fw), abs(Fv)
        u_P = G['u_c'] + {'plano': 0.0, 'aresta_ext': L / 2, 'aresta_int': -L / 2}[onde]
        a = abs(u_P - G['u_s'])
        sig = {}
        # 1. aro entre raios
        if p_s > 0:
            sig['aro (entre raios)'] = 6 * (Fw * p_s / 8) / (L * t ** 2)
        # 2. aro em consola axial (faixa + garras como nervuras)
        bf = b_eff_axial(a)
        nr = bf / p_g
        fac = np.cos(alfa) ** 2
        A_T, I_T, c_T = _seccao_T(bf, t, nr * fac, e, e_topo, h)
        sig['aro (consola axial)'] = Fw * a * c_T / I_T + Fu / A_T
        # 3. garra (uma só garra apanha a aresta da rocha)
        Fg = Fv * np.cos(alfa) + Fu * np.sin(alfa)
        sig['garra'] = 6 * Fg * h / (L_g * e ** 2) + Fw / (L_g * (e + e_topo) / 2)
        # 4/5. raios ou disco
        M_out = Fu * R_EXT + Fw * a
        T = Fv * R_EXT
        if tr != 'disco':
            N = Fw + F_th
            if N >= 0.9 * Pcr:
                return dict(valido=False, motivo='encurvadura dos raios (Euler)')
            amp = 1 / (1 - N / Pcr)
            f_out = 2 * M_out / (n_r * G['R_i'])
            f_t = T / (n_r * G['R_i'])
            s_ax = amp * (N / A_r + N * s_f / Z_in)
            sig['raio'] = s_ax + f_out * Ls / Z_out + f_t * Ls / Z_in
        else:
            sc_ = Fw / (td * 2 * R_HUB)
            scr = 3.6 * E * (td / Ls) ** 2
            s_th = 0.5 * E * alpha_t * DT * G['R_i'] / Ls
            if sc_ + s_th >= 0.9 * scr:
                return dict(valido=False, motivo='encurvadura do disco')
            amp = 1 / (1 - (sc_ + s_th) / scr)
            s_b = 6 * M_out / (td ** 2 * np.pi * R_HUB)
            tau = T / (2 * np.pi * R_HUB ** 2 * td)
            sig['disco'] = np.sqrt((amp * (sc_ + s_th) + s_b) ** 2 + 3 * tau ** 2)
        k = max(sig, key=sig.get)
        nomes.append(nome); FS_c.append(sy / max(sig[k], 1e-9)); comp_c.append(k)
    ic = int(np.argmin(FS_c))
    FS = float(FS_c[ic])
    req = pl.PLANETAS[planeta]['FS']
    V = volumes(G, g, fam)
    rho = mat['rho'] * 1e-9
    return dict(valido=True, massa_kg=(V['total'] + V_VERDE) * rho, massa_proj_kg=V['total'] * rho,
                massa_aro_kg=V['aro'] * rho, massa_garras_kg=V['garras'] * rho, massa_raios_kg=V['raios'] * rho,
                FS_min=FS, FS_req=req, passa=FS >= req, caso_critico=nomes[ic], zona_critica=comp_c[ic],
                G=G, gn=gn)


def volumes(G, g, fam):
    gn = G['gn']
    tg, tr = TIPO_GARRA[fam], TIPO_RAIO[fam]
    alfa = np.radians(g.get('alfa', 0.0))
    V_aro = np.pi * (G['R_o'] ** 2 - G['R_i'] ** 2) * G['L']
    e_t = PONTA_TOPO if tg == 'ponta' else gn['e_garra']
    V_g = int(g['n_garras']) * (gn['e_garra'] + e_t) / 2 * gn['h_garra'] * G['L'] / np.cos(alfa)
    if tr == 'disco':
        V_r = np.pi * (G['R_i'] ** 2 - R_HUB ** 2) * gn['t_disco']
    else:
        _, f_arc = arco_raio(G['Ls'], g.get('curv', 0.0)) if tr == 'curvo' else (0.0, 1.0)
        V_r = int(g['n_raios']) * gn['t_raio'] * gn['b_raio'] * G['Ls'] * f_arc
    return dict(aro=V_aro, garras=V_g, raios=V_r, total=V_aro + V_g + V_r)


# ------------------------------------------------------------------------------
# população
# ------------------------------------------------------------------------------
def limites(planeta, fam=None):
    return dict(GENES[fam or FAMILIA[planeta]])


def amostrar(planeta, n, fam=None):
    L = limites(planeta, fam)
    nomes = list(L)
    mats = list(materiais(planeta))
    sem = SEMENTE + (7 if fam and fam != FAMILIA[planeta] else 0) + 13 * list(FAMILIA).index(planeta)
    X = qmc.LatinHypercube(d=len(nomes) + 1, seed=sem).random(n)
    out = []
    for x in X:
        g = {}
        for j, k in enumerate(nomes):
            lo, hi = L[k]
            g[k] = int(np.floor(lo + x[j] * (hi - lo + 1 - 1e-9))) if k in INTEIROS else float(lo + x[j] * (hi - lo))
        out.append((g, mats[int(x[-1] * len(mats) * (1 - 1e-12))]))
    return out


def vid_de(planeta, i, recurso=False):
    return '{}-{}{}{:03d}'.format(PREFIXO[planeta], SIGLA, 'F' if recurso else '', i)


def _gerar(planeta, n, fam, recurso=False):
    mats = materiais(planeta)
    linhas, res = [], []
    for i, (g, nm) in enumerate(amostrar(planeta, n, fam)):
        g = {k: (round(v, 3) if isinstance(v, float) else v) for k, v in g.items()}
        r = avaliar(planeta, g, nm, mats, fam)
        r['familia'] = fam
        vid = vid_de(planeta, i, recurso)
        lin = dict(id=vid, peca=PECA, planeta=planeta, familia=fam, recurso=int(recurso), material=nm, **g,
                   delta_mm=dg.de(planeta)['delta'], k_deg=dg.de(planeta)['k_mat'])
        if r['valido']:
            lin.update(massa_kg=round(r['massa_kg'], 4), massa_proj_kg=round(r['massa_proj_kg'], 4),
                       massa_aro_kg=round(r['massa_aro_kg'], 4), massa_garras_kg=round(r['massa_garras_kg'], 4),
                       massa_raios_kg=round(r['massa_raios_kg'], 4),
                       FS_min=round(r['FS_min'], 3), FS_req=r['FS_req'], passa=int(r['passa']),
                       caso_critico=r['caso_critico'], zona_critica=r['zona_critica'], motivo='')
        else:
            lin.update(massa_kg='', massa_proj_kg='', massa_aro_kg='', massa_garras_kg='', massa_raios_kg='',
                       FS_min='', FS_req=pl.PLANETAS[planeta]['FS'], passa=0, caso_critico='', zona_critica='',
                       motivo=r['motivo'])
        linhas.append(lin); res.append((vid, g, nm, r))
    return linhas, res


def gerar_populacao(planeta, n=None):
    n = n or N_POP.get(planeta, N_POP_DEF)
    linhas, res = _gerar(planeta, n, FAMILIA[planeta])
    if FAMILIA[planeta] != RECURSO and sum(1 for x in res if x[3].get('passa')) < MIN_PASSAM:
        l2, r2 = _gerar(planeta, 2 * n, RECURSO, recurso=True)
        linhas += l2; res += r2
    return linhas, res


def gravar_csv(caminho, linhas):
    os.makedirs(os.path.dirname(caminho), exist_ok=True)
    chaves = []
    for l in linhas:
        chaves += [k for k in l if k not in chaves]
    with open(caminho, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=chaves, delimiter=';')
        w.writeheader(); w.writerows(linhas)


def massa_original(nome_mat='Al 7075-T6 (CNC)'):
    return V_STEP * mt.MATERIAIS[nome_mat]['rho'] * 1e-9


# ------------------------------------------------------------------------------
# desenho de uma roda (vista lateral, plano v-w) — também usado pelo peca_roda
# ------------------------------------------------------------------------------
def desenhar(ax, g, fam, planeta, titulo=''):
    G = geometria(g, fam, planeta); gn = G['gn']
    th = np.linspace(0, 2 * np.pi, 361)
    ax.fill(np.r_[G['R_o'] * np.cos(th), G['R_i'] * np.cos(th[::-1])],
            np.r_[G['R_o'] * np.sin(th), G['R_i'] * np.sin(th[::-1])], color='#2E86C1', lw=0)
    n_g = int(g['n_garras'])
    tg = TIPO_GARRA[fam]
    e_t = PONTA_TOPO if tg == 'ponta' else gn['e_garra']
    for k in range(n_g):
        a = np.radians(-90 + k * 360 / n_g)
        er, et = np.array([np.cos(a), np.sin(a)]), np.array([-np.sin(a), np.cos(a)])
        P = [G['R_o'] * er - gn['e_garra'] / 2 * et, R_EXT * er - e_t / 2 * et,
             R_EXT * er + e_t / 2 * et, G['R_o'] * er + gn['e_garra'] / 2 * et]
        P = np.array(P)
        ax.fill(P[:, 0], P[:, 1], color='#1B4F72', lw=0)
    if TIPO_RAIO[fam] == 'disco':
        r_ = np.r_[G['R_i'] * np.cos(th), R_HUB * np.cos(th[::-1])]
        ax.fill(r_, np.r_[G['R_i'] * np.sin(th), R_HUB * np.sin(th[::-1])], color='#5DADE2', lw=0)
    else:
        for j in range(int(g['n_raios'])):
            P = perfil_raio(G, g, fam, j)
            ax.fill(P[:, 0], P[:, 1], color='#5DADE2', ec='#1B4F72', lw=.4)
    ax.fill(R_HUB * np.cos(th), R_HUB * np.sin(th), color='#27AE60', lw=0)
    ax.fill(R_FURO * np.cos(th), R_FURO * np.sin(th), color='white', lw=0)
    ax.set_aspect('equal'); ax.axis('off')
    ax.set_xlim(-R_EXT * 1.05, R_EXT * 1.05); ax.set_ylim(-R_EXT * 1.05, R_EXT * 1.05)
    if titulo:
        ax.set_title(titulo, fontsize=7)


def perfil_raio(G, g, fam, j, n_arc=24, r_tip=None):
    """Polígono (v, w) do raio j: raiz PLANA em r = R_HUB (perpendicular ao raio da roda),
    lados retos (reto) ou arcos concêntricos (curvo: arco tangente ao raio na raiz), ponta
    cortada pela circunferência a meio do aro (fica dentro do aro depois da união).
    Ordem: raiz lado 1 -> ponta lado 1 -> arco da ponta -> ponta lado 2 -> raiz lado 2."""
    r_tip = r_tip or (G['R_i'] + G['gn']['t_aro'] / 2)
    L1, L2 = lados_raio(G, g, fam, j, n_arc, r_tip)
    b1, b2 = L1[-1], L2[-1]
    a1, a2 = np.arctan2(b1[1], b1[0]), np.arctan2(b2[1], b2[0])
    if a2 - a1 > np.pi:
        a2 -= 2 * np.pi
    elif a1 - a2 > np.pi:
        a2 += 2 * np.pi
    arc = np.array([r_tip * np.array([np.cos(x), np.sin(x)]) for x in np.linspace(a1, a2, 7)[1:-1]])
    return np.vstack([L1, arc, L2[::-1]])


def lados_raio(G, g, fam, j, n_arc=24, r_tip=None):
    """[lado 1, lado 2]: pontos da raiz até à circunferência da ponta (r_tip)."""
    gn = G['gn']
    n_r = int(g['n_raios'])
    th = np.radians(-90 + (j + 0.5) * 360 / n_r)
    er, et = np.array([np.cos(th), np.sin(th)]), np.array([-np.sin(th), np.cos(th)])
    w = gn['t_raio'] / 2
    r_tip = r_tip or (G['R_i'] + gn['t_aro'] / 2)
    A = R_HUB * er
    out = []
    if TIPO_RAIO[fam] != 'curvo':
        for sg in (-1, 1):
            d = np.sqrt(r_tip ** 2 - w ** 2)
            out.append(np.array([A + sg * w * et, d * er + sg * w * et]))
        return out
    Rc = curva_raio(G, g)
    O = A + Rc * et
    phi0 = np.arctan2(-et[1], -et[0])
    # sentido em que o arco se afasta do centro da roda
    t1 = O + Rc * np.array([np.cos(phi0 + 1e-3), np.sin(phi0 + 1e-3)])
    sent = 1.0 if np.linalg.norm(t1) > R_HUB else -1.0
    phis = np.linspace(0, np.pi, 4001)
    for sg in (-1, 1):
        rho = Rc - sg * w            # sg=-1 -> mais longe de O ... ponto na raiz = A + sg w et
        dirs = np.array([np.cos(phi0 + sent * phis), np.sin(phi0 + sent * phis)]).T
        pts = O + rho * dirs
        r = np.linalg.norm(pts, axis=1)
        k = int(np.argmax(r >= r_tip))
        if k == 0:
            raise ValueError('raio curvo não chega ao aro')
        # interpolação no cruzamento
        f = (r_tip - r[k - 1]) / (r[k] - r[k - 1])
        fim = pts[k - 1] + f * (pts[k] - pts[k - 1])
        ph_fim = phis[k - 1] + f * (phis[k] - phis[k - 1])
        ph = np.linspace(0, ph_fim, n_arc)
        P = O + rho * np.array([np.cos(phi0 + sent * ph), np.sin(phi0 + sent * ph)]).T
        P[-1] = fim
        out.append(P)
    return out


def curva_raio(G, g):
    """Raio Rc do arco médio do raio curvo (tangente radial na raiz, flecha = curv x corda)."""
    beta = 4 * np.arctan(2 * g['curv'])
    # corda c ~ Ls (de R_HUB a R_tip); Rc = c / (2 sin(beta/2))
    c = G['R_i'] + G['gn']['t_aro'] / 2 - R_HUB
    return c / (2 * np.sin(beta / 2))


# ------------------------------------------------------------------------------
def correr():
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    diag = os.path.join(AQUI, 'diag')
    resumo, melhores, todos = [], {}, {}
    mo = massa_original()
    for p in FAMILIA:
        linhas, res = gerar_populacao(p)
        gravar_csv(os.path.join(diag, 'populacoes', p + '.csv'), linhas)
        ok = sorted([x for x in res if x[3]['valido'] and x[3]['passa']], key=lambda x: x[3]['massa_kg'])
        gravar_csv(os.path.join(diag, p + '_top10.csv'), [l for l in linhas if l['id'] in {x[0] for x in ok[:TOP]}])
        todos[p] = res
        val = [x for x in res if x[3]['valido']]
        top = ok[0] if ok else None
        melhores[p] = top
        zonas = {}
        for x in val:
            zonas[x[3]['zona_critica']] = zonas.get(x[3]['zona_critica'], 0) + 1
        resumo.append(dict(planeta=p, familia=FAMILIA[p], familia_mais_leve=top[3]['familia'] if top else '',
                           n=len(res), validas=len(val), passam=len(ok), mais_leve=top[0] if top else '',
                           material=top[2] if top else '', massa_kg=round(top[3]['massa_kg'], 3) if top else '',
                           massa_proj_kg=round(top[3]['massa_proj_kg'], 3) if top else '',
                           massa_original_Al_kg=round(mo, 2), FS=round(top[3]['FS_min'], 2) if top else '',
                           caso_critico=top[3]['caso_critico'] if top else '',
                           zona_critica=top[3]['zona_critica'] if top else '',
                           zonas_criticas_validas='; '.join('{} {}'.format(k, v) for k, v in sorted(zonas.items(), key=lambda kv: -kv[1]))))
        print('{:9s} {:8s} n={} válidas={} passam={}'.format(p, FAMILIA[p], len(res), len(val), len(ok))
              + (' [recurso: {} passam]'.format(sum(1 for x in ok if x[3]['familia'] != FAMILIA[p]))
                 if any(x[3]['familia'] != FAMILIA[p] for x in res) else '')
              + (' | {} {} {:.2f} kg (projeto {:.2f}; aro {:.2f} garras {:.2f} raios {:.2f}) FS {:.2f} [{} / {}]'.format(
                  top[0], top[2].split(' (')[0], top[3]['massa_kg'], top[3]['massa_proj_kg'], top[3]['massa_aro_kg'],
                  top[3]['massa_garras_kg'], top[3]['massa_raios_kg'], top[3]['FS_min'], top[3]['caso_critico'],
                  top[3]['zona_critica']) if top else ''))
    gravar_csv(os.path.join(diag, 'resumo_rodas.csv'), resumo)
    # dispersão
    fig, axs = plt.subplots(2, 4, figsize=(18, 8.5)); axs = axs.ravel()
    cores = {'aro (entre raios)': '#E67E22', 'aro (consola axial)': '#C0392B', 'garra': '#8E44AD',
             'raio': '#2E86C1', 'disco': '#16A085'}
    for ax, p in zip(axs, FAMILIA):
        val = [x for x in todos[p] if x[3]['valido']]
        req = pl.PLANETAS[p]['FS']
        for z, c in cores.items():
            sel = [x for x in val if x[3]['zona_critica'] == z]
            if sel:
                ax.scatter([x[3]['massa_kg'] for x in sel], [x[3]['FS_min'] for x in sel], s=10, c=c, alpha=.6,
                           label='crítico: ' + z)
        tp = sorted([x for x in val if x[3]['passa']], key=lambda x: x[3]['massa_kg'])[:TOP]
        ax.scatter([x[3]['massa_kg'] for x in tp], [x[3]['FS_min'] for x in tp], s=45, facecolors='none',
                   edgecolors='k', label='10 mais leves que passam')
        ax.axhline(req, color='r', ls='--', lw=1)
        ax.axvline(mo, color='k', ls=':', lw=1, label='roda do STEP (Al, maciça)')
        ax.set_yscale('log'); ax.set_xscale('log')
        ax.set_title('{} ({})'.format(p, NOME_FAM[FAMILIA[p]]), fontsize=10)
        ax.set_xlabel('massa da roda [kg]'); ax.set_ylabel('FS (peça gasta)'); ax.grid(alpha=.3, which='both')
    axs[0].legend(fontsize=6.5)
    axs[-1].axis('off')
    fig.suptitle('Roda — população 2D por planeta (com degradação); cor = zona crítica', fontweight='bold')
    fig.tight_layout(); fig.savefig(os.path.join(diag, 'dispersao.png'), dpi=110); plt.close(fig)
    # mais leves
    fig, axs = plt.subplots(1, 7, figsize=(21, 3.6))
    for ax, p in zip(axs, FAMILIA):
        top = melhores[p]
        if not top:
            ax.axis('off'); ax.set_title(p + '\nnenhuma passa', fontsize=8); continue
        vid, g, nm, r = top
        desenhar(ax, g, r['familia'], p, '{}  {}\n{} | {:.2f} kg | FS {:.2f}\n{}'.format(
            p, vid, nm.split(' (')[0].replace('-6Al-4V', ''), r['massa_kg'], r['FS_min'], NOME_FAM[r['familia']]))
    fig.suptitle('Roda — variante mais leve que passa por planeta (vista lateral; verde = cubo, azul = projeto). '
                 'Roda do STEP: {:.1f} kg (Al)'.format(mo), fontsize=10, fontweight='bold')
    fig.tight_layout(rect=(0, 0, 1, 0.9)); fig.savefig(os.path.join(diag, 'mais_leves_rodas.png'), dpi=130); plt.close(fig)
    return resumo


if __name__ == '__main__':
    print('Roda: Ø{:.1f} x {:.1f} | flange u = {:.0f} | cubo Ø{:.0f} x {:.0f} (verde {:.0f} cm3) | STEP {:.0f} cm3 = {:.1f} kg Al'.format(
        2 * R_EXT, L0, U_FLANGE, 2 * R_HUB, H_HUB, V_VERDE / 1e3, V_STEP / 1e3, massa_original()))
    for p in FAMILIA:
        print('  {:9s} dT = {:5.1f} °C | casos: {}'.format(p, dT(p), ', '.join(c[0] for c in casos(p))))
    correr()
    print('[OK] diag/populacoes/*.csv, *_top10.csv, dispersao.png, resumo_rodas.csv, mais_leves_rodas.png')
