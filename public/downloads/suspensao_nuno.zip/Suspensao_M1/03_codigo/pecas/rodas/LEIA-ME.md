# Roda — pipeline 2D + 3D (M1, 02/11)

Pasta: `m1\pecas\rodas\` (usa `..\nucleo\` para cargas, planetas, degradação e materiais).
Uma só peça: as 3 rodas do lado são iguais (mesmo raio, mesmos casos por roda). `montar` troca as 3.

## Ordem
1. `python gerador_rodas.py` (~4 s) → `diag\populacoes\<planeta>.csv`, `diag\<planeta>_top10.csv`, `diag\dispersao.png`,
   `diag\resumo_rodas.csv`, `diag\mais_leves_rodas.png` (vista lateral da mais leve de cada planeta — boa para slides).
2. `python peca_roda.py` (~2 s) → `diag\candidatas_3d_rodas.csv`, `diag\teste_3d.png` (perfil que o Rhino vai construir,
   face fixa a vermelho, carga a magenta), `diag\intact\<planeta>_casos_equivalentes.csv`.
3. Rhino: `_ScriptEditor` → `teste_rhino_rodas.py` → Run → `diag\teste_rhino_rodas.txt` + camada `Teste_rodas`.
4. Grasshopper (`pecas.gh`): Panel PECA = `roda`; **N = 5**.

## Modelo
- STEP: a roda é uma MALHA facetada = anel maciço Ø506,7 × 335,6, aro de 20,8 mm, sem raios: 10 880 cm³ = **30,6 kg em Al**.
  → parametrizada de raiz.
- **VERDE:** cubo em anel Ø200/Ø140 × 40 mm aparafusado à flange do joelho (face exterior da flange: u = +72,0 mm no
  traseiro/frente, +69,8 no do meio — a montagem encosta o cubo a cada flange).
- **OBSTÁCULO:** o interior do aro com u < 72 (joelho + motor da roda) → os raios só podem estar entre a flange e a
  borda exterior (fatia u = 72…72 + b, b ≤ 40).
- **PROJETO:** aro (casca) + garras + raios/disco, com o Ø exterior FIXO (cinemática e altura ao solo iguais).
  A borda interior do aro fica fixa; uma roda mais larga cresce para fora.
- Genes: `t_aro`, `n_garras`, `h_garra`, `e_garra`, `largura` (fração de 335,6), `n_raios`, `t_raio` (tangencial),
  `b_raio` (axial), `curv` (flecha/corda do raio curvo), `alfa` (ângulo do chevron), `t_disco`.

## Gramática (planeta → forma)
| planeta | família | regra |
|---|---|---|
| Lua, Mercúrio | raios curvos | ciclo térmico 300 / 610 °C: aro e cubo dilatam diferente; o raio reto fica preso (σ = E α ΔT R/L), o curvo dobra |
| Marte | garras em chevron | tração na areia (Curiosity/Perseverance) + aro ≥ 4 mm (perfuração: lição do Curiosity) |
| Europa | garras em ponta | morder o gelo duro |
| Titã | larga + garras altas | areia orgânica mole: largura 1,0–1,25×, garras 15–30 mm |
| Io | raios retos | lava rugosa com arestas vivas: aro ≥ 4 mm |
| Vénus | disco fechado | 1 mm de corrosão em TODAS as faces mata os raios finos |
| (recurso) | raios retos | se a família dá < 5 que passam (como nas barras) |

## Análise 2D (por caso: os do joelho traseiro sem `embate`, que é aplicado no joelho)
1. aro entre raios (anel em flexão, vão = passo dos raios), M = P p/8;
2. **aro em consola axial**: os raios estão do lado de fora, a carga no meio ou na aresta INTERIOR → M = P a;
   secção = faixa do aro (largura = passo dos raios) + garras como nervuras axiais (secção em T);
3. garra em consola: tração (`subir_rocha`) numa só garra, M = F h;
4. raio: compressão (Euler K = 0,7) + excentricidade do raio curvo + flexão fora do plano (F_u R + F_w a, repartido
   por n/2 raios) + flexão no plano (binário da tração) + **térmica** (ΔT = 0,15 × amplitude do planeta, HIPÓTESE);
5. disco: compressão + encurvadura de placa + flexão de placa + corte da torção + térmica.
Degradação: genes = peça GASTA; nova: aro + δ (×2 em Vénus/Io), garra + δ na altura e + 2δ na espessura, raios/disco + 2δ.

## Resultados 2D (mais leve que passa; roda do STEP = 30,6 kg Al)
| planeta | família | passam | mais leve | material | massa kg | FS | crítico |
|---|---|---|---|---|---|---|---|
| Lua | curvos | 185 | LUA-R132 | Al 7075-T6 | 12,75 | 2,07 | aterragem / aro (consola axial) |
| Mercúrio | curvos → **recurso retos** | 64 | MER-RF729 | Ti-6Al-4V L-PBF | 25,69 | 2,50 | queda_lat+ / raio |
| Marte | chevron | 137 | MAR-R243 | Al 7075-T6 | 12,90 | 2,58 | aresta_int / aro (consola axial) |
| Europa | ponta | 401 | EUR-R523 | Al 7075-T6 | 12,67 | 4,27 | queda_lat+ / aro (consola axial) |
| Titã | larga | 331 | TIT-R150 | Al 7075-T6 | 9,89 | 11,6 | subir_rocha / raio |
| Io | retos | 458 | IO-R422 | Al 7075-T6 | 11,98 | 3,52 | queda_lat+ / raio |
| Vénus | disco | 165 | VÉN-R044 | Ti-6Al-4V | 39,07 | 2,85 | queda_lat+ / aro (consola axial) |

Mensagens:
- **−58 a −68 %** de massa em Lua/Marte/Europa/Titã/Io; o aro é ~70 % da massa (a consola axial manda: os raios só
  cabem do lado de fora por causa do motor).
- **Mercúrio**: a 430 °C o Al não serve; em Ti (α pequeno) o alívio térmico do raio curvo vale menos que a
  excentricidade que ele cria → o melhor curvo fica em FS 2,19 < 2,2 e a gramática recorre a raios retos.
- **Titã**: FS 11,6 — limitada pelas regras de terreno/fabrico (largura, garras altas, espessuras mínimas), não pela resistência.
- **Vénus**: 39 kg (> STEP) — g = 8,87, 465 °C, FS 2,5 e 1 mm de corrosão em todas as faces.

## 3D
- Massa 3D prevista / 2D das 5 candidatas: 0,97–1,01.
- 7 casos 3D (queda + aterragem → `vertical_max`). `POR_VARIANTE = True`: `gh_intact_peca.py` passa a variante a
  `lista_casos` e `dist_ligacoes` (o contacto e a garra carregada dependem da largura).
- Face FIXA = raízes planas dos raios em r = 100 (disco: 24 faces planas); face de CARGA = topo da garra de baixo.
- `montar(planeta)`: filas 41–47 (FILA0 = 41), camada `Montagem_rodas::<planeta>`, as 3 rodas do STEP trocadas
  pela variante + cubo verde, exporta `diag\intact\<planeta>_<id>_suspensao.stp`.

## Hipóteses / a verificar
1. Espaço livre dos raios = fatia u ≥ 72 (flange) — VERIFICAR no Rhino que o joelho não entra lá.
2. Cubo verde em anel Ø200/Ø140 × 40 (furação/aperto à flange não modelados).
3. ΔT aro–cubo = 0,15 × (Tmax − Tmin); mancha de contacto 50 mm; uma só garra apanha a aresta da rocha.
4. Chevron no 3D = loft reto (topos das garras regrados, não planos): face de carga identificada pela posição.
5. Intact numa peça Ø507 com aro de 3–8 mm pode ser lento (pontos finos): ver tempo no 1.º caso.
