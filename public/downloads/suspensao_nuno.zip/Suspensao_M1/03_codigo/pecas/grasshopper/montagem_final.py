#! python3
# r: numpy, scipy, matplotlib
r"""
MONTAGEM FINAL — 2 SUSPENSÕES COMPLETAS POR PLANETA (02/11, chat 12)

    suspensão 1 = a MELHOR de cada peça     (1.ª linha de <planeta>_top3.csv de cada peça)
    suspensão 2 = a SEGUNDA melhor de cada peça (2.ª linha; se só 1 passou, repete a 1.ª)

Peças trocadas (o resto do STEP — suportes, articulações, atuador, dobradiças — fica igual):
    joelho traseiro x2 (traseira + frente: o da frente é o espelho, como no rhino_montar_top3.py)
    joelho do meio, barra traseira, barra do meio, barra do frente, barra esquerda, roda x3
Cada peça nova = variante (NURBS) + zonas verdes cortadas do STEP (como no montar() de cada peça).
Se uma peça não tem nenhuma variante que passou em 3D, fica a ORIGINAL do STEP (aparece no resumo).

Saídas em C:\Mestrado\designD\m1\pecas\final\ :
    <planeta>_suspensao_1.stp / _2.stp   (para o Fusion; na POSIÇÃO ORIGINAL do STEP da NASA)
    <planeta>_suspensao_1.csv / _2.csv   (peça, id, material, FS 3D, volume e massa no Rhino, massa original)
    resumo_suspensoes.csv                (todas; também se faz SEM Rhino: python montagem_final.py)
No Rhino: camada Montagem_final::<planeta>::suspensao_<k> (fila 50 + planeta, ao lado das outras).

COMO CORRER
  - Sozinho no fim do ciclo (gh_maestro_peca com PECA = "ciclo").
  - À mão: _ScriptEditor -> abrir este ficheiro -> PLANETA = "Lua" (ou "todos") -> Run.
    Precisa do STEP da suspensão importado no Rhino (se não estiver, importa-o).
"""
PLANETA = "todos"

import os
import sys
import csv
import json

GH = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else r"C:\Mestrado\designD\m1\pecas\gh"
if GH not in sys.path:
    sys.path.insert(0, GH)
import pecas_registo as reg

BASE = reg.BASE if os.path.isdir(reg.BASE) else os.path.dirname(GH)
SAIDA = os.path.join(BASE, "final")
TRASEIRO = r"C:\Mestrado\designD\m1\joelho_traseiro_STEP"
STEP = os.path.join(TRASEIRO, "step", "suspensao_v1.step")
INVENTARIO = os.path.join(BASE, "nucleo", "dados", "inventario.json")
FOLGA_MM = 600.0
FILA0 = 50                 # filas: joelho do meio 1-7, barras 9-39, rodas 41-47, montagem final 50-56
RHO_AL_ORIGINAL = 2810.0   # kg/m3: o STEP original considerado em Al 7075 (como nos resumos das peças)
RHO_PREFIXO = [("Al", 2810.0), ("Ti", 4430.0), ("Inconel", 8190.0)]   # recurso, se o módulo não der rho

# peça -> (nome no STEP, quantas no lado, pasta dos resultados 3D)
PECAS_FINAL = [
    ("joelho traseiro", "joelho traserio", 2, reg.SAIDA_TRASEIRO),
    ("joelho do meio", "joleho do meio", 1, reg.SAIDAS["joelho do meio"]),
    ("barra traseira", "barra traseira", 1, reg.SAIDAS["barra traseira"]),
    ("barra do meio", "barra do meio", 1, reg.SAIDAS["barra do meio"]),
    ("barra do frente", "barra do frente", 1, reg.SAIDAS["barra do frente"]),
    ("barra esquerda", "barra esquerda", 1, reg.SAIDAS["barra esquerda"]),
    ("roda", "roda", 3, reg.SAIDAS["roda"]),
]


def _f(x, d=None):
    try:
        return float(x)
    except Exception:
        return d


# ==============================================================================
# PARTE SEM RHINO: escolha das variantes + resumo
# ==============================================================================
def ler_top(pasta, planeta):
    f = os.path.join(pasta, planeta + "_top3.csv")
    if not os.path.exists(f):
        return []
    return list(csv.DictReader(open(f, encoding="utf-8-sig"), delimiter=";"))


def escolha(planeta, k):
    """{peça: (linha do top3 ou None, nota)} para a suspensão k (1 ou 2)."""
    out = {}
    for peca, _, _, pasta in PECAS_FINAL:
        top = ler_top(pasta, planeta)
        if len(top) >= k:
            out[peca] = (top[k - 1], "")
        elif top:
            out[peca] = (top[0], "só 1 passou em 3D: repete a 1.ª")
        else:
            out[peca] = (None, "nenhuma passou em 3D (ou ainda não corrida): fica a ORIGINAL do STEP")
    return out


def volumes_originais():
    """{nome no STEP: volume total no lado (mm3)} a partir do inventário do STEP."""
    try:
        inv = json.load(open(INVENTARIO, encoding="utf-8"))["pecas"]
    except Exception:
        return {}
    out = {}
    for _, nome, _, _ in PECAS_FINAL:
        out[nome] = sum(q["volume_mm3"] for q in inv if nome in q["nome"].lower())
    return out


def resumo_sem_rhino(planetas=None, gravar=True):
    """Tabela das 2 suspensões por planeta com a massa 3D dos resumos do Intact (sem Rhino).
    massa_3d = como em cada peça (variante + zonas verdes); original = volume do STEP x Al."""
    planetas = planetas or reg.PLANETAS_CICLO
    vo = volumes_originais()
    linhas = []
    for pl in planetas:
        for k in (1, 2):
            tot = tot_o = 0.0
            falta = []
            for peca, nome, n, _ in PECAS_FINAL:
                lin, nota = escolha(pl, k)[peca]
                m_o = vo.get(nome, 0.0) * RHO_AL_ORIGINAL * 1e-9
                m = _f(lin.get("massa_3d")) * n if lin else m_o
                if lin is None:
                    falta.append(peca)
                if peca == "joelho traseiro":
                    # a massa 3D do traseiro é só a zona de projeto (sem os encaixes verdes do STEP):
                    # não se compara com o STEP inteiro aqui -> massa real no <planeta>_suspensao_k.csv (Rhino)
                    m_o = ""
                    nota = (nota + "; " if nota else "") + "massa = zona de projeto (sem verdes); fora do total"
                else:
                    tot += m
                    tot_o += m_o
                linhas.append(dict(planeta=pl, suspensao=k, peca=peca, quantidade=n,
                                   id=lin["id"] if lin else "ORIGINAL", material=lin.get("material", "") if lin else "Al (STEP)",
                                   FS_3d=lin.get("FS_3d", "") if lin else "", massa_kg=round(m, 3),
                                   massa_original_kg=round(m_o, 3) if m_o != "" else "", nota=nota))
            linhas.append(dict(planeta=pl, suspensao=k, peca="TOTAL sem joelhos traseiros", quantidade="", id="",
                               material="", FS_3d="", massa_kg=round(tot, 2), massa_original_kg=round(tot_o, 2),
                               nota=("faltam: " + ", ".join(falta)) if falta else
                               "{:+.0f} % vs original".format(100 * (tot / tot_o - 1) if tot_o else 0)))
    if gravar:
        os.makedirs(SAIDA, exist_ok=True)
        with open(os.path.join(SAIDA, "resumo_suspensoes.csv"), "w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=list(linhas[0]), delimiter=";")
            w.writeheader()
            w.writerows(linhas)
    return linhas


# ==============================================================================
# PARTE RHINO
# ==============================================================================
def _rhino():
    global System
    import System
    import Rhino
    import Rhino.Geometry as rg
    import scriptcontext as sc
    import rhinoscriptsyntax as rs
    return Rhino, rg, sc, rs


def _brep(g, xf):
    Rhino, rg, sc, rs = _rhino()
    b = None
    if isinstance(g, rg.Brep):
        b = g.DuplicateBrep()
    elif isinstance(g, rg.Extrusion):
        b = g.ToBrep()
    elif isinstance(g, rg.Mesh):
        b = g.DuplicateMesh()
    if b is not None:
        b.Transform(xf)
    return b


def pecas_do_step():
    """[(nome completo em minúsculas, geometria global)] de todas as peças do STEP no Rhino.
    O nome junta os nomes do bloco e dos sub-blocos. Ignora o que os scripts criaram."""
    Rhino, rg, sc, rs = _rhino()
    out = []

    def descer(idef, xf, nome):
        for o in idef.GetObjects():
            g = o.Geometry
            n = nome + " / " + (o.Attributes.Name or "")
            if isinstance(g, rg.InstanceReferenceGeometry):
                sub = sc.doc.InstanceDefinitions.FindId(g.ParentIdefId)
                descer(sub, xf * g.Xform, n + " / " + (sub.Name or ""))
            else:
                b = _brep(g, xf)
                if b is not None:
                    out.append((n.lower(), b))

    cfg = Rhino.DocObjects.ObjectEnumeratorSettings()
    cfg.HiddenObjects = True
    cfg.LockedObjects = True
    for o in sc.doc.Objects.GetObjectList(cfg):
        if o.IsDeleted:
            continue
        lay = sc.doc.Layers[o.Attributes.LayerIndex].FullPath
        if lay.startswith(("Joelho_completo", "Montagem", "Intact", "Teste_", "Suspensao_")):
            continue
        g = o.Geometry
        n = o.Attributes.Name or ""
        if isinstance(g, rg.InstanceReferenceGeometry):
            idef = sc.doc.InstanceDefinitions.FindId(g.ParentIdefId)
            descer(idef, g.Xform, n + " / " + (idef.Name or ""))
        else:
            b = _brep(g, rg.Transform.Identity)
            if b is not None:
                out.append((n.lower(), b))
    return out


def _volume(g):
    Rhino, rg, sc, rs = _rhino()
    try:
        vp = rg.VolumeMassProperties.Compute(g)
        return abs(vp.Volume) if vp is not None else 0.0
    except Exception:
        return 0.0


def _rho(pm, planeta, nome_mat):
    try:
        return float(pm.material(planeta, nome_mat)["rho"])
    except Exception:
        for p, r in RHO_PREFIXO:
            if str(nome_mat).startswith(p):
                return r
    return RHO_AL_ORIGINAL


def _traseiro(planeta, vid, joelhos, tol):
    """04/11: o código do traseiro lê 'diag/populacoes/<planeta>.csv' com caminho RELATIVO
    -> correr com a pasta do joelho traseiro como pasta atual."""
    cwd0 = os.getcwd()
    os.chdir(TRASEIRO)
    try:
        return _traseiro_core(planeta, vid, joelhos, tol)
    finally:
        os.chdir(cwd0)


def _traseiro_core(planeta, vid, joelhos, tol):
    """Joelho traseiro: variante + verdes, na traseira E na frente (espelho). Mesmo código do
    rhino_montar_top3.py (que NÃO se altera: é usado pelo lote do traseiro)."""
    Rhino, rg, sc, rs = _rhino()
    import numpy as np
    if TRASEIRO not in sys.path:
        sys.path.append(TRASEIRO)          # no FIM: não tapa os módulos das peças novas
    import rhino_montar_top3 as rmt
    cwd = os.getcwd()
    try:
        gv, j3, fa, rf, po = rmt._modulos()
    finally:
        os.chdir(cwd)
    G = gv._NS["geometria"]
    O, U, W, V = (np.array(G["referencial"][k], float) for k in ("origem_mm", "u", "w", "v"))
    X_S = G["x_fronteira_preservar"]
    ZC = j3.B_INTERFACE / 2.0

    def p3(x, y, z=ZC):
        P = O + x * U + y * W + (z - ZC) * V
        return rg.Point3d(float(P[0]), float(P[1]), float(P[2]))

    o_pt = rg.Point3d(*[float(c) for c in O])
    perto = [b for b in joelhos if b.GetBoundingBox(True).Center.DistanceTo(o_pt) < 1500]
    longe = [b for b in joelhos if b not in perto]
    espelho = None
    if perto and longe:
        bb1, bb2 = rg.BoundingBox.Empty, rg.BoundingBox.Empty
        for b in perto:
            bb1.Union(b.GetBoundingBox(True))
        for b in longe:
            bb2.Union(b.GetBoundingBox(True))
        c1, c2 = bb1.Center, bb2.Center
        n = c2 - c1
        if n.Length > 1:
            espelho = rg.Transform.Mirror(rg.Plane(0.5 * (c1 + c2), n))
    caixa = rg.Box(rg.Plane(p3(X_S, 0.0), rg.Vector3d(*U), rg.Vector3d(*W)),
                   rg.Interval(0.0, 2000.0), rg.Interval(-2000.0, 2000.0), rg.Interval(-2000.0, 2000.0)).ToBrep()
    verdes = []
    for b in perto:
        if isinstance(b, rg.Brep):
            r = rg.Brep.CreateBooleanIntersection(b, caixa, tol)
            if r:
                verdes.extend(list(r))
    if not verdes:
        raise Exception("joelho traseiro: o corte das zonas verdes falhou")
    sel = [l for l in po.ler_populacao(planeta) if l["id"] == vid]
    genes = po.genes_de_linha(sel[0])
    rv = po.avaliar(planeta, genes, contornos=True)
    f = dict(rv["geo"], base=rv["esq"], planeta=planeta)
    sil = lambda *_: None
    if rv["familia"] == "fechada":
        var = rf.fechada(f, O, U, W, ZC, tol, log=sil)
    elif rv["familia"] == "trelica":
        var = rf.trelica(f, O, U, W, ZC, tol, j3.B_INTERFACE, X_S, log=sil)
    else:
        var = rf.isogrid(f, O, U, W, ZC, tol, X_S, log=sil)
    lados = [rg.Transform.Identity] + ([espelho] if espelho is not None else [])
    novas, verdes_out = [], []
    for xf in lados:
        g = var.DuplicateBrep()
        g.Transform(xf)
        novas.append(g)
        for b in verdes:
            h = b.DuplicateBrep()
            h.Transform(xf)
            verdes_out.append(h)
    return novas, verdes_out, None


def _peca_nova(peca, planeta, vid, originais, tol):
    """(variantes, verdes, módulo geo) da peça nova, em coordenadas do STEP."""
    Rhino, rg, sc, rs = _rhino()
    pm, rm = reg.modulos(peca)
    if peca == "joelho do meio":
        var = rm.construir(planeta, vid, tol)["peca"]
        return [var], rm.zonas_verdes_step(originais, tol), pm
    if peca.startswith("barra"):
        import rhino_barra as rb
        var = rb.construir(peca, planeta, vid, tol)["peca"]
        return [var], rb.verdes_step(peca, originais, tol), pm
    if peca == "roda":
        var = rm.construir(planeta, vid, tol)["peca"]
        cubo = rm.cubo_verde(tol)
        novas, verdes = [], []
        for nr in pm.cs.RODAS:
            xf = rm.para_roda(nr)
            g = var.DuplicateBrep()
            g.Transform(xf)
            novas.append(g)
            if cubo is not None:
                h = cubo.DuplicateBrep()
                h.Transform(xf)
                verdes.append(h)
        return novas, verdes, pm
    raise Exception("peça desconhecida: " + peca)


def _separar(pecas_step):
    """{peça: [geometrias originais]} + resto (o que não se troca)."""
    grupos = {p: [] for p, _, _, _ in PECAS_FINAL}
    resto = []
    for nome, g in pecas_step:
        dono = None
        # do nome mais "fundo" (o próprio sólido) para o do bloco de cima: o 1.º que corresponde decide
        for seg in reversed([x.strip() for x in nome.split(" / ") if x.strip()]):
            for p, nome_step, _, _ in PECAS_FINAL:
                if nome_step in seg:
                    dono = p
                    break
            if dono:
                break
        (grupos[dono] if dono else resto).append(g)
    return grupos, resto


def _camada(nome, cor):
    Rhino, rg, sc, rs = _rhino()
    if not rs.IsLayer(nome):
        rs.AddLayer(nome, cor)
    return sc.doc.Layers.FindByFullPath(nome, -1)


def montar_suspensao_completa(planeta, exportar=True):
    Rhino, rg, sc, rs = _rhino()
    planeta = [p for p in reg.PLANETAS_CICLO if reg._tira(p) == reg._tira(planeta)][0]
    tol = sc.doc.ModelAbsoluteTolerance
    for p, _, _, _ in PECAS_FINAL[1:]:
        reg.modulos(p)            # carrega já os módulos das peças novas (antes dos do joelho traseiro)
    pecas = pecas_do_step()
    if not any("roda" in n for n, _ in pecas) and os.path.exists(STEP):
        rs.Command('_-Import "{}" _Enter'.format(STEP), echo=False)
        pecas = pecas_do_step()
    grupos, resto = _separar(pecas)
    em_falta = [p for p, g in grupos.items() if not g]
    if em_falta:
        raise Exception("Não encontrei no Rhino: {} (importa o STEP da suspensão)".format(", ".join(em_falta)))
    bb = rg.BoundingBox.Empty
    for _, g in pecas:
        bb.Union(g.GetBoundingBox(True))
    passo_x = bb.Max.X - bb.Min.X + FOLGA_MM
    passo_y = bb.Max.Y - bb.Min.Y + FOLGA_MM
    fila = FILA0 + reg.PLANETAS_CICLO.index(planeta)
    os.makedirs(SAIDA, exist_ok=True)
    vo = volumes_originais()
    msgs = []
    rs.EnableRedraw(False)
    try:
        _camada("Montagem_final", (120, 120, 120))
        _camada("Montagem_final::" + planeta, (120, 120, 120))
        for k in (1, 2):
            esc = escolha(planeta, k)
            mover = rg.Transform.Translation(rg.Vector3d(passo_x * k, -passo_y * fila, 0.0))
            raiz = "Montagem_final::{}::suspensao_{}".format(planeta, k)
            ids, linhas = [], []

            def junta(geo, lay, nm):
                g = geo.Duplicate()
                g.Transform(mover)
                a = Rhino.DocObjects.ObjectAttributes()
                a.LayerIndex = lay
                a.Name = nm
                ids.append(sc.doc.Objects.AddMesh(g, a) if isinstance(g, rg.Mesh) else sc.doc.Objects.AddBrep(g, a))

            lay_r = _camada(raiz + "::resto_do_STEP", (150, 150, 150))
            for i, g in enumerate(resto):
                junta(g, lay_r, "step_{}".format(i + 1))
            m_tot = m_tot_o = 0.0
            for peca, nome_step, n, _ in PECAS_FINAL:
                lin, nota = esc[peca]
                slug = peca.replace(" ", "_")
                m_o = vo.get(nome_step, 0.0) * RHO_AL_ORIGINAL * 1e-9
                m_tot_o += m_o
                if lin is None:
                    lay = _camada(raiz + "::" + slug + "_ORIGINAL", (200, 120, 60))
                    for i, g in enumerate(grupos[peca]):
                        junta(g, lay, "{}_original_{}".format(slug, i + 1))
                    m_tot += m_o
                    linhas.append(dict(peca=peca, quantidade=n, id="ORIGINAL", material="Al (STEP)", FS_3d="",
                                       massa_3d_intact_kg="", volume_rhino_cm3=round(vo.get(nome_step, 0.0) / 1e3, 1),
                                       massa_rhino_kg=round(m_o, 3), massa_original_kg=round(m_o, 3), nota=nota))
                    continue
                vid = lin["id"]
                try:
                    if peca == "joelho traseiro":
                        novas, verdes, pm = _traseiro(planeta, vid, grupos[peca], tol)
                        pm = reg.modulos("joelho do meio")[0]          # só para o rho do material
                    else:
                        novas, verdes, pm = _peca_nova(peca, planeta, vid, grupos[peca], tol)
                except Exception as e:
                    # não consegui construir: fica a original, e diz-se porquê
                    lay = _camada(raiz + "::" + slug + "_ORIGINAL", (200, 120, 60))
                    for i, g in enumerate(grupos[peca]):
                        junta(g, lay, "{}_original_{}".format(slug, i + 1))
                    m_tot += m_o
                    linhas.append(dict(peca=peca, quantidade=n, id="ORIGINAL", material="Al (STEP)", FS_3d="",
                                       massa_3d_intact_kg="", volume_rhino_cm3="", massa_rhino_kg=round(m_o, 3),
                                       massa_original_kg=round(m_o, 3), nota="{} falhou: {}".format(vid, e)))
                    continue
                lay_v = _camada(raiz + "::" + slug, (60, 110, 200))
                lay_g = _camada(raiz + "::" + slug + "_verde_STEP", (60, 180, 60))
                for i, g in enumerate(novas):
                    junta(g, lay_v, "{}_{}_{}".format(slug, vid, i + 1))
                for i, g in enumerate(verdes):
                    junta(g, lay_g, "{}_{}_verde{}".format(slug, vid, i + 1))
                vol = sum(_volume(g) for g in novas + verdes)
                m = vol * _rho(pm, planeta, lin.get("material", "")) * 1e-9
                m_tot += m
                linhas.append(dict(peca=peca, quantidade=n, id=vid, material=lin.get("material", ""),
                                   FS_3d=lin.get("FS_3d", ""), massa_3d_intact_kg=lin.get("massa_3d", ""),
                                   volume_rhino_cm3=round(vol / 1e3, 1), massa_rhino_kg=round(m, 3),
                                   massa_original_kg=round(m_o, 3), nota=nota))
            linhas.append(dict(peca="TOTAL (peças trocadas)", quantidade="", id="", material="", FS_3d="",
                               massa_3d_intact_kg="", volume_rhino_cm3="", massa_rhino_kg=round(m_tot, 2),
                               massa_original_kg=round(m_tot_o, 2),
                               nota="{:+.0f} % vs original".format(100 * (m_tot / m_tot_o - 1) if m_tot_o else 0)))
            rs.AddObjectsToGroup(ids, rs.AddGroup("suspensao_{}_{}".format(planeta, k)))
            with open(os.path.join(SAIDA, "{}_suspensao_{}.csv".format(planeta, k)), "w", newline="",
                      encoding="utf-8-sig") as f:
                w = csv.DictWriter(f, fieldnames=list(linhas[0]), delimiter=";")
                w.writeheader()
                w.writerows(linhas)
            txt = "suspensão {}: {:.1f} kg (original {:.1f} kg)".format(k, m_tot, m_tot_o)
            if exportar:
                # 02/11: o STEP sai na POSIÇÃO ORIGINAL do STEP da NASA (no Rhino as suspensões ficam
                # afastadas para se verem todas; para exportar voltam ao sítio e depois regressam)
                destino = os.path.join(SAIDA, "{}_suspensao_{}.stp".format(planeta, k))
                volta = rg.Transform.Translation(rg.Vector3d(-passo_x * k, passo_y * fila, 0.0))
                ida = rg.Transform.Translation(rg.Vector3d(passo_x * k, -passo_y * fila, 0.0))
                ids_o = [sc.doc.Objects.Transform(i_, volta, True) for i_ in ids]   # (o id pode mudar)
                ids_o = [i_ for i_ in ids_o if i_ != System.Guid.Empty]
                try:
                    rs.UnselectAllObjects()
                    rs.SelectObjects(ids_o)
                    rs.Command('_-Export "{}" _Enter _Enter'.format(destino), echo=False)
                    rs.UnselectAllObjects()
                finally:
                    ids = [sc.doc.Objects.Transform(i_, ida, True) for i_ in ids_o]
                txt += " -> " + os.path.basename(destino) + " (posição original)"
            msgs.append(txt)
    finally:
        rs.EnableRedraw(True)
    return "{}: {}".format(planeta, "; ".join(msgs))


def montar_todas(planetas=None, exportar=True):
    planetas = planetas or reg.PLANETAS_CICLO
    msgs = []
    for pl in planetas:
        try:
            msgs.append(montar_suspensao_completa(pl, exportar))
        except Exception as e:
            msgs.append("{}: FALHOU ({})".format(pl, e))
    try:
        resumo_sem_rhino(planetas)
    except Exception:
        pass
    txt = "\n".join(msgs)
    try:
        os.makedirs(SAIDA, exist_ok=True)
        with open(os.path.join(SAIDA, "log_montagem_final.txt"), "w", encoding="utf-8") as f:
            f.write(txt + "\n")
    except Exception:
        pass
    return txt


if __name__ == "__main__":
    try:
        import Rhino  # noqa: F401
        TEM_RHINO = True
    except Exception:
        TEM_RHINO = False
    if TEM_RHINO:
        print(montar_todas() if reg._tira(PLANETA) == "todos" else montar_suspensao_completa(PLANETA))
    else:
        for l in resumo_sem_rhino():
            if l["peca"].startswith("TOTAL"):
                print(l["planeta"], l["suspensao"], l["massa_kg"], "kg | original", l["massa_original_kg"], "|", l["nota"])
