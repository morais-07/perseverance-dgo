#! python3
# r: numpy, scipy, matplotlib
r"""
SELETOR DE DESIGNS — demonstração da apresentação M1 (v2, 03/11 noite)

    AMBIENTE (planeta)  ->  REGRAS da gramática  ->  GEOMETRIA (peça gerada e verificada)

Componente Python 3 do Grasshopper no ficheiro NOVO seletor.gh (NÃO no pecas.gh do ciclo).
Invólucro de 3 linhas:
    #! python3
    # r: numpy, scipy, matplotlib
    exec(open(r"C:\Mestrado\designD\m1\pecas\gh\seletor_suspensao.py", encoding="utf-8").read())

Não simula nada. Só lê resultados já feitos e constrói a geometria da variante (alguns segundos
da 1.ª vez; depois fica em memória).

ENTRADAS (nomes exatos; todas opcionais)
  modo       (str)  "peca" (defeito) ou "suspensao"
  planeta    (str)  Lua, Marte, Mercúrio, Europa, Titã, Io, Vénus
  peca       (str)  joelho traseiro, joelho do meio, barra traseira, barra do meio,
                    barra do frente, barra esquerda, roda
  suspensao  (int)  1 = a melhor variante, 2 = a segunda melhor
  variante   (str)  id à mão (ex. LUA-BM032). Vazio = a escolhida por 'suspensao'
  isolar     (bool) True = esconde as camadas do Rhino (só se vê o preview do Grasshopper)
  enquadrar  (bool) True = zoom quando a escolha muda
  recarregar (bool) True = volta a ler o STEP do Rhino (se mudaste o ficheiro)

SAÍDAS (ligar cada uma a um Custom Preview com cor)
  info   texto para um Panel (ambiente, regras, variante, material, massa, FS)
  geo    a peça gerada (AZUL)
  verde  zonas verdes do STEP que ficam iguais (VERDE)
  resto  o resto da suspensão do STEP (CINZENTO)

MODO "suspensao": se já houver camadas Montagem_final (depois da montagem final), mostra a
suspensão 1/2 do planeta; se não houver, mostra a suspensão base do STEP + tabela das variantes
já aprovadas para esse planeta.
"""
import os
import sys
import csv

BASE = r"C:\Mestrado\designD\m1\pecas"
FINAL = os.path.join(BASE, "final")
NUCLEO = os.path.join(BASE, "nucleo")
GH = os.path.join(BASE, "gh")
for _p in (GH, NUCLEO):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import Rhino
import Rhino.Geometry as rg
import scriptcontext as sc
import rhinoscriptsyntax as rs
import montagem_final as mf      # só usa as funções; não corre a montagem
import pecas_registo as reg

PLANETAS = ["Lua", "Marte", "Mercúrio", "Europa", "Titã", "Io", "Vénus"]
PECAS = [p for p, _, _, _ in mf.PECAS_FINAL]
RAIZ = "Montagem_final"

# ---- gramática: família de cada peça por planeta, e porquê ----
JOELHO = {
    "Lua": ("tubo fechado", "cavidade selada: só a pele exterior fica exposta ao regolito abrasivo"),
    "Mercúrio": ("tubo fechado", "regolito + ciclo térmico enorme: secção fechada e curvas de raio grande"),
    "Marte": ("tubo fechado", "rochas aguçadas: parede >= 4 mm contra perfuração"),
    "Europa": ("treliça", "ambiente pouco agressivo para a estrutura: abre-se material (janelas)"),
    "Titã": ("treliça", "o ambiente mais benigno: treliça mais aberta"),
    "Io": ("treliça", "lava rugosa e enxofre: treliça com curvas >= 30 mm"),
    "Vénus": ("nervuras (isogrid)", "465 °C + ácido: Ti/Inconel, 1 mm de corrosão em todas as faces"),
}
BARRAS = {
    "Lua": "tubo retangular oco", "Mercúrio": "tubo retangular oco", "Marte": "tubo retangular oco (parede >= 4 mm)",
    "Europa": "caixa treliçada (Warren); barra esquerda: RECURSO tubo (paredes com janelas não chegam)",
    "Titã": "caixa treliçada (Warren)",
    "Io": "caixa treliçada (Warren); barra esquerda: RECURSO tubo",
    "Vénus": "RECURSO tubo fechado nas 4 (o perfil I aberto não aguenta a torção)",
}
RODA = {
    "Lua": ("raios curvos", "ciclo térmico: o raio curvo absorve a dilatação raio/aro"),
    "Mercúrio": ("RECURSO raios retos (Ti)", "os curvos ficam em FS 2,19 < 2,2: a gramática recorre aos retos"),
    "Marte": ("garras chevron + aro >= 4 mm", "tração em areia/poeira; aro grosso contra rochas aguçadas"),
    "Europa": ("garras em ponta", "morder o gelo duro (atrito ~0,5 a -160 °C)"),
    "Titã": ("roda larga + garras altas", "areia orgânica mole: mais largura = menos afundamento"),
    "Io": ("raios retos + aro >= 4 mm", "lava arrefecida com arestas vivas"),
    "Vénus": ("disco fechado (Ti)", "corrosão em todas as faces: menos superfície exposta"),
}


def _entrada(nome, defeito):
    v = globals().get(nome, None)
    return defeito if v is None or (isinstance(v, str) and not v.strip()) else v


def _tira(s):
    import unicodedata
    return unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode().strip().lower()


def _escolhe(v, lista):
    for p in lista:
        if _tira(p) == _tira(v):
            return p
    for p in lista:                       # aceita "frente", "meio", "esquerda"...
        if _tira(v) and _tira(v) in _tira(p):
            return p
    return lista[0]


def _num(x, casas=2):
    try:
        return ("{:." + str(casas) + "f}").format(float(x)).replace(".", ",")
    except Exception:
        return "-" if x in (None, "") else str(x)


# ------------------------------------------------------------------------------------------
# TEXTO
# ------------------------------------------------------------------------------------------
def ambiente(pl):
    try:
        import planetas as pls
        import degradacao as dg
        P = pls.PLANETAS[pl]
        D = dg.DEGRADACAO[pl]
        return ["AMBIENTE  g = {:.2f} m/s²  |  T = {} a {} °C  |  FS exigido {}".format(P["g"], P["T"][0], P["T"][1], P["FS"]),
                "  " + P["ambiente"],
                "  terreno: " + P["terreno"],
                "  degradação: " + D["regra"]]
    except Exception as e:
        return ["AMBIENTE (não consegui ler planetas.py: {})".format(e)]


def regra(pl, peca):
    if peca.startswith("joelho"):
        return "{} — {}".format(*JOELHO[pl])
    if peca.startswith("barra"):
        return BARRAS[pl]
    return "{} — {}".format(*RODA[pl])


def linha_top(peca, pl, k, vid):
    """Linha do <planeta>_top3.csv (id, material, massa_3d, FS_3d) ou None."""
    pasta = [d for p, _, _, d in mf.PECAS_FINAL if p == peca][0]
    top = mf.ler_top(pasta, pl)
    if vid:
        for l in top:
            if l.get("id") == vid:
                return l, top
        return None, top
    return (top[k - 1] if len(top) >= k else (top[0] if top else None)), top


def texto_peca(pl, peca, k, vid, lin, top, n_geo):
    L = ["{}  —  {}".format(pl.upper(), peca.upper()), ""]
    L += ambiente(pl)
    L += ["", "REGRA (gramática):  " + regra(pl, peca), ""]
    if lin is None and not vid:
        L.append("Ainda nenhuma variante aprovada em 3D para esta peça neste planeta")
        L.append("(o ciclo ainda não lá chegou, ou nenhuma passou -> fica a ORIGINAL).")
    else:
        L.append("VARIANTE  {}{}".format(vid or lin.get("id"), "" if vid else "   (suspensão {}: {} melhor)".format(k, "a" if k == 1 else "2.ª")))
        if lin:
            L.append("  material: {}".format(lin.get("material", "-")))
            L.append("  massa 3D: {} kg   |   FS 3D: {}".format(_num(lin.get("massa_3d")), _num(lin.get("FS_3d"))))
        if n_geo == 0:
            L.append("  (geometria não construída — ver erro em baixo)")
    if top:
        L += ["", "APROVADAS EM 3D NESTE PLANETA (mais leve primeiro):"]
        for i, l in enumerate(top, 1):
            L.append("  {}. {:12s} {:24s} {:>6s} kg   FS {}".format(
                i, l.get("id", ""), l.get("material", "")[:24], _num(l.get("massa_3d")), _num(l.get("FS_3d"))))
    return L


def texto_suspensao(pl, k):
    L = ["{}  —  SUSPENSÃO {} ({})".format(pl.upper(), k, "as melhores peças" if k == 1 else "as segundas melhores"), ""]
    L += ambiente(pl)
    L += ["", "REGRAS (gramática)",
          "  joelhos: {} — {}".format(*JOELHO[pl]),
          "  barras:  {}".format(BARRAS[pl]),
          "  rodas:   {} — {}".format(*RODA[pl]), ""]
    f = os.path.join(FINAL, "{}_suspensao_{}.csv".format(pl, k))
    if os.path.exists(f):
        T = list(csv.DictReader(open(f, encoding="utf-8-sig"), delimiter=";"))
        L.append("{:18s} {:4s} {:12s} {:22s} {:>6s} {:>9s} {:>9s}".format(
            "PEÇA", "QTD", "VARIANTE", "MATERIAL", "FS 3D", "MASSA kg", "NASA kg"))
        for r in T:
            if r["peca"].startswith("TOTAL"):
                L += ["", "TOTAL das peças trocadas: {} kg (NASA em Al: {} kg)  ->  {}".format(
                    r["massa_rhino_kg"], r["massa_original_kg"], r["nota"])]
            else:
                L.append("{:18s} {:4s} {:12s} {:22s} {:>6s} {:>9s} {:>9s}".format(
                    r["peca"][:18], str(r["quantidade"]), r["id"][:12], r["material"][:22], str(r["FS_3d"] or "-"),
                    str(r["massa_rhino_kg"]), str(r["massa_original_kg"])))
        return L
    # ainda sem montagem final: o que já está escolhido para este planeta
    L.append("(Ainda sem montagem final: no Rhino vê-se a suspensão BASE do STEP.)")
    L.append("Variantes já escolhidas para a suspensão {}:".format(k))
    esc = mf.escolha(pl, k)
    for peca, n in [(p, q) for p, _, q, _ in mf.PECAS_FINAL]:
        lin, nota = esc[peca]
        if lin is None:
            L.append("  {:16s} x{}  ainda nada (fica a ORIGINAL)".format(peca, n))
        else:
            L.append("  {:16s} x{}  {:12s} {:22s} {:>6s} kg  FS {}".format(
                peca, n, lin.get("id", ""), lin.get("material", "")[:22], _num(lin.get("massa_3d")), _num(lin.get("FS_3d"))))
    return L


# ------------------------------------------------------------------------------------------
# RHINO (o documento do Rhino, não o do Grasshopper)
# ------------------------------------------------------------------------------------------
class _NoRhino(object):
    def __enter__(self):
        self.gh = sc.doc
        sc.doc = Rhino.RhinoDoc.ActiveDoc
        return sc.doc

    def __exit__(self, *a):
        sc.doc = self.gh
        return False


def step_em_grupos(recarregar):
    """{peça: [originais]}, resto  — lido uma vez do Rhino e guardado em memória."""
    if recarregar or sc.sticky.get("seletor:step") is None:
        pecas = mf.pecas_do_step()
        if not any("roda" in n for n, _ in pecas) and os.path.exists(mf.STEP):
            rs.Command('_-Import "{}" _Enter'.format(mf.STEP), echo=False)
            pecas = mf.pecas_do_step()
        sc.sticky["seletor:step"] = mf._separar(pecas)
        sc.sticky["seletor:geo"] = {}
    return sc.sticky["seletor:step"]


def construir(peca, pl, vid, grupos, tol):
    cache = sc.sticky.setdefault("seletor:geo", {})
    chave = (peca, pl, vid)
    if chave not in cache:
        if peca == "joelho traseiro":
            novas, verdes, _ = mf._traseiro(pl, vid, grupos[peca], tol)
        else:
            novas, verdes, _ = mf._peca_nova(peca, pl, vid, grupos[peca], tol)
        cache[chave] = (novas, verdes)
    return cache[chave]


def esconder_camadas(isolar, manter=None):
    guard = sc.sticky.get("seletor:vis")
    topo = [n for n in rs.LayerNames() if "::" not in n and n != manter]
    if isolar:
        if guard is None:
            sc.sticky["seletor:vis"] = {n: rs.LayerVisible(n) for n in topo}
        for n in topo:
            if rs.LayerVisible(n):
                rs.LayerVisible(n, False)
    elif guard is not None:
        for n, v in guard.items():
            if rs.IsLayer(n):
                rs.LayerVisible(n, v)
        sc.sticky["seletor:vis"] = None


def enquadrar_bb(geos, chave):
    if sc.sticky.get("seletor:ultimo") == chave:
        return
    bb = rg.BoundingBox.Empty
    for g in geos:
        bb.Union(g.GetBoundingBox(True))
    if bb.IsValid:
        bb.Inflate(0.15 * bb.Diagonal.Length)
        for v in sc.doc.Views.GetViewList(True, False):
            v.ActiveViewport.ZoomBoundingBox(bb)
            v.Redraw()
    sc.sticky["seletor:ultimo"] = chave


def mostrar_suspensao(pl, k, isolar, enquadrar):
    if not rs.IsLayer(RAIZ):
        esconder_camadas(False)          # suspensão base: tudo como estava
        return ""
    alvo = "{}::{}::suspensao_{}".format(RAIZ, pl, k)
    esconder_camadas(isolar, manter=RAIZ)
    rs.LayerVisible(RAIZ, True)
    for n in rs.LayerNames():
        if not n.startswith(RAIZ + "::"):
            continue
        p = n.split("::")
        if len(p) == 2:
            rs.LayerVisible(n, p[1] == pl)
        elif len(p) == 3:
            rs.LayerVisible(n, p[1] == pl and p[2] == "suspensao_{}".format(k))
    if enquadrar:
        ids = []
        for n in rs.LayerNames():
            if n.startswith(alvo):
                ids += rs.ObjectsByLayer(n) or []
        geos = [rs.coercegeometry(i) for i in ids]
        enquadrar_bb([g for g in geos if g is not None], ("susp", pl, k))
    return "" if rs.IsLayer(alvo) else "\n(não encontrei a camada {})".format(alvo)


# =============================================================================================
modo_ = "suspensao" if _tira(_entrada("modo", "peca")).startswith("susp") else "peca"
pl_ = _escolhe(_entrada("planeta", "Lua"), PLANETAS)
peca_ = _escolhe(_entrada("peca", "joelho do meio"), PECAS)
k_ = 2 if str(_entrada("suspensao", 1)).strip() in ("2", "2.0") else 1
vid_ = str(_entrada("variante", "")).strip()
isolar_ = bool(_entrada("isolar", True))
enquadrar_ = bool(_entrada("enquadrar", True))
recarregar_ = bool(_entrada("recarregar", False))

info, geo, verde, resto = "", [], [], []
erro = ""
with _NoRhino() as doc:
    rs.EnableRedraw(False)
    try:
        if modo_ == "suspensao":
            erro = mostrar_suspensao(pl_, k_, isolar_, enquadrar_)
            info = "\n".join(texto_suspensao(pl_, k_))
        else:
            lin, top = linha_top(peca_, pl_, k_, vid_)
            vid = vid_ or (lin.get("id") if lin else "")
            n_geo = 0
            try:
                grupos, resto_step = step_em_grupos(recarregar_)
                outras = [g for p, gs in grupos.items() if p != peca_ for g in gs]
                resto = list(resto_step) + outras
                if vid:
                    geo, verde = construir(peca_, pl_, vid, grupos, doc.ModelAbsoluteTolerance)
                    geo, verde = list(geo), list(verde)
                    n_geo = len(geo)
                else:
                    geo = list(grupos[peca_])      # sem variante: mostra a ORIGINAL a azul
                esconder_camadas(isolar_)
                if enquadrar_:
                    enquadrar_bb(geo + verde, ("peca", peca_, pl_, vid))
            except Exception as e:
                erro = "\n(erro a construir {} {}: {})".format(peca_, vid, e)
            info = "\n".join(texto_peca(pl_, peca_, k_, vid_, lin, top, n_geo))
    except Exception as e:
        erro += "\n(erro: {})".format(e)
    finally:
        rs.EnableRedraw(True)
info += erro
