"""
REGISTO DAS PEÇAS NOVAS para os componentes genéricos do Grasshopper
(gh_intact_peca.py e gh_maestro_peca.py, ficheiro pecas.gh).

Cada peça tem uma pasta em m1\\pecas\\ com dois módulos:
  geo   (sem Rhino): PLANETAS, nome_planeta, candidatos, linha, lista_casos, n_casos,
        material, FS_req, dist_ligacoes, V_VERDE, NOME_FAM, SAIDA
  rhino (RhinoCommon): construir(planeta, vid, tol) -> dict(peca, face_fixa, face_carga,
        centro_carga, desc, volume, estado), montar(planeta)
Para acrescentar uma peça (barras, rodas): juntar uma linha a PECAS.

Também guarda a memória (sticky) com um PREFIXO por peça, para não se misturar com
a do joelho traseiro (unnamed.gh) quando os dois estão abertos no mesmo Rhino.
"""
import os
import sys
import importlib
import unicodedata

BASE = r"C:\Mestrado\designD\m1\pecas"
_DEPS_BARRAS = ["secoes", "gerador_barras", "peca_barra", "rhino_barra"]
PECAS = {
    "joelho do meio": dict(pasta="joelho_meio", deps=["gerador_meio"], geo="peca_meio", rhino="rhino_meio"),
    # 02/11: as 4 barras (uma pasta, um gerador; invólucros geo_/rhino_barra_<x>.py ligam a API a cada barra)
    "barra traseira": dict(pasta="barras", deps=_DEPS_BARRAS, geo="geo_barra_traseira", rhino="rhino_barra_traseira"),
    "barra do meio": dict(pasta="barras", deps=_DEPS_BARRAS, geo="geo_barra_meio", rhino="rhino_barra_meio"),
    "barra do frente": dict(pasta="barras", deps=_DEPS_BARRAS, geo="geo_barra_frente", rhino="rhino_barra_frente"),
    "barra esquerda": dict(pasta="barras", deps=_DEPS_BARRAS, geo="geo_barra_esquerda", rhino="rhino_barra_esquerda"),
    # 02/11: a roda (uma peça: as 3 rodas do lado são iguais; montar troca as 3)
    "roda": dict(pasta="rodas", deps=["gerador_rodas"], geo="peca_roda", rhino="rhino_roda"),
}
_MTIMES = {}

# ---- 02/11 (chat 12): CICLO ÚNICO AUTOMÁTICO (Panel PECA = "ciclo") ----
# fila peça x planeta; cada peça corre os 7 planetas (modo 'todos') e passa à seguinte.
# O joelho traseiro já está feito (unnamed.gh, lote de 02/11) -> só entra na montagem final.
ORDEM_CICLO = ["joelho do meio", "barra traseira", "barra do meio", "barra do frente", "barra esquerda", "roda"]
# 03/11 13h30: barras do meio/frente/esquerda e roda 5 -> 3 (tempo: ~70 min por planeta com 5).
# A barra traseira fica com 5 (já ia a meio com 5; mudar recomeçava o planeta).
N_CICLO = {"joelho do meio": 10, "barra traseira": 5, "barra do meio": 3, "barra do frente": 3,
           "barra esquerda": 3, "roda": 3}
PLANETAS_CICLO = ["Lua", "Marte", "Mercúrio", "Europa", "Titã", "Io", "Vénus"]
# pastas de resultados 3D (iguais a pm.SAIDA de cada peça; aqui para não ter de importar os módulos)
SAIDAS = {"joelho do meio": os.path.join(BASE, "joelho_meio", "diag", "intact"),
          "barra traseira": os.path.join(BASE, "barras", "diag", "traseira", "intact"),
          "barra do meio": os.path.join(BASE, "barras", "diag", "meio", "intact"),
          "barra do frente": os.path.join(BASE, "barras", "diag", "frente", "intact"),
          "barra esquerda": os.path.join(BASE, "barras", "diag", "esquerda", "intact"),
          "roda": os.path.join(BASE, "rodas", "diag", "intact")}
SAIDA_TRASEIRO = r"C:\Mestrado\designD\m1\joelho_traseiro_STEP\diag\intact"
CHAVE_CICLO = "pecas:ciclo_peca"         # sticky SEM prefixo: a peça atual do ciclo (maestro -> gh_intact)
CHAVE_INTACT = "pecas:intact_comp"       # sticky SEM prefixo: o componente gh_intact_peca


def _tira(s):
    return unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode().strip().lower()


def e_ciclo(v):
    return v is not None and _tira(v) in ("ciclo", "todas", "tudo")


def planetas_por_fazer(peca):
    s = SAIDAS[nome_peca(peca)]
    return [p for p in PLANETAS_CICLO if not os.path.exists(os.path.join(s, p + "_FEITO.txt"))]


def peca_do_ciclo():
    """1.ª peça da ORDEM_CICLO com algum planeta sem <planeta>_FEITO.txt (None = ciclo acabado)."""
    for p in ORDEM_CICLO:
        if planetas_por_fazer(p):
            return p
    return None


def ciclo_estado():
    """Texto curto: o que está feito / falta, por peça (para o Panel 'estado')."""
    out = []
    for p in ORDEM_CICLO:
        f = 7 - len(planetas_por_fazer(p))
        out.append("{} {}/7".format(p, f))
    t = 7 - len([q for q in PLANETAS_CICLO
                 if not os.path.exists(os.path.join(SAIDA_TRASEIRO, q + "_FEITO.txt"))])
    return "joelho traseiro {}/7 | ".format(t) + " | ".join(out)


def nome_peca(v):
    for n in PECAS:
        if _tira(n) == _tira(v):
            return n
    raise Exception("Peça desconhecida: {!r}. Usa uma destas: {} (ou 'ciclo')".format(v, ", ".join(PECAS)))


def modulos(peca):
    """(geo, rhino) da peça; volta a carregar tudo se algum ficheiro mudou no disco."""
    cfg = PECAS[nome_peca(peca)]
    pasta = os.path.join(BASE, cfg["pasta"])
    for p in (os.path.join(BASE, "nucleo"), pasta):
        if p in sys.path:
            sys.path.remove(p)
        sys.path.insert(0, p)              # a pasta da peça fica sempre à frente
    nomes = cfg["deps"] + [cfg["geo"], cfg["rhino"]]
    mods = [importlib.import_module(n) for n in nomes]
    mudou = False
    for m in mods:
        try:
            t = os.path.getmtime(m.__file__)
        except Exception:
            continue
        if _MTIMES.get(m.__name__) not in (None, t):
            mudou = True
        _MTIMES[m.__name__] = t
    if mudou:
        mods = [importlib.reload(m) for m in mods]
    return mods[-2], mods[-1]


def versao(peca):
    """Muda quando algum ficheiro da peça muda (para invalidar a geometria em cache)."""
    cfg = PECAS[nome_peca(peca)]
    return tuple(_MTIMES.get(n) for n in cfg["deps"] + [cfg["geo"], cfg["rhino"]])


class Sticky(object):
    """sc.sticky com prefixo 'peca:<nome>:' (mesma interface que um dict)."""

    def __init__(self, sticky, peca):
        self._s = sticky
        self._p = "peca:{}:".format(nome_peca(peca))

    def get(self, k, defeito=None):
        return self._s.get(self._p + k, defeito) if (self._p + k) in self._s else defeito

    def __getitem__(self, k):
        return self._s[self._p + k]

    def __setitem__(self, k, v):
        self._s[self._p + k] = v

    def __contains__(self, k):
        return (self._p + k) in self._s

    def pop(self, k, *defeito):
        if (self._p + k) in self._s:
            v = self._s[self._p + k]
            del self._s[self._p + k]
            return v
        if defeito:
            return defeito[0]
        raise KeyError(k)
