# r: numpy, scipy, matplotlib
"""
GRASSHOPPER -> INTACT.SIMULATION : verificação 3D de uma variante de uma PEÇA NOVA
(versão genérica do gh_intact.py do joelho traseiro; ficheiro pecas.gh)

ENTRADAS (botão direito -> "+"; nomes exatos):
  PECA      (str)  Panel: "joelho do meio", "barra traseira", ..., "roda" — ou "ciclo" (02/11: a peça
                   vem do maestro, que corre todas as peças seguidas; o Panel do maestro também = "ciclo")
  planeta   (str)  "Lua", "Mercúrio", "Marte", "Europa", "Titã", "Io", "Vénus"
  variante  (str)  código, ex. "MAR-057", ou um número n = a n-ésima mais leve que passa no 2D
  caso      (int)  slider 0..N-1 (ver saída 'casos')

SAÍDAS: iguais às do gh_intact.py -> os blocos do Intact ligam-se da MESMA maneira:
  peca, face_fixa, face_carga, F_dir, F_N, M_eixo, M_Nmm, E_MPa, nu, rho_tmm3, sy_MPa,
  perigo_max, casos, pontos, info

Joelho do meio: face FIXA = onde o braço encontra a bossa do furo Ø72,5 (barra do meio);
face de CARGA = onde o braço encontra o cubo da roda (plano u = x_s). As cargas da roda
(e a reação induzida pelo pino do bogie) chegam ao cubo rígido e passam para a face como
F e M = soma (P - centro) x F. Casos 3D = os 17 do 2D reduzidos por linearidade (8).
Unidades MMS (mm, t, s): N, MPa, t/mm3, N.mm.
"""
import os
import sys

GH_PASTA = r"C:\Mestrado\designD\m1\pecas\gh"
if GH_PASTA not in sys.path:
    sys.path.insert(0, GH_PASTA)
import matplotlib
matplotlib.use("Agg")
import numpy as np
import Rhino.Geometry as rg
import scriptcontext as sc
import importlib
import pecas_registo as reg

TOL = 0.01
AFAST = 8.0          # mm: pontos mais perto das faces de ligação ficam de fora (picos artificiais)
D_TRANS = 25.0       # mm: zona de transição junto às ligações (avaliada à parte, só informativa)


def _entrada(nome, defeito):
    v = globals().get(nome, None)
    return defeito if v is None or (isinstance(v, str) and not v.strip()) else v


_peca_in = _entrada("PECA", "joelho do meio")
if reg.e_ciclo(_peca_in):
    # 02/11: ciclo único -> a peça é a que o maestro está a correr (ou a 1.ª por fazer)
    _p = sc.sticky.get(reg.CHAVE_CICLO) or reg.peca_do_ciclo() or reg.ORDEM_CICLO[-1]
    PECA_ = reg.nome_peca(_p)
else:
    PECA_ = reg.nome_peca(_peca_in)
pm, rm = reg.modulos(PECA_)
ST = reg.Sticky(sc.sticky, PECA_)
sc.sticky[reg.CHAVE_INTACT] = ghenv.Component

planeta_ = pm.nome_planeta(_entrada("planeta", "Marte"))
var_ = str(_entrada("variante", "1")).strip().upper()
caso_ = int(_entrada("caso", 0))

# ---- modo automático: o gh_maestro_peca.py escolhe a variante e o caso ----
ST["intact_comp"] = ghenv.Component
LOTE = ST.get("lote_ativo", False) and ST.get("lote_alvo")
if LOTE:
    planeta_, var_, caso_ = ST["lote_alvo"]
if var_.isdigit():
    ids_ = pm.candidatos(planeta_, max(int(var_), 1))
    if not ids_:
        raise Exception("Nenhuma variante de {} passa no 2D".format(planeta_))
    var_ = ids_[-1]
lin = pm.linha(planeta_, var_)
vid = lin["id"]

# ---- geometria (cache por peça / planeta / variante / versão dos ficheiros) ----
chave = (PECA_, planeta_, vid, reg.versao(PECA_))
cache = ST.get("intact_gh", {}) or {}
if cache.get("chave") != chave:
    r = rm.construir(planeta_, vid, TOL)
    cache = dict(chave=chave, r=r)
    ST["intact_gh"] = cache
r = cache["r"]
peca = r["peca"]
face_fixa = r["face_fixa"]
face_carga = r["face_carga"]
c0 = np.asarray(r["centro_carga"], float)
d = r["desc"]


def _pt(P):
    return rg.Point3d(float(P[0]), float(P[1]), float(P[2]))


# ---- caso de carga -> força + momento no centro da face de carga ----
_POR_VAR = getattr(pm, "POR_VARIANTE", False)          # 02/11 roda: contacto depende da largura da variante
lista = pm.lista_casos(planeta_, vid=vid) if _POR_VAR else pm.lista_casos(planeta_)
casos = [l[0] for l in lista]
caso_ = max(0, min(caso_, len(lista) - 1))
nome_c, F, M0, equiv = lista[caso_]
F_N = float(np.linalg.norm(F))
u_ = F / max(F_N, 1e-9)
F_dir = rg.Vector3d(float(u_[0]), float(u_[1]), float(u_[2]))
M = np.asarray(M0, float) - np.cross(c0, F)            # = soma (P - c0) x F   [N.mm]
M_Nmm = float(np.linalg.norm(M))
if M_Nmm > 1e-9:
    m_ = M / M_Nmm
    M_eixo = rg.Line(_pt(c0 - 20 * m_), _pt(c0 + 20 * m_))
else:
    # 31/10 (traseiro): com momento 0 o solver do Intact não arranca -> 1 N.mm
    M_eixo = rg.Line(_pt(c0), _pt(c0 + 20 * pm.U3))
    M_Nmm = 1.0

# ---- pontos para o Solution Sampler (superfície, 0,5 mm para dentro, longe das ligações) ----
if "pontos_zona" not in cache:
    mp = rg.MeshingParameters.QualityRenderMesh
    mp.MaximumEdgeLength = 4.0
    mp.MinimumEdgeLength = 0.5
    malha = rg.Mesh()
    for mm_ in rg.Mesh.CreateFromBrep(peca, mp) or []:
        malha.Append(mm_)
    malha.Normals.ComputeNormals()
    n_v = malha.Vertices.Count
    V = np.array([[malha.Vertices[i].X, malha.Vertices[i].Y, malha.Vertices[i].Z] for i in range(n_v)])
    Nn = np.array([[malha.Normals[i].X, malha.Normals[i].Y, malha.Normals[i].Z] for i in range(n_v)])
    P = V - 0.5 * Nn
    df, dc = pm.dist_ligacoes(P, planeta=planeta_, vid=vid) if _POR_VAR else pm.dist_ligacoes(P)
    dmin = np.minimum(df, dc)
    ok = dmin > AFAST
    cache["pontos_zona"] = [(_pt(p), bool(z)) for p, z in zip(P[ok], dmin[ok] < D_TRANS)]
sel_ = cache["pontos_zona"]
pontos = [q[0] for q in sel_]
ST["intact_zona"] = [q[1] for q in sel_]
ST["intact_pontos_loc"] = pontos

# ---- material (temperatura + degradação do planeta), unidades MMS ----
mat = pm.material(planeta_, lin["material"])
E_MPa = float(mat["E"])
nu = 0.33
rho_tmm3 = float(mat["rho"]) * 1e-12
sy_MPa = float(mat["sy"])
FSr = pm.FS_req(planeta_)
perigo_max = round(1.0 / FSr, 4)

vol = float(r["volume"])
massa_braco_3d = vol * float(mat["rho"]) * 1e-9
massa_3d = massa_braco_3d + pm.V_VERDE * float(mat["rho"]) * 1e-9     # + zonas verdes (como no 2D)

info = "{} | {} | {} | {} | {}\n".format(PECA_, planeta_, vid, pm.NOME_FAM[d["familia"]], lin["material"])
info += "massa {:.2f} kg (braço 3D {:.3f} / 2D {:.3f}) | FS 2D {:.2f} | FS exigido {}\n".format(
    massa_3d, massa_braco_3d, d["massa_braco_2d"], d["FS_2d"], FSr)
info += "geometria: {}{}\n".format(r["estado"], (" | " + "; ".join(sorted(set(d["avisos"])))) if d["avisos"] else "")
info += "caso {} de {}: {} | F = {:.0f} N | M = {:.0f} N.m\n".format(caso_ + 1, len(lista), nome_c, F_N, M_Nmm / 1e3)
if equiv:
    info += "  (representa: {})\n".format(", ".join(n for n, _ in equiv))
info += "material: E = {:.1f} GPa, cedência no planeta = {:.0f} MPa, rho = {:.0f} kg/m3\n".format(
    E_MPa / 1e3, sy_MPa, float(mat["rho"]))
info += "PASSA se o Danger Level (p99,9 dos {} pontos) < {}\n".format(len(pontos), perigo_max)

# ---- estado para o maestro ----
ST["intact_contador"] = ST.get("intact_contador", 0) + 1
ST["intact_estado"] = dict(peca=PECA_, planeta=planeta_, id=vid, caso=caso_, nome_caso=nome_c,
                           n_casos=len(lista), massa_3d=massa_3d, massa_braco_3d=massa_braco_3d,
                           massa_2d=d["massa_2d"], FS_2d=d["FS_2d"], material=lin["material"],
                           perigo_max=perigo_max, sy_MPa=sy_MPa, n_pontos=len(pontos),
                           contador=ST["intact_contador"])
if LOTE:
    info = "[AUTOMÁTICO] " + info
