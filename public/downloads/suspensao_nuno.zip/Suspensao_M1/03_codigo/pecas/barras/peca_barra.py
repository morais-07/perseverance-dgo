"""
==============================================================================
 BARRAS - DESCRIÇÃO 3D DE UMA VARIANTE (sem Rhino: só numpy)
==============================================================================
Ponte entre a geração 2D (gerador_barras.py) e o construtor Rhino (rhino_barra.py).

Referencial da barra (do STEP): P = raiz + s*e1 + n*N + v*B
  e1 = eixo (raiz -> ponta), N = direção da largura t (rodada 'rot' de e2), B = e1 x N
Peça 3D = troço de PROJETO (s0 .. s1), peça NOVA (genes engrossados):
  - loft de secções t(s) x b(s) (retângulo de cantos redondos), tampas planas
       face FIXA  = tampa em s = s0 (encosta à ponta verde da raiz)
       face CARGA = tampa em s = s1 (encosta à ponta verde do lado da roda)
  - tubo:    cavidade (loft interior) com tampas de espessura = parede + respiro Ø3
  - treliça: caixa (cavidade entre banzos e paredes, tampas de espessura = banzo)
             + janelas triangulares (Warren) que atravessam as 2 paredes laterais
Massa 3D PREVISTA: analítica (geometria reta: exata a menos do facetado).

API (igual à do joelho do meio, para os componentes genéricos do Grasshopper):
  api(peca) -> dict com PLANETAS, nome_planeta, candidatos, linha, lista_casos, n_casos,
               material, FS_req, dist_ligacoes, V_VERDE, NOME_FAM, SAIDA, descrever, ...
==============================================================================
"""
import os, sys, csv
import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__))
if AQUI not in sys.path:
    sys.path.insert(0, AQUI)
_NUC = os.path.normpath(os.path.join(AQUI, '..', 'nucleo'))
if _NUC not in sys.path:
    sys.path.insert(1, _NUC)
import gerador_barras as gb
import planetas as pl
import degradacao as dg

PLANETAS = list(gb.FAMILIA)
NOME_FAM = gb.NOME_FAM
K_SEC = 5                   # secções do loft (a conicidade é linear)
R_JANELA = 3.0
FOLGA_BANZO = 1.0           # mm: janelas afastadas da face interior dos banzos (evita faces coincidentes)


def nome_planeta(v):
    import unicodedata
    tira = lambda s: unicodedata.normalize('NFKD', str(s)).encode('ascii', 'ignore').decode().strip().lower()
    for n in PLANETAS:
        if tira(n) == tira(v):
            return n
    raise Exception('Planeta desconhecido: {!r}. Usa um destes: {}'.format(v, ', '.join(PLANETAS)))


def pasta(peca):
    return os.path.join(AQUI, 'diag', gb.SLUG[peca])


def saida(peca):
    return os.path.join(pasta(peca), 'intact')


# ------------------------------------------------------------------------------
# população / candidatos / material
# ------------------------------------------------------------------------------
_POP = {}


def ler_populacao(peca, planeta):
    f = os.path.join(pasta(peca), 'populacoes', planeta + '.csv')
    k = (peca, planeta)
    t = os.path.getmtime(f)
    if k not in _POP or _POP[k][0] != t:
        _POP[k] = (t, list(csv.DictReader(open(f, encoding='utf-8-sig'), delimiter=';')))
    return _POP[k][1]


def linha(peca, planeta, vid):
    for l in ler_populacao(peca, planeta):
        if l['id'].upper() == vid.upper():
            return l
    raise Exception('Não encontrei {} em diag/{}/populacoes/{}.csv'.format(vid, gb.SLUG[peca], planeta))


def genes_de_linha(l):
    fam = l['familia']
    g = {}
    for k in ['largura', 'prof', 'conicidade', 'rot'] + list(gb.GENES[fam]):
        g[k] = int(float(l[k])) if k in gb.INTEIROS else float(l[k])
    return g


def material(planeta, nome_mat):
    return gb.materiais(planeta)[nome_mat]


def FS_req(planeta):
    return float(pl.PLANETAS[planeta]['FS'])


_PREV = {}


def candidatos(peca, planeta, n):
    """As n mais leves que passam no 2D, ordenadas pela massa 3D PREVISTA (analítica)."""
    pop = [l for l in ler_populacao(peca, planeta) if l.get('passa') == '1' and l.get('massa_kg')]
    pop.sort(key=lambda l: float(l['massa_kg']))
    pop = pop[:max(4 * n, 20)]                 # a previsão só reordena as mais leves
    out = []
    for l in pop:
        k = (peca, planeta, l['id'])
        if k not in _PREV:
            try:
                _PREV[k] = massa_prevista(peca, planeta, l['id'])['massa_3d_prevista']
            except Exception:
                _PREV[k] = None
        if _PREV[k] is not None:
            out.append((_PREV[k], l['id']))
    out.sort()
    return [v for _, v in out[:n]]


# ------------------------------------------------------------------------------
# casos 3D (reduzidos por linearidade, como no joelho do meio)
# ------------------------------------------------------------------------------
_CASOS3D = {}


def lista_casos(peca, planeta, gravar=False):
    k = (peca, planeta)
    if k in _CASOS3D and not gravar:
        return _CASOS3D[k]
    todos = gb.casos(peca, planeta)
    grupos = []
    for nome, F, M0 in todos:
        f = np.linalg.norm(F)
        chave = np.r_[F / f, M0 / f]
        for gr in grupos:
            if (np.allclose(gr['chave'], chave, rtol=1e-6, atol=1e-6 * max(1.0, np.abs(chave).max())) or
                    np.allclose(gr['chave'], -chave, rtol=1e-6, atol=1e-6 * max(1.0, np.abs(chave).max()))):   # 02/11: carga simétrica (-F, -M) = mesmo Danger Level (elasticidade linear)
                gr['membros'].append((nome, f)); break
        else:
            grupos.append(dict(chave=chave, membros=[(nome, f)], F=F, M0=M0, f=f))
    out = []
    for gr in grupos:
        nome_max, fmax = max(gr['membros'], key=lambda x: x[1])
        esc = fmax / gr['f']
        eq = [m for m in gr['membros'] if m[0] != nome_max]
        rot = nome_max
        if eq:
            rot = 'vertical_max' if abs(gr['chave'][2]) > 0.999 else nome_max + '*'
            eq = [(nome_max, fmax)] + eq
        ordem = (1 if eq else 0, [x[0] for x in todos].index(nome_max))
        out.append((ordem, (rot, gr['F'] * esc, gr['M0'] * esc, eq)))
    out = [c for _, c in sorted(out, key=lambda x: x[0])]
    _CASOS3D[k] = out
    if gravar:
        os.makedirs(saida(peca), exist_ok=True)
        with open(os.path.join(saida(peca), planeta + '_casos_equivalentes.csv'), 'w', encoding='utf-8-sig') as fh:
            fh.write('planeta;caso_3D;F_N;casos_2D_proporcionais (% da força)\n')
            for nome, F, M0, eq in out:
                fh.write('{};{};{:.1f};{}\n'.format(planeta, nome, np.linalg.norm(F),
                         ', '.join('{} ({:.0f} %)'.format(n_, 100 * f_ / np.linalg.norm(F)) for n_, f_ in eq)))
    return out


def dist_ligacoes(peca, P):
    """Pontos globais -> (distância à face FIXA, distância à face de CARGA) [mm] (planos s0 / s1)."""
    G = gb.GEO[peca]
    s = (np.atleast_2d(P) - G['raiz']) @ G['e1']
    return np.maximum(s - G['s0'], 0.0), np.maximum(G['s1'] - s, 0.0)


def p3(peca, s, n, v, N, B):
    G = gb.GEO[peca]
    s = np.asarray(s, float); n = np.asarray(n, float) + 0 * s; v = np.asarray(v, float) + 0 * s
    return G['raiz'] + s[..., None] * G['e1'] + n[..., None] * N + v[..., None] * B


# ------------------------------------------------------------------------------
# descrição de uma variante
# ------------------------------------------------------------------------------
def _area_ret(t, b, R):
    import secoes as sc_
    A, _, _ = sc_._ret_arred(np.asarray(t, float), np.asarray(b, float), np.asarray(R, float))
    return A


def descrever(peca, planeta, vid):
    l = linha(peca, planeta, vid)
    g = genes_de_linha(l)
    fam = l['familia']
    nm = l['material']
    r = gb.avaliar(peca, planeta, g, nm, fam=fam)
    if not r.get('valido'):
        raise Exception('{} não é válida: {}'.format(vid, r.get('motivo')))
    G = gb.GEO[peca]
    dl = dg.de(planeta)['delta']
    gn = r['gn']
    N, B = gb.direcoes(G, g['rot'])
    s0, s1 = G['s0'], G['s1']
    S = np.linspace(s0, s1, K_SEC)
    f = gb.escala(G, S, g['conicidade'])
    tn, bn = g['largura'] * f + 2 * dl, g['prof'] * f + 2 * dl
    rc = float(g['r_cantos']) if fam == 'fechada' else 0.0
    Rn = np.maximum(rc * np.minimum(tn, bn), 0.5)
    secoes = [dict(s=float(S[i]), c=G['raiz'] + S[i] * G['e1'], t=float(tn[i]), b=float(bn[i]), R=float(Rn[i]))
              for i in range(K_SEC)]
    d = dict(peca=peca, planeta=planeta, id=l['id'], familia=fam, recurso=l.get('recurso') == '1', material=nm,
             genes=g, genes_novos=gn, N=N, B=B, e1=G['e1'], s0=s0, s1=s1, secoes=secoes,
             b_max=float(bn.max()), t_max=float(tn.max()),
             massa_2d=float(l['massa_kg']), massa_braco_2d=float(l['massa_meio_kg']), FS_2d=float(l['FS_min']),
             cavidades=[], janelas=[], avisos=[])
    tt = lambda s: g['largura'] * gb.escala(G, np.asarray(s, float), g['conicidade']) + 2 * dl
    bb = lambda s: g['prof'] * gb.escala(G, np.asarray(s, float), g['conicidade']) + 2 * dl
    if fam == 'fechada':
        e = float(gn['parede'])
        Sc = np.linspace(s0 + e, s1 - e, K_SEC)
        cav = []
        for s_ in Sc:
            ti, bi = float(tt(s_)) - 2 * e, float(bb(s_)) - 2 * e
            if ti < 2 or bi < 2:
                cav = []; break
            Ri = max(rc * min(float(tt(s_)), float(bb(s_))) - e, 0.5)
            cav.append(dict(s=float(s_), c=G['raiz'] + s_ * G['e1'], t=ti, b=bi, R=Ri))
        if cav:
            d['cavidades'].append(cav)
        else:
            d['avisos'].append('tubo sem cavidade: peça maciça')
    elif fam == 'trelica':
        wc, e = float(gn['banzo']), float(gn['parede'])
        Sc = np.linspace(s0 + wc, s1 - wc, K_SEC)
        d['cavidades'].append([dict(s=float(s_), c=G['raiz'] + s_ * G['e1'], t=float(tt(s_)) - 2 * wc,
                                    b=float(bb(s_)) - 2 * e, R=0.5) for s_ in Sc])
        d['janelas'] = _janelas(gn, g, G, tt, d)
        d['parede'] = e
    else:
        raise Exception('Família {} sem construtor 3D nas barras'.format(fam))
    return d


def _inset_arredondado(poly, offs, r, n_arco=6, passo=3.0):
    """(cópia de joelho_meio/peca_meio.py) Polígono convexo com cada aresta recuada offs[k]
    e cantos de raio r -> pontos (s, n) da fronteira, ou None se não couber."""
    P = np.asarray(poly, float)
    k = len(P)
    if 0.5 * np.sum(P[:, 0] * np.roll(P[:, 1], -1) - np.roll(P[:, 0], -1) * P[:, 1]) < 0:
        P = P[::-1]; offs = list(offs)[::-1]
        offs = offs[1:] + offs[:1]
    linhas = []
    for i in range(k):
        a, b = P[i], P[(i + 1) % k]
        dvec = (b - a) / np.linalg.norm(b - a)
        nin = np.array([-dvec[1], dvec[0]])
        linhas.append((a + (offs[i] + r) * nin, dvec, nin))
    Q = []
    for i in range(k):
        (a1, d1, _), (a2, d2, _) = linhas[i - 1], linhas[i]
        M = np.array([d1, -d2]).T
        if abs(np.linalg.det(M)) < 1e-9:
            return None
        tt = np.linalg.solve(M, a2 - a1)
        Q.append(a1 + tt[0] * d1)
    Q = np.array(Q)
    for i in range(k):
        if (Q[(i + 1) % k] - Q[i]) @ linhas[i][1] <= 1e-6:
            return None
    if 0.5 * np.sum(Q[:, 0] * np.roll(Q[:, 1], -1) - np.roll(Q[:, 0], -1) * Q[:, 1]) <= 1.0:
        return None
    out = []
    for i in range(k):
        n_prev, n_cur = -linhas[i - 1][2], -linhas[i][2]
        a0, a1 = np.arctan2(n_prev[1], n_prev[0]), np.arctan2(n_cur[1], n_cur[0])
        da = (a1 - a0) % (2 * np.pi)
        for aa in a0 + da * np.linspace(0, 1, n_arco):
            out.append(Q[i] + r * np.array([np.cos(aa), np.sin(aa)]))
        p_ini = Q[i] + r * n_cur
        p_fim = Q[(i + 1) % k] + r * n_cur
        m = max(int(np.linalg.norm(p_fim - p_ini) / passo), 1)
        for f in np.linspace(0, 1, m + 1)[1:-1]:
            out.append(p_ini + f * (p_fim - p_ini))
    return np.array(out)


def _janelas(gn, g, G, tt, d):
    """Janelas triangulares (Warren) no plano (s, n), entre as faces interiores dos banzos."""
    wc, wd, n = float(gn['banzo']), float(gn['diagonal']), int(gn['paineis'])
    mont = float(gn.get('montantes', 0)) >= 0.5
    s0, s1 = G['s0'], G['s1']
    pos0 = max(wd, wc + 2.0)                     # poste de ponta: nunca entra na tampa
    sa, sb = s0, s1
    p = (sb - sa) / n
    S = [sa + j * p for j in range(n + 1)]
    lim = lambda s: float(tt(s)) / 2 - wc - FOLGA_BANZO            # face interior do banzo (n > 0)
    lado = [(-1) ** (j + 1) for j in range(n + 1)]                   # nó j: -1 em baixo, +1 em cima
    P = lambda j, sg: (S[j], sg * lim(S[j]))
    tri = []
    if mont:
        for j in range(n):
            a, b = P(j, lado[j]), P(j + 1, lado[j + 1])
            ow0 = pos0 if j == 0 else wd / 2
            ow1 = pos0 if j == n - 1 else wd / 2
            tri.append(([a, P(j, lado[j + 1]), b], [ow0, 0.0, wd / 2]))
            tri.append(([a, b, P(j + 1, lado[j])], [wd / 2, ow1, 0.0]))
    else:
        for j in range(n + 1):
            if j == 0:
                pts = [P(0, lado[0]), P(0, -lado[0]), P(1, -lado[0])]; offs = [pos0, 0.0, wd / 2]
            elif j == n:
                pts = [P(n - 1, -lado[n]), P(n, -lado[n]), P(n, lado[n])]; offs = [0.0, pos0, wd / 2]
            else:
                pts = [P(j - 1, -lado[j]), P(j, lado[j]), P(j + 1, -lado[j])]; offs = [wd / 2, wd / 2, 0.0]
            tri.append((pts, offs))
    out = []
    for pts, offs in tri:
        Q = _inset_arredondado(pts, offs, R_JANELA)
        if Q is None:
            d['avisos'].append('janela demasiado pequena: fica maciça'); continue
        out.append(Q)
    return out


def _area_poli(Q):
    return 0.5 * abs(np.sum(Q[:, 0] * np.roll(Q[:, 1], -1) - np.roll(Q[:, 0], -1) * Q[:, 1]))


def volume_previsto(d):
    """Volume [mm3] do troço 3D tal como o rhino_barra o constrói (analítico)."""
    integ = np.trapezoid if hasattr(np, 'trapezoid') else np.trapz
    sec = d['secoes']
    V = integ(_area_ret([x['t'] for x in sec], [x['b'] for x in sec], [x['R'] for x in sec]), [x['s'] for x in sec])
    for cav in d['cavidades']:
        V -= integ(_area_ret([x['t'] for x in cav], [x['b'] for x in cav], [x['R'] for x in cav]), [x['s'] for x in cav])
    for J in d['janelas']:
        V -= _area_poli(J) * 2 * d['parede']
    return float(V)


def massa_prevista(peca, planeta, vid):
    d = descrever(peca, planeta, vid)
    V = volume_previsto(d)
    rho = material(planeta, d['material'])['rho'] * 1e-9
    G = gb.GEO[peca]
    return dict(id=vid, material=d['material'], massa_2d=d['massa_2d'], massa_meio_2d=d['massa_braco_2d'],
                massa_meio_3d_prevista=V * rho, massa_3d_prevista=(V + G['V_verde']) * rho, FS_2d=d['FS_2d'])


# ------------------------------------------------------------------------------
# API por peça (para geo_barra_<x>.py)
# ------------------------------------------------------------------------------
def api(peca):
    peca = gb.nome_barra(peca)
    return dict(
        PECA=peca, NOME_STEP=gb.GEO[peca]['nome_step'], SAIDA=saida(peca), PLANETAS=PLANETAS, NOME_FAM=NOME_FAM,
        V_VERDE=gb.GEO[peca]['V_verde'], nome_planeta=nome_planeta, material=material, FS_req=FS_req,
        candidatos=lambda planeta, n: candidatos(peca, planeta, n),
        linha=lambda planeta, vid: linha(peca, planeta, vid),
        lista_casos=lambda planeta, gravar=False: lista_casos(peca, planeta, gravar),
        n_casos=lambda planeta: len(lista_casos(peca, planeta)),
        dist_ligacoes=lambda P: dist_ligacoes(peca, P),
        descrever=lambda planeta, vid: descrever(peca, planeta, vid),
        massa_prevista=lambda planeta, vid: massa_prevista(peca, planeta, vid),
    )


# ------------------------------------------------------------------------------
# teste fora do Rhino
# ------------------------------------------------------------------------------
def figura_teste(caminho, peca='barra traseira', n=5):
    """Vista lateral (s, n) e secção das n primeiras candidatas de cada planeta."""
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    fig, axs = plt.subplots(len(PLANETAS), 1, figsize=(12, 2.0 * len(PLANETAS)))
    for ax, p in zip(axs, PLANETAS):
        vid = candidatos(peca, p, 1)[0]
        d = descrever(peca, p, vid)
        sec = d['secoes']
        s = [x['s'] for x in sec]; t = np.array([x['t'] for x in sec])
        ax.fill(np.r_[s, s[::-1]], np.r_[t / 2, -t[::-1] / 2], color='#2E86C1', alpha=.5, ec='k')
        for cav in d['cavidades']:
            sc_ = [x['s'] for x in cav]; tc = np.array([x['t'] for x in cav])
            ax.plot(np.r_[sc_, sc_[::-1], sc_[0]], np.r_[tc / 2, -tc[::-1] / 2, tc[0] / 2], 'w--', lw=1)
        for J in d['janelas']:
            ax.fill(J[:, 0], J[:, 1], color='white', ec='k', lw=.6)
        mp = massa_prevista(peca, p, vid)
        ax.set_title('{} {} ({}{}) | massa 2D {:.2f} kg / 3D prevista {:.2f} kg | {}'.format(
            p, vid, NOME_FAM[d['familia']], ', recurso' if d['recurso'] else '', d['massa_2d'],
            mp['massa_3d_prevista'], '; '.join(sorted(set(d['avisos']))) or 'sem avisos'), fontsize=8)
        ax.set_aspect('equal'); ax.grid(alpha=.3)
    fig.tight_layout(); fig.savefig(caminho, dpi=100); plt.close(fig)


if __name__ == '__main__':
    import time
    os.makedirs(os.path.join(AQUI, 'diag'), exist_ok=True)
    linhas = []
    for peca in gb.BARRAS:
        for p in PLANETAS:
            t0 = time.time()
            ids = candidatos(peca, p, 5)
            cs_ = lista_casos(peca, p, gravar=True)
            for vid in ids:
                m = massa_prevista(peca, p, vid)
                d = descrever(peca, p, vid)
                linhas.append(dict(peca=peca, planeta=p, id=vid, familia=d['familia'], material=m['material'],
                                   massa_2d=round(m['massa_2d'], 3), massa_3d_prevista=round(m['massa_3d_prevista'], 3),
                                   razao=round(m['massa_3d_prevista'] / m['massa_2d'], 3), FS_2d=m['FS_2d'],
                                   janelas=len(d['janelas']), avisos='; '.join(sorted(set(d['avisos'])))))
            print('{:15s} {:9s} {} casos 3D (de {}) | 5 candidatas {} | {:.1f} s'.format(
                peca, p, len(cs_), len(gb.casos(peca, p)), ids, time.time() - t0))
        figura_teste(os.path.join(AQUI, 'diag', gb.SLUG[peca], 'teste_3d.png'), peca)
    gb.gravar_csv(os.path.join(AQUI, 'diag', 'candidatas_3d_barras.csv'), linhas)
    r = np.array([l['razao'] for l in linhas])
    print('massa 3D prevista / 2D: min {:.3f} med {:.3f} max {:.3f}'.format(r.min(), np.median(r), r.max()))
    print('[OK] diag/candidatas_3d_barras.csv, diag/<barra>/teste_3d.png, diag/<barra>/intact/*_casos_equivalentes.csv')
