# r: numpy, scipy, matplotlib
"""Módulo 'rhino' da barra traseira para os componentes genéricos do Grasshopper (pecas_registo.py)."""
import rhino_barra as _rb
globals().update(_rb.api("barra traseira"))
