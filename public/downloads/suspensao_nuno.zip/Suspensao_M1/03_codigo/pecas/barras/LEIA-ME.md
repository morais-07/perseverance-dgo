# Barras — pipeline 2D + 3D (M1, 02/11)

Pasta: `m1\pecas\barras\` (usa `..\nucleo\` para cargas, planetas, degradação e materiais).

## Ordem
1. `python gerador_barras.py [traseira meio frente esquerda]` (~1 min, as 4) → `diag\<barra>\populacoes\<planeta>.csv`,
   `diag\<barra>\<planeta>_top10.csv`, `diag\<barra>\dispersao.png`, `diag\resumo_barras.csv`, `diag\mais_leves_barras.png`.
2. `python peca_barra.py` (~12 s) → teste da descrição 3D: `diag\candidatas_3d_barras.csv` (5 candidatas por barra × planeta,
   massa 3D prevista), `diag\<barra>\teste_3d.png`, `diag\<barra>\intact\<planeta>_casos_equivalentes.csv`.
3. Rhino: `_ScriptEditor` → `teste_rhino_barras.py` → Run → `diag\teste_rhino_barras.txt` + camada `Teste_barras`.
4. Grasshopper (`pecas.gh`): Panel PECA = `barra traseira` / `barra do meio` / `barra do frente` / `barra esquerda`; **N = 5**.

## Ficheiros
- `gerador_barras.py` — geometria do STEP, genes, análise, populações. `secoes.py` = cópia do joelho do meio.
- `peca_barra.py` — descrição 3D sem Rhino, massa prevista (analítica), casos 3D, `api(peca)`.
- `rhino_barra.py` — sólidos (loft, cavidade, janelas), faces de ligação, `montar`.
- `geo_barra_<x>.py`, `rhino_barra_<x>.py` — invólucros de 3 linhas que ligam a API a cada barra (`gh\pecas_registo.py`).

## Modelo
- STEP: as 4 barras são **varões maciços**. Pontas (Ø72,5; na esquerda Ø89,2 / Ø76,6) encaixam nos suportes → **VERDE**.
  Troço do meio (reto) → **PROJETO**. Barra traseira 2040 cm³ (5,7 kg Al): verde 684 + troço 1357 cm³.
- Consola: fixa na raiz (lado do corpo), carregada na ponta pelas rodas (núcleo: mesmos casos + induzidos do pino do bogie).
  A barra esquerda vê as 2 rodas do bogie → 15 casos 3D (as outras 8).
- Genes: **tamanho** (fração do raio do espaço de projeto) e **aspeto** (t/b) → largura t e prof b (a secção cabe sempre);
  **conicidade** (mais grossa na raiz se > 0); **rot** (rotação da secção em torno do eixo, −90…90°) + família.
- Famílias: tubo retangular de cantos redondos (Lua/Mercúrio/Marte); **treliça = caixa com banzos contínuos e paredes
  laterais com janelas triangulares (Warren)**, fechada à torção pelas diagonais (Europa/Titã/Io); perfil I com nervuras (Vénus).
- Análise: flexão biaxial + torção + corte; tubo = `secoes.caixa_sigma` (+ encurvadura local); treliça = banzos (Bredt, placa
  comprimida) + diagonais (corte + torção, Euler fora da parede); perfil I = encurvadura de alma e banzo; **Euler global da
  consola (K = 2)** como amplificação 1/(1 − P/Pcr). Degradação igual às outras peças (paredes da treliça: 2 faces expostas).
- Massa = troço NOVO + pontas verdes (volume do STEP), no mesmo material.

## Decisões / hipóteses (02/11)
1. **Espaço de projeto = cilindro Ø 1,6 × Ø do troço original** (Ø106 / Ø115 na esquerda), livre de obstáculos (A VERIFICAR
   no Rhino com a suspensão montada). Com 1,3× ficavam 5 barra × planeta sem nenhuma variante.
2. **Regra de recurso da gramática:** se a família do planeta dá < 5 variantes que passam (N do 3D), junta-se a família
   tubo fechado (IDs com `F`, ex. `VÉN-BTF896`). Usada em: **Vénus (as 4 barras)** — o perfil I aberto não aguenta a torção das
   cargas laterais (FS máx 0,97 em 4 × 600, guardado em `diag\_venus_perfil_aberto\`) — e **barra esquerda em Europa e Io**
   (as paredes com janelas chegam só a FS ≈ 2,2 < 2,5). Na barra esquerda de Europa/Io o tubo de recurso é a mais leve.
3. **Em Vénus o varão original maciço, mesmo em Inconel 718, não passa na barra esquerda (FS 1,75 < 2,5)** e fica no limite na
   barra do frente (2,52): o ambiente obriga a secções maiores → resultado para a apresentação.
4. Corte fora do plano (Vb) incluído de forma simplificada; concentrações de tensão no ombro troço/ponta ignoradas no 2D
   (o Intact exclui 8 mm junto às faces de ligação, como nas outras peças).

## Resultados 2D (mais leve que passa)
| barra | planeta | família (recurso) | passam | mais leve | material | massa total / troço kg (original Al: troço) | FS |
|---|---|---|---|---|---|---|---|
| traseira | Lua | fechada | 239 | LUA-BT000 | Al 7075-T6 | 2.94 / 1.018 (3.813) | 2.62 |
| traseira | Mercúrio | fechada | 267 | MER-BT132 | Ti-6Al-4V | 4.31 / 1.281 (3.813) | 2.31 |
| traseira | Marte | fechada | 198 | MAR-BT211 | Al 7075-T6 | 2.895 / 0.974 (3.813) | 2.39 |
| traseira | Europa | trelica | 31 | EUR-BT514 | Al 7075-T6 | 3.452 / 1.531 (3.813) | 2.68 |
| traseira | Titã | trelica | 92 | TIT-BT122 | Al 7075-T6 | 2.53 / 0.609 (3.813) | 3.13 |
| traseira | Io | trelica | 64 | IO-BT514 | Al 7075-T6 | 3.526 / 1.605 (3.813) | 3.67 |
| traseira | Vénus | isogrid → tubo | 126 | VÉN-BTF896 | Ti-6Al-4V | 6.557 / 3.529 (3.813) | 2.72 |
| do meio | Lua | fechada | 238 | LUA-BM032 | Al 7075-T6 | 2.69 / 0.769 (3.706) | 2.59 |
| do meio | Mercúrio | fechada | 253 | MER-BM576 | Ti-6Al-4V | 4.623 / 1.594 (3.706) | 2.31 |
| do meio | Marte | fechada | 198 | MAR-BM255 | Al 7075-T6 | 3.014 / 1.093 (3.706) | 2.54 |
| do meio | Europa | trelica | 26 | EUR-BM032 | Ti-6Al-4V | 4.53 / 1.502 (3.706) | 3.12 |
| do meio | Titã | trelica | 87 | TIT-BM167 | Al 7075-T6 | 2.589 / 0.668 (3.706) | 3.12 |
| do meio | Io | trelica | 37 | IO-BM054 | Al 7075-T6 | 3.319 / 1.398 (3.706) | 2.6 |
| do meio | Vénus | isogrid → tubo | 124 | VÉN-BMF565 | Ti-6Al-4V | 6.421 / 3.392 (3.706) | 2.81 |
| do frente | Lua | fechada | 227 | LUA-BF201 | Al 7075-T6 | 3.955 / 2.034 (6.249) | 2.48 |
| do frente | Mercúrio | fechada | 180 | MER-BF636 | Ti-6Al-4V | 6.453 / 3.424 (6.249) | 2.29 |
| do frente | Marte | fechada | 174 | MAR-BF329 | Al 7075-T6 | 3.839 / 1.918 (6.249) | 2.33 |
| do frente | Europa | trelica | 8 | EUR-BF747 | Ti-6Al-4V | 5.855 / 2.826 (6.249) | 2.61 |
| do frente | Titã | trelica | 42 | TIT-BF242 | Al 7075-T6 | 3.38 / 1.459 (6.249) | 2.61 |
| do frente | Io | trelica | 15 | IO-BF747 | Ti-6Al-4V | 6.035 / 3.006 (6.249) | 3.36 |
| do frente | Vénus | isogrid → tubo | 46 | VÉN-BFF1225 | Ti-6Al-4V | 9.015 / 5.986 (6.249) | 2.61 |
| esquerda | Lua | fechada | 142 | LUA-BE211 | Al 7075-T6 | 4.384 / 2.145 (5.946) | 2.25 |
| esquerda | Mercúrio | fechada | 65 | MER-BE475 | Ti-6Al-4V | 7.716 / 4.186 (5.946) | 2.57 |
| esquerda | Marte | fechada | 92 | MAR-BE251 | Al 7075-T6 | 5.206 / 2.966 (5.946) | 2.1 |
| esquerda | Europa | trelica → tubo | 474 | EUR-BEF1117 | Al 7075-T6 | 3.851 / 1.611 (5.946) | 2.97 |
| esquerda | Titã | trelica | 26 | TIT-BE337 | Al 7075-T6 | 5.143 / 2.903 (5.946) | 2.78 |
| esquerda | Io | trelica → tubo | 566 | IO-BEF1037 | Al 7075-T6 | 3.878 / 1.639 (5.946) | 2.52 |
| esquerda | Vénus | isogrid → tubo | 7 | VÉN-BEF1523 | Inconel 718 | 19.532 / 13.005 (5.946) | 2.85 |

Massa 3D prevista / 2D das 5 candidatas: 0,99–1,04 (geometria reta: sem as cunhas do joelho do meio).
