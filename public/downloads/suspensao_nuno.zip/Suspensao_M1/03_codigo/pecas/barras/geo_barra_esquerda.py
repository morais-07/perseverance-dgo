"""Módulo 'geo' da barra esquerda para os componentes genéricos do Grasshopper (pecas_registo.py).
Só liga a API de peca_barra.py a esta barra."""
import peca_barra as _pb
globals().update(_pb.api("barra esquerda"))
