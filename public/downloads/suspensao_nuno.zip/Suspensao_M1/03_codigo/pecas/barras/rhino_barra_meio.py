# r: numpy, scipy, matplotlib
"""Módulo 'rhino' da barra do meio para os componentes genéricos do Grasshopper (pecas_registo.py)."""
import rhino_barra as _rb
globals().update(_rb.api("barra do meio"))
