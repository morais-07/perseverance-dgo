# r: numpy, scipy, matplotlib
"""
==============================================================================
 BARRAS - CONSTRUÇÃO 3D NO RHINO (RhinoCommon) + MONTAGEM
==============================================================================
A geometria vem de peca_barra.descrever() (pontos globais do STEP):
  1. loft das secções (retângulo de cantos redondos t x b) de s0 a s1 -> tampas planas
     (tampa s0 = face FIXA, tampa s1 = face de CARGA: planas e faces próprias)
  2. tubo:    cavidade (loft interior, tampas planas) + respiro Ø3
     treliça: cavidade da caixa + janelas triangulares extrudidas na direção B
              (atravessam as duas paredes laterais; os banzos ficam inteiros)
construir(planeta, vid) -> dict(peca, face_fixa, face_carga, centro_carga, desc, volume, estado)
montar(planeta)         -> suspensão do STEP com a barra trocada pelas 2 melhores + STEP
api(peca)               -> funções ligadas a uma barra (rhino_barra_<x>.py)
==============================================================================
"""
import os
import sys
import csv

AQUI = r"C:\Mestrado\designD\m1\pecas\barras"
NUCLEO = r"C:\Mestrado\designD\m1\pecas\nucleo"
STEP = r"C:\Mestrado\designD\m1\joelho_traseiro_STEP\step\suspensao_v1.step"
for _p in (AQUI, NUCLEO):
    if _p not in sys.path:
        sys.path.insert(0, _p)
import numpy as np
import Rhino
import Rhino.Geometry as rg
import scriptcontext as sc
import gerador_barras as gb
import peca_barra as pb

FOLGA_MM = 600.0
FILA0 = 9                  # filas de montagem: 1-7 joelho do meio; barras a partir da 9
_LOG = []


def _log(*a):
    _LOG.append(" ".join(str(x) for x in a))


def _lista(tipo, itens):
    from System.Collections.Generic import List
    l = List[tipo]()
    for i in itens:
        l.Add(i)
    return l


def _pt(P):
    return rg.Point3d(float(P[0]), float(P[1]), float(P[2]))


def _vec(V):
    return rg.Vector3d(float(V[0]), float(V[1]), float(V[2]))


def _seccao(S, N, B):
    """Retângulo t (direção N) x b (direção B), cantos de raio R, centrado em S['c']."""
    import math
    t, b = S['t'], S['b']
    r = max(min(S['R'], 0.49 * t, 0.49 * b), 0.3)
    O = _pt(S['c']); Nv = _vec(N); Bv = _vec(B)

    def P(u, v):
        return O + Nv * u + Bv * v
    a, h = t / 2.0, b / 2.0
    k = 1 - math.cos(math.pi / 4)
    pc = rg.PolyCurve()
    pc.Append(rg.Line(P(a, 0), P(a, h - r)))
    pc.Append(rg.Arc(P(a, h - r), P(a - r * k, h - r * k), P(a - r, h)))
    pc.Append(rg.Line(P(a - r, h), P(-a + r, h)))
    pc.Append(rg.Arc(P(-a + r, h), P(-a + r * k, h - r * k), P(-a, h - r)))
    pc.Append(rg.Line(P(-a, h - r), P(-a, -h + r)))
    pc.Append(rg.Arc(P(-a, -h + r), P(-a + r * k, -h + r * k), P(-a + r, -h)))
    pc.Append(rg.Line(P(-a + r, -h), P(a - r, -h)))
    pc.Append(rg.Arc(P(a - r, -h), P(a - r * k, -h + r * k), P(a, -h + r)))
    pc.Append(rg.Line(P(a, -h + r), P(a, 0)))
    return pc.ToNurbsCurve()


def _solido(b, tol):
    if b is None:
        return None
    if not b.IsSolid:
        c = b.CapPlanarHoles(tol)
        b = c if c is not None else b
    if b.IsSolid and b.SolidOrientation == rg.BrepSolidOrientation.Inward:
        b.Flip()
    return b if b.IsSolid else None


def _loft_solido(secoes, N, B, tol):
    curvas = [_seccao(S, N, B) for S in secoes]
    r = rg.Brep.CreateFromLoft(_lista(rg.Curve, curvas), rg.Point3d.Unset, rg.Point3d.Unset,
                               rg.LoftType.Straight, False)
    return _solido(r[0] if r else None, tol)


def _diferenca(corpo, ferramentas, tol, nome):
    ferramentas = [f for f in ferramentas if f is not None]
    if not ferramentas:
        return corpo, False
    V0 = corpo.GetVolume()
    r = rg.Brep.CreateBooleanDifference(_lista(rg.Brep, [corpo]), _lista(rg.Brep, ferramentas), tol)
    if r:
        novo = max(r, key=lambda x: x.GetVolume())
        if novo.IsSolid and novo.GetVolume() < V0 - 1.0:
            return novo, True
    _log("AVISO: {} falhou (Boolean)".format(nome))
    return corpo, False


def _dentro(corpo, ferr, tol, n_max=400):
    """True se a ferramenta está TODA dentro do corpo, sem tocar na pele (amostra dos vértices da malha)."""
    ms = rg.Mesh.CreateFromBrep(ferr, rg.MeshingParameters.Coarse) or []
    pts = [v for m in ms for v in m.Vertices]
    if not pts:
        return False
    passo = max(1, len(pts) // n_max)
    for v in pts[::passo]:
        p = rg.Point3d(v.X, v.Y, v.Z)
        if not corpo.IsPointInside(p, tol, True):
            return False
        if corpo.ClosestPoint(p).DistanceTo(p) < 0.5:
            return False
    return True


def _vazio_por_casca(corpo, ferr, tol):
    """02/11: cavidade FECHADA lá dentro -> a booleana do RhinoCommon falha (não há interseções).
    Entra como casca interior (normais para dentro) do mesmo Brep = sólido com vazio."""
    if ferr is None or not _dentro(corpo, ferr, tol):
        return corpo, False
    V0 = corpo.GetVolume()
    Vc = abs(ferr.GetVolume())
    c = ferr.DuplicateBrep()
    if c.SolidOrientation == rg.BrepSolidOrientation.Outward:
        c.Flip()
    novo = corpo.DuplicateBrep()
    novo.Append(c)
    if novo.IsValid and novo.IsSolid and abs(novo.GetVolume() - (V0 - Vc)) < 0.01 * V0:
        return novo, True
    return corpo, False


def _janela(peca, d, Q, H, tol):
    """Polígono (s, n) -> prisma na direção B, de -H a +H."""
    P0 = pb.p3(peca, Q[:, 0], Q[:, 1], -H, d['N'], d['B'])
    pts = [_pt(p) for p in P0]
    pts.append(pts[0])
    crv = rg.PolylineCurve(_lista(rg.Point3d, pts))
    srf = rg.Surface.CreateExtrusion(crv, _vec(d['B'] * 2 * H))
    return _solido(srf.ToBrep(), tol) if srf is not None else None


def construir(peca, planeta, vid, tol=0.01):
    del _LOG[:]
    peca = gb.nome_barra(peca)
    d = pb.descrever(peca, planeta, vid)
    N, B = d['N'], d['B']
    corpo = _loft_solido(d['secoes'], N, B, tol)
    if corpo is None:
        raise Exception("{}: o loft exterior não fechou".format(vid))
    estado = []
    V_cheio = corpo.GetVolume()
    for cav in d['cavidades']:
        oco = _loft_solido(cav, N, B, tol)
        corpo, ok = _diferenca(corpo, [oco], tol, "cavidade")
        if not ok:                                   # 02/11: vazio fechado -> casca interior
            corpo, ok = _vazio_por_casca(corpo, oco, tol)
            if ok:
                _log("cavidade por casca interior (sem booleana)")
        estado.append("oca" if ok else "MACIÇA (cavidade falhou)")
    if d['familia'] == 'fechada' and d['cavidades'] and estado and estado[-1] == "oca":
        m = d['cavidades'][0][len(d['cavidades'][0]) // 2]
        cil = rg.Cylinder(rg.Circle(rg.Plane(_pt(m['c']), _vec(B)), 1.5), d['b_max'] / 2 + 5).ToBrep(True, True)
        corpo, ok = _diferenca(corpo, [cil], tol, "respiro")
        estado.append("respiro Ø3" if ok else "sem respiro")
    if d['janelas']:
        H = d['b_max'] / 2 + 5
        ferr = [_janela(peca, d, J, H, tol) for J in d['janelas']]
        corpo, ok = _diferenca(corpo, ferr, tol, "janelas")
        estado.append("{} janelas x 2 paredes".format(len(d['janelas']) if ok else 0))
    if d['cavidades']:
        estado.append("{:.0f} % do maciço".format(100.0 * corpo.GetVolume() / V_cheio))
    # faces de ligação: tampas planas perpendiculares ao eixo em s0 / s1
    G = gb.GEO[peca]
    fixa, carga = [], []
    for fc in corpo.Faces:
        if not fc.IsPlanar(0.1):
            continue
        fb = fc.DuplicateFace(False)
        amp = rg.AreaMassProperties.Compute(fb)
        if amp is None:
            continue
        c = np.array([amp.Centroid.X, amp.Centroid.Y, amp.Centroid.Z])
        s = (c - G['raiz']) @ G['e1']
        if abs(s - G['s0']) < 0.5:
            fixa.append((amp.Area, fb, amp.Centroid))
        elif abs(s - G['s1']) < 0.5:
            carga.append((amp.Area, fb, amp.Centroid))
    if not carga or not fixa:
        raise Exception("{}: não encontrei as faces de ligação (fixa {}, carga {})".format(vid, len(fixa), len(carga)))

    def junta(lst):
        b = lst[0][1].DuplicateBrep()
        for _, f, _ in lst[1:]:
            b.Append(f)
        return b
    A = sum(x[0] for x in carga)
    cc = np.sum([x[0] * np.array([x[2].X, x[2].Y, x[2].Z]) for x in carga], axis=0) / A
    if corpo.SolidOrientation == rg.BrepSolidOrientation.Inward:
        corpo.Flip()
    return dict(peca=corpo, face_fixa=junta(fixa), face_carga=junta(carga), centro_carga=cc,
                desc=d, volume=corpo.GetVolume(), estado="; ".join(estado),
                n_faces=(len(fixa), len(carga)), log=list(_LOG))


# ==============================================================================
# MONTAGEM NA SUSPENSÃO (cópia ao lado da original) + STEP
# ==============================================================================
def _brep(g, xf):
    b = None
    if isinstance(g, rg.Brep):
        b = g.DuplicateBrep()
    elif isinstance(g, rg.Extrusion):
        b = g.ToBrep()
    elif isinstance(g, rg.Mesh):
        b = g.DuplicateMesh()
    if b is not None:
        b.Transform(xf)
    return b


def pecas_da_suspensao(nome):
    """Todas as peças do STEP (transformação global), marcando as que têm 'nome'."""
    nome = nome.lower()
    out = []

    def descer(idef, xf, alvo):
        for o in idef.GetObjects():
            g = o.Geometry
            j = alvo or nome in (o.Attributes.Name or "").lower()
            if isinstance(g, rg.InstanceReferenceGeometry):
                sub = sc.doc.InstanceDefinitions.FindId(g.ParentIdefId)
                descer(sub, xf * g.Xform, j or nome in (sub.Name or "").lower())
            else:
                b = _brep(g, xf)
                if b is not None:
                    out.append((j, b))

    cfg = Rhino.DocObjects.ObjectEnumeratorSettings()
    cfg.HiddenObjects = True
    cfg.LockedObjects = True
    for o in sc.doc.Objects.GetObjectList(cfg):
        if o.IsDeleted:
            continue
        lay = sc.doc.Layers[o.Attributes.LayerIndex].FullPath
        if lay.startswith(("Joelho_completo", "Montagem", "Intact", "Teste_", "Suspensao_")):
            continue
        g = o.Geometry
        j = nome in (o.Attributes.Name or "").lower()
        if isinstance(g, rg.InstanceReferenceGeometry):
            idef = sc.doc.InstanceDefinitions.FindId(g.ParentIdefId)
            descer(idef, g.Xform, j or nome in (idef.Name or "").lower())
        else:
            b = _brep(g, rg.Transform.Identity)
            if b is not None:
                out.append((j, b))
    return out


def _camada(nome, cor):
    import rhinoscriptsyntax as rs
    if not rs.IsLayer(nome):
        rs.AddLayer(nome, cor)
    return sc.doc.Layers.FindByFullPath(nome, -1)


def caixas_verdes(peca):
    """Semi-espaços s < s0 (ponta da raiz) e s > s1 (ponta da roda), no referencial da barra."""
    G = gb.GEO[peca]
    pl_ = rg.Plane(_pt(G['raiz']), _vec(G['e1']), _vec(G['e2']))
    a = rg.Box(pl_, rg.Interval(-2000.0, G['s0']), rg.Interval(-2000.0, 2000.0), rg.Interval(-2000.0, 2000.0)).ToBrep()
    b = rg.Box(pl_, rg.Interval(G['s1'], 2000.0), rg.Interval(-2000.0, 2000.0), rg.Interval(-2000.0, 2000.0)).ToBrep()
    return a, b


def barra_do_step(peca, pecas):
    """(barras do STEP desta peça, resto) — a barra é a peça com o nome perto do eixo."""
    G = gb.GEO[peca]
    meio = _pt((G['raiz'] + G['ponta']) / 2)
    sim = [b for j, b in pecas if j and b.GetBoundingBox(True).Center.DistanceTo(meio) < 150]
    resto = [b for j, b in pecas if not (j and b.GetBoundingBox(True).Center.DistanceTo(meio) < 150)]
    return sim, resto


def verdes_step(peca, barras, tol):
    cxs = caixas_verdes(peca)
    out = []
    for b in barras:
        if isinstance(b, rg.Brep):
            for cx in cxs:
                r = rg.Brep.CreateBooleanIntersection(b, cx, tol)
                if r:
                    out.extend(list(r))
    return out


def montar(peca, planeta, exportar=True):
    import rhinoscriptsyntax as rs
    peca = gb.nome_barra(peca)
    planeta = pb.nome_planeta(planeta)
    tol = sc.doc.ModelAbsoluteTolerance
    fich = os.path.join(pb.saida(peca), planeta + "_top3.csv")
    if not os.path.exists(fich):
        raise Exception("Falta {}: corre primeiro o maestro para {}".format(fich, planeta))
    top = list(csv.DictReader(open(fich, encoding="utf-8-sig"), delimiter=";"))
    if not top:
        return "nenhuma variante de {} passou em 3D: nada para montar".format(planeta)
    nome = gb.GEO[peca]['nome_step']
    pecas = pecas_da_suspensao(nome)
    if not any(j for j, _ in pecas) and os.path.exists(STEP):
        rs.Command('_-Import "{}" _Enter'.format(STEP), echo=False)
        pecas = pecas_da_suspensao(nome)
    barras, resto = barra_do_step(peca, pecas)
    if not barras:
        raise Exception('Não encontrei "{}" no Rhino: importa o STEP da suspensão.'.format(nome))
    verdes = verdes_step(peca, barras, tol)
    if not verdes:
        raise Exception("O corte das pontas verdes do STEP falhou.")
    bb = rg.BoundingBox.Empty
    for _, b in pecas:
        bb.Union(b.GetBoundingBox(True))
    passo_x = bb.Max.X - bb.Min.X + FOLGA_MM
    passo_y = bb.Max.Y - bb.Min.Y + FOLGA_MM
    fila = FILA0 + 8 * gb.BARRAS.index(peca) + pb.PLANETAS.index(planeta)
    msgs = []
    raiz_lay = "Montagem_barras::" + gb.SLUG[peca]
    rs.EnableRedraw(False)
    try:
        _camada("Montagem_barras", (120, 120, 120))
        _camada(raiz_lay, (120, 120, 120))
        _camada(raiz_lay + "::" + planeta, (120, 120, 120))
        for lugar, lin in enumerate(top, 1):
            vid = lin["id"]
            var = construir(peca, planeta, vid, tol)["peca"]
            mover = rg.Transform.Translation(rg.Vector3d(passo_x * lugar, -passo_y * fila, 0.0))
            base = "{}::{}::{}_{}".format(raiz_lay, planeta, lugar, vid)
            lay_s = _camada(base + "::suspensao", (150, 150, 150))
            lay_v = _camada(base + "::barra_variante", (60, 110, 200))
            lay_g = _camada(base + "::barra_verde_STEP", (60, 180, 60))
            ids = []

            def junta(geo, lay, nm):
                g = geo.Duplicate()
                g.Transform(mover)
                a = Rhino.DocObjects.ObjectAttributes()
                a.LayerIndex = lay
                a.Name = nm
                ids.append(sc.doc.Objects.AddMesh(g, a) if isinstance(g, rg.Mesh) else sc.doc.Objects.AddBrep(g, a))

            for k, b in enumerate(resto):
                junta(b, lay_s, "suspensao_{}".format(k + 1))
            junta(var, lay_v, "{}_{}".format(gb.SLUG[peca], vid))
            for k, b in enumerate(verdes):
                junta(b, lay_g, "{}_{}_verde{}".format(gb.SLUG[peca], vid, k + 1))
            rs.AddObjectsToGroup(ids, rs.AddGroup("montagem_{}_{}_{}".format(gb.SLUG[peca], planeta, vid)))
            txt = "{}. {} ({} kg, FS 3D {})".format(lugar, vid, lin.get("massa_3d"), lin.get("FS_3d"))
            if exportar:
                destino = os.path.join(pb.saida(peca), "{}_{}_suspensao.stp".format(planeta, vid))
                rs.UnselectAllObjects()
                rs.SelectObjects(ids)
                rs.Command('_-Export "{}" _Enter _Enter'.format(destino), echo=False)
                rs.UnselectAllObjects()
                txt += " -> " + os.path.basename(destino)
            msgs.append(txt)
    finally:
        rs.EnableRedraw(True)
    return "{} montagens de {} ({}): {}".format(len(msgs), planeta, peca, "; ".join(msgs))


def api(peca):
    peca = gb.nome_barra(peca)
    return dict(construir=lambda planeta, vid, tol=0.01: construir(peca, planeta, vid, tol),
                montar=lambda planeta, exportar=True: montar(peca, planeta, exportar),
                caixas_verdes=lambda: caixas_verdes(peca), PECA=peca)
