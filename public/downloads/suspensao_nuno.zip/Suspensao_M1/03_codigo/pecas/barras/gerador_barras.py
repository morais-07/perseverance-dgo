"""
==============================================================================
 GERADOR DE VARIANTES 2D - AS 4 BARRAS DA SUSPENSÃO (por planeta, com degradação)
==============================================================================
Barras do STEP (todas VARÕES MACIÇOS):  ponta raiz (VERDE, encaixa no suporte)
   -> troço do meio (PROJETO, reto)  -> ponta do lado da roda (VERDE)
     barra traseira  (bogie -> joelho traseiro)   Ø66,3 x 393 mm   (2040 cm3)
     barra do meio   (bogie -> joelho do meio)    Ø66,3 x 382 mm   (2002 cm3)
     barra do frente (cubo do rocker -> frente)   Ø66,3 x 644 mm   (2907 cm3)
     barra esquerda  (cubo do rocker -> bogie)    Ø71,6 x 526 mm   (2913 cm3)
Cada barra é uma CONSOLA: fixa na raiz, carregada na ponta pelas rodas
(nucleo/cargas_suspensao: mesmos casos por roda + induzidos pelo pino do bogie).

Genes comuns: largura t (altura da secção na direção n), prof b (direção b),
  conicidade c (t e b x (1 + c (1 - 2u)), u = 0 na raiz -> mais grossa na raiz),
  rot (ângulo da secção em torno do eixo da barra: n = cos e2 + sin e3)
  + genes da FAMÍLIA do planeta (iguais aos do joelho do meio):
    fechada (Lua, Mercúrio, Marte): tubo retangular de cantos redondos -> parede, r_cantos
    trelica (Europa, Titã, Io):     2 banzos + diagonais (Warren) no plano (e1, n)
    isogrid (Vénus):                perfil I (alma no plano (e1, n)) com nervuras
Espaço de projeto: cilindro Ø D_ENV = 1,6 x Ø do troço original à volta do eixo
  (HIPÓTESE: livre de obstáculos; verificar no Rhino com a suspensão montada).
Análise em cada estação e caso: N, Vn, T, M (flexão no plano, sobre o eixo b),
  Mn (flexão fora do plano) -> secoes.caixa_sigma (tubo, encurvadura local) /
  banzos + diagonais com Euler (treliça) / perfil I com encurvadura de alma e
  banzo (nervuras).  + Euler GLOBAL da consola (K = 2): amplificação 1/(1 - P/Pcr).
Degradação: genes = secção GASTA (FS); dg.engrossar = peça NOVA (massa).

Uso:  python gerador_barras.py [barra ...]   (barra = traseira, meio, frente, esquerda)
Saída: diag/<barra>/populacoes/<planeta>.csv, diag/<barra>/<planeta>_top10.csv,
       diag/<barra>/dispersao.png, diag/resumo_barras.csv, diag/mais_leves_barras.png
==============================================================================
"""
import os, sys, csv, json
import numpy as np
from scipy.stats import qmc

AQUI = os.path.dirname(os.path.abspath(__file__))
_NUC = os.path.normpath(os.path.join(AQUI, '..', 'nucleo'))
if _NUC not in sys.path:
    sys.path.insert(0, _NUC)
if AQUI not in sys.path:
    sys.path.insert(0, AQUI)
import cargas_suspensao as cs
import planetas as pl
import degradacao as dg
import materiais as mt
import secoes as sc

BARRAS = ['barra traseira', 'barra do meio', 'barra do frente', 'barra esquerda']
SLUG = {'barra traseira': 'traseira', 'barra do meio': 'meio', 'barra do frente': 'frente',
        'barra esquerda': 'esquerda'}
SIGLA = {'barra traseira': 'BT', 'barra do meio': 'BM', 'barra do frente': 'BF', 'barra esquerda': 'BE'}
FAMILIA = {'Lua': 'fechada', 'Mercúrio': 'fechada', 'Marte': 'fechada',
           'Europa': 'trelica', 'Titã': 'trelica', 'Io': 'trelica', 'Vénus': 'isogrid'}
# REGRA DE RECURSO (02/11): se a família do planeta dá menos de MIN_PASSAM variantes que passam
# (N do 3D), a população recebe também a família RECURSO (tubo fechado, ID com 'F').
# Motivo físico: as cargas laterais dão torção grande nas barras; o perfil aberto (Vénus: FS
# máx 0,97 em 4 x 600) e as paredes com janelas na barra esquerda (Europa/Io) não chegam.
RECURSO = 'fechada'
MIN_PASSAM = 5
PREFIXO = {'Lua': 'LUA', 'Mercúrio': 'MER', 'Marte': 'MAR', 'Europa': 'EUR',
           'Titã': 'TIT', 'Io': 'IO', 'Vénus': 'VÉN'}
NOME_FAM = {'fechada': 'tubo oco', 'trelica': 'treliça', 'isogrid': 'nervuras'}
N_EST = 41
N_POP = {'Mercúrio': 800, 'Vénus': 800, 'Europa': 800, 'Io': 800}
N_POP_DEF = 400
SEMENTE = 23
TOP = 10
K_EULER = 2.0               # consola (fixa na raiz, livre na ponta): conservador
ENV = 1.60                  # espaço de projeto: Ø 1,6 x troço original (02/11: 1,3 deixava 5 barra x planeta sem nenhuma)
GENES = {
    'fechada': dict(parede=(1.5, 14.0), r_cantos=(0.10, 0.50)),
    'trelica': dict(banzo=(3.0, 16.0), parede=(2.0, 8.0), diagonal=(4.0, 14.0), paineis=(3, 10), montantes=(0, 1)),
    'isogrid': dict(banzo=(5.0, 25.0), alma=(4.0, 20.0), nervura=(3.0, 10.0), paineis=(2, 8)),
}
INTEIROS = {'paineis', 'montantes'}
PAREDE_MIN = {'CNC': 3.0, 'L-PBF': 1.5}
JANELA_MIN = 14.0
NU_K = 0.904


# ------------------------------------------------------------------------------
# geometria da barra (STEP)
# ------------------------------------------------------------------------------
def _geo(peca):
    p = cs.PECAS[peca]
    cil = [c for c in cs._pecas[p['nome_step']]['cilindros'] if c['tipo'] == 'veio']
    def perto(P):
        return min(cil, key=lambda c: np.linalg.norm(np.array(c['centro_global_mm']) - P))
    cr, cp = perto(p['raiz']), perto(p['ponta'])
    meio = [c for c in cil if c is not cr and c is not cp][0]
    e1 = p['eixo']
    ref = np.array([0.0, 0.0, 1.0]) if abs(e1[2]) < 0.9 else np.array([1.0, 0.0, 0.0])
    e2 = cs._unit(np.cross(ref, e1)); e3 = np.cross(e1, e2)
    L = p['comprimento']
    s0, s1 = cr['comprimento_mm'] / 2, L - cp['comprimento_mm'] / 2
    vol = lambda c: np.pi * (c['diametro_mm'] / 2) ** 2 * c['comprimento_mm']
    return dict(peca=peca, raiz=np.asarray(p['raiz'], float), ponta=np.asarray(p['ponta'], float),
                e1=e1, e2=e2, e3=e3, L=L, s0=s0, s1=s1, D_raiz=cr['diametro_mm'], D_ponta=cp['diametro_mm'],
                L_raiz=cr['comprimento_mm'], L_ponta=cp['comprimento_mm'], D_meio=meio['diametro_mm'],
                L_meio=meio['comprimento_mm'], V_verde=vol(cr) + vol(cp), V_meio=vol(meio),
                V_step=cs._pecas[p['nome_step']]['volume_mm3'], D_env=ENV * meio['diametro_mm'],
                nome_step=p['nome_step'].split(':')[0])


GEO = {b: _geo(b) for b in BARRAS}


def nome_barra(v):
    import unicodedata
    tira = lambda s: unicodedata.normalize('NFKD', str(s)).encode('ascii', 'ignore').decode().strip().lower()
    for b in BARRAS:
        if tira(v) in (tira(b), tira(SLUG[b]), tira(SIGLA[b])):
            return b
    raise Exception('Barra desconhecida: {!r}. Usa: {}'.format(v, ', '.join(BARRAS)))


def comuns(peca):
    """Genes amostrados: tamanho (fração do raio do espaço de projeto ocupada na raiz) e
    aspeto (t/b, amostrado em log) -> largura t e prof b (ver dimensoes); a secção cabe sempre."""
    return dict(tamanho=(0.50, 1.00), aspeto=(np.log(0.4), np.log(2.5)), conicidade=(-0.2, 0.5),
                rot=(-90.0, 90.0))


def dimensoes(peca, planeta, g, fam=None):
    """(tamanho, aspeto) -> largura t, prof b (peça GASTA) tais que a peça NOVA na secção
    maior ocupa 'tamanho' x o raio do espaço de projeto."""
    G = GEO[peca]; fam = fam or FAMILIA[planeta]; dl = dg.de(planeta)['delta']
    a = np.exp(g['aspeto'])
    t0, b0 = np.sqrt(a), 1 / np.sqrt(a)
    rf = g['r_cantos'] if fam == 'fechada' else 0.0
    r0 = raio_envolvente(t0, b0, rf * min(t0, b0))
    fmax = 1 + abs(g['conicidade'])
    k = (g['tamanho'] * G['D_env'] / 2 / fmax) / r0
    return float(k * t0 - 2 * dl), float(k * b0 - 2 * dl)


def materiais(planeta):
    out = {}
    for nome, base in mt.MATERIAIS.items():
        m, _ = pl.material_no_planeta(nome, base, planeta)
        if m is not None:
            out[nome] = dg.material_gasto(m, planeta)
    return out


def direcoes(G, rot):
    a = np.radians(rot)
    n = np.cos(a) * G['e2'] + np.sin(a) * G['e3']
    bd = np.cross(G['e1'], n)
    return n, bd


def estacoes(G, n=N_EST):
    return np.linspace(G['s0'], G['s1'], n)


def escala(G, s, c):
    u = (s - G['s0']) / (G['s1'] - G['s0'])
    return 1 + c * (1 - 2 * u)


def raio_envolvente(t, b, R):
    """Raio máximo (à volta do eixo) de um retângulo t x b com cantos de raio R."""
    R = np.minimum(R, 0.5 * np.minimum(t, b))
    return np.hypot(t / 2 - R, b / 2 - R) + R


# ------------------------------------------------------------------------------
# cargas: F e M0 (em relação à origem global) por caso, só com as rodas da barra
# ------------------------------------------------------------------------------
_CASOS = {}


def casos(peca, planeta):
    k = (peca, planeta)
    if k not in _CASOS:
        out = []
        for nome, lst in cs.cargas_aplicadas(planeta).items():
            F = np.zeros(3); M0 = np.zeros(3)
            for roda, Fi, Pi in lst:
                if roda in cs.PECAS[peca]['rodas']:
                    F += Fi; M0 += np.cross(Pi, Fi)
            if np.linalg.norm(F) > 0:
                out.append((nome, F, M0))
        _CASOS[k] = out
    return _CASOS[k]


def esforcos(peca, planeta, rot, s):
    """N (com sinal, + tração), Vn, Vb, T, M (sobre b: tensão ao longo de n), Mn (sobre n)."""
    G = GEO[peca]
    n, bd = direcoes(G, rot)
    Q = G['raiz'][None, :] + s[:, None] * G['e1'][None, :]
    R = {k: [] for k in ('N', 'Vn', 'Vb', 'T', 'M', 'Mn')}
    nomes = []
    for nome, F, M0 in casos(peca, planeta):
        M = M0[None, :] - np.cross(Q, F)
        R['N'].append(np.full(len(s), F @ G['e1'])); R['Vn'].append(np.full(len(s), F @ n))
        R['Vb'].append(np.full(len(s), F @ bd))
        R['T'].append(M @ G['e1']); R['M'].append(M @ bd); R['Mn'].append(M @ n)
        nomes.append(nome)
    return nomes, {k: np.array(v) for k, v in R.items()}


# ------------------------------------------------------------------------------
# avaliação de uma variante
# ------------------------------------------------------------------------------
def avaliar(peca, planeta, g, nome_mat, mats=None, fam=None):
    mats = mats or materiais(planeta)
    mat = mats[nome_mat]
    G = GEO[peca]
    fam = fam or FAMILIA[planeta]
    m = dg.de(planeta)
    dl = m['delta']
    proc = 'L-PBF' if 'L-PBF' in nome_mat else 'CNC'
    if 'largura' not in g:
        g = dict(g); g['largura'], g['prof'] = dimensoes(peca, planeta, g, fam)
    s = estacoes(G)
    f = escala(G, s, g['conicidade'])
    t = g['largura'] * f; b = g['prof'] * f                    # peça GASTA
    gn = dg.engrossar(g, fam, planeta)
    if fam == 'trelica':                                        # paredes com janelas: 2 faces expostas
        gn['parede'] = float(g['parede']) + 2 * dl
    tn, bn = t + 2 * dl, b + 2 * dl                             # peça NOVA
    R_n = g['r_cantos'] * np.minimum(tn, bn) if fam == 'fechada' else np.full_like(tn, 0.5)
    if (raio_envolvente(tn, bn, R_n) > G['D_env'] / 2).any():
        return dict(valido=False, motivo='sai do espaço de projeto (Ø {:.0f})'.format(G['D_env']))
    if (np.minimum(t, b) < 12).any():
        return dict(valido=False, motivo='secção demasiado pequena')
    nomes, S = esforcos(peca, planeta, g['rot'], s)
    Ns = S['N']
    N, V, M, Mn, T = (np.abs(S[x]) for x in ('N', 'Vn', 'M', 'Mn', 'T'))
    Vb = np.abs(S['Vb'])
    E, sy = mat['E'], mat['sy']
    Lf = G['s1'] - G['s0']
    fc = np.ones_like(t)

    if fam == 'fechada':
        if g['parede'] < max(PAREDE_MIN[proc], m['parede_min'] or 0):
            return dict(valido=False, motivo='parede abaixo do mínimo')
        if m['r_cantos_min'] and g['r_cantos'] < m['r_cantos_min']:
            return dict(valido=False, motivo='cantos com raio abaixo do mínimo')
        ee = np.minimum(g['parede'], 0.5 * np.minimum(t, b)); rr = g['r_cantos'] * np.minimum(t, b)
        sc.E_MAT, sc.SY_MAT = E, sy
        smax = np.zeros_like(N)
        for i in range(N.shape[0]):
            p_, f_, _, _ = sc.caixa_sigma(t, b, ee, rr, N[i], np.hypot(V[i], Vb[i]), M[i], fc, Mn[i], T[i])
            smax[i] = np.maximum(p_, f_)
        A, Iz, In, _ = sc.caixa_props(t, b, ee, rr)
        en = np.minimum(gn['parede'], 0.5 * np.minimum(tn, bn))
        A_new, _, _, _ = sc.caixa_props(tn, bn, en, g['r_cantos'] * np.minimum(tn, bn))

    elif fam == 'trelica':
        # caixa: 2 banzos contínuos (placas b x wc, perpendiculares a n) + 2 paredes laterais
        # de espessura e (perpendiculares a b) com janelas triangulares (treliça Warren de
        # diagonais wd). Torção: célula fechada (Bredt) com as paredes em treliça.
        wc, e, wd, n = g['banzo'], g['parede'], g['diagonal'], int(g['paineis'])
        if e < PAREDE_MIN[proc] - 1.5 or e < (m['parede_min'] or 0):
            return dict(valido=False, motivo='parede abaixo do mínimo')
        h = t - wc
        if (t - 2 * wc < JANELA_MIN).any() or (b - 2 * e < 6).any():
            return dict(valido=False, motivo='sem altura para janelas')
        p = Lf / n
        if p < 2 * wd + JANELA_MIN:
            return dict(valido=False, motivo='painéis demasiado curtos')
        A = 2 * wc * b
        Iz = 2 * (b * wc ** 3 / 12 + wc * b * (h / 2) ** 2)
        In = 2 * wc * b ** 3 / 12 + 2 * wc * e * ((b - e) / 2) ** 2 * 2     # banzos + cordas das paredes
        Am = h * (b - e)
        q = T / (2 * Am)                                   # fluxo de corte da torção
        sig = N / A + M * (t / 2) / Iz + Mn * (b / 2) / In
        tau = q / wc + 1.5 * Vb / (2 * b * wc)
        s_banzo = np.sqrt(sig ** 2 + 3 * tau ** 2)
        # placa do banzo comprimida entre as paredes (simplesmente apoiada, k = 4)
        scr_b = 3.62 * E * (wc / np.maximum(b - 2 * e, 1e-6)) ** 2
        s_banzo = np.maximum(s_banzo, sig * sy / scr_b)
        Ld = np.sqrt(p ** 2 + h ** 2)
        Fd = (V / 2 + q * h) * Ld / h                      # por parede: corte + torção
        sd = Fd / (wd * e)
        Kef = 0.7 if g['montantes'] >= 0.5 else 1.0
        scr = np.pi ** 2 * E * (e ** 2 / 12) / (Kef * Ld) ** 2   # encurvadura para fora da parede
        smax = np.maximum(s_banzo, np.maximum(sd, sd * sy / scr))
        hn = tn - gn['banzo']
        en = gn['parede']
        A_new = 2 * gn['banzo'] * bn + 2 * en * (n * gn['diagonal'] * np.sqrt(p ** 2 + hn ** 2)
                                                  + (n + 1) * g['montantes'] * gn['diagonal'] * hn) / Lf

    else:   # isogrid: perfil I (alma no plano e1-n) com nervuras transversais
        tf, tw, wr, n = g['banzo'], g['alma'], g['nervura'], int(g['paineis'])
        hw = t - 2 * tf
        if (hw < JANELA_MIN).any() or (b <= tw + 2).any():
            return dict(valido=False, motivo='perfil I sem alma / banzos demasiado largos')
        A = 2 * b * tf + tw * hw
        Iz = (b * t ** 3 - (b - tw) * hw ** 3) / 12
        In = (2 * tf * b ** 3 + hw * tw ** 3) / 12
        bl = (b - tw) / 2
        J = (2 * b * tf ** 3 + hw * tw ** 3) / 3
        a_rib = Lf / n
        kv = np.where(a_rib >= hw, 5.35 + 4 * (hw / a_rib) ** 2, 4 + 5.35 * (hw / a_rib) ** 2)
        tcr = kv * NU_K * E * (tw / hw) ** 2
        scr_f = 0.43 * NU_K * E * (tf / np.maximum(bl, 1e-6)) ** 2
        smax = np.zeros_like(N)
        for i in range(N.shape[0]):
            sig = N[i] / A + M[i] * (t / 2) / Iz + Mn[i] * (b / 2) / In
            tau = V[i] / (tw * hw) + 1.5 * Vb[i] / (2 * tf * b) + T[i] * np.maximum(tf, tw) / J
            smax[i] = np.maximum.reduce([np.sqrt(sig ** 2 + 3 * tau ** 2), sig * sy / scr_f, tau * sy / tcr])
        hwn = tn - 2 * gn['banzo']
        A_new = 2 * bn * gn['banzo'] + gn['alma'] * hwn + (n - 1) * gn['nervura'] * hwn * (bn - gn['alma']) / Lf

    # Euler GLOBAL da consola (inércia mínima a meio do troço): amplificação da flexão
    Imin = float(np.min(np.minimum(Iz, In)))
    Pcr = np.pi ** 2 * E * Imin / (K_EULER * G['L']) ** 2
    Pc = np.maximum(-Ns.max(1), 0.0)                       # compressão máxima do caso
    if (Pc >= 0.9 * Pcr).any():
        return dict(valido=False, motivo='encurvadura global (Euler)')
    smax = smax / (1 - Pc[:, None] / Pcr)

    FS_casos = sy / np.maximum(smax.max(1), 1e-9)
    ic = int(np.argmin(FS_casos)); jc = int(np.argmax(smax[ic]))
    integ = np.trapezoid if hasattr(np, 'trapezoid') else np.trapz
    V_proj = float(integ(np.broadcast_to(A_new, len(s)), s))
    rho = mat['rho'] * 1e-9
    FS = float(FS_casos[ic])
    req = pl.PLANETAS[planeta]['FS']
    return dict(valido=True, massa_kg=(V_proj + G['V_verde']) * rho, massa_meio_kg=V_proj * rho,
                FS_min=FS, FS_req=req, passa=FS >= req, caso_critico=nomes[ic],
                s_critico=float(s[jc]), Pcr_kN=Pcr / 1e3, s=s, t=t, b=b, gn=gn)


# ------------------------------------------------------------------------------
# população
# ------------------------------------------------------------------------------
def limites(peca, planeta, fam=None):
    fam = fam or FAMILIA[planeta]
    L = comuns(peca); L.update(GENES[fam])
    m = dg.de(planeta)
    if fam == 'fechada':
        L['parede'] = (max(PAREDE_MIN['L-PBF'], m['parede_min'] or 0), L['parede'][1])
        if m['r_cantos_min']:
            L['r_cantos'] = (m['r_cantos_min'], L['r_cantos'][1])
    return L


def amostrar(peca, planeta, n, fam=None):
    L = limites(peca, planeta, fam)
    nomes = list(L)
    mats = list(materiais(planeta))
    sem = SEMENTE + 101 * BARRAS.index(peca) + (7 if fam and fam != FAMILIA[planeta] else 0)
    X = qmc.LatinHypercube(d=len(nomes) + 1, seed=sem).random(n)
    out = []
    for x in X:
        g = {}
        for j, k in enumerate(nomes):
            lo, hi = L[k]
            g[k] = int(np.floor(lo + x[j] * (hi - lo + 1 - 1e-9))) if k in INTEIROS else float(lo + x[j] * (hi - lo))
        out.append((g, mats[int(x[-1] * len(mats) * (1 - 1e-12))]))
    return out


def vid_de(peca, planeta, i, recurso=False):
    return '{}-{}{}{:03d}'.format(PREFIXO[planeta], SIGLA[peca], 'F' if recurso else '', i)


def gerar_populacao(peca, planeta, n=None):
    """Família do planeta; se passarem < MIN_PASSAM junta a família de RECURSO."""
    n = n or N_POP.get(planeta, N_POP_DEF)
    linhas, res = _gerar(peca, planeta, n, FAMILIA[planeta])
    if FAMILIA[planeta] != RECURSO and sum(1 for x in res if x[3].get('passa')) < MIN_PASSAM:
        l2, r2 = _gerar(peca, planeta, 2 * n, RECURSO, recurso=True)      # recurso: amostra dupla
        linhas += l2; res += r2
    return linhas, res


def _gerar(peca, planeta, n, fam, recurso=False):
    mats = materiais(planeta)
    linhas, res = [], []
    for i, (g, nm) in enumerate(amostrar(peca, planeta, n, fam)):
        g['largura'], g['prof'] = dimensoes(peca, planeta, g, fam)
        g = {k: (round(v, 3) if isinstance(v, float) else v) for k, v in g.items()}   # = CSV
        r = avaliar(peca, planeta, g, nm, mats, fam)
        r['familia'] = fam
        vid = vid_de(peca, planeta, i, recurso)
        lin = dict(id=vid, peca=peca, planeta=planeta, familia=fam, recurso=int(recurso), material=nm, **g,
                   delta_mm=dg.de(planeta)['delta'], k_deg=dg.de(planeta)['k_mat'])
        if r['valido']:
            lin.update(massa_kg=round(r['massa_kg'], 4), massa_meio_kg=round(r['massa_meio_kg'], 4),
                       FS_min=round(r['FS_min'], 3), FS_req=r['FS_req'], passa=int(r['passa']),
                       caso_critico=r['caso_critico'], s_critico_mm=round(r['s_critico'], 1),
                       Pcr_kN=round(r['Pcr_kN'], 1), motivo='')
        else:
            lin.update(massa_kg='', massa_meio_kg='', FS_min='', FS_req=pl.PLANETAS[planeta]['FS'], passa=0,
                       caso_critico='', s_critico_mm='', Pcr_kN='', motivo=r['motivo'])
        linhas.append(lin); res.append((vid, g, nm, r))
    return linhas, res


def gravar_csv(caminho, linhas):
    os.makedirs(os.path.dirname(caminho), exist_ok=True)
    chaves = []
    for l in linhas:
        chaves += [k for k in l if k not in chaves]
    with open(caminho, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=chaves, delimiter=';')
        w.writeheader(); w.writerows(linhas)


def massa_original(peca, nome_mat='Al 7075-T6 (CNC)'):
    G = GEO[peca]
    rho = mt.MATERIAIS[nome_mat]['rho'] * 1e-9
    return G['V_step'] * rho, G['V_meio'] * rho


def correr(barras):
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    diag = os.path.join(AQUI, 'diag')
    resumo = []
    melhores = {}
    for peca in barras:
        G = GEO[peca]
        d = os.path.join(diag, SLUG[peca])
        todos = {}
        for p in FAMILIA:
            linhas, res = gerar_populacao(peca, p)
            gravar_csv(os.path.join(d, 'populacoes', p + '.csv'), linhas)
            ok = sorted([x for x in res if x[3]['valido'] and x[3]['passa']], key=lambda x: x[3]['massa_kg'])
            gravar_csv(os.path.join(d, p + '_top10.csv'), [l for l in linhas if l['id'] in {x[0] for x in ok[:TOP]}])
            todos[p] = res
            val = [x for x in res if x[3]['valido']]
            mo, mm = massa_original(peca)
            top = ok[0] if ok else None
            resumo.append(dict(peca=peca, planeta=p, familia=FAMILIA[p], familia_mais_leve=top[3]['familia'] if top else '',
                               n=len(res), validas=len(val),
                               passam=len(ok), mais_leve=top[0] if top else '',
                               material=top[2] if top else '',
                               massa_kg=round(top[3]['massa_kg'], 3) if top else '',
                               massa_meio_kg=round(top[3]['massa_meio_kg'], 3) if top else '',
                               massa_meio_original_Al_kg=round(mm, 3), FS=round(top[3]['FS_min'], 2) if top else '',
                               caso_critico=top[3]['caso_critico'] if top else ''))
            melhores[(peca, p)] = top
            print('{:15s} {:9s} {:8s} n={} válidas={} passam={}'.format(peca, p, FAMILIA[p], len(res), len(val), len(ok))
                  + (' [recurso: {} tubos passam]'.format(sum(1 for x in ok if x[3]['familia'] != FAMILIA[p]))
                     if any(x[3]['familia'] != FAMILIA[p] for x in res) else '')
                  + (' | {} {} {:.2f} kg (meio {:.3f}, orig. Al {:.2f}) FS {:.2f} [{}]'.format(
                      top[0], top[2].split(' (')[0], top[3]['massa_kg'], top[3]['massa_meio_kg'], mm,
                      top[3]['FS_min'], top[3]['caso_critico']) if top else ''))
        # dispersão massa do troço x FS
        fig, axs = plt.subplots(2, 4, figsize=(18, 8.5)); axs = axs.ravel()
        for ax, p in zip(axs, FAMILIA):
            val = [x for x in todos[p] if x[3]['valido']]
            req = pl.PLANETAS[p]['FS']
            if val:
                mb = np.array([x[3]['massa_meio_kg'] for x in val]); fs = np.array([x[3]['FS_min'] for x in val])
                ps = fs >= req
                ax.scatter(mb[~ps], fs[~ps], s=12, c='0.7', label='não passa')
                ax.scatter(mb[ps], fs[ps], s=14, c='#2E86C1', label='passa')
                tp = sorted([x for x in val if x[3]['passa']], key=lambda x: x[3]['massa_kg'])[:TOP]
                ax.scatter([x[3]['massa_meio_kg'] for x in tp], [x[3]['FS_min'] for x in tp], s=40,
                           facecolors='none', edgecolors='r', label='10 mais leves')
            ax.axhline(req, color='r', ls='--', lw=1)
            ax.axvline(massa_original(peca)[1], color='k', ls=':', lw=1, label='troço original (Al maciço)')
            ax.set_yscale('log'); ax.set_title('{} ({})'.format(p, NOME_FAM[FAMILIA[p]]), fontsize=10)
            ax.set_xlabel('massa do troço de projeto [kg]'); ax.set_ylabel('FS (peça gasta)'); ax.grid(alpha=.3)
        axs[0].legend(fontsize=7); axs[-1].axis('off')
        fig.suptitle('{} — população 2D por planeta (com degradação)'.format(peca.capitalize()), fontweight='bold')
        fig.tight_layout(); fig.savefig(os.path.join(d, 'dispersao.png'), dpi=110); plt.close(fig)
    gravar_csv(os.path.join(diag, 'resumo_barras.csv'), resumo)
    figura_mais_leves(barras, melhores, os.path.join(diag, 'mais_leves_barras.png'))
    return resumo


def figura_mais_leves(barras, melhores, caminho):
    """Secção (no início do troço, peça nova) da mais leve de cada barra x planeta."""
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    pls = list(FAMILIA)
    fig, axs = plt.subplots(len(barras), len(pls), figsize=(2.3 * len(pls), 2.5 * len(barras)), squeeze=False)
    for i, peca in enumerate(barras):
        G = GEO[peca]
        for j, p in enumerate(pls):
            ax = axs[i, j]; ax.set_aspect('equal'); ax.axis('off')
            th = np.linspace(0, 2 * np.pi, 100)
            ax.plot(G['D_env'] / 2 * np.cos(th), G['D_env'] / 2 * np.sin(th), 'r:', lw=.7)
            ax.fill(G['D_meio'] / 2 * np.cos(th), G['D_meio'] / 2 * np.sin(th), color='0.85', ec='0.5', lw=.5)
            top = melhores.get((peca, p))
            if i == 0:
                ax.set_title(p, fontsize=9)
            if j == 0:
                ax.text(-G['D_env'] * 0.75, 0, peca.replace('barra ', ''), rotation=90, va='center', ha='center', fontsize=9)
            if not top:
                ax.text(0, 0, 'nenhuma\npassa', ha='center', va='center', fontsize=7); continue
            vid, g, nm, r = top
            fam = r['familia']; gn = r['gn']
            t, b = r['t'][0] + 2 * dg.de(p)['delta'], r['b'][0] + 2 * dg.de(p)['delta']
            a = np.radians(g['rot'])
            Rm = np.array([[np.cos(a), -np.sin(a)], [np.sin(a), np.cos(a)]])
            def ret(tt, bb, RR, cor, ec='k'):
                RR = min(RR, 0.49 * min(tt, bb))
                pts = []
                for cx, cy, a0 in ((tt / 2 - RR, bb / 2 - RR, 0), (-tt / 2 + RR, bb / 2 - RR, 90),
                                   (-tt / 2 + RR, -bb / 2 + RR, 180), (tt / 2 - RR, -bb / 2 + RR, 270)):
                    for q in np.radians(np.linspace(a0, a0 + 90, 8)):
                        pts.append((cx + RR * np.cos(q), cy + RR * np.sin(q)))
                P = np.array(pts) @ Rm.T
                ax.fill(P[:, 0], P[:, 1], color=cor, ec=ec, lw=.6)
            if fam == 'fechada':
                ret(t, b, gn['r_cantos'] * min(t, b), '#2E86C1')
                e = gn['parede']
                if t - 2 * e > 2 and b - 2 * e > 2:
                    ret(t - 2 * e, b - 2 * e, max(gn['r_cantos'] * min(t, b) - e, 0.3), 'white')
            elif fam == 'trelica':
                for sg in (-1, 1):
                    P = np.array([[sg * (t / 2 - gn['banzo'] / 2)], [0]])
                    c = (Rm @ P).ravel()
                    tt, bb = gn['banzo'], b
                    Q = np.array([[-tt / 2, -bb / 2], [tt / 2, -bb / 2], [tt / 2, bb / 2], [-tt / 2, bb / 2]]) @ Rm.T + c
                    ax.fill(Q[:, 0], Q[:, 1], color='#2E86C1', ec='k', lw=.6)
                e = gn['parede']; hh = t - 2 * gn['banzo']
                for sg in (-1, 1):          # paredes laterais com janelas (claras)
                    Q = np.array([[-hh / 2, sg * b / 2], [hh / 2, sg * b / 2], [hh / 2, sg * (b / 2 - e)],
                                  [-hh / 2, sg * (b / 2 - e)]]) @ Rm.T
                    ax.fill(Q[:, 0], Q[:, 1], color='#2E86C1', alpha=.35, ec='k', lw=.4, ls='--')
            else:
                tf, tw = gn['banzo'], gn['alma']
                for sg in (-1, 1):
                    c = (Rm @ np.array([sg * (t / 2 - tf / 2), 0])).ravel()
                    Q = np.array([[-tf / 2, -b / 2], [tf / 2, -b / 2], [tf / 2, b / 2], [-tf / 2, b / 2]]) @ Rm.T + c
                    ax.fill(Q[:, 0], Q[:, 1], color='#2E86C1', ec='k', lw=.6)
                hw = t - 2 * tf
                Q = np.array([[-hw / 2, -tw / 2], [hw / 2, -tw / 2], [hw / 2, tw / 2], [-hw / 2, tw / 2]]) @ Rm.T
                ax.fill(Q[:, 0], Q[:, 1], color='#2E86C1', ec='k', lw=.6)
            ax.text(0, -G['D_env'] * 0.62, '{}\n{} {:.2f} kg | FS {:.2f}'.format(
                vid, nm.split(' (')[0].replace('-6Al-4V', ''), r['massa_kg'], r['FS_min']), ha='center', va='top', fontsize=6.5)
            ax.set_xlim(-G['D_env'] * 0.6, G['D_env'] * 0.6); ax.set_ylim(-G['D_env'] * 0.9, G['D_env'] * 0.6)
    fig.suptitle('Barras — secção da variante mais leve que passa (cinza = varão original, vermelho = espaço de projeto; treliça: paredes claras = com janelas)',
                 fontsize=10, fontweight='bold')
    fig.tight_layout(); fig.savefig(caminho, dpi=120); plt.close(fig)


if __name__ == '__main__':
    bs = [nome_barra(a) for a in sys.argv[1:]] or BARRAS
    for b in bs:
        G = GEO[b]
        print('{:15s} L={:.0f} troço {:.0f}-{:.0f} mm Ø{:.1f} | pontas Ø{:.1f}x{:.1f} / Ø{:.1f}x{:.1f} | '
              'V STEP {:.0f} cm3 (verde {:.0f} + meio {:.0f})'.format(
                  b, G['L'], G['s0'], G['s1'], G['D_meio'], G['D_raiz'], G['L_raiz'], G['D_ponta'], G['L_ponta'],
                  G['V_step'] / 1e3, G['V_verde'] / 1e3, G['V_meio'] / 1e3))
    correr(bs)
    print('[OK] diag/<barra>/populacoes/*.csv, *_top10.csv, dispersao.png, diag/resumo_barras.csv, diag/mais_leves_barras.png')
