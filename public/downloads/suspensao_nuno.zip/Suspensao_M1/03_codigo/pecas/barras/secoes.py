"""
Fórmulas de secção COPIADAS de joelho_traseiro_STEP/familias.py (01/11), sem
alterações: retângulo de cantos arredondados, tubo (caixa_props / caixa_sigma
com encurvadura local das paredes) e correção de Bleich para vigas curvas.
Copiadas para não depender dos ficheiros do lote do joelho traseiro.
"""
import numpy as np

CAV_MIN = 6.0           # mm, cavidade mínima (abaixo disto a secção fica cheia)


def _canto():
    """Constantes do 'canto' removido por um arredondamento de raio 1."""
    n = 1200
    u = (np.arange(n) + 0.5) / n
    X, Y = np.meshgrid(u, u)
    m = (X - 1) ** 2 + (Y - 1) ** 2 > 1
    a = m.mean()
    c = Y[m].mean()
    I = ((Y[m] - c) ** 2).mean() * a
    return a, c, I


_A_C, _C_C, _I_C = _canto()


def _ret_arred(t, b, r):
    """Área e inércias de um retângulo t (em n) x b (em z) com cantos de raio r."""
    r = np.minimum(r, 0.5 * np.minimum(t, b))
    A = b * t - 4 * _A_C * r ** 2
    Iz = b * t ** 3 / 12 - 4 * (_I_C * r ** 4 + _A_C * r ** 2 * (t / 2 - _C_C * r) ** 2)
    In = t * b ** 3 / 12 - 4 * (_I_C * r ** 4 + _A_C * r ** 2 * (b / 2 - _C_C * r) ** 2)
    return A, Iz, In


def caixa_props(t, b, e, r):
    """Tubo: exterior (t, b, r) menos interior (t-2e, b-2e, r-e). e >= min/2 -> cheio."""
    A0, Iz0, In0 = _ret_arred(t, b, r)
    ti, bi = t - 2 * e, b - 2 * e
    oco = (ti >= CAV_MIN) & (bi >= CAV_MIN)
    tiv, biv = np.where(oco, ti, 0.0), np.where(oco, bi, 0.0)
    A1, Iz1, In1 = _ret_arred(tiv, biv, np.maximum(r - e, 0.0))
    A1 = np.where(oco, A1, 0.0); Iz1 = np.where(oco, Iz1, 0.0); In1 = np.where(oco, In1, 0.0)
    return A0 - A1, Iz0 - Iz1, In0 - In1, oco


E_MAT, SY_MAT = None, None      # definidos em _fechada (encurvadura local)

# ------------------------------------------------------------------------------
# CORREÇÃO DE BLEICH: banzos finos em vigas CURVAS
#   A tensão circunferencial puxa o banzo para o centro de curvatura; o banzo
#   (placa fina) dobra-se ("curling"): só uma largura efetiva alfa*b trabalha e
#   aparece uma tensão TRANSVERSAL de flexão gama*sigma na ligação à alma.
#   Parâmetro: q = b^2 / (r t)  (b = meia-largura livre do banzo, r = raio do
#   banzo, t = espessura do banzo). Tabela obtida resolvendo a equação clássica
#   da faixa de placa sobre fundação elástica (Bleich 1933; Timoshenko):
#       phi'''' + 4 phi = 4 , junto à alma phi = phi' = 0
#       I (banzo em consola):           bordo livre phi'' = phi''' = 0
#       CX (tubo: banzo entre 2 paredes): meio do banzo phi' = phi''' = 0
#   (nu = 0.3; os valores de gama coincidem com os tabelados por Bleich/Roark)
# ------------------------------------------------------------------------------
_BQ = np.array([0.0000, 0.0500, 0.1000, 0.2000, 0.3000, 0.4000, 0.5000, 0.6000, 0.8000, 1.0000,
                1.2500, 1.5000, 2.0000, 2.5000, 3.0000, 4.0000, 5.0000, 6.0000, 8.0000])
_ALFA = {'I': np.array([1.0000, 0.9986, 0.9946, 0.9789, 0.9545, 0.9234, 0.8880, 0.8505, 0.7758, 0.7081,
                        0.6378, 0.5826, 0.5058, 0.4564, 0.4218, 0.3742, 0.3406, 0.3141, 0.2744]),
         'CX': np.array([1.0000, 0.9994, 0.9976, 0.9904, 0.9788, 0.9632, 0.9442, 0.9223, 0.8729, 0.8197,
                         0.7537, 0.6926, 0.5912, 0.5167, 0.4624, 0.3913, 0.3471, 0.3164, 0.2745])}
_GAMA = {'I': np.array([0.0000, 0.1497, 0.2977, 0.5817, 0.8408, 1.0673, 1.2576, 1.4120, 1.6251, 1.7413,
                        1.8027, 1.8157, 1.7941, 1.7685, 1.7553, 1.7572, 1.7734, 1.7892, 1.8079]),
         'CX': np.array([0.0000, 0.0999, 0.1994, 0.3951, 0.5837, 0.7622, 0.9282, 1.0802, 1.3387, 1.5370,
                         1.7102, 1.8179, 1.9089, 1.9179, 1.8993, 1.8547, 1.8275, 1.8155, 1.8115])}
_K_BLEICH = np.sqrt(3 * (1 - 0.3 ** 2))


def bleich(q, tipo='CX'):
    """(alfa, gama) para q = b^2/(r t). Acima da tabela: alfa ~ 1/m (assíntota), gama ~ 1.81."""
    q = np.nan_to_num(np.asarray(q, float), nan=0.0, posinf=0.0)
    a = np.interp(q, _BQ, _ALFA[tipo])
    a = np.where(q > _BQ[-1], 1.0 / np.sqrt(np.maximum(q, 1e-9) * _K_BLEICH), a)
    g = np.interp(q, _BQ, _GAMA[tipo])
    return a, g


def _raio(rho):
    r = np.abs(np.asarray(rho, float))
    return np.where(np.isfinite(r) & (r > 0), r, np.inf)


def bleich_tensao(t, b, e_banzo, b_livre, rho, N, M, fc, Iz, A, tipo):
    """Tensão equivalente no banzo de uma viga curva com a correção de Bleich:
    inércia reduzida (largura efetiva) + tensão transversal gama*sigma combinada
    (Von Mises, sinais opostos: fator sqrt(1 + gama + gama^2))."""
    r = _raio(rho)
    q_in = b_livre ** 2 / (np.maximum(r - t / 2 + e_banzo / 2, 1e-6) * e_banzo)
    q_out = b_livre ** 2 / ((r + t / 2 - e_banzo / 2) * e_banzo)
    a_in, g_in = bleich(np.where(np.isfinite(r), q_in, 0.0), tipo)
    a_out, _ = bleich(np.where(np.isfinite(r), q_out, 0.0), tipo)
    braco2 = (t / 2 - e_banzo / 2) ** 2
    largura = 2 * b_livre                         # largura do banzo que pode enrolar
    dI = ((1 - a_in) + (1 - a_out)) * largura * e_banzo * braco2
    Iz_red = np.maximum(Iz - dI, 0.2 * Iz)
    sN = np.abs(N) / A
    sM = fc * np.abs(M) * (t / 2) / Iz_red
    return (sN + sM) * np.sqrt(1 + g_in + g_in ** 2), g_in


def caixa_sigma(t, b, e, r, N, V, M, fc, Mn, T, rho=None):
    """Tensão equivalente máxima (no plano e fora do plano) do tubo.
    rho: raio do eixo (para a correção de Bleich nas curvas)."""
    A, Iz, In, oco = caixa_props(t, b, e, r)
    sN = np.abs(N) / A
    sM = fc * np.abs(M) * (t / 2) / Iz
    Q = b * e * (t / 2 - e / 2) + 2 * e * np.maximum(t / 2 - e, 0) ** 2 / 2
    tauV = np.where(oco, np.abs(V) * Q / (Iz * 2 * e), 1.5 * np.abs(V) / A)
    plano = np.maximum(sN + sM, np.sqrt(sN ** 2 + 3 * tauV ** 2))
    sb = np.abs(Mn) * (b / 2) / In
    Am = (t - e) * (b - e) - (4 - np.pi) * np.maximum(r - e / 2, 0) ** 2
    a_, c_ = np.maximum(t, b), np.minimum(t, b)
    tauT = np.where(oco, np.abs(T) / (2 * np.maximum(Am, 1e-9) * e),
                    np.abs(T) * (3 * a_ + 1.8 * c_) / (a_ ** 2 * c_ ** 2))
    fora = np.sqrt(sb ** 2 + 3 * tauT ** 2)
    # encurvadura local das paredes do tubo (placa simplesmente apoiada, k = 4):
    #   sigma_cr = 3.62 E (e / largura)^2 ; entra como tensão equivalente sigma * sy / sigma_cr
    if E_MAT is not None:
        cr_z = 3.62 * E_MAT * (e / np.maximum(b - e, 1e-6)) ** 2      # paredes de largura b
        cr_n = 3.62 * E_MAT * (e / np.maximum(t - e, 1e-6)) ** 2      # paredes de largura t
        plano = np.where(oco, np.maximum(plano, (sN + sM) * SY_MAT / cr_z), plano)
        fora = np.where(oco, np.maximum(fora, sb * SY_MAT / cr_n), fora)
    # Bleich: as paredes interior/exterior da curva enrolam entre as duas paredes laterais
    if rho is not None:
        b_livre = np.maximum(b / 2 - e, 0.0)
        sb_, _ = bleich_tensao(t, b, e, b_livre, rho, N, M, fc, Iz, A, 'CX')
        plano = np.where(oco, np.maximum(plano, sb_), plano)
    return plano, fora, A, oco

