# r: numpy, scipy, matplotlib
"""Módulo 'rhino' da barra do frente para os componentes genéricos do Grasshopper (pecas_registo.py)."""
import rhino_barra as _rb
globals().update(_rb.api("barra do frente"))
