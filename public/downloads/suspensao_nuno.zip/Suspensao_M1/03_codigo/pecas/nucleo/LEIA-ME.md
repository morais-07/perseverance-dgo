# m1\pecas\nucleo — núcleo comum das peças novas (01/11)

- `planetas.py`, `degradacao.py` — cópias CONGELADAS da pasta do joelho traseiro (md5 801b018c… / 4d4e3b89…).
- `materiais.py` — cópia de `gerador_variantes.MATERIAIS`.
- `cargas_suspensao.py` — estática do rocker-bogie a partir do STEP (`dados\inventario.json`).
  `python cargas_suspensao.py` → geometria, VALIDAÇÃO no joelho traseiro (Marte e Lua: OK) e `saida\envolvente_pecas.csv`.

## Hipóteses do modelo de cargas
1. Mesmos casos por roda do joelho traseiro (W = m·g/6 × fatores do planeta) + `subir_rocha-` (marcha atrás) nas peças novas.
2. Pino do bogie (furo Ø68 do suporte do meio, eixo ≈ X, Y = 844) é LIVRE: uma carga numa roda do bogie faz a outra reagir na vertical.
   O pino não está a meio (traseira 621 mm, meio 447 mm) → carga na traseira faz o MEIO reagir ×1,39 (casos `caso@traseira` nas peças do meio).
   Reação induzida só vertical, nunca negativa. No joelho traseiro a induzida (×0,72) é sempre menor que o caso próprio → as populações do traseiro continuam válidas.
3. Cubo do rocker (articulação 01) encastrado: o diferencial segura o momento → sem casos induzidos na roda da frente.
4. `barra esquerda do da direita` = braço traseiro do rocker (cubo → pino do bogie): vê as DUAS rodas do bogie.

## Envolvente (Mf máx na raiz, N·m) — Lua / Marte / Vénus
| peça | Lua | Marte | Vénus |
|---|---|---|---|
| joelho traseiro (|M|) | 794 | 1423 | 3403 |
| joelho do meio (|M|) | 1082 | 1940 | 4637 |
| barra traseira | 1602 | 2871 | 6863 |
| barra do meio | 1360 | 2437 | 5826 |
| barra do frente | 2383 | 4271 | 10212 |
| barra esquerda | 4257 | 7629 | 18240 |
Caso dimensionante em todas: `queda_lat±` na própria roda.
