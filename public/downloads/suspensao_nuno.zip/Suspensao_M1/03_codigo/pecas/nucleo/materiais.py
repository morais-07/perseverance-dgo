"""Cópia congelada de gerador_variantes.MATERIAIS (joelho traseiro, 01/11).
Valores típicos de literatura - confirmar nas fichas técnicas.
rho [kg/m3], E e sy/sf [MPa]."""
MATERIAIS = {
    'Al 7075-T6 (CNC)':        dict(rho=2810, E=71.7e3,  sy=503, sf=159, cor='#2E86C1'),
    'Ti-6Al-4V (CNC)':         dict(rho=4430, E=113.8e3, sy=880, sf=510, cor='#7D3C98'),
    'Ti-6Al-4V (L-PBF+HIP)':   dict(rho=4430, E=110e3,   sy=850, sf=300, cor='#C0392B'),
    'AlSi10Mg (L-PBF)':        dict(rho=2670, E=70e3,    sy=200, sf=90,  cor='#D68910'),
    'Inconel 718 (CNC)':       dict(rho=8190, E=200e3,   sy=1030, sf=450, cor='#1E8449'),
}
