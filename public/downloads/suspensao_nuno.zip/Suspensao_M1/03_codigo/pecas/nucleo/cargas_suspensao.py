"""
==============================================================================
 CARGAS NA SUSPENSÃO ROCKER-BOGIE  (núcleo comum às peças novas do M1)
==============================================================================
Objetivo: dar a CADA peça da suspensão (joelhos, 4 barras) as forças e
momentos que lhe chegam, para os MESMOS casos de carga do planeta que o
joelho traseiro usou (planetas.fatores, W = m g / 6).

Geometria: tudo do STEP da NASA (dados/inventario.json): centros e eixos das
rodas, furos/veios de ligação entre peças.  Referencial global do STEP [mm]:
  X = lateral (rodas para +X), Y = longitudinal (frente em -Y), Z = vertical.

Topologia (lado direito do rover, o único no STEP):
  corpo --(diferencial)-- cubo do ROCKER (articulação 01, eixo ~X, Y≈92)
     ROCKER = barra do frente  -> suporte dianteiro -> joelho :2 -> roda:4 (frente)
            + barra esquerda do da direita -> articulação 02
  PINO DO BOGIE (furo Ø68 do suporte do meio, eixo ~X, Y≈844)
     BOGIE  = suporte do meio + barra traseira -> suporte traseiro -> joelho :1 -> roda:1
                              + barra do meio  -> joelho do meio -> roda:2

Casos por roda (iguais aos do joelho traseiro, referencial da roda):
  u = eixo da roda, para FORA (do joelho para a roda)   [x2D do joelho]
  w = vertical (+Z)                                    [y2D]
  v = u x w ... = direção de marcha (+Y global ≈ para trás)
  queda, queda_lat±, aresta_ext/int, embate, aterragem, subir_rocha (+v)
  + subir_rocha- (-v) só nas peças novas (o rover também anda para trás).

Equilíbrio do mecanismo (HIPÓTESE, ver HIPOTESES):
  * PINO DO BOGIE é livre (Mx = 0): uma carga numa roda do bogie obriga a
    OUTRA roda do bogie a reagir na vertical.  Como o pino não está a meio
    (traseira a 621 mm, meio a 448 mm), uma carga na roda TRASEIRA faz a do
    MEIO reagir ~1,39x -> casos "induzidos" (sufixo '@traseira'/'@meio').
    A reação induzida é só vertical (sem atrito) e nunca negativa (roda no ar).
  * CUBO DO ROCKER: o diferencial liga os dois rockers e segura o momento
    -> encastramento (sem casos induzidos na roda da frente).

Saída: torsor (F, M) numa secção qualquer de cada peça, vindo do lado da roda:
      F_sec = soma F_i      M_sec = soma (P_i - Q) x F_i
==============================================================================
"""
import os
import json
import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__))
import sys
sys.path.insert(0, AQUI)
import planetas as pl          # cópia congelada (mesmo md5 do joelho traseiro)

INV = os.path.join(AQUI, 'dados', 'inventario.json')
F_EMBATE = pl.F_EMBATE

# ------------------------------------------------------------------------------
# 1. GEOMETRIA DO STEP
# ------------------------------------------------------------------------------
_inv = json.load(open(INV, encoding='utf-8'))
_pecas = {p['nome']: p for p in _inv['pecas']}


def _cil(peca, diametro, tipo=None, tol=0.6, perto=None):
    """Cilindro de uma peça pelo diâmetro (e tipo). Se houver vários, o mais
    perto de 'perto'."""
    cs = [c for c in _pecas[peca]['cilindros']
          if abs(c['diametro_mm'] - diametro) < tol and (tipo is None or c['tipo'] == tipo)]
    if not cs:
        raise KeyError(f'{peca}: sem cilindro Ø{diametro}')
    if perto is not None:
        cs.sort(key=lambda c: np.linalg.norm(np.array(c['centro_global_mm']) - perto))
    c = cs[0]
    return np.array(c['centro_global_mm'], float), np.array(c['eixo_global'], float)


def _unit(a):
    a = np.asarray(a, float)
    return a / np.linalg.norm(a)


def _roda(nome_roda, nome_joelho):
    """Centro, raio, largura e referencial (u, w, v) de uma roda."""
    C, ax = _cil(nome_roda, 506.72, 'veio')
    R = 253.36
    L = 335.61
    Cj = np.array(_pecas[nome_joelho]['centro_global_mm'])
    u = _unit(ax)
    if u @ (C - Cj) < 0:            # u aponta do joelho para a roda (para fora)
        u = -u
    w = np.array([0.0, 0.0, 1.0])
    u = _unit(u - (u @ w) * w)       # horizontal
    v = np.cross(w, u)               # como no joelho traseiro: v = (-u_y, u_x, 0)
    return dict(C=C, R=R, L=L, u=u, w=w, v=v, joelho=nome_joelho, centro_joelho=Cj)


RODAS = {
    'traseira': _roda('roda:1', 'joelho traserio:1'),
    'meio':     _roda('roda:2', 'joleho do meio:1'),
    'frente':   _roda('roda:4', 'joelho traserio:2'),
}

# pino do bogie: furo Ø68 do suporte do meio, eixo ~X
PINO_BOGIE, EIXO_BOGIE = _cil('suporte do meio:1', 68.148, 'furo')
EIXO_BOGIE = _unit(EIXO_BOGIE)
BOGIE = ('traseira', 'meio')

# extremidades das peças (centro dos furos/veios de ligação).
#   'raiz' = lado do corpo (de onde a peça é segura); 'ponta' = lado da roda
#   'rodas' = rodas cujo caminho de carga passa pela peça
PECAS = {
    'joelho traseiro': dict(
        raiz=_cil('joelho traserio:1', 173.8, 'furo')[0],
        ponta=RODAS['traseira']['C'], rodas=['traseira'], tipo='joelho'),
    'joelho do meio': dict(
        raiz=_cil('joleho do meio:1', 72.5, 'furo')[0],
        ponta=RODAS['meio']['C'], rodas=['meio'], tipo='joelho',
        eixo_raiz=_unit(_cil('joleho do meio:1', 72.5, 'furo')[1])),
    'barra traseira': dict(
        raiz=_cil('barra traseira:1', 72.5, 'veio', perto=PINO_BOGIE)[0],
        ponta=_cil('barra traseira:1', 72.5, 'veio', perto=RODAS['traseira']['C'])[0],
        rodas=['traseira'], tipo='barra', diam=72.5, nome_step='barra traseira:1'),
    'barra do meio': dict(
        raiz=_cil('barra do meio:1', 72.5, 'veio', perto=PINO_BOGIE)[0],
        ponta=_cil('barra do meio:1', 72.5, 'veio', perto=RODAS['meio']['C'])[0],
        rodas=['meio'], tipo='barra', diam=72.5, nome_step='barra do meio:1'),
    'barra do frente': dict(
        raiz=_cil('barra do frente:1', 72.5, 'veio', perto=np.array([812., 92., -200.]))[0],
        ponta=_cil('barra do frente:1', 72.5, 'veio', perto=RODAS['frente']['C'])[0],
        rodas=['frente'], tipo='barra', diam=72.5, nome_step='barra do frente:1'),
    'barra esquerda': dict(        # braço traseiro do rocker: cubo -> pino do bogie
        raiz=_cil('barra esquerda do da direita:1', 89.2, 'veio')[0],
        ponta=_cil('barra esquerda do da direita:1', 76.6, 'veio')[0],
        rodas=['traseira', 'meio'], tipo='barra', diam=89.2,
        nome_step='barra esquerda do da direita:1', via_pino_bogie=True),
}
for _n, _p in PECAS.items():
    _p['comprimento'] = float(np.linalg.norm(_p['ponta'] - _p['raiz']))
    _p['eixo'] = _unit(_p['ponta'] - _p['raiz'])


# ------------------------------------------------------------------------------
# 2. CASOS DE CARGA NUMA RODA (referencial local -> global)
# ------------------------------------------------------------------------------
def casos_locais(planeta, extra=True):
    """{nome: (Fu, Fw, Fv, onde)}  em N, iguais a planetas.casos_e_cenarios
    (+ subir_rocha do gh_intact).  onde: 'plano' | 'aresta_ext' | 'aresta_int'
    | 'joelho'."""
    W = pl.peso_roda(planeta)
    f = pl.fatores(planeta)
    Fq = f['queda'] * W
    c = {
        'queda':       (0.0, Fq, 0.0, 'plano'),
        'queda_lat+':  (+f['mu'] * Fq, Fq, 0.0, 'plano'),
        'queda_lat-':  (-f['mu'] * Fq, Fq, 0.0, 'plano'),
        'aresta_ext':  (0.0, f['aresta'] * W, 0.0, 'aresta_ext'),
        'aresta_int':  (0.0, f['aresta'] * W, 0.0, 'aresta_int'),
        'embate':      (+f['embate'] * W, 0.0, 0.0, 'joelho'),
        'aterragem':   (0.0, f['aterragem'] * W, 0.0, 'plano'),
        'subir_rocha': (0.0, 0.0, +f['aresta'] * W, 'plano'),
    }
    if extra:
        c['subir_rocha-'] = (0.0, 0.0, -f['aresta'] * W, 'plano')
    return c


def ponto(roda, onde):
    """Ponto de aplicação global (contacto com o solo, aresta, ou o joelho)."""
    r = RODAS[roda]
    if onde == 'joelho':
        return r['centro_joelho'].copy()
    x = {'plano': 0.0, 'aresta_ext': +r['L'] / 2, 'aresta_int': -r['L'] / 2}[onde]
    return r['C'] + x * r['u'] - r['R'] * r['w']


def forca_global(roda, Fu, Fw, Fv):
    r = RODAS[roda]
    return Fu * r['u'] + Fw * r['w'] + Fv * r['v']


def reacao_induzida(roda_alvo, F, P):
    """Força vertical na OUTRA roda do bogie que anula o momento no pino
    (eixo do bogie). Devolve (roda, F, P) ou None (roda no ar / não é bogie)."""
    if roda_alvo not in BOGIE:
        return None
    outra = BOGIE[1] if roda_alvo == BOGIE[0] else BOGIE[0]
    P2 = ponto(outra, 'plano')
    a = EIXO_BOGIE
    m1 = a @ np.cross(P - PINO_BOGIE, F)
    m2 = a @ np.cross(P2 - PINO_BOGIE, np.array([0.0, 0.0, 1.0]))   # por 1 N vertical
    Fz = -m1 / m2
    if Fz <= 0:
        return None            # a outra roda teria de puxar o solo -> levanta
    return outra, np.array([0.0, 0.0, Fz]), P2


def cargas_aplicadas(planeta, induzidos=True):
    """Lista de casos do sistema: cada caso = lista de (roda, F_global, P_global).
    Nome 'caso@roda'.  Com induzidos: inclui a reação na outra roda do bogie."""
    out = {}
    for roda in RODAS:
        for nome, (Fu, Fw, Fv, onde) in casos_locais(planeta).items():
            F = forca_global(roda, Fu, Fw, Fv)
            P = ponto(roda, onde)
            lst = [(roda, F, P)]
            if induzidos:
                ind = reacao_induzida(roda, F, P)
                if ind is not None:
                    lst.append(ind)
            out[f'{nome}@{roda}'] = lst
    return out


# ------------------------------------------------------------------------------
# 3. TORSOR NUMA SECÇÃO DE UMA PEÇA
# ------------------------------------------------------------------------------
def torsor(peca, cargas, Q):
    """(F, M) que passa na secção Q da peça, vindo do lado da(s) roda(s).
    Só contam as cargas aplicadas em rodas cujo caminho passa pela peça."""
    p = PECAS[peca]
    F = np.zeros(3); M = np.zeros(3)
    for roda, Fi, Pi in cargas:
        if roda in p['rodas']:
            F += Fi
            M += np.cross(Pi - Q, Fi)
    return F, M


def esforcos_barra(peca, cargas, n=21):
    """Esforços ao longo de uma barra no referencial da barra:
    N (axial, +tração), Vy, Vz, T (torção), My, Mz (flexão), |Mf| = hypot.
    Estações de s = 0 (raiz) a L (ponta)."""
    p = PECAS[peca]
    e1 = p['eixo']
    ref = np.array([0.0, 0.0, 1.0]) if abs(e1[2]) < 0.9 else np.array([1.0, 0.0, 0.0])
    e2 = _unit(np.cross(ref, e1)); e3 = np.cross(e1, e2)
    s = np.linspace(0, p['comprimento'], n)
    res = dict(s=s, N=[], V2=[], V3=[], T=[], M2=[], M3=[])
    for si in s:
        Q = p['raiz'] + si * e1
        F, M = torsor(peca, cargas, Q)
        # a secção vê a força do lado da ponta: N > 0 se puxa a ponta para fora
        res['N'].append(F @ e1); res['V2'].append(F @ e2); res['V3'].append(F @ e3)
        res['T'].append(M @ e1); res['M2'].append(M @ e2); res['M3'].append(M @ e3)
    for k in list(res):
        res[k] = np.asarray(res[k])
    res['Mf'] = np.hypot(res['M2'], res['M3'])
    res['V'] = np.hypot(res['V2'], res['V3'])
    res['e'] = (e1, e2, e3)
    return res


def tabela_peca(peca, planeta, induzidos=True):
    """Resumo por caso: |F|, N, |V|, T, Mf na RAIZ (secção mais carregada
    nas barras em consola), N em kN e momentos em N.m."""
    linhas = []
    for nome, cargas in cargas_aplicadas(planeta, induzidos).items():
        if not any(r in PECAS[peca]['rodas'] for r, _, _ in cargas):
            continue
        if PECAS[peca]['tipo'] == 'barra':
            e = esforcos_barra(peca, cargas, n=11)
            k = int(np.argmax(e['Mf']))
            linhas.append(dict(caso=nome, N=e['N'][k], V=e['V'][k], T=e['T'][k],
                               Mf=e['Mf'][k], s_crit=e['s'][k], Mf_ponta=e['Mf'][-1]))
        else:
            F, M = torsor(peca, cargas, PECAS[peca]['raiz'])
            linhas.append(dict(caso=nome, F=np.linalg.norm(F), M=np.linalg.norm(M),
                               Fv=F[2], Fx=F[0], Fy=F[1], Mx=M[0], My=M[1], Mz=M[2]))
    return linhas


# ------------------------------------------------------------------------------
# 4. VALIDAÇÃO: o joelho traseiro tem de dar as cargas que já usava
# ------------------------------------------------------------------------------
def validar_joelho_traseiro(planeta='Marte'):
    """(1) As forças na roda traseira, escritas no referencial 2D do joelho
    (geometria_joelho.json: u, w), têm de ser exatamente as de
    planetas.casos_e_cenarios e, para Marte, as de analise_esforcos.casos_de_carga.
    (2) O momento fora do plano (eixo v) na raiz, calculado aqui em 3D, tem de
    ser igual ao M = (P - S) x F de analise_esforcos.esforcos no plano 2D."""
    g = json.load(open(os.path.join(AQUI, 'dados', 'geometria_joelho.json'), encoding='utf-8'))
    ref = g['referencial']
    O = np.array(ref['origem_mm']); u2 = np.array(ref['u']); w2 = np.array(ref['w'])
    r = RODAS['traseira']
    ok = True
    print(f'Referencial: u STEP {np.round(r["u"], 4)} vs json {np.round(u2, 4)} | '
          f'centro {np.round(r["C"], 2)} vs {np.round(O, 2)}')
    ok &= np.allclose(r['u'], u2, atol=2e-3) and np.allclose(r['C'], O, atol=0.5)
    casos_pl, _ = pl.casos_e_cenarios()
    S_raiz = PECAS['joelho traseiro']['raiz']
    S2 = np.array([(S_raiz - O) @ u2, (S_raiz - O) @ w2])
    print(f'{"caso":12s}{"F 2D (planetas)":>22s}{"F 2D (3D->2D)":>22s}{"M_v 2D":>12s}{"M_v 3D":>12s}  [N, N.m]')
    for nome, (Fu, Fw, Fv, onde) in casos_locais(planeta, extra=False).items():
        F = forca_global('traseira', Fu, Fw, Fv)
        P = ponto('traseira', onde)
        F2 = np.array([F @ u2, F @ w2])
        if nome == 'subir_rocha':
            alvo = np.array([0.0, 0.0])        # fora do plano: Fz do cenário
            okc = abs(F @ r['v'] - pl.fatores(planeta)['aresta'] * pl.peso_roda(planeta)) < 1e-6
        else:
            alvo = np.array(casos_pl[f'{planeta}:{nome}']['F'])
            okc = np.allclose(F2, alvo, atol=1e-6)
        P2 = np.array([(P - O) @ u2, (P - O) @ w2])
        M2d = (P2 - S2)[0] * F2[1] - (P2 - S2)[1] * F2[0]      # = ae.esforcos (z)
        _, M = torsor('joelho traseiro', [('traseira', F, P)], S_raiz)
        M3v = M @ np.cross(u2, w2)
        okm = abs(M2d - M3v) < 1e-3 * max(1.0, abs(M2d)) if nome != 'subir_rocha' else True
        ok &= okc and okm
        print(f'{nome:12s}{str(np.round(alvo, 1)):>22s}{str(np.round(F2, 1)):>22s}'
              f'{M2d / 1e3:12.1f}{M3v / 1e3:12.1f}  {"OK" if okc and okm else "ERRO"}')
    # analise_esforcos (Marte, DADOS fixos): W*6 na queda, mu 0.6
    if planeta == 'Marte':
        W = 1025.0 * 3.71 / 6
        ae = {'2. Queda no buraco': (0.0, 6 * W), '4. Queda + lateral (+X)': (0.6 * 6 * W, 6 * W)}
        c = casos_locais('Marte', extra=False)
        okae = (np.allclose(ae['2. Queda no buraco'], c['queda'][:2]) and
                np.allclose(ae['4. Queda + lateral (+X)'], c['queda_lat+'][:2]))
        print(f'analise_esforcos.casos_de_carga (Marte): queda {ae["2. Queda no buraco"][1]:.1f} N '
              f'= {c["queda"][1]:.1f} N -> {"OK" if okae else "ERRO"}')
        ok &= okae
    return bool(ok)


def resumo_geometria():
    print('Rodas (centro, u):')
    for n, r in RODAS.items():
        print(f'  {n:9s} C={np.round(r["C"], 1)}  u={np.round(r["u"], 3)}  contacto Z={ponto(n, "plano")[2]:.0f}')
    print(f'Pino do bogie {np.round(PINO_BOGIE, 1)} eixo {np.round(EIXO_BOGIE, 3)}')
    for n in BOGIE:
        d = (ponto(n, 'plano') - PINO_BOGIE)
        print(f'  braço até ao contacto da roda {n}: {abs(d[1]):.0f} mm (em Y)')
    print('Peças:')
    for n, p in PECAS.items():
        print(f'  {n:16s} L={p["comprimento"]:6.0f} mm  raiz={np.round(p["raiz"], 0)}  '
              f'ponta={np.round(p["ponta"], 0)}  rodas={p["rodas"]}')


def exportar(ficheiro=os.path.join(AQUI, 'saida', 'envolvente_pecas.csv')):
    """Envolvente por planeta x peça x caso -> CSV (; e vírgula decimal não:
    ponto, como os outros CSV do projeto)."""
    os.makedirs(os.path.dirname(ficheiro), exist_ok=True)
    cab = 'planeta;peca;caso;induzido;N_N;V_N;T_Nm;Mf_Nm;s_crit_mm;F_N;M_Nm\n'
    with open(ficheiro, 'w', encoding='utf-8-sig') as f:
        f.write(cab)
        for p in pl.PLANETAS:
            for peca in PECAS:
                for d in tabela_peca(peca, p):
                    roda = d['caso'].split('@')[1]
                    ind = roda not in PECAS[peca]['rodas'] or (
                        peca == 'barra esquerda' and False)
                    if PECAS[peca]['tipo'] == 'barra':
                        f.write(f"{p};{peca};{d['caso']};{ind};{d['N']:.1f};{d['V']:.1f};"
                                f"{d['T']/1e3:.2f};{d['Mf']/1e3:.2f};{d['s_crit']:.0f};;\n")
                    else:
                        f.write(f"{p};{peca};{d['caso']};{ind};;;;;;{d['F']:.1f};{d['M']/1e3:.2f}\n")
    return ficheiro


if __name__ == '__main__':
    resumo_geometria()
    print('\n=== VALIDAÇÃO no joelho traseiro ===')
    tudo = all(validar_joelho_traseiro(p) for p in ['Marte', 'Lua'])
    print('VALIDAÇÃO:', 'OK' if tudo else 'FALHOU')
    print('\n=== Marte: envolvente por peça (raiz / secção crítica) ===')
    for peca in PECAS:
        L = tabela_peca(peca, 'Marte')
        if PECAS[peca]['tipo'] == 'barra':
            k = max(L, key=lambda d: d['Mf'])
            kt = max(L, key=lambda d: abs(d['T']))
            print(f'{peca:16s} Mf máx {k["Mf"]/1e3:7.0f} N.m ({k["caso"]})  '
                  f'T máx {abs(kt["T"])/1e3:6.0f} N.m ({kt["caso"]})  N {k["N"]:7.0f} N')
        else:
            k = max(L, key=lambda d: d['M'])
            print(f'{peca:16s} |M| raiz {k["M"]/1e3:7.0f} N.m ({k["caso"]})  |F| {k["F"]:6.0f} N')
    print('\n[OK]', exportar())
