"""
==============================================================================
 GEOMETRIA DO JOELHO DO MEIO A PARTIR DO STEP
==============================================================================
Plano 2D = plano u-w da roda:2 (u = eixo da roda, w = vertical, origem no
centro da roda), como no joelho traseiro. Diferença de topologia:
  - RAIZ = bossa do furo Ø72,5 da barra do meio (eixo inclinado 30°, quase
    perpendicular ao plano) -> zona VERDE 1 (fora da roda, em cima à esquerda);
  - CUBO = corpo de revolução dentro da roda (rolamentos) -> zona VERDE 2
    (tudo o que fica dentro da largura da roda + folga, como no traseiro);
  - entre as duas: o BRAÇO curvo = zona de projeto (cinzento).
Grava dados/geometria_meio.json + dados/geometria_meio.png.
Uso: python geometria_meio.py <suspensao_v1.step>
==============================================================================
"""
import sys, os, json
import numpy as np
import cv2
import leitor_step as ls

AQUI = os.path.dirname(os.path.abspath(__file__))
RES = 0.25
FOLGA_PNEU = 20.0
NOME_J, NOME_R = 'joleho do meio:1', 'roda:2'
U_BOSSA = -215.0      # mm: à esquerda disto e acima de W_BOSSA = bossa da raiz
W_BOSSA = 95.0


def silhueta(J, c, u, w):
    def p2(P):
        d = P - c
        return np.c_[d @ u, d @ w]
    L2 = [p2(L) for L in J['_loops_globais']]
    T = np.vstack(L2); lo = T.min(0) - 5; hi = T.max(0) + 5
    W_, H = (np.ceil((hi - lo) / RES)).astype(int) + 1
    mask = np.zeros((H, W_), np.uint8)
    px = lambda P: np.c_[(P[:, 0] - lo[0]) / RES, H - 1 - (P[:, 1] - lo[1]) / RES].round().astype(np.int32)
    for L in L2:
        if len(L) >= 3:
            cv2.fillPoly(mask, [px(L)], 255)
    for sf in J['_superficies_globais']:          # cilindros/cones: amostrar a superfície
        M, R, t, esc = sf['M'], sf['R'], sf['t'], sf['escala']
        o, x, y, z = M[:3, 3] * esc, M[:3, 0], M[:3, 1], M[:3, 2]
        angs, vv, ref = [], [], None
        for L in sf['loops']:
            dq = L - o
            a = np.unwrap(np.arctan2(dq @ y, dq @ x))
            ref = a.mean() if ref is None else ref
            a = a - 2 * np.pi * np.round((a.mean() - ref) / (2 * np.pi))
            angs.append(a); vv.append(dq @ z)
        angs = np.concatenate(angs); vv = np.concatenate(vv)
        a0, a1 = angs.min(), angs.max()
        if a1 - a0 > 2 * np.pi - np.radians(15):
            a0, a1 = 0.0, 2 * np.pi
        UU, VV = np.meshgrid(np.linspace(a0, a1, 73), np.linspace(vv.min(), vv.max(), 3))
        rho = R * esc + t * VV
        P = o + (rho * np.cos(UU))[..., None] * x + (rho * np.sin(UU))[..., None] * y + VV[..., None] * z
        Q = p2(P.reshape(-1, 3)).reshape(P.shape[0], P.shape[1], 2)
        for i in range(Q.shape[0] - 1):
            for j in range(Q.shape[1] - 1):
                cv2.fillPoly(mask, [px(np.array([Q[i, j], Q[i, j + 1], Q[i + 1, j + 1], Q[i + 1, j]]))], 255)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
    return mask, lo, H


def extrair(step):
    inv = ls.inventario(step)
    J = next(p for p in inv['pecas'] if p['nome'] == NOME_J)
    R = next(p for p in inv['pecas'] if p['nome'] == NOME_R)
    cil = [cc for cc in R['cilindros'] if cc['tipo'] in ('furo', 'veio')]
    ext = max(cil, key=lambda cc: cc['raio_mm']); inn = min(cil, key=lambda cc: cc['raio_mm'])
    c = np.array(ext['centro_global_mm'], float)
    u = np.array(ext['eixo_global'], float); u[2] = 0; u /= np.linalg.norm(u)
    w = np.array([0, 0, 1.0])
    Pj = np.vstack(J['_loops_globais'])
    if ((Pj - c) @ u).mean() > 0:
        u = -u
    v = np.cross(w, u)
    largura = max(ext['comprimento_mm'], inn['comprimento_mm'])
    mask, lo, H = silhueta(J, c, u, w)
    Hh, Ww = mask.shape
    X = lo[0] + np.arange(Ww) * RES
    Y = lo[1] + (H - 1 - np.arange(Hh)) * RES
    XX, YY = np.meshgrid(X, Y)
    x_s = -largura / 2 + FOLGA_PNEU
    m = mask > 0
    z_cubo = m & (XX >= x_s)
    z_boss = m & (XX < U_BOSSA) & (YY > W_BOSSA)
    z_braco = m & ~z_cubo & ~z_boss

    def cont(z):
        cs, _ = cv2.findContours(z.astype(np.uint8) * 255, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        cc = max(cs, key=cv2.contourArea).reshape(-1, 2).astype(float)
        P = np.c_[lo[0] + cc[:, 0] * RES, lo[1] + (H - 1 - cc[:, 1]) * RES]
        P = cv2.approxPolyDP(P.astype(np.float32).reshape(-1, 1, 2), 0.15, True).reshape(-1, 2)
        return P.astype(float).tolist()

    # volumes da peça ORIGINAL por zona
    #   cubo: corpo de revolução -> V = sum(pi r^2 du)  (r = max|w| na coluna)
    cols = np.flatnonzero(X >= x_s)
    r_col = np.array([np.abs(Y[m[:, j]]).max() if m[:, j].any() else 0 for j in cols])
    V_cubo = float(np.sum(np.pi * r_col ** 2) * RES)
    #   bossa e braço: área em planta x profundidade medida nos pontos do STEP
    du, dv, dw = (Pj - c) @ u, (Pj - c) @ v, (Pj - c) @ w
    sel_b = (du < U_BOSSA) & (dw > W_BOSSA)
    prof_boss = float(np.percentile(dv[sel_b], 99.5) - np.percentile(dv[sel_b], 0.5))
    sel_a = (du >= U_BOSSA) & (du < x_s)
    prof_braco = float(np.percentile(dv[sel_a], 99.5) - np.percentile(dv[sel_a], 0.5))
    v_meio_braco = float(0.5 * (np.percentile(dv[sel_a], 99.5) + np.percentile(dv[sel_a], 0.5)))
    raiz = np.array(next(cc for cc in J['cilindros'] if cc['tipo'] == 'furo' and abs(cc['raio_mm'] - 36.25) < 0.5)['centro_global_mm'])
    A_boss = z_boss.sum() * RES ** 2
    V_boss = float(A_boss * prof_boss - np.pi * 36.25 ** 2 * prof_boss / 0.866)   # menos o furo (inclinado)
    V_total = float(J['volume_mm3'])
    V_braco = V_total - V_cubo - V_boss
    # âncoras: faces onde o braço encontra as zonas verdes
    #   cubo: coluna x_s; bossa: fronteira braço/bossa
    col = np.argmin(np.abs(X - (x_s - 1.0)))
    yy = Y[z_braco[:, col]]
    anc_cubo = [x_s, float(yy.min()), float(yy.max())]
    dil = cv2.dilate(z_boss.astype(np.uint8), np.ones((5, 5), np.uint8)) > 0
    fr = dil & z_braco
    fx, fy = XX[fr], YY[fr]
    anc_boss = [float(fx.mean()), float(fy.mean())]
    return dict(
        fonte=os.path.basename(step), joelho=NOME_J, roda=NOME_R,
        referencial=dict(origem_mm=c.tolist(), u=u.tolist(), w=w.tolist(), v=v.tolist(),
                         nota='x2D=(P-origem).u (eixo da roda), y2D=(P-origem).w (vertical), v = fora do plano'),
        roda_dados=dict(raio_ext_mm=ext['raio_mm'], raio_int_mm=inn['raio_mm'], largura_mm=largura),
        folga_pneu_mm=FOLGA_PNEU, x_fronteira_cubo=x_s, u_bossa=U_BOSSA, w_bossa=W_BOSSA,
        raiz_2D=[float((raiz - c) @ u), float((raiz - c) @ w)], raiz_v=float((raiz - c) @ v),
        ancora_cubo=anc_cubo, ancora_bossa=anc_boss,
        prof_braco_mm=prof_braco, prof_bossa_mm=prof_boss, v_meio_braco=v_meio_braco,
        volumes_mm3=dict(total=V_total, cubo=V_cubo, bossa=V_boss, braco=V_braco),
        silhueta=cont(m), verde_cubo=cont(z_cubo), verde_bossa=cont(z_boss), braco_original=cont(z_braco),
        cilindros=[cc for cc in J['cilindros'] if cc['tipo'] in ('furo', 'veio')],
    )


def figura(g, caminho):
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(9, 7))
    r = g['roda_dados']
    from matplotlib.patches import Rectangle
    for s in (1, -1):
        ax.add_patch(Rectangle((-r['largura_mm'] / 2, min(s * r['raio_int_mm'], s * r['raio_ext_mm'])),
                               r['largura_mm'], r['raio_ext_mm'] - r['raio_int_mm'], color='0.6', alpha=.4))
    ax.axhline(-r['raio_ext_mm'], color='saddlebrown'); ax.text(-300, -r['raio_ext_mm'] + 5, 'solo')
    ax.fill(*np.array(g['braco_original']).T, color='#cfcfcf', ec='k', label='braço original (zona de projeto)')
    ax.fill(*np.array(g['verde_cubo']).T, color='limegreen', ec='darkgreen', alpha=.8, label='a preservar')
    ax.fill(*np.array(g['verde_bossa']).T, color='limegreen', ec='darkgreen', alpha=.8)
    ax.plot(*g['raiz_2D'], 'ro'); ax.text(g['raiz_2D'][0] + 5, g['raiz_2D'][1] + 8, 'furo Ø72,5\n(barra do meio)', fontsize=8)
    a = g['ancora_cubo']; ax.plot([a[0]] * 2, a[1:], 'r-', lw=3, label='âncoras')
    ax.plot(*g['ancora_bossa'], 'rs')
    ax.axvline(g['x_fronteira_cubo'], color='g', ls='--', lw=1)
    V = g['volumes_mm3']
    ax.set_title(f"Joelho do meio a partir do STEP | V total {V['total']/1e3:.0f} cm³ "
                 f"(cubo {V['cubo']/1e3:.0f}, bossa {V['bossa']/1e3:.0f}, braço {V['braco']/1e3:.0f})\n"
                 f"profundidade do braço ≈ {g['prof_braco_mm']:.0f} mm", fontweight='bold')
    ax.set_aspect('equal'); ax.grid(ls='--', alpha=.4); ax.legend(fontsize=8, loc='lower left')
    ax.set_xlabel('u = eixo da roda [mm]'); ax.set_ylabel('w = vertical [mm]')
    fig.savefig(caminho, dpi=110, bbox_inches='tight'); plt.close(fig)


if __name__ == '__main__':
    step = sys.argv[1] if len(sys.argv) > 1 else os.path.join(AQUI, '..', '..', 'joelho_traseiro_STEP', 'step', 'suspensao_v1.step')
    g = extrair(step)
    os.makedirs(os.path.join(AQUI, 'dados'), exist_ok=True)
    json.dump(g, open(os.path.join(AQUI, 'dados', 'geometria_meio.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    figura(g, os.path.join(AQUI, 'dados', 'geometria_meio.png'))
    V = g['volumes_mm3']
    print(f"raiz 2D {np.round(g['raiz_2D'],1)} (v={g['raiz_v']:.1f}) | âncora cubo {np.round(g['ancora_cubo'],1)} | âncora bossa {np.round(g['ancora_bossa'],1)}")
    print(f"prof braço {g['prof_braco_mm']:.1f} (meio v={g['v_meio_braco']:.1f}) | prof bossa {g['prof_bossa_mm']:.1f}")
    print({k: round(x / 1e3, 1) for k, x in V.items()}, 'cm3')
    print('[OK] dados/geometria_meio.json, dados/geometria_meio.png')
