# Joelho do meio — pipeline 2D (M1)

Pasta: `m1\pecas\joelho_meio\` (usa `..\nucleo\` para cargas, planetas, degradação e materiais).

## Ordem
1. `python geometria_meio.py` → `dados\geometria_meio.json` + `.png` (lê `..\..\joelho_traseiro_STEP\step\suspensao_v1.step`).
2. `python gerador_meio.py` → `diag\populacoes\<planeta>.csv`, `diag\<planeta>_top10.csv`,
   `diag\contornos_top10.json` (contornos das 10 mais leves para o 3D), `diag\dispersao_meio.png`, `diag\mais_leves_meio.png`.

## Modelo
- Plano 2D = u–w da roda:2 (igual ao traseiro). VERDE: bossa do furo Ø72,5 (barra do meio) e cubo dentro da roda (u ≥ −147,8).
  Zona de projeto = braço curvo entre as duas. Volumes do STEP: total 3690 cm³ = cubo 2865 + bossa 282 + **braço 543 (≈1,53 kg Al)**.
- Eixo do braço = Bézier cúbica de (−255, 150) [bossa] a (−90, 5) [cubo], ângulo de saída `ang`, abertura `curva`. Só o troço fora das zonas verdes conta (massa e tensões).
- Genes comuns: largura (altura no plano), prof, conicidade, ang, curva. Famílias: tubo (Lua/Mercúrio/Marte), treliça (Europa/Titã/Io), perfil I com nervuras (Vénus).
- Cargas: `nucleo.cargas_suspensao` (17 casos: @meio + induzidos @traseira pelo pino do bogie). Em cada estação: torsor 3D → N, V, M no plano (Winkler-Bach + Bleich), Mn fora do plano, T.
- Degradação: FS com a peça GASTA (genes), massa da peça NOVA (`dg.engrossar`), material × k_mat. Regras de raio interior mínimo (Mercúrio 40, Europa/Io 30 mm) aplicadas ao bordo interior da curva.
- Geometria válida: curva interior ≥ raio mínimo; não toca no pneu (folga 20 mm); cada bordo entra na bossa e cruza a face do cubo dentro da altura real (−43 a +54 mm).
- Massa total = braço + zonas verdes (cubo maciço como no STEP) no mesmo material → ordenação das 10 mais leves pela massa total.

## Resultados (01/11, N = 300; Mercúrio e Vénus 600)
| Planeta | família | passam | mais leve | massa total / braço | FS |
|---|---|---|---|---|---|
| Lua | tubo | 71 | LUA-052 Al 7075 | 9,07 / 0,23 kg | 2,24 |
| Mercúrio | tubo | 42 | MER-253 Ti CNC | 14,43 / 0,49 kg | 2,25 |
| Marte | tubo | 56 | MAR-057 Al 7075 | 9,23 / 0,39 kg | 2,67 |
| Europa | treliça | 47 | EUR-101 Al 7075 | 9,17 / 0,33 kg | 3,60 |
| Titã | treliça | 55 | TIT-101 Al 7075 | 9,15 / 0,31 kg | 7,77 (mandam as espessuras mínimas) |
| Io | treliça | 43 | IO-101 Al 7075 | 9,19 / 0,35 kg | 3,00 |
| Vénus | nervuras | 12 | VÉN-079 Ti CNC | 15,17 / 1,23 kg | 2,84 |
Caso dimensionante: `queda_lat+@meio` (tubos) e `subir_rocha@meio` (treliças/nervuras).

## Falta
- 3D no Rhino a partir de `contornos_top10.json` (construtor por família) + Intact + montagem na suspensão.
- O cubo é maciço no STEP (8,8 kg em Al): fica fora da otimização (zona verde), como no traseiro.
