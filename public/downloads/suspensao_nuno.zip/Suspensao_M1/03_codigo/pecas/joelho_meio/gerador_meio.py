"""
==============================================================================
 GERADOR DE VARIANTES 2D - JOELHO DO MEIO (por planeta, com degradação)
==============================================================================
Mesma lógica do joelho traseiro, adaptada à topologia desta peça:
  bossa da raiz (furo da barra do meio, VERDE) -> BRAÇO curvo (projeto) -> cubo (VERDE)

Genes (comuns): largura (altura do braço no plano), prof (profundidade),
  conicidade (variação da profundidade ao longo do braço), ang (ângulo de
  saída da bossa), curva (abertura da curva) + genes da FAMÍLIA do planeta:
    fechada  (Lua, Mercúrio, Marte): tubo oco  -> parede, r_cantos
    trelica  (Europa, Titã, Io):     2 banzos + diagonais -> banzo, diagonal, paineis, montantes
    isogrid  (Vénus):                perfil I com nervuras -> banzo, alma, nervura, paineis
Eixo do braço = curva de Bézier cúbica da bossa (ângulo 'ang') ao cubo (horizontal).

Cargas: nucleo/cargas_suspensao (rocker-bogie a partir do STEP): casos @meio +
  induzidos @traseira (pino do bogie livre). Torsor 3D em cada estação do braço
  -> N, V (no plano), M (no plano, Winkler-Bach), Mn (fora do plano), T (torção).
Degradação (nucleo/degradacao): genes = secção ESTRUTURAL (peça gasta, dá o FS);
  dg.engrossar acrescenta a pele sacrificial (peça nova, dá a massa); material x k_mat.
Massa: braço (zona de projeto) + zonas verdes (cubo + bossa, volume do STEP).

Uso:  python gerador_meio.py [planeta ...]      (sem argumentos: os 7)
Saída: diag/populacoes/<planeta>.csv, diag/<planeta>_top10.csv,
       diag/contornos_top10.json, diag/dispersao_meio.png, diag/mais_leves_meio.png
==============================================================================
"""
import os, sys, csv, json
import numpy as np
from scipy.stats import qmc
from matplotlib.path import Path

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(AQUI, '..', 'nucleo'))
import cargas_suspensao as cs
import planetas as pl
import degradacao as dg
import materiais as mt
import secoes as sc

G = json.load(open(os.path.join(AQUI, 'dados', 'geometria_meio.json'), encoding='utf-8'))
C0 = np.array(G['referencial']['origem_mm']); U3 = np.array(G['referencial']['u'])
W3 = np.array(G['referencial']['w']); V3 = np.array(G['referencial']['v'])
V_MEIO = G['v_meio_braco']                     # plano médio do braço (fora do plano da roda)
VERDES = [Path(np.array(G['verde_cubo'])), Path(np.array(G['verde_bossa']))]
V_VERDE = G['volumes_mm3']['cubo'] + G['volumes_mm3']['bossa']
V_BRACO_ORIG = G['volumes_mm3']['braco']
R_INT_RODA = G['roda_dados']['raio_int_mm']; L_RODA = G['roda_dados']['largura_mm']
FOLGA = G['folga_pneu_mm']

A_PT = np.array([-255.0, 150.0])               # início do eixo (dentro da bossa, junto ao furo)
B_PT = np.array([-90.0, 5.0])                  # fim do eixo (dentro do cubo, a meio da face)
#   o eixo começa e acaba DENTRO das zonas verdes: só o troço na zona de projeto conta
#   (massa e tensões); assim a curva fica suave (raio do eixo 67-440 mm)
N_EST = 60
N_POP = {'Mercúrio': 600, 'Vénus': 600}        # resto: 300 (~35 % são geometricamente válidas)
N_POP_DEF = 300
SEMENTE = 11
TOP = 10
PECA = 'joelho do meio'

FAMILIA = {'Lua': 'fechada', 'Mercúrio': 'fechada', 'Marte': 'fechada',
           'Europa': 'trelica', 'Titã': 'trelica', 'Io': 'trelica', 'Vénus': 'isogrid'}
PREFIXO = {'Lua': 'LUA', 'Mercúrio': 'MER', 'Marte': 'MAR', 'Europa': 'EUR',
           'Titã': 'TIT', 'Io': 'IO', 'Vénus': 'VÉN'}
COMUNS = dict(largura=(30.0, 95.0), prof=(15.0, 110.0), conicidade=(-0.4, 0.4),
              ang=(-75.0, -25.0), curva=(0.20, 0.60))
GENES = {
    'fechada': dict(parede=(3.0, 12.0), r_cantos=(0.10, 0.50)),
    'trelica': dict(banzo=(6.0, 22.0), diagonal=(5.0, 16.0), paineis=(2, 5), montantes=(0, 1)),
    'isogrid': dict(banzo=(6.0, 30.0), alma=(6.0, 26.0), nervura=(4.0, 10.0), paineis=(2, 6)),
}
INTEIROS = {'paineis', 'montantes'}
PAREDE_MIN = {'CNC': 3.0, 'L-PBF': 1.5}
JANELA_MIN = 14.0
NU_K = 0.904                                   # pi^2/(12(1-nu^2)), nu = 0.3


# ------------------------------------------------------------------------------
# materiais do planeta (temperatura + degradação)
# ------------------------------------------------------------------------------
def materiais(planeta):
    out = {}
    for nome, base in mt.MATERIAIS.items():
        m, _ = pl.material_no_planeta(nome, base, planeta)
        if m is not None:
            out[nome] = dg.material_gasto(m, planeta)
    return out


# ------------------------------------------------------------------------------
# eixo do braço
# ------------------------------------------------------------------------------
def eixo(g, n=N_EST):
    th = np.radians(g['ang'])
    dA = np.array([np.cos(th), np.sin(th)]); dB = np.array([1.0, 0.0])
    h = g['curva'] * np.linalg.norm(B_PT - A_PT)
    P = [A_PT, A_PT + h * dA, B_PT - h * dB, B_PT]
    t = np.linspace(0, 1, n)[:, None]
    X = (1 - t) ** 3 * P[0] + 3 * (1 - t) ** 2 * t * P[1] + 3 * (1 - t) * t ** 2 * P[2] + t ** 3 * P[3]
    d1 = 3 * ((1 - t) ** 2 * (P[1] - P[0]) + 2 * (1 - t) * t * (P[2] - P[1]) + t ** 2 * (P[3] - P[2]))
    d2 = 6 * ((1 - t) * (P[2] - 2 * P[1] + P[0]) + t * (P[3] - 2 * P[2] + P[1]))
    sp = np.linalg.norm(d1, axis=1)
    tang = d1 / sp[:, None]
    kap = (d1[:, 0] * d2[:, 1] - d1[:, 1] * d2[:, 0]) / sp ** 3
    s = np.r_[0, np.cumsum(np.linalg.norm(np.diff(X, axis=0), axis=1))]
    projeto = ~np.array([any(p.contains_point(x) for p in VERDES) for x in X])
    return dict(X=X, tang=tang, nrm=np.c_[-tang[:, 1], tang[:, 0]], kap=kap, s=s, projeto=projeto)


def bordos(e, t):
    return e['X'] + 0.5 * t[:, None] * e['nrm'], e['X'] - 0.5 * t[:, None] * e['nrm']


def geometria_valida(e, t, planeta):
    rho = 1.0 / np.maximum(np.abs(e['kap']), 1e-9)
    r_int = rho - t / 2
    r_min = max(dg.de(planeta)['r_int_min'] or 0.0, 5.0)
    k = e['projeto']
    if (r_int[k] < r_min).any():
        return f'curva interior com raio < {r_min:.0f} mm'
    for B in bordos(e, t):                       # não tocar no pneu
        dentro = B[:, 0] > -L_RODA / 2
        if (np.hypot(B[dentro, 0], B[dentro, 1]) > R_INT_RODA - FOLGA).any():
            return 'toca no pneu'
    if e['s'][k].size < 3:
        return 'braço demasiado curto'
    # ligação às zonas verdes com a secção inteira:
    #   cubo: cada bordo cruza a face u = x_fronteira dentro da altura real da face
    #   bossa: cada bordo entra na bossa
    xf, w0, w1 = G['ancora_cubo']
    for B in bordos(e, t):
        if not VERDES[1].contains_points(B).any():
            return 'não liga à bossa'
        j = np.flatnonzero((B[:-1, 0] < xf) & (B[1:, 0] >= xf))
        if j.size == 0:
            return 'não chega ao cubo'
        j = j[-1]; f = (xf - B[j, 0]) / (B[j + 1, 0] - B[j, 0])
        wc = B[j, 1] + f * (B[j + 1, 1] - B[j, 1])
        if not (w0 - 2 <= wc <= w1 + 2):
            return 'não cabe na face do cubo'
    return None


# ------------------------------------------------------------------------------
# cargas: por caso, F total e momento em relação à origem global
# ------------------------------------------------------------------------------
_CASOS = {}


def casos(planeta):
    if planeta not in _CASOS:
        out = []
        for nome, lst in cs.cargas_aplicadas(planeta).items():
            F = np.zeros(3); M0 = np.zeros(3)
            for roda, Fi, Pi in lst:
                if roda in cs.PECAS[PECA]['rodas']:
                    F += Fi; M0 += np.cross(Pi, Fi)
            if np.linalg.norm(F) > 0:
                out.append((nome, F, M0))
        _CASOS[planeta] = out
    return _CASOS[planeta]


def esforcos(e, planeta):
    """N, V, M (no plano), Mn (fora), T por caso (linhas) e estação (colunas). N.mm."""
    Q = C0 + e['X'][:, :1] * U3 + e['X'][:, 1:] * W3 + V_MEIO * V3
    tau = e['tang'][:, :1] * U3 + e['tang'][:, 1:] * W3
    nrm = e['nrm'][:, :1] * U3 + e['nrm'][:, 1:] * W3
    R = {k: [] for k in ('N', 'V', 'M', 'Mn', 'T')}
    nomes = []
    for nome, F, M0 in casos(planeta):
        M = M0[None, :] - np.cross(Q, F)              # momento em Q da carga do lado da roda
        R['N'].append(tau @ F); R['V'].append(nrm @ F)
        R['M'].append(M @ V3); R['Mn'].append(np.sum(M * nrm, 1)); R['T'].append(np.sum(M * tau, 1))
        nomes.append(nome)
    return nomes, {k: np.array(v) for k, v in R.items()}


def fc_winkler(t, rho):
    """Fator de Winkler-Bach (fibra interior) de um retângulo de altura t e raio rho."""
    rho = np.abs(rho)
    ri = np.maximum(rho - t / 2, 1e-6); ro = rho + t / 2
    rn = t / np.log(ro / ri)
    ecc = np.maximum(rho - rn, 1e-9)
    f = (rn - ri) * t / (6 * ecc * ri)
    return np.where(rho / t > 50, 1.0, np.maximum(f, 1.0))


# ------------------------------------------------------------------------------
# famílias: tensão equivalente (peça GASTA = genes) e área (peça NOVA = engrossada)
# ------------------------------------------------------------------------------
def avaliar(planeta, g, nome_mat, mats=None):
    mats = mats or materiais(planeta)
    mat = mats[nome_mat]
    fam = FAMILIA[planeta]
    e = eixo(g)
    t = np.full(N_EST, g['largura'])
    m = dg.de(planeta)
    proc = 'L-PBF' if 'L-PBF' in nome_mat else 'CNC'
    motivo = geometria_valida(e, t + 2 * m['delta'], planeta)
    if motivo:
        return dict(valido=False, motivo=motivo)
    k = e['projeto']
    u = (e['s'] - e['s'][k][0]) / max(e['s'][k][-1] - e['s'][k][0], 1e-9)
    b = np.maximum(g['prof'] * (1 + g['conicidade'] * (2 * np.clip(u, 0, 1) - 1)), 12.0)
    rho = np.where(np.abs(e['kap']) > 1e-6, 1.0 / np.where(np.abs(e['kap']) > 1e-6, e['kap'], 1), np.inf)
    fc = fc_winkler(t, np.where(np.isfinite(rho), rho, 1e9))
    nomes, S = esforcos(e, planeta)
    N, V, M, Mn, T = (np.abs(S[x]) for x in ('N', 'V', 'M', 'Mn', 'T'))
    gn = dg.engrossar(g, fam, planeta)               # peça NOVA (massa)
    tn, bn = t + 2 * m['delta'], b + 2 * m['delta']
    E, sy = mat['E'], mat['sy']
    L_braco = e['s'][k][-1] - e['s'][k][0]

    if fam == 'fechada':
        if g['parede'] < max(PAREDE_MIN[proc], m['parede_min'] or 0):
            return dict(valido=False, motivo='parede abaixo do mínimo')
        if m['r_cantos_min'] and g['r_cantos'] < m['r_cantos_min']:
            return dict(valido=False, motivo='cantos com raio abaixo do mínimo')
        ee = np.minimum(g['parede'], 0.5 * np.minimum(t, b)); rr = g['r_cantos'] * np.minimum(t, b)
        sc.E_MAT, sc.SY_MAT = E, sy
        smax = np.zeros_like(N)
        for i in range(N.shape[0]):
            p_, f_, _, _ = sc.caixa_sigma(t, b, ee, rr, N[i], V[i], M[i], fc, Mn[i], T[i], rho=rho)
            smax[i] = np.maximum(p_, f_)
        en = np.minimum(gn['parede'], 0.5 * np.minimum(tn, bn))
        A_new, _, _, _ = sc.caixa_props(tn, bn, en, g['r_cantos'] * np.minimum(tn, bn))

    elif fam == 'trelica':
        wc, wd, n = g['banzo'], g['diagonal'], int(g['paineis'])
        h = t - wc
        if (t - 2 * wc < JANELA_MIN).any():
            return dict(valido=False, motivo='sem altura para janelas (banzos demasiado largos)')
        A = 2 * wc * b
        Iz = 2 * (b * wc ** 3 / 12 + wc * b * (h / 2) ** 2)
        In = 2 * wc * b ** 3 / 12
        a_, c_ = np.maximum(wc, b), np.minimum(wc, b)
        sig = N / A + fc * M * (t / 2) / Iz + Mn * (b / 2) / In
        tau = 0.5 * T * (3 * a_ + 1.8 * c_) / (a_ ** 2 * c_ ** 2)
        s_banzo = np.sqrt(sig ** 2 + 3 * tau ** 2)
        p = L_braco / n
        Ld = np.sqrt(p ** 2 + h ** 2)
        Fd = V / (h / Ld)
        sd = Fd / (wd * b)
        Kef = 0.7 if g['montantes'] >= 0.5 else 1.0
        scr = np.pi ** 2 * E * (wd ** 2 / 12) / (Kef * Ld) ** 2
        s_diag = np.maximum(sd, sd * sy / scr)
        smax = np.maximum(s_banzo, s_diag)
        hn = tn - gn['banzo']
        A_new = 2 * gn['banzo'] * bn + (n * gn['diagonal'] * bn * np.sqrt(p ** 2 + hn ** 2)
                                        + (n + 1) * g['montantes'] * gn['diagonal'] * bn * hn) / L_braco

    else:   # isogrid (Vénus): perfil I com nervuras transversais
        tf, tw, wr, n = g['banzo'], g['alma'], g['nervura'], int(g['paineis'])
        hw = t - 2 * tf
        if (hw < JANELA_MIN).any() or (b <= tw + 2).any():
            return dict(valido=False, motivo='perfil I sem alma / banzos demasiado largos')
        A = 2 * b * tf + tw * hw
        Iz = (b * t ** 3 - (b - tw) * hw ** 3) / 12
        In = (2 * tf * b ** 3 + hw * tw ** 3) / 12
        bl = (b - tw) / 2
        J = (2 * b * tf ** 3 + hw * tw ** 3) / 3
        smax = np.zeros_like(N)
        a_rib = L_braco / n
        kv = np.where(a_rib >= hw, 5.35 + 4 * (hw / a_rib) ** 2, 4 + 5.35 * (hw / a_rib) ** 2)
        tcr = kv * NU_K * E * (tw / hw) ** 2
        scr_f = 0.43 * NU_K * E * (tf / np.maximum(bl, 1e-6)) ** 2
        for i in range(N.shape[0]):
            sb_, _ = sc.bleich_tensao(t, b, tf, bl, rho, N[i], M[i], fc, Iz, A, 'I')
            sig = np.maximum(sb_, N[i] / A + fc * M[i] * (t / 2) / Iz) + Mn[i] * (b / 2) / In
            tau = V[i] / (tw * hw) + T[i] * max(tf, tw) / J
            smax[i] = np.maximum.reduce([np.sqrt(sig ** 2 + 3 * tau ** 2), sig * sy / scr_f, tau * sy / tcr])
        hwn = tn - 2 * gn['banzo']
        A_new = 2 * bn * gn['banzo'] + gn['alma'] * hwn + (n - 1) * gn['nervura'] * hwn * (bn - gn['alma']) / L_braco

    sk = smax[:, k]
    FS_casos = sy / np.maximum(sk.max(1), 1e-9)
    ic = int(np.argmin(FS_casos)); jc = int(np.argmax(sk[ic]))
    integ = np.trapezoid if hasattr(np, 'trapezoid') else np.trapz
    V_braco = float(integ(np.broadcast_to(A_new, N_EST)[k], e['s'][k]))
    massa_braco = V_braco * mat['rho'] * 1e-9
    massa = (V_braco + V_VERDE) * mat['rho'] * 1e-9
    FS = float(FS_casos[ic])
    req = pl.PLANETAS[planeta]['FS']
    return dict(valido=True, massa_kg=massa, massa_braco_kg=massa_braco, FS_min=FS, FS_req=req,
                passa=FS >= req, caso_critico=nomes[ic], s_critico=float(e['s'][k][jc] - e['s'][k][0]),
                eixo=e, t=t, b=b, gn=gn)


# ------------------------------------------------------------------------------
# população por planeta
# ------------------------------------------------------------------------------
def limites(planeta):
    fam = FAMILIA[planeta]
    L = dict(COMUNS); L.update(GENES[fam])
    m = dg.de(planeta)
    if fam == 'fechada':
        lo = max(PAREDE_MIN['L-PBF'], m['parede_min'] or 0)
        L['parede'] = (lo, L['parede'][1])
        if m['r_cantos_min']:
            L['r_cantos'] = (m['r_cantos_min'], L['r_cantos'][1])
    return L


def amostrar(planeta, n, semente=SEMENTE):
    L = limites(planeta)
    nomes = list(L)
    mats = list(materiais(planeta))
    X = qmc.LatinHypercube(d=len(nomes) + 1, seed=semente).random(n)
    out = []
    for x in X:
        g = {}
        for j, k in enumerate(nomes):
            lo, hi = L[k]
            if k in INTEIROS:
                g[k] = int(np.floor(lo + x[j] * (hi - lo + 1 - 1e-9)))
            else:
                g[k] = float(lo + x[j] * (hi - lo))
        out.append((g, mats[int(x[-1] * len(mats) * (1 - 1e-12))]))
    return out


def gerar_populacao(planeta, n=None):
    n = n or N_POP.get(planeta, N_POP_DEF)
    mats = materiais(planeta)
    linhas, res = [], []
    for i, (g, nm) in enumerate(amostrar(planeta, n)):
        r = avaliar(planeta, g, nm, mats)
        vid = f'{PREFIXO[planeta]}-{i:03d}'
        lin = dict(id=vid, planeta=planeta, familia=FAMILIA[planeta], material=nm,
                   **{k: round(v, 3) if isinstance(v, float) else v for k, v in g.items()},
                   delta_mm=dg.de(planeta)['delta'], k_deg=dg.de(planeta)['k_mat'])
        if r['valido']:
            lin.update(massa_kg=round(r['massa_kg'], 4), massa_braco_kg=round(r['massa_braco_kg'], 4),
                       FS_min=round(r['FS_min'], 3), FS_req=r['FS_req'], passa=int(r['passa']),
                       caso_critico=r['caso_critico'], s_critico_mm=round(r['s_critico'], 1), motivo='')
        else:
            lin.update(massa_kg='', massa_braco_kg='', FS_min='', FS_req=pl.PLANETAS[planeta]['FS'],
                       passa=0, caso_critico='', s_critico_mm='', motivo=r['motivo'])
        linhas.append(lin); res.append((vid, g, nm, r))
    return linhas, res


def gravar_csv(caminho, linhas):
    os.makedirs(os.path.dirname(caminho), exist_ok=True)
    chaves = []
    for l in linhas:
        chaves += [k for k in l if k not in chaves]
    with open(caminho, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=chaves, delimiter=';')
        w.writeheader(); w.writerows(linhas)


def correr(planetas):
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    diag = os.path.join(AQUI, 'diag')
    resumo, conts, todos = [], {}, {}
    for p in planetas:
        linhas, res = gerar_populacao(p)
        gravar_csv(os.path.join(diag, 'populacoes', f'{p}.csv'), linhas)
        ok = sorted([x for x in res if x[3]['valido'] and x[3]['passa']], key=lambda x: x[3]['massa_kg'])
        top = ok[:TOP]
        gravar_csv(os.path.join(diag, f'{p}_top10.csv'), [l for l in linhas if l['id'] in {x[0] for x in top}])
        for vid, g, nm, r in top:
            e = r['eixo']; k = e['projeto'].copy(); idx = np.flatnonzero(k)
            k[max(idx[0] - 1, 0)] = True; k[min(idx[-1] + 1, N_EST - 1)] = True
            Bs, Bi = bordos(e, np.full(N_EST, r['gn']['largura']))
            dl = dg.de(p)['delta']
            conts[vid] = dict(planeta=p, familia=FAMILIA[p], material=nm, genes=g, genes_novos=r['gn'],
                              eixo=e['X'][k].round(3).tolist(), prof_nova=(r['b'][k] + 2 * dl).round(3).tolist(),
                              bordo_cima=Bs[k].round(3).tolist(), bordo_baixo=Bi[k].round(3).tolist(),
                              massa_kg=r['massa_kg'], massa_braco_kg=r['massa_braco_kg'], FS_min=r['FS_min'])
        todos[p] = res
        val = [x for x in res if x[3]['valido']]
        resumo.append((p, len(res), len(val), len(ok), top[0] if top else None))
        print(f"{p:9s} {FAMILIA[p]:8s} n={len(res)} válidas={len(val)} passam={len(ok)}"
              + (f" | mais leve {top[0][0]} {top[0][2]} {top[0][3]['massa_kg']:.2f} kg "
                 f"(braço {top[0][3]['massa_braco_kg']:.2f}) FS {top[0][3]['FS_min']:.2f} [{top[0][3]['caso_critico']}]" if top else ''))
    json.dump(conts, open(os.path.join(diag, 'contornos_top10.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

    # dispersão massa do braço x FS
    fig, axs = plt.subplots(2, 4, figsize=(18, 8.5)); axs = axs.ravel()
    for ax, p in zip(axs, planetas):
        val = [x for x in todos[p] if x[3]['valido']]
        req = pl.PLANETAS[p]['FS']
        mb = np.array([x[3]['massa_braco_kg'] for x in val]); fs = np.array([x[3]['FS_min'] for x in val])
        ps = fs >= req
        ax.scatter(mb[~ps], fs[~ps], s=12, c='0.7', label='não passa')
        ax.scatter(mb[ps], fs[ps], s=14, c='#2E86C1', label='passa')
        tp = [x for x in val if x[3]['passa']]
        tp = sorted(tp, key=lambda x: x[3]['massa_kg'])[:TOP]
        ax.scatter([x[3]['massa_braco_kg'] for x in tp], [x[3]['FS_min'] for x in tp], s=40,
                   facecolors='none', edgecolors='r', label='10 mais leves')
        ax.axhline(req, color='r', ls='--', lw=1)
        ax.axvline(V_BRACO_ORIG * 2810e-9, color='k', ls=':', lw=1, label='braço original (Al)')
        ax.set_yscale('log'); ax.set_title(f'{p} ({NOME_FAM[FAMILIA[p]]})', fontsize=10)
        ax.set_xlabel('massa do braço [kg]'); ax.set_ylabel('FS (peça gasta)'); ax.grid(alpha=.3)
    axs[0].legend(fontsize=7)
    axs[-1].axis('off')
    fig.suptitle('Joelho do meio — população 2D por planeta (com degradação)', fontweight='bold')
    fig.tight_layout(); fig.savefig(os.path.join(diag, 'dispersao_meio.png'), dpi=110); plt.close(fig)

    # desenho da mais leve de cada planeta
    fig, axs = plt.subplots(2, 4, figsize=(18, 9)); axs = axs.ravel()
    for ax, (p, n, nv, npas, top) in zip(axs, resumo):
        ax.fill(*np.array(G['braco_original']).T, color='none', ec='0.6', ls='--', lw=1)
        for k_ in ('verde_cubo', 'verde_bossa'):
            ax.fill(*np.array(G[k_]).T, color='limegreen', ec='darkgreen', alpha=.7)
        if top:
            c = conts[top[0]]
            P = np.r_[np.array(c['bordo_cima']), np.array(c['bordo_baixo'])[::-1]]
            ax.fill(*P.T, color='#2E86C1', alpha=.8, ec='k')
            ax.plot(*np.array(c['eixo']).T, 'w--', lw=.8)
            ax.set_title(f"{p}: {top[0]} | {top[2].split(' (')[0]}\n{c['massa_kg']:.2f} kg "
                         f"(braço {c['massa_braco_kg']:.2f}) | FS {c['FS_min']:.2f}", fontsize=9)
        else:
            ax.set_title(f'{p}: nenhuma passa', fontsize=9)
        ax.set_aspect('equal'); ax.set_xlim(-310, 100); ax.set_ylim(-110, 225); ax.grid(alpha=.3)
    axs[-1].axis('off')
    fig.suptitle('Joelho do meio — variante mais leve que passa, por planeta (tracejado = braço original)', fontweight='bold')
    fig.tight_layout(); fig.savefig(os.path.join(diag, 'mais_leves_meio.png'), dpi=110); plt.close(fig)
    return resumo


NOME_FAM = {'fechada': 'tubo oco', 'trelica': 'treliça', 'isogrid': 'nervuras'}

if __name__ == '__main__':
    pls = sys.argv[1:] or list(FAMILIA)
    correr(pls)
    print('[OK] diag/populacoes/*.csv, diag/*_top10.csv, diag/contornos_top10.json, diag/dispersao_meio.png, diag/mais_leves_meio.png')
