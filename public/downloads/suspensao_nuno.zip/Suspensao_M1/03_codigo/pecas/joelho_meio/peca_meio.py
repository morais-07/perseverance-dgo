"""
==============================================================================
 JOELHO DO MEIO - DESCRIÇÃO 3D DE UMA VARIANTE (sem Rhino: só numpy)
==============================================================================
Ponte entre a geração 2D (gerador_meio.py) e o construtor Rhino (rhino_meio.py).
Tudo o que é geometria/cálculo fica aqui (testável fora do Rhino); o
rhino_meio.py só transforma estas listas de pontos em sólidos.

Referencial (do STEP, geometria_meio.json):  P = C0 + u*U + w*W + v*V
  u = eixo da roda (+X global), w = vertical (+Z), v = fora do plano (+Y)

Peça 3D = BRAÇO NOVO (genes engrossados pela degradação, como no traseiro):
  - loft de secções t x b ao longo do eixo Bézier (prolongado para dentro das
    zonas verdes), depois cortado pelas zonas verdes:
       cubo  = semi-espaço u >= x_s          -> face de CARGA (plana, u = x_s)
       bossa = quadrante u < -215, w > 95    -> face FIXA (planos u = -215 / w = 95)
  - família: tubo oco (cavidade + respiro Ø3) | treliça (janelas passantes)
             | perfil I com nervuras (rebaixos dos dois lados até à alma)

CASOS 3D: os 17 casos do 2D reduzidos por LINEARIDADE: casos com a mesma
direção de força e o mesmo ponto (ex. queda@meio, aterragem@meio e TODOS os
induzidos @traseira = força vertical no contacto da roda do meio) só diferem
na intensidade -> corre-se só o maior. Fica em diag/intact/casos_equivalentes.csv.
==============================================================================
"""
import os, sys, csv
import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__))
if AQUI not in sys.path:
    sys.path.insert(0, AQUI)
_NUC = os.path.normpath(os.path.join(AQUI, '..', 'nucleo'))
if _NUC not in sys.path:
    sys.path.insert(1, _NUC)
import gerador_meio as gm
import planetas as pl
import degradacao as dg

PECA = 'joelho do meio'
NOME_STEP = 'joleho do meio'           # nome do componente no STEP (com o erro de escrita do Fusion)
SAIDA = os.path.join(AQUI, 'diag', 'intact')
PLANETAS = list(gm.FAMILIA)
NOME_FAM = gm.NOME_FAM

G = gm.G
C0, U3, W3, V3 = gm.C0, gm.U3, gm.W3, gm.V3
V_MEIO = gm.V_MEIO
X_S = float(G['x_fronteira_cubo'])     # face do cubo (carga)
U_B, W_B = float(G['u_bossa']), float(G['w_bossa'])   # quadrante da bossa (fixa)
EXT_A = 60.0                           # mm: prolongamento do eixo para dentro da bossa
EXT_B = 20.0                           # mm: e para dentro do cubo
PASSO_SEC = 2                          # usar 1 estação em cada 2 no loft
R_JANELA = 3.0                         # mm: raio dos cantos das janelas / rebaixos
MARGEM = 2.0                           # mm: janelas/cavidade afastadas das zonas verdes


# ------------------------------------------------------------------------------
# utilitários
# ------------------------------------------------------------------------------
def p3(u, w, v=None):
    """Coordenadas (u, w[, v]) -> ponto global (numpy). Aceita arrays."""
    u = np.asarray(u, float); w = np.asarray(w, float)
    v = np.full_like(u, V_MEIO) if v is None else np.asarray(v, float) + 0 * u
    return C0 + u[..., None] * U3 + w[..., None] * W3 + v[..., None] * V3


def local(P):
    d = np.asarray(P, float) - C0
    return np.stack([d @ U3, d @ W3, d @ V3], -1)


def dist_bossa(u, w):
    """Distância (no plano) ao quadrante da bossa (0 dentro)."""
    du = np.maximum(np.asarray(u) - U_B, 0.0)
    dw = np.maximum(W_B - np.asarray(w), 0.0)
    return np.hypot(du, dw)


def dist_verdes(u, w):
    """Distância (no plano) à zona verde mais próxima (bossa ou cubo)."""
    return np.minimum(dist_bossa(u, w), np.maximum(X_S - np.asarray(u), 0.0))


def nome_planeta(v):
    import unicodedata
    tira = lambda s: unicodedata.normalize('NFKD', str(s)).encode('ascii', 'ignore').decode().strip().lower()
    for n in PLANETAS:
        if tira(n) == tira(v):
            return n
    raise Exception('Planeta desconhecido: {!r}. Usa um destes: {}'.format(v, ', '.join(PLANETAS)))


# ------------------------------------------------------------------------------
# população / candidatos / material
# ------------------------------------------------------------------------------
def ler_populacao(planeta):
    f = os.path.join(AQUI, 'diag', 'populacoes', planeta + '.csv')
    return list(csv.DictReader(open(f, encoding='utf-8-sig'), delimiter=';'))


def linha(planeta, vid):
    for l in ler_populacao(planeta):
        if l['id'].upper() == vid.upper():
            return l
    raise Exception('Não encontrei {} em diag/populacoes/{}.csv'.format(vid, planeta))


PREVISTA = os.path.join(AQUI, 'diag', 'massa3d_prevista')


def ler_prevista(planeta):
    """{id: massa_3d prevista [kg]} de diag/massa3d_prevista/<planeta>.csv (vazio se não existir)."""
    f = os.path.join(PREVISTA, planeta + '.csv')
    if not os.path.exists(f):
        return {}
    return {l['id']: float(l['massa_3d_prevista_kg']) for l in
            csv.DictReader(open(f, encoding='utf-8-sig'), delimiter=';') if l.get('massa_3d_prevista_kg')}


def candidatos(planeta, n):
    """As n mais leves que passam no 2D. Ordem: massa 3D PREVISTA (geometria real do
    braço 3D: pontas em cunha + janelas/cavidade só no troço livre) se existir
    diag/massa3d_prevista/<planeta>.csv (prever_massa_3d.py); senão massa 2D."""
    pop = [l for l in ler_populacao(planeta) if l.get('passa') == '1' and l.get('massa_kg')]
    prev = ler_prevista(planeta)
    if prev:                                   # só as que o 3D consegue construir
        pop = [l for l in pop if l['id'] in prev]
    pop.sort(key=lambda l: prev.get(l['id'], float(l['massa_kg'])))
    return [l['id'] for l in pop[:n]]


def genes_de_linha(l):
    fam = gm.FAMILIA[l['planeta']]
    g = {}
    for k in list(gm.COMUNS) + list(gm.GENES[fam]):
        g[k] = int(float(l[k])) if k in gm.INTEIROS else float(l[k])
    return g


def material(planeta, nome_mat):
    """Material do planeta (temperatura + degradação k_mat), E/sy em MPa, rho kg/m3."""
    return gm.materiais(planeta)[nome_mat]


def FS_req(planeta):
    return float(pl.PLANETAS[planeta]['FS'])


# ------------------------------------------------------------------------------
# casos de carga 3D (reduzidos por linearidade)
# ------------------------------------------------------------------------------
_CASOS3D = {}


def lista_casos(planeta, gravar=False):
    """[(nome, F_global [N], M0_global [N.mm] em relação à origem global, equivalentes)]"""
    if planeta in _CASOS3D and not gravar:
        return _CASOS3D[planeta]
    todos = gm.casos(planeta)                     # (nome, F, M0) só com as rodas da peça
    grupos = []
    for nome, F, M0 in todos:
        f = np.linalg.norm(F)
        chave = np.r_[F / f, M0 / f]
        for gr in grupos:
            if (np.allclose(gr['chave'], chave, rtol=1e-6, atol=1e-6 * max(1.0, np.abs(chave).max())) or
                    np.allclose(gr['chave'], -chave, rtol=1e-6, atol=1e-6 * max(1.0, np.abs(chave).max()))):   # 02/11: carga simétrica (-F, -M) = mesmo Danger Level (elasticidade linear)
                gr['membros'].append((nome, f))
                break
        else:
            grupos.append(dict(chave=chave, membros=[(nome, f)], F=F, M0=M0, f=f, nome=nome))
    out = []
    for gr in grupos:
        nome_max, fmax = max(gr['membros'], key=lambda x: x[1])
        esc = fmax / gr['f']
        eq = [m for m in gr['membros'] if m[0] != nome_max]
        rot = nome_max
        if eq:                                    # grupo de casos proporcionais: nome claro
            rot = 'vertical_max' if abs(gr['chave'][2]) > 0.999 else nome_max + '*'
            eq = [(nome_max, fmax)] + eq
        ordem = (1 if eq else 0, [x[0] for x in todos].index(nome_max))
        out.append((ordem, (rot, gr['F'] * esc, gr['M0'] * esc, eq)))
    # ordem: casos da própria roda primeiro, o vertical máximo no fim
    out = [c for _, c in sorted(out, key=lambda x: x[0])]
    _CASOS3D[planeta] = out
    if gravar:
        os.makedirs(SAIDA, exist_ok=True)
        with open(os.path.join(SAIDA, planeta + '_casos_equivalentes.csv'), 'w', encoding='utf-8-sig') as fh:
            fh.write('planeta;caso_3D;F_N;casos_2D_proporcionais (% da força)\n')
            for nome, F, M0, eq in out:
                fh.write('{};{};{:.1f};{}\n'.format(planeta, nome, np.linalg.norm(F),
                         ', '.join('{} ({:.0f} %)'.format(n, 100 * f / np.linalg.norm(F)) for n, f in eq)))
    return out


def n_casos(planeta):
    return len(lista_casos(planeta))


V_VERDE = gm.V_VERDE                   # mm3: cubo + bossa (maciços, do STEP)


def dist_ligacoes(P):
    """Pontos globais (n x 3) -> (distância à face FIXA, distância à face de CARGA) [mm],
    medidas no plano (as faces são planas: u = -215 / w = 95 e u = x_s)."""
    L = local(np.atleast_2d(P))
    return dist_bossa(L[:, 0], L[:, 1]), np.maximum(X_S - L[:, 0], 0.0)


# ------------------------------------------------------------------------------
# descrição geométrica de uma variante
# ------------------------------------------------------------------------------
def _eixo_prolongado(g):
    """Eixo Bézier (gm.eixo) + prolongamentos retos para dentro das zonas verdes."""
    e = gm.eixo(g)
    X, T = e['X'], e['tang']
    pa = [X[0] - d * T[0] for d in np.linspace(EXT_A, 0, 4)[:-1]]
    pb = [X[-1] + d * T[-1] for d in np.linspace(0, EXT_B, 3)[1:]]
    Xp = np.vstack([pa, X, pb])
    Tp = np.vstack([[T[0]] * len(pa), T, [T[-1]] * len(pb)])
    s = np.r_[0, np.cumsum(np.linalg.norm(np.diff(Xp, axis=0), axis=1))]
    return e, Xp, Tp, s, len(pa)


def descrever(planeta, vid):
    """Tudo o que o construtor Rhino precisa (listas de pontos globais)."""
    l = linha(planeta, vid)
    g = genes_de_linha(l)
    nm = l['material']
    r = gm.avaliar(planeta, g, nm)
    if not r.get('valido'):
        raise Exception('{} não é geometricamente válida: {}'.format(vid, r.get('motivo')))
    fam = gm.FAMILIA[planeta]
    gn = r['gn']                                   # genes da peça NOVA
    dl = dg.de(planeta)['delta']
    e, Xp, Tp, s, na = _eixo_prolongado(g)
    Np = np.c_[-Tp[:, 1], Tp[:, 0]]
    b_e = np.asarray(r['b'], float) + 2 * dl       # profundidade nova nas estações do eixo
    bp = np.r_[[b_e[0]] * na, b_e, [b_e[-1]] * (len(Xp) - na - len(b_e))]
    t = float(gn['largura'])
    idx = list(range(0, len(Xp), PASSO_SEC))
    if idx[-1] != len(Xp) - 1:
        idx.append(len(Xp) - 1)
    rc = (float(gn['r_cantos']) if fam == 'fechada' else 0.0)
    secoes = [dict(c=Xp[i], n=Np[i], tg=Tp[i], t=t, b=float(bp[i]),
                   R=max(rc * min(t, bp[i]), 0.5) if fam == 'fechada' else 0.5) for i in idx]
    d = dict(planeta=planeta, id=l['id'], familia=fam, material=nm, genes=g, genes_novos=gn,
             massa_2d=float(l['massa_kg']), massa_braco_2d=float(l['massa_braco_kg']),
             FS_2d=float(l['FS_min']), secoes=secoes, b_max=float(bp.max()), t=t,
             cavidades=[], janelas=[], rebaixos=[], avisos=[])

    # troço útil: estações cuja secção INTEIRA está fora das zonas verdes (+ margem)
    def fora(i, meia=t / 2):
        q = np.array([Xp[i] + k * meia * Np[i] for k in (-1, 0, 1)])
        return (dist_verdes(q[:, 0], q[:, 1]) > MARGEM).all()
    livre = [i for i in range(len(Xp)) if fora(i)]
    if len(livre) < 3:
        d['avisos'].append('braço curto: sem troço livre para cavidade/janelas')
        return d
    ia, ib = livre[0], livre[-1]
    sa, sb = s[ia], s[ib]
    d['s_livre'] = (float(sa), float(sb))

    def mapa(S, Nn):
        """(s, n) -> (u, w) ao longo do eixo prolongado."""
        S = np.asarray(S, float); Nn = np.asarray(Nn, float)
        x = np.interp(S, s, Xp[:, 0]); y = np.interp(S, s, Xp[:, 1])
        nx = np.interp(S, s, Np[:, 0]); ny = np.interp(S, s, Np[:, 1])
        nn = np.hypot(nx, ny)
        return np.c_[x + Nn * nx / nn, y + Nn * ny / nn]

    if fam == 'fechada':
        ee = float(gn['parede'])
        cav = []
        for j, i in enumerate(idx):
            if ia <= i <= ib:
                S_ = secoes[j]
                ti, bi = S_['t'] - 2 * ee, S_['b'] - 2 * ee
                if ti > 2 and bi > 2:
                    cav.append(dict(c=S_['c'], n=S_['n'], tg=S_['tg'], t=ti, b=bi,
                                    R=max(S_['R'] - ee, 0.5)))
        # pontas em ogiva (8 mm além da última secção): encurta até ficarem longe das zonas verdes
        def ponta_ok(P_, sg):
            pt = P_['c'] + sg * 8.0 * P_['tg']
            q = np.array([pt + k * P_['t'] / 2 * P_['n'] for k in (-1, 0, 1)])
            return (dist_verdes(q[:, 0], q[:, 1]) > MARGEM).all()
        while len(cav) >= 3 and not ponta_ok(cav[0], -1):
            cav.pop(0)
        while len(cav) >= 3 and not ponta_ok(cav[-1], +1):
            cav.pop()
        if len(cav) >= 3:
            d['cavidades'].append(cav)
        else:
            d['avisos'].append('tubo sem cavidade (troço livre curto): peça maciça')
    elif fam == 'trelica':
        d['janelas'] = _janelas_trelica(gn, t, sa, sb, mapa, d)
    else:
        d['rebaixos'] = _rebaixos_isogrid(gn, t, sa, sb, mapa, d)
    return d


# ------------------------------------------------------------------------------
# janelas (treliça) e rebaixos (nervuras) no espaço (s, n) do braço
# ------------------------------------------------------------------------------
def _inset_arredondado(poly, offs, r, n_arco=6, passo=3.0):
    """Polígono CONVEXO (anti-horário) com cada aresta recuada offs[k] e cantos de raio r.
    Devolve a lista de pontos (s, n) da fronteira, ou None se não couber."""
    P = np.asarray(poly, float)
    k = len(P)
    if 0.5 * np.sum(P[:, 0] * np.roll(P[:, 1], -1) - np.roll(P[:, 0], -1) * P[:, 1]) < 0:
        P = P[::-1]; offs = list(offs)[::-1]
        offs = offs[1:] + offs[:1]          # aresta k liga P[k] -> P[k+1]
    linhas = []
    for i in range(k):
        a, b = P[i], P[(i + 1) % k]
        dvec = (b - a) / np.linalg.norm(b - a)
        nin = np.array([-dvec[1], dvec[0]])  # normal para dentro (polígono anti-horário)
        linhas.append((a + (offs[i] + r) * nin, dvec, nin))
    Q = []
    for i in range(k):
        (a1, d1, _), (a2, d2, _) = linhas[i - 1], linhas[i]
        M = np.array([d1, -d2]).T
        if abs(np.linalg.det(M)) < 1e-9:
            return None
        tt = np.linalg.solve(M, a2 - a1)
        Q.append(a1 + tt[0] * d1)
    Q = np.array(Q)
    # o polígono interior tem de continuar convexo, com a mesma orientação e sem inverter
    for i in range(k):
        e1 = Q[(i + 1) % k] - Q[i]
        if e1 @ linhas[i][1] <= 1e-6:
            return None
    area = 0.5 * np.sum(Q[:, 0] * np.roll(Q[:, 1], -1) - np.roll(Q[:, 0], -1) * Q[:, 1])
    if area <= 1.0:
        return None
    out = []
    for i in range(k):
        n_prev, n_cur = -linhas[i - 1][2], -linhas[i][2]      # normais para fora
        a0, a1 = np.arctan2(n_prev[1], n_prev[0]), np.arctan2(n_cur[1], n_cur[0])
        da = (a1 - a0) % (2 * np.pi)
        for aa in a0 + da * np.linspace(0, 1, n_arco):
            out.append(Q[i] + r * np.array([np.cos(aa), np.sin(aa)]))
        # aresta reta até ao canto seguinte, amostrada (o eixo é curvo)
        p_ini = Q[i] + r * n_cur
        p_fim = Q[(i + 1) % k] + r * n_cur
        m = max(int(np.linalg.norm(p_fim - p_ini) / passo), 1)
        for f in np.linspace(0, 1, m + 1)[1:-1]:
            out.append(p_ini + f * (p_fim - p_ini))
    return np.array(out)


def _janelas_trelica(gn, t, sa, sb, mapa, d):
    wc, wd, n = float(gn['banzo']), float(gn['diagonal']), int(gn['paineis'])
    mont = float(gn.get('montantes', 0)) >= 0.5
    h = t - 2 * wc
    if h < 2 * R_JANELA + 4:
        d['avisos'].append('treliça sem altura para janelas')
        return []
    p = (sb - sa) / n
    S = [sa + j * p for j in range(n + 1)]
    lado = [(-1) ** j * h / 2 for j in range(n + 1)]       # nó j no banzo de baixo (j par) / cima
    tri = []
    if mont:
        for j in range(n):
            a, b = (S[j], lado[j]), (S[j + 1], lado[j + 1])
            ow0 = wd if j == 0 else wd / 2
            ow1 = wd if j == n - 1 else wd / 2
            # triângulo A: montante j, banzo do lado do nó j+1, diagonal
            tri.append(([a, (S[j], lado[j + 1]), b], [ow0, 0.0, wd / 2]))
            # triângulo B: diagonal, banzo do lado do nó j, montante j+1
            tri.append(([a, b, (S[j + 1], lado[j])], [wd / 2, ow1, 0.0]))
    else:
        for j in range(n + 1):
            if j == 0:
                pts = [(S[0], lado[0]), (S[0], -lado[0]), (S[1], -lado[0])]
                offs = [wd, 0.0, wd / 2]
            elif j == n:
                pts = [(S[n - 1], -lado[n]), (S[n], -lado[n]), (S[n], lado[n])]
                offs = [0.0, wd, wd / 2]
            else:
                pts = [(S[j - 1], -lado[j]), (S[j], lado[j]), (S[j + 1], -lado[j])]
                offs = [wd / 2, wd / 2, 0.0]
            tri.append((pts, offs))
    out = []
    for pts, offs in tri:
        Q = _inset_arredondado(pts, offs, R_JANELA)
        if Q is None:
            d['avisos'].append('janela demasiado pequena: fica maciça')
            continue
        uv = mapa(Q[:, 0], Q[:, 1])
        if (dist_verdes(uv[:, 0], uv[:, 1]) < MARGEM).any():
            d['avisos'].append('janela junto à zona verde: fica maciça')
            continue
        out.append(uv)
    return out


def _rebaixos_isogrid(gn, t, sa, sb, mapa, d):
    tf, tw, wr, n = float(gn['banzo']), float(gn['alma']), float(gn['nervura']), int(gn['paineis'])
    hw = t - 2 * tf
    if hw < 2 * R_JANELA + 4:
        d['avisos'].append('perfil I sem altura para rebaixos')
        return []
    p = (sb - sa) / n
    out = []
    for j in range(n):
        s0, s1 = sa + j * p, sa + (j + 1) * p
        pts = [(s0, -hw / 2), (s1, -hw / 2), (s1, hw / 2), (s0, hw / 2)]
        offs = [0.0, wr if j == n - 1 else wr / 2, 0.0, wr if j == 0 else wr / 2]
        Q = _inset_arredondado(pts, offs, R_JANELA)
        if Q is None:
            d['avisos'].append('rebaixo demasiado pequeno')
            continue
        uv = mapa(Q[:, 0], Q[:, 1])
        if (dist_verdes(uv[:, 0], uv[:, 1]) < MARGEM).any():
            d['avisos'].append('rebaixo junto à zona verde: fica maciço')
            continue
        out.append(uv)
    d['alma'] = tw
    return out


# ------------------------------------------------------------------------------
# massa 3D PREVISTA (sem Rhino): rasterização do braço no plano u-w x profundidade
# (validada com o Rhino a 01/11: treliça/nervuras com erro < 0,5 %)
# ------------------------------------------------------------------------------
def volume_previsto(planeta, vid, h=1.0, d=None):
    """Volume [mm3] do braço 3D tal como o rhino_meio o constrói (corte pelas zonas verdes,
    cavidade/janelas/rebaixos da descrição). Devolve (volume, volume_maciço)."""
    from matplotlib.path import Path
    from scipy.spatial import cKDTree
    d = d or descrever(planeta, vid)
    e, Xp, Tp, s, na = _eixo_prolongado(d['genes'])
    sd = np.linspace(0, s[-1], 3000)
    X = np.c_[np.interp(sd, s, Xp[:, 0]), np.interp(sd, s, Xp[:, 1])]
    T = np.gradient(X, axis=0); T /= np.linalg.norm(T, axis=1)[:, None]
    N = np.c_[-T[:, 1], T[:, 0]]
    sec = d['secoes']
    sc_s = np.array([s[np.argmin(np.linalg.norm(Xp - S['c'], axis=1))] for S in sec])
    sc_b = np.array([S['b'] for S in sec])
    t = d['t']
    lo = X.min(0) - t; hi = X.max(0) + t                 # só a caixa do braço
    u = np.arange(max(lo[0], -340), min(hi[0], X_S + h), h); w = np.arange(lo[1], hi[1], h)
    U, W = np.meshgrid(u, w); P = np.c_[U.ravel(), W.ravel()]
    _, ii = cKDTree(X).query(P)
    rel = P - X[ii]; n = np.sum(rel * N[ii], 1); tg = np.sum(rel * T[ii], 1)
    dentro = (np.abs(n) <= t / 2) & (np.abs(tg) <= h)
    dentro &= ~((ii == 0) & (tg < 0)) & ~((ii == len(X) - 1) & (tg > 0))
    dentro &= ~(P[:, 0] >= X_S) & ~((P[:, 0] < U_B) & (P[:, 1] > W_B))
    P, n, ii = P[dentro], n[dentro], ii[dentro]
    b = np.interp(sd[ii], sc_s, sc_b)
    dep = b.copy()
    V_mac = dep.sum() * h * h
    if d['familia'] == 'fechada':
        ee = float(d['genes_novos']['parede'])
        for cav in d['cavidades']:
            s0 = sc_s[[np.allclose(S['c'], cav[0]['c']) for S in sec].index(True)] - 3.0
            s1 = sc_s[[np.allclose(S['c'], cav[-1]['c']) for S in sec].index(True)] + 3.0
            m = (np.abs(n) <= t / 2 - ee) & (sd[ii] >= s0) & (sd[ii] <= s1)
            dep = np.where(m, dep - np.maximum(b - 2 * ee, 0), dep)
    elif d['familia'] == 'trelica':
        for J in d['janelas']:
            dep = np.where(Path(J).contains_points(P), 0.0, dep)
    else:
        for J in d['rebaixos']:
            dep = np.where(Path(J).contains_points(P), np.minimum(dep, d['alma']), dep)
    return float(dep.sum() * h * h), float(V_mac)


def massa_prevista(planeta, vid):
    d = descrever(planeta, vid)
    V, Vm = volume_previsto(planeta, vid, d=d)
    rho = material(planeta, d['material'])['rho'] * 1e-9
    return dict(id=vid, material=d['material'], massa_2d=d['massa_2d'], massa_braco_2d=d['massa_braco_2d'],
                massa_braco_3d_prevista=V * rho, massa_braco_macica=Vm * rho,
                massa_3d_prevista=(V + V_VERDE) * rho, FS_2d=d['FS_2d'])


# ------------------------------------------------------------------------------
# teste fora do Rhino: volume aproximado do braço (área no plano x prof) vs 2D
# ------------------------------------------------------------------------------
def figura_teste(caminho, planetas=None):
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    planetas = planetas or PLANETAS
    fig, axs = plt.subplots(2, 4, figsize=(18, 9)); axs = axs.ravel()
    for ax, p in zip(axs, planetas):
        vid = candidatos(p, 1)[0]
        d = descrever(p, vid)
        for k_ in ('verde_cubo', 'verde_bossa'):
            ax.fill(*np.array(G[k_]).T, color='limegreen', ec='darkgreen', alpha=.5)
        ax.axvline(X_S, color='r', lw=.8); ax.plot([-320, U_B, U_B], [W_B, W_B, 240], 'r', lw=.8)
        cs = np.array([S['c'] + S['t'] / 2 * S['n'] for S in d['secoes']])
        ci = np.array([S['c'] - S['t'] / 2 * S['n'] for S in d['secoes']])
        ax.fill(*np.r_[cs, ci[::-1]].T, color='#2E86C1', alpha=.35, ec='k')
        for cav in d['cavidades']:
            ax.plot(*np.array([c['c'] for c in cav]).T, 'w-', lw=2)
        for J in d['janelas'] + d['rebaixos']:
            ax.fill(*J.T, color='white', ec='k', lw=.6)
        ax.set_title('{} {} ({})\n{} janelas/rebaixos{}'.format(
            p, vid, NOME_FAM[d['familia']], len(d['janelas']) + len(d['rebaixos']),
            ' | ' + '; '.join(sorted(set(d['avisos']))) if d['avisos'] else ''), fontsize=8)
        ax.set_aspect('equal'); ax.set_xlim(-330, -60); ax.set_ylim(-80, 240); ax.grid(alpha=.3)
    axs[-1].axis('off')
    fig.tight_layout(); fig.savefig(caminho, dpi=100); plt.close(fig)


if __name__ == '__main__':
    for p in PLANETAS:
        cs_ = lista_casos(p)
        ids = candidatos(p, 10)
        av = []
        for vid in ids:
            d = descrever(p, vid)
            av.append((vid, len(d['janelas']) + len(d['rebaixos']) + len(d['cavidades']), sorted(set(d['avisos']))))
        print('{:9s} {} casos 3D (de {}): {}'.format(p, len(cs_), len(gm.casos(p)), [c[0] for c in cs_]))
        for a in av:
            print('    ', a)
    figura_teste(os.path.join(AQUI, 'diag', 'teste_3d_meio.png'))
    print('[OK] diag/teste_3d_meio.png')
