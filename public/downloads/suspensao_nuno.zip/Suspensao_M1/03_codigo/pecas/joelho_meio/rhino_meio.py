# r: numpy, scipy, matplotlib
"""
==============================================================================
 JOELHO DO MEIO - CONSTRUÇÃO 3D NO RHINO (RhinoCommon) + MONTAGEM
==============================================================================
A geometria vem de peca_meio.descrever() (listas de pontos globais); aqui só
se fazem os sólidos:
  1. loft das secções (retângulo de cantos arredondados t x b) ao longo do eixo
     prolongado -> CapPlanarHoles
  2. família: tubo   -> cavidade (loft interior com pontas em ogiva) + respiro Ø3
              treliça -> janelas passantes (extrusão na profundidade)
              nervuras -> rebaixos dos dois lados até à alma
  3. corte pelas zonas verdes: cubo (u >= x_s) e bossa (u < -215 e w > 95)
     -> face de CARGA (plano u = x_s) e face FIXA (planos u = -215 / w = 95)

construir(planeta, vid)  -> dict(peca, face_fixa, face_carga, centro_carga, desc, volume)
montar(planeta)          -> copia a suspensão do STEP com o joelho do meio trocado
                            pelas 2 melhores (diag/intact/<planeta>_top3.csv) e exporta STEP

Coordenadas = as do STEP (o Rhino tem o STEP importado tal como está).
==============================================================================
"""
import os
import sys
import csv

AQUI = r"C:\Mestrado\designD\m1\pecas\joelho_meio"
NUCLEO = r"C:\Mestrado\designD\m1\pecas\nucleo"
STEP = r"C:\Mestrado\designD\m1\joelho_traseiro_STEP\step\suspensao_v1.step"
for _p in (AQUI, NUCLEO):
    if _p not in sys.path:
        sys.path.insert(0, _p)
import numpy as np
import Rhino
import Rhino.Geometry as rg
import scriptcontext as sc
import peca_meio as pm

FOLGA_MM = 600.0
_ULTIMO_LOG = []


def _log(*a):
    _ULTIMO_LOG.append(" ".join(str(x) for x in a))


def _lista(tipo, itens):
    from System.Collections.Generic import List
    l = List[tipo]()
    for i in itens:
        l.Add(i)
    return l


def _pt(P):
    return rg.Point3d(float(P[0]), float(P[1]), float(P[2]))


def _vec(V):
    return rg.Vector3d(float(V[0]), float(V[1]), float(V[2]))


def _seccao(S, v0=None):
    """Retângulo t (direção normal no plano) x b (direção v) com cantos de raio R.
    Começa sempre a meio do lado +n e roda no mesmo sentido (loft limpo)."""
    import math
    t, b = S['t'], S['b']
    r = max(min(S['R'], 0.49 * t, 0.49 * b), 0.3)
    O = _pt(pm.p3(S['c'][0], S['c'][1], pm.V_MEIO if v0 is None else v0))
    N = _vec(S['n'][0] * pm.U3 + S['n'][1] * pm.W3)
    Z = _vec(pm.V3)

    def P(u, v):
        return O + N * u + Z * v

    a, h = t / 2.0, b / 2.0
    k = 1 - math.cos(math.pi / 4)
    pc = rg.PolyCurve()
    pc.Append(rg.Line(P(a, 0), P(a, h - r)))
    pc.Append(rg.Arc(P(a, h - r), P(a - r * k, h - r * k), P(a - r, h)))
    pc.Append(rg.Line(P(a - r, h), P(-a + r, h)))
    pc.Append(rg.Arc(P(-a + r, h), P(-a + r * k, h - r * k), P(-a, h - r)))
    pc.Append(rg.Line(P(-a, h - r), P(-a, -h + r)))
    pc.Append(rg.Arc(P(-a, -h + r), P(-a + r * k, -h + r * k), P(-a + r, -h)))
    pc.Append(rg.Line(P(-a + r, -h), P(a - r, -h)))
    pc.Append(rg.Arc(P(a - r, -h), P(a - r * k, -h + r * k), P(a, -h + r)))
    pc.Append(rg.Line(P(a, -h + r), P(a, 0)))
    return pc.ToNurbsCurve()


def _loft(curvas, p0=None, p1=None):
    ini = p0 if p0 is not None else rg.Point3d.Unset
    fim = p1 if p1 is not None else rg.Point3d.Unset
    r = rg.Brep.CreateFromLoft(_lista(rg.Curve, curvas), ini, fim, rg.LoftType.Normal, False)
    return r[0] if r else None


def _solido(b, tol):
    if b is None:
        return None
    if not b.IsSolid:
        c = b.CapPlanarHoles(tol)
        b = c if c is not None else b
    if b.IsSolid and b.SolidOrientation == rg.BrepSolidOrientation.Inward:
        b.Flip()
    return b if b.IsSolid else None


def _extrusao(uv, v0, v1, tol):
    """Polígono (u, w) fechado -> prisma na direção v, de v0 a v1."""
    pts = [_pt(p) for p in pm.p3(uv[:, 0], uv[:, 1], v0)]
    pts.append(pts[0])
    crv = rg.PolylineCurve(_lista(rg.Point3d, pts))
    srf = rg.Surface.CreateExtrusion(crv, _vec(pm.V3 * (v1 - v0)))
    if srf is None:
        return None
    return _solido(srf.ToBrep(), tol)


def _diferenca(corpo, ferramentas, tol, nome):
    ferramentas = [f for f in ferramentas if f is not None]
    if not ferramentas:
        return corpo, False
    V0 = corpo.GetVolume()
    r = rg.Brep.CreateBooleanDifference(_lista(rg.Brep, [corpo]), _lista(rg.Brep, ferramentas), tol)
    if r:
        novo = max(r, key=lambda x: x.GetVolume())
        if novo.IsSolid and novo.GetVolume() < V0 - 1.0:
            return novo, True
    _log("AVISO: {} falhou (Boolean)".format(nome))
    return corpo, False


def _respiro(cav):
    """Cilindro Ø3 que liga o meio da cavidade ao exterior (parede +v)."""
    m = cav[len(cav) // 2]
    base = _pt(pm.p3(m['c'][0], m['c'][1]))
    return rg.Cylinder(rg.Circle(rg.Plane(base, _vec(pm.V3)), 1.5), m['b'] / 2 + 5).ToBrep(True, True)


def _cavidade_tol(corpo, cav, tol):
    """Tenta várias construções da cavidade (a 1.ª que funcionar fica).
    A: loft com pontas em ogiva + respiro unidos -> 1 diferença
    B: loft com pontas em ogiva -> diferença; depois respiro -> diferença
    C: loft com tampas PLANAS (pontas reduzidas a 50 %) -> diferença; depois respiro
    Devolve (corpo, 'A'|'B'|'C'|'FALHOU ...', ogiva, plano)."""
    cin = [_seccao(S) for S in cav]
    a, z = cav[0], cav[-1]
    p0 = _pt(pm.p3(*(a['c'] - 8.0 * a['tg'])))
    p1 = _pt(pm.p3(*(z['c'] + 8.0 * z['tg'])))
    cil = _respiro(cav)
    diag = []
    ogiva = _solido(_loft(cin, p0, p1), tol)
    diag.append("ogiva " + ("sólida" if ogiva is not None else "não fechou"))
    if ogiva is not None:
        u = rg.Brep.CreateBooleanUnion(_lista(rg.Brep, [ogiva, cil]), tol)
        if u and len(u) == 1 and u[0].IsSolid:
            novo, ok = _diferenca(corpo, [u[0]], tol, "cavidade A")
            if ok:
                return novo, "A", ogiva, None
        diag.append("A falhou")
        novo, ok = _diferenca(corpo, [ogiva], tol, "cavidade B")
        if ok:
            novo2, ok2 = _diferenca(novo, [cil], tol, "respiro B")
            return ((novo2, "B") if ok2 else (novo, "B sem respiro")) + (ogiva, None)
        diag.append("B falhou")
    # C: tampas planas, pontas reduzidas (sem pontos singulares)
    def reduz(S, f):
        S2 = dict(S); S2['t'] = S['t'] * f; S2['b'] = S['b'] * f; S2['R'] = max(S['R'] * f, 0.3)
        return S2
    cav_c = [reduz(cav[0], 0.5)] + list(cav[1:-1]) + [reduz(cav[-1], 0.5)]
    plano = _solido(_loft([_seccao(S) for S in cav_c]), tol)
    diag.append("tampas planas " + ("sólida" if plano is not None else "não fechou"))
    if plano is not None:
        novo, ok = _diferenca(corpo, [plano], tol, "cavidade C")
        if ok:
            novo2, ok2 = _diferenca(novo, [cil], tol, "respiro C")
            return ((novo2, "C") if ok2 else (novo, "C sem respiro")) + (ogiva, plano)
        diag.append("C falhou")
    return corpo, "FALHOU (" + "; ".join(diag) + ")", ogiva, plano


def _dentro(corpo, ferr, tol, n_max=400):
    """True se a ferramenta está TODA dentro do corpo, sem tocar na pele (amostra dos vértices da malha)."""
    ms = rg.Mesh.CreateFromBrep(ferr, rg.MeshingParameters.Coarse) or []
    pts = [v for m in ms for v in m.Vertices]
    if not pts:
        return False
    passo = max(1, len(pts) // n_max)
    for v in pts[::passo]:
        p = rg.Point3d(v.X, v.Y, v.Z)
        if not corpo.IsPointInside(p, tol, True):
            return False
        if corpo.ClosestPoint(p).DistanceTo(p) < 0.5:          # parede < 0,5 mm: não é de confiança
            return False
    return True


def _vazio_por_casca(corpo, ferr, tol):
    """D (02/11): sem booleana. A cavidade fechada entra como casca interior (normais para dentro)
    do mesmo Brep -> sólido com vazio interior (é o que a booleana daria). Só se estiver toda dentro."""
    if ferr is None or not _dentro(corpo, ferr, tol):
        return corpo, False
    V0 = corpo.GetVolume()
    Vc = abs(ferr.GetVolume())
    c = ferr.DuplicateBrep()
    if c.SolidOrientation == rg.BrepSolidOrientation.Outward:
        c.Flip()
    novo = corpo.DuplicateBrep()
    novo.Append(c)
    if novo.IsValid and novo.IsSolid and abs(novo.GetVolume() - (V0 - Vc)) < 0.01 * V0:
        return novo, True
    return corpo, False


def _cavidade(corpo, cav, tol):
    """02/11: A/B/C com a tolerância do documento e depois com 0,01 e 0,05 mm (as booleanas de lofts
    curvos falham muito a 0,001 mm); se tudo falhar, D = vazio interior sem booleana (sem respiro)."""
    diag, og, pl = [], None, None
    for t in (tol, 0.01, 0.05):
        if diag and t <= tol:
            continue
        novo, como, og_, pl_ = _cavidade_tol(corpo, cav, t)
        og, pl = og or og_, pl or pl_
        if not como.startswith("FALHOU"):
            return novo, como + ("" if t == tol else " (tol {} mm)".format(t))
        diag.append("tol {}: {}".format(t, como))
    for nome, ferr in (("ogiva", og), ("tampas planas", pl)):
        novo, ok = _vazio_por_casca(corpo, ferr, tol)
        if ok:
            _log("cavidade D ({}): vazio interior sem booleana, sem respiro".format(nome))
            return novo, "D ({}, sem respiro)".format(nome)
    return corpo, "FALHOU (" + " | ".join(diag) + "; D: cavidade não está toda dentro)"


def caixas_verdes():
    """Caixas do cubo (u >= x_s) e da bossa (u < -215, w > 95), no referencial do STEP."""
    pl_c = rg.Plane(_pt(pm.p3(pm.X_S, 0.0, 0.0)), _vec(pm.U3), _vec(pm.W3))
    cubo = rg.Box(pl_c, rg.Interval(0.0, 2000.0), rg.Interval(-2000.0, 2000.0),
                  rg.Interval(-2000.0, 2000.0)).ToBrep()
    pl_b = rg.Plane(_pt(pm.p3(pm.U_B, pm.W_B, 0.0)), _vec(pm.U3), _vec(pm.W3))
    bossa = rg.Box(pl_b, rg.Interval(-2000.0, 0.0), rg.Interval(0.0, 2000.0),
                   rg.Interval(-2000.0, 2000.0)).ToBrep()
    return cubo, bossa


def construir(planeta, vid, tol=0.01):
    del _ULTIMO_LOG[:]
    d = pm.descrever(planeta, vid)
    # 1. corpo exterior
    ext = [_seccao(S) for S in d['secoes']]
    corpo = _solido(_loft(ext), tol)
    if corpo is None:
        raise Exception("{}: o loft exterior não fechou".format(vid))
    estado = []
    # 2. família
    if d['familia'] == 'fechada':
        # 02/11: cortar pelas zonas verdes PRIMEIRO -> a booleana do corte não deita fora o vazio
        cubo, bossa = caixas_verdes()
        corpo, ok = _diferenca(corpo, [cubo, bossa], tol, "corte pelas zonas verdes")
        if not ok:
            raise Exception("{}: o corte pelas zonas verdes falhou".format(vid))
        V_cheio = corpo.GetVolume()
        ok_total = bool(d['cavidades'])
        for cav in d['cavidades']:
            corpo, como = _cavidade(corpo, cav, tol)
            _log("cavidade: " + como)
            ok_total = ok_total and not como.startswith("FALHOU")
        V_oco = corpo.GetVolume()
        if ok_total and V_oco > V_cheio - 1.0:
            ok_total = False
            _log("AVISO: cavidade feita mas o volume não baixou")
        estado.append("oca ({:.0f} % do maciço)".format(100.0 * V_oco / V_cheio) if ok_total else "MACIÇA")
    elif d['familia'] == 'trelica':
        H = d['b_max'] / 2 + 5
        ferr = [_extrusao(J, pm.V_MEIO - H, pm.V_MEIO + H, tol) for J in d['janelas']]
        corpo, ok = _diferenca(corpo, ferr, tol, "janelas")
        estado.append("{} janelas".format(len(d['janelas']) if ok else 0))
    else:
        H = d['b_max'] / 2 + 5
        a = d.get('alma', 10.0) / 2
        ferr = []
        for J in d['rebaixos']:
            ferr.append(_extrusao(J, pm.V_MEIO + a, pm.V_MEIO + H, tol))
            ferr.append(_extrusao(J, pm.V_MEIO - H, pm.V_MEIO - a, tol))
        corpo, ok = _diferenca(corpo, ferr, tol, "rebaixos")
        estado.append("{} rebaixos x 2 lados".format(len(d['rebaixos']) if ok else 0))
    # 3. corte pelas zonas verdes (tubo: já foi feito ANTES da cavidade)
    if d['familia'] != 'fechada':
        cubo, bossa = caixas_verdes()
        corpo, ok = _diferenca(corpo, [cubo, bossa], tol, "corte pelas zonas verdes")
        if not ok:
            raise Exception("{}: o corte pelas zonas verdes falhou".format(vid))
    # 4. faces de ligação
    fixa, carga = [], []
    for fc in corpo.Faces:
        if not fc.IsPlanar(0.1):
            continue
        fb = fc.DuplicateFace(False)
        amp = rg.AreaMassProperties.Compute(fb)
        if amp is None:
            continue
        c = pm.local(np.array([amp.Centroid.X, amp.Centroid.Y, amp.Centroid.Z]))
        if abs(c[0] - pm.X_S) < 0.5:
            carga.append((amp.Area, fb, amp.Centroid))
        elif (abs(c[0] - pm.U_B) < 0.5 and c[1] > pm.W_B - 0.5) or (abs(c[1] - pm.W_B) < 0.5 and c[0] < pm.U_B + 0.5):
            fixa.append((amp.Area, fb, amp.Centroid))
    if not carga or not fixa:
        raise Exception("{}: não encontrei as faces de ligação (fixa {}, carga {})".format(vid, len(fixa), len(carga)))

    def junta(lst):
        b = lst[0][1].DuplicateBrep()
        for _, f, _ in lst[1:]:
            b.Append(f)
        return b
    # centro da carga = centroide (ponderado por área) das faces no plano do cubo
    A = sum(x[0] for x in carga)
    cc = np.sum([x[0] * np.array([x[2].X, x[2].Y, x[2].Z]) for x in carga], axis=0) / A
    if corpo.SolidOrientation == rg.BrepSolidOrientation.Inward:
        corpo.Flip()
    return dict(peca=corpo, face_fixa=junta(fixa), face_carga=junta(carga), centro_carga=cc,
                desc=d, volume=corpo.GetVolume(), estado="; ".join(estado),
                n_faces=(len(fixa), len(carga)), log=list(_ULTIMO_LOG))


# ==============================================================================
# MONTAGEM NA SUSPENSÃO (cópia ao lado da original) + STEP
# ==============================================================================
def _brep(g, xf):
    b = None
    if isinstance(g, rg.Brep):
        b = g.DuplicateBrep()
    elif isinstance(g, rg.Extrusion):
        b = g.ToBrep()
    elif isinstance(g, rg.Mesh):
        b = g.DuplicateMesh()
    if b is not None:
        b.Transform(xf)
    return b


def pecas_da_suspensao(nome):
    """Todas as peças do STEP (transformação global), marcando as que têm 'nome'."""
    nome = nome.lower()
    out = []

    def descer(idef, xf, alvo):
        for o in idef.GetObjects():
            g = o.Geometry
            j = alvo or nome in (o.Attributes.Name or "").lower()
            if isinstance(g, rg.InstanceReferenceGeometry):
                sub = sc.doc.InstanceDefinitions.FindId(g.ParentIdefId)
                descer(sub, xf * g.Xform, j or nome in (sub.Name or "").lower())
            else:
                b = _brep(g, xf)
                if b is not None:
                    out.append((j, b))

    cfg = Rhino.DocObjects.ObjectEnumeratorSettings()
    cfg.HiddenObjects = True
    cfg.LockedObjects = True
    for o in sc.doc.Objects.GetObjectList(cfg):
        if o.IsDeleted:
            continue
        lay = sc.doc.Layers[o.Attributes.LayerIndex].FullPath
        if lay.startswith(("Joelho_completo", "Montagem", "Intact", "Teste_")):
            continue
        g = o.Geometry
        j = nome in (o.Attributes.Name or "").lower()
        if isinstance(g, rg.InstanceReferenceGeometry):
            idef = sc.doc.InstanceDefinitions.FindId(g.ParentIdefId)
            descer(idef, g.Xform, j or nome in (idef.Name or "").lower())
        else:
            b = _brep(g, rg.Transform.Identity)
            if b is not None:
                out.append((j, b))
    return out


def _camada(nome, cor):
    import rhinoscriptsyntax as rs
    if not rs.IsLayer(nome):
        rs.AddLayer(nome, cor)
    return sc.doc.Layers.FindByFullPath(nome, -1)


def zonas_verdes_step(joelhos, tol):
    cubo, bossa = caixas_verdes()
    verdes = []
    for b in joelhos:
        if isinstance(b, rg.Brep):
            for cx in (cubo, bossa):
                r = rg.Brep.CreateBooleanIntersection(b, cx, tol)
                if r:
                    verdes.extend(list(r))
    return verdes


def montar(planeta, exportar=True):
    import rhinoscriptsyntax as rs
    planeta = pm.nome_planeta(planeta)
    tol = sc.doc.ModelAbsoluteTolerance
    fich = os.path.join(pm.SAIDA, planeta + "_top3.csv")
    if not os.path.exists(fich):
        raise Exception("Falta {}: corre primeiro o maestro para {}".format(fich, planeta))
    top = list(csv.DictReader(open(fich, encoding="utf-8-sig"), delimiter=";"))
    if not top:
        return "nenhuma variante de {} passou em 3D: nada para montar".format(planeta)
    pecas = pecas_da_suspensao(pm.NOME_STEP)
    if not any(j for j, _ in pecas) and os.path.exists(STEP):
        rs.Command('_-Import "{}" _Enter'.format(STEP), echo=False)
        pecas = pecas_da_suspensao(pm.NOME_STEP)
    O = _pt(pm.C0)
    joelhos = [b for j, b in pecas if j and b.GetBoundingBox(True).Center.DistanceTo(O) < 1500]
    resto = [b for j, b in pecas if not (j and b.GetBoundingBox(True).Center.DistanceTo(O) < 1500)]
    if not joelhos:
        raise Exception('Não encontrei "{}" no Rhino: importa o STEP da suspensão.'.format(pm.NOME_STEP))
    verdes = zonas_verdes_step(joelhos, tol)
    if not verdes:
        raise Exception("O corte das zonas verdes do STEP falhou.")
    bb = rg.BoundingBox.Empty
    for _, b in pecas:
        bb.Union(b.GetBoundingBox(True))
    passo_x = bb.Max.X - bb.Min.X + FOLGA_MM
    passo_y = bb.Max.Y - bb.Min.Y + FOLGA_MM
    fila = 1 + pm.PLANETAS.index(planeta)          # uma fila por planeta, afastada das do traseiro
    msgs = []
    rs.EnableRedraw(False)
    try:
        _camada("Montagem_meio", (120, 120, 120))
        _camada("Montagem_meio::" + planeta, (120, 120, 120))
        for lugar, lin in enumerate(top, 1):
            vid = lin["id"]
            var = construir(planeta, vid, tol)["peca"]
            mover = rg.Transform.Translation(rg.Vector3d(passo_x * lugar, -passo_y * fila, 0.0))
            base = "Montagem_meio::{}::{}_{}".format(planeta, lugar, vid)
            lay_s = _camada(base + "::suspensao", (150, 150, 150))
            lay_v = _camada(base + "::joelho_meio_variante", (60, 110, 200))
            lay_g = _camada(base + "::joelho_meio_verde_STEP", (60, 180, 60))
            ids = []

            def junta(geo, lay, nome):
                g = geo.Duplicate()
                g.Transform(mover)
                a = Rhino.DocObjects.ObjectAttributes()
                a.LayerIndex = lay
                a.Name = nome
                ids.append(sc.doc.Objects.AddMesh(g, a) if isinstance(g, rg.Mesh) else sc.doc.Objects.AddBrep(g, a))

            for k, b in enumerate(resto):
                junta(b, lay_s, "suspensao_{}".format(k + 1))
            junta(var, lay_v, "joelho_meio_{}".format(vid))
            for k, b in enumerate(verdes):
                junta(b, lay_g, "joelho_meio_{}_verde{}".format(vid, k + 1))
            rs.AddObjectsToGroup(ids, rs.AddGroup("montagem_meio_{}_{}".format(planeta, vid)))
            txt = "{}. {} ({} kg, FS 3D {})".format(lugar, vid, lin.get("massa_3d"), lin.get("FS_3d"))
            if exportar:
                destino = os.path.join(pm.SAIDA, "{}_{}_suspensao.stp".format(planeta, vid))
                rs.UnselectAllObjects()
                rs.SelectObjects(ids)
                rs.Command('_-Export "{}" _Enter _Enter'.format(destino), echo=False)
                rs.UnselectAllObjects()
                txt += " -> " + os.path.basename(destino)
            msgs.append(txt)
    finally:
        rs.EnableRedraw(True)
    return "{} montagens de {} (joelho do meio): {}".format(len(msgs), planeta, "; ".join(msgs))
