# r: numpy, scipy, matplotlib
"""
GRASSHOPPER -> INTACT.SIMULATION : prepara a verificação 3D de uma variante
(componente "Python 3 Script" do Rhino 8; os blocos do Intact fazem o cálculo)

ENTRADAS (botão direito -> "+"; o nome tem de ser igual):
  planeta   (str)  "Lua", "Mercúrio", "Marte", "Europa", "Titã", "Io", "Vénus"
  variante  (str)  "A" (finalista leve), "B" (finalista rígida) ou um código, ex. "MAR-079"
  caso      (int)  slider 0..N-1: que caso de carga do planeta (ver saída 'casos')

SAÍDAS (ligar aos blocos do Intact):
  peca        -> Component block: Geometry
  face_fixa   -> FixedRestraint block: Geometry        (ligação à direção, em cima)
  face_carga  -> Vector Force block: Geometry  e  Torque block: Geometry   (ligação ao cubo)
  F_dir       -> Vector Force: direção
  F_N         -> Vector Force: magnitude [N]
  M_eixo      -> Torque: eixo (linha pelo centro da face de carga)
  M_Nmm       -> Torque: valor [N·mm]
  E_MPa, nu, rho_tmm3, sy_MPa -> Custom Ductile Material (já corrigido pela temperatura do planeta)

UNIDADES: o Rhino está em mm, por isso o Intact tem de usar o sistema MMS
  (mm, tonelada, s -> força em N, tensão em MPa, densidade em t/mm3, momento em N·mm).
  Em cada bloco do Intact: botão direito -> unidades -> MMS.
  perigo_max  -> o "Danger Level" máximo tem de ficar ABAIXO deste valor (= 1 / FS exigido)
  casos       -> lista com o nome de cada caso de carga
  pontos      -> Solution Sampler: Points (pontos na superfície, longe das ligações e da carga)
  info        -> Panel com o resumo

PORQUÊ FORÇA + MOMENTO NA FACE DO CUBO:
  a carga real atua no contacto roda-solo, fora da peça. O cubo (zona verde) é muito
  rígido, por isso transporta-a para a face de ligação como uma força F (igual) e um
  momento M = (P_contacto - centro_da_face) x F. O bloco Torque do Intact, com o eixo
  na direção de M, aplica exatamente esse momento (forças que crescem linearmente a
  partir do eixo). O caso 'embate' (rocha contra o joelho) é aplicado diretamente na
  face exterior da peça mais próxima do ponto de impacto.
"""
import os
import sys
import csv

PASTA = r"C:\Mestrado\designD\m1\joelho_traseiro_STEP"
os.chdir(PASTA)
if PASTA not in sys.path:
    sys.path.insert(0, PASTA)
import matplotlib
matplotlib.use("Agg")
import numpy as np
import Rhino.Geometry as rg
import scriptcontext as sc

import gerador_variantes as gv
import joelho3d as j3
import familias as fa
import populacoes as po
import rhino_familias as rf

# se os ficheiros da pasta mudaram (correções), volta a carregá-los sem reiniciar o Rhino
import importlib
_versoes = sc.sticky.get("intact_versoes_mod", {})
_mudou = False
for _m in (fa, rf, po, gv, j3):
    try:
        _t = os.path.getmtime(_m.__file__)
    except Exception:
        continue
    if _versoes.get(_m.__name__) not in (None, _t):
        importlib.reload(_m)
        _mudou = True
    _versoes[_m.__name__] = _t
sc.sticky["intact_versoes_mod"] = _versoes
if _mudou:
    gv._NS = None
    sc.sticky["intact_gh"] = {}

gv._init()
TOL = 0.01
G = gv._NS["geometria"]
O, U, W = (np.array(G["referencial"][k], float) for k in ("origem_mm", "u", "w"))
Zw = np.cross(U, W); Zw /= np.linalg.norm(Zw)        # direção da profundidade no mundo
X_S = G["x_fronteira_preservar"]
ZC = j3.B_INTERFACE / 2.0
ANC = gv._NS["ancoras_verdes"]
Y_CORTE = 0.5 * (ANC[2] + ANC[4])                     # separa o braço de cima do de baixo


def mundo_pt(x, y, z):
    P = O + x * U + y * W + (z - ZC) * Zw
    return rg.Point3d(*[float(c) for c in P])


def mundo_vec(v):
    V = v[0] * U + v[1] * W + v[2] * Zw
    return rg.Vector3d(*[float(c) for c in V])


def local(P):
    d = np.array([P.X, P.Y, P.Z]) - O
    return np.array([d @ U, d @ W, d @ Zw + ZC])


R_EMBATE = 15.0          # mm, raio da mancha de contacto rocha-joelho (caso 'embate')


def _mancha_contacto(fc, uv, R):
    """Recorta na face fc uma mancha ~circular de raio R à volta do ponto (u, v).
    Devolve (Brep da mancha, True) ou, se nada resultar, (face inteira, False).
    Método 1: interseção da face com um cilindro de raio R normal à pele (curva exata na face).
    Método 2: círculo no plano tangente puxado para a face (PullToBrepFace)."""
    Pc = fc.PointAt(*uv)
    n = fc.NormalAt(*uv)
    n.Unitize()
    face_b = fc.DuplicateFace(False)
    curvas = []
    try:
        pl = rg.Plane(Pc - n * (3 * R), n)
        cil = rg.Cylinder(rg.Circle(pl, R), 6 * R).ToBrep(True, True)
        ok, cs, _ = rg.Intersect.Intersection.BrepBrep(face_b, cil, TOL)
        if ok and cs:
            jun = rg.Curve.JoinCurves(cs, 0.1) or cs
            curvas = [c for c in jun if c.IsClosed] or list(jun)
    except Exception:
        curvas = []
    if not curvas:
        try:
            circ = rg.Circle(rg.Plane(Pc, n), R).ToNurbsCurve()
            curvas = list(rg.Curve.PullToBrepFace(circ, fc, TOL) or [])
        except Exception:
            curvas = []
    if curvas:
        try:
            # a curva deve ficar só a que rodeia o ponto de impacto (num tubo o cilindro pode
            # cortar também o lado de trás): fica a mais próxima de Pc
            curvas.sort(key=lambda c: c.PointAt(c.ClosestPoint(Pc)[1]).DistanceTo(Pc))
            from System.Collections.Generic import List as _NetList
            for cv in (curvas[:1], curvas):
                lst_ = _NetList[rg.Curve]()
                for c_ in cv:
                    lst_.Add(c_)
                partes = fc.Split(lst_, TOL)
                if partes is None or partes.Faces.Count < 2:
                    continue
                melhor_ = None
                for f2 in partes.Faces:
                    ok2, u2, v2 = f2.ClosestPoint(Pc)
                    if not ok2 or f2.PointAt(u2, v2).DistanceTo(Pc) > 0.2:
                        continue
                    if f2.IsPointOnFace(u2, v2) == rg.PointFaceRelation.Exterior:
                        continue
                    b2 = f2.DuplicateFace(False)
                    a2 = rg.AreaMassProperties.Compute(b2)
                    if a2 is None:
                        continue
                    if melhor_ is None or a2.Area < melhor_[0]:
                        melhor_ = (a2.Area, b2)
                if melhor_ is not None and melhor_[0] < 4.0 * np.pi * R * R:
                    return melhor_[1], True
        except Exception:
            pass
    return face_b, False


def _entrada(nome, defeito):
    v = globals().get(nome, None)
    return defeito if v is None else v


def _nome_planeta(v):
    """Aceita 'marte', 'Marte ', 'Venus', 'Titã\n'... e devolve o nome exato."""
    import unicodedata
    tira = lambda s: unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode().strip().lower()
    for nome in fa.FAMILIA:
        if tira(nome) == tira(v):
            return nome
    raise Exception("Planeta desconhecido: {!r}. Usa um destes: {}".format(v, ", ".join(fa.FAMILIA)))


planeta_ = _nome_planeta(_entrada("planeta", "Marte"))
var_ = (str(_entrada("variante", "A")) or "A").strip().upper()
caso_ = int(_entrada("caso", 0))

# ---- modo automático: o componente gh_maestro.py escolhe a variante e o caso ----
sc.sticky["intact_comp"] = ghenv.Component          # o maestro volta a correr este componente
LOTE = sc.sticky.get("lote_ativo", False) and sc.sticky.get("lote_alvo")
if LOTE:
    planeta_, var_, caso_ = sc.sticky["lote_alvo"]

# ---- variante e geometria (cache) ----
if var_ in ("A", "B"):
    sel = [l for l in csv.DictReader(open("diag/populacoes/finalistas.csv", encoding="utf-8-sig"), delimiter=";")
           if l["planeta"] == planeta_ and l["escolha"].startswith(var_)]
else:
    sel = [l for l in po.ler_populacao(planeta_) if l["id"] == var_]
if not sel:
    raise Exception("Não encontrei a variante {!r} de {!r} em diag/populacoes/finalistas.csv".format(var_, planeta_))
lin = sel[0]
genes = po.genes_de_linha(lin)
fam = fa.FAMILIA[planeta_]
chave = (planeta_, lin["id"], "v2")
cache = sc.sticky.get("intact_gh", {})
if cache.get("chave") != chave:
    rv = po.avaliar(planeta_, genes, contornos=True)
    f = dict(rv["geo"], base=rv["esq"], planeta=planeta_)
    silencio = lambda *_: None
    if fam == "fechada":
        b = rf.fechada(f, O, U, W, ZC, TOL, log=silencio)
    elif fam == "trelica":
        b = rf.trelica(f, O, U, W, ZC, TOL, j3.B_INTERFACE, X_S, log=silencio)
    else:
        b = rf.isogrid(f, O, U, W, ZC, TOL, X_S, log=silencio)
    cache = dict(chave=chave, peca=b, rv=rv)
    sc.sticky["intact_gh"] = cache
peca = cache["peca"]
rv = cache["rv"]

# ---- faces de ligação: planas, em x = x_s (referencial local) ----
face_fixa, face_carga = None, None
cen_fixa, cen_carga = None, None
melhor = {}
for fc in peca.Faces:
    fb = fc.DuplicateFace(False)
    amp = rg.AreaMassProperties.Compute(fb)
    if amp is None:
        continue
    c = local(amp.Centroid)
    if abs(c[0] - X_S) > 0.5 or not fc.IsPlanar(0.1):
        continue
    lado = "cima" if c[1] > Y_CORTE else "baixo"
    if lado not in melhor or amp.Area > melhor[lado][0]:
        melhor[lado] = (amp.Area, fb, c)
if "cima" in melhor:
    _, face_fixa, cen_fixa = melhor["cima"]
if "baixo" in melhor:
    _, face_carga, cen_carga = melhor["baixo"]

# ---- casos de carga do planeta -> força + momento no centro da face do cubo ----
cn = gv.chave_cenario(planeta_)
cen = gv.CENARIOS[cn]
pts = gv.pontos_roda()
lista = []
for nome in cen["casos"]:
    c = gv.CASOS[nome]
    F = np.array([c["F"][0], c["F"][1], 0.0])
    if c["onde"] == "joelho":
        lista.append((nome.split(":")[-1], F, None, "embate"))
    else:
        lista.append((nome.split(":")[-1], F, np.array([pts[c["onde"]][0], pts[c["onde"]][1], ZC]), "cubo"))
if "Fz" in cen:
    lista.append(("subir_rocha", np.array([0.0, 0.0, cen["Fz"]]), np.array([pts["plano"][0], pts["plano"][1], ZC]), "cubo"))
casos = [l[0] for l in lista]
caso_ = max(0, min(caso_, len(lista) - 1))
nome_c, F, P, onde = lista[caso_]
F_N = float(np.linalg.norm(F))
F_dir = mundo_vec(F / max(F_N, 1e-9))
M_eixo, M_Nmm = None, 0.0
embate_mancha, ponto_embate = None, None
if onde == "cubo" and cen_carga is not None:
    M = np.cross(P - cen_carga, F)                         # N·mm, referencial local
    M_Nmm = float(np.linalg.norm(M))
    if M_Nmm > 1e-9:
        m = M / np.linalg.norm(M)
        c0 = cen_carga
        M_eixo = rg.Line(mundo_pt(*(c0 - 20 * m)), mundo_pt(*(c0 + 20 * m)))
elif onde == "embate":
    # rocha contra o joelho. 31/10: no modelo NURBS liso a face mais próxima da rocha é a PELE
    # INTEIRA do tubo -> a carga ficava espalhada pela peça toda e o filtro de pontos tirava-os
    # todos (Sampler sem valores). Agora recorta-se uma mancha de contacto circular (raio
    # R_EMBATE) nessa face, à volta do ponto de impacto, e a carga entra só aí.
    sk = rv["esq"]["sketch"]
    y_rocha = gv._P[1] + gv.H_ROCHA
    perto = np.abs(sk[:, 1] - y_rocha) < 6
    if perto.any():
        Pj = sk[perto][np.argmin(sk[perto][:, 0])]
        alvo = mundo_pt(Pj[0], Pj[1], ZC)
        d_min, fc_min, uv_min = 1e99, None, None
        for fc in peca.Faces:
            ok, u, v = fc.ClosestPoint(alvo)
            if ok:
                d = fc.PointAt(u, v).DistanceTo(alvo)
                if d < d_min:
                    d_min, fc_min, uv_min = d, fc, (u, v)
        if fc_min is not None:
            face_carga, embate_mancha = _mancha_contacto(fc_min, uv_min, R_EMBATE)
            ponto_embate = fc_min.PointAt(*uv_min)

if M_eixo is None:
    # sem momento (caso 'embate'): eixo qualquer (o bloco Torque precisa de um eixo válido).
    # 31/10: com valor 0 o solver do Intact não arrancava (Stress parado em 00:00.0, sempre na
    # simulação do embate). Usa-se 1 N·mm: desprezável face a F ~ 1000 N, mas não é carga nula.
    c0 = cen_carga if cen_carga is not None else np.array([X_S, 0.0, ZC])
    M_eixo = rg.Line(mundo_pt(*c0), mundo_pt(*(c0 + np.array([20.0, 0.0, 0.0]))))
    M_Nmm = 1.0

# ---- pontos de amostragem para o bloco Solution Sampler do Intact ----
#   vértices de uma malha da superfície da peça, puxados 0,5 mm para dentro (a tensão máxima
#   está na superfície), SEM os pontos a menos de AFAST mm das faces de ligação e da face
#   onde entra a carga: aí o modelo dá picos artificiais (encastramento perfeito, carga
#   aplicada de golpe, canto vivo contra a zona verde), que não são tensões reais.
AFAST = 8.0
D_TRANS = fa.L_PONTA + 10.0
if "pontos_zona" not in cache:
    mp = rg.MeshingParameters.QualityRenderMesh
    mp.MaximumEdgeLength = 4.0
    mp.MinimumEdgeLength = 0.5
    malha = rg.Mesh()
    for mm_ in rg.Mesh.CreateFromBrep(peca, mp) or []:
        malha.Append(mm_)
    malha.Normals.ComputeNormals()
    base = []
    for i in range(malha.Vertices.Count):
        v_ = malha.Vertices[i]
        n_ = malha.Normals[i]
        P_ = rg.Point3d(v_.X - 0.5 * n_.X, v_.Y - 0.5 * n_.Y, v_.Z - 0.5 * n_.Z)
        d_ = X_S - local(P_)[0]
        if d_ > AFAST:
            base.append((P_, d_ < D_TRANS))
    cache["pontos_zona"] = base
sel_ = cache["pontos_zona"]
if onde == "embate" and ponto_embate is not None:
    # tira só os pontos junto à mancha de contacto (antes: junto à face inteira -> 0 pontos)
    sel_ = [q for q in sel_ if q[0].DistanceTo(ponto_embate) > R_EMBATE + AFAST]
elif onde == "embate" and face_carga is not None:
    sel_ = [q for q in sel_ if face_carga.ClosestPoint(q[0]).DistanceTo(q[0]) > AFAST]
sc.sticky["intact_ponto_embate"] = ponto_embate
pontos = [q[0] for q in sel_]
# zona de transição (a menos de D_TRANS mm das faces de ligação): a peça passa da secção cheia
# da ligação para a secção da família; os cantos aí ainda não têm boleado no modelo NURBS, por
# isso o pico é avaliado à parte (o critério de aprovação usa o resto da peça)
sc.sticky["intact_zona"] = [q[1] for q in sel_]
sc.sticky["intact_pontos_loc"] = pontos           # para o diagnóstico do maestro (coordenadas)

# ---- material (corrigido pela temperatura do planeta), unidades MMS (mm, t, s) ----
import degradacao as dg
mat = dg.material_gasto(gv.material(cn, genes["material"]), planeta_)   # k_mat da degradação do planeta
E_MPa = float(mat["E"])
nu = 0.33
rho_tmm3 = float(mat["rho"]) * 1e-12            # kg/m3 -> t/mm3
sy_MPa = float(mat["sy"])
perigo_max = round(1.0 / cen["FS"], 4)

info = "{} | {} | {} | {}\n".format(planeta_, lin["id"], fa.NOME_FAMILIA[fam], genes["material"])
info += "massa {:.2f} kg | FS análise 2D {:.2f} | FS exigido {}\n".format(
    float(lin["massa_kg"]), float(lin["FS_min"]), cen["FS"])
info += "caso {} de {}: {} | F = {:.0f} N | M = {:.0f} N·mm\n".format(caso_ + 1, len(lista), nome_c, F_N, M_Nmm)
info += "material: E = {:.1f} GPa, cedência a quente = {:.0f} MPa, rho = {:.0f} kg/m3\n".format(
    mat["E"] / 1e3, mat["sy"], float(mat["rho"]))
info += "PASSA se o Danger Level máximo < {} (excluir os picos colados às faces de ligação)\n".format(perigo_max)
if onde == "embate":
    info += ("embate: carga numa mancha de contacto R = {:.0f} mm\n".format(R_EMBATE) if embate_mancha else
             "AVISO embate: o recorte da mancha falhou, carga na face inteira (resultado conservador/irrealista)\n")
if face_fixa is None or face_carga is None:
    info += "AVISO: não encontrei as faces de ligação (usa o bloco Pick Face do Intact)\n"

# ---- estado para o maestro (que variante/caso acabou de ser preparado) ----
try:
    massa_3d = float(peca.GetVolume()) * float(mat["rho"]) * 1e-9
except Exception:
    massa_3d = float(lin["massa_kg"])
sc.sticky["intact_contador"] = sc.sticky.get("intact_contador", 0) + 1
sc.sticky["intact_estado"] = dict(planeta=planeta_, id=lin["id"], caso=caso_, nome_caso=nome_c,
                                  n_casos=len(lista), massa_3d=massa_3d, massa_2d=float(lin["massa_kg"]),
                                  FS_2d=float(lin["FS_min"]), material=genes["material"],
                                  perigo_max=perigo_max, sy_MPa=sy_MPa, n_pontos=len(pontos),
                                  embate_mancha=embate_mancha,
                                  contador=sc.sticky["intact_contador"])
if LOTE:
    info = "[AUTOMÁTICO] " + info
