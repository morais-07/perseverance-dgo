"""
==============================================================================
 FAMÍLIAS ESTRUTURAIS POR PLANETA  (gramática de forma: o ambiente escolhe a topologia)
==============================================================================
O planeta deixa de mudar só a espessura e passa a escolher o TIPO de estrutura:

  FECHADA  (Lua, Mercúrio, Marte) - tubo oco de cantos arredondados
      regra: pó/regolito entra em rebaixos abertos e prende juntas -> secção
      fechada, lisa por fora; a secção fechada é muito rígida à torção (Bredt).
      (cavidade com furo de respiro: no vácuo o ar preso do lançamento tem de sair)

  TRELIÇA  (Europa, Titã, Io) - banzos de borda + diagonais, janelas passantes
      regra: gelo acumula-se em superfícies planas e em cavidades -> estrutura
      aberta que o deixa cair; cargas baixas (g baixa) -> barras finas.
      diagonais verificadas à tração/compressão E à encurvadura (Euler).

  NERVURAS TRIANGULARES (Vénus) - alma grossa + nervuras em ziguezague em rebaixos abertos
      regra: 92 bar esmagam cavidades fechadas -> só rebaixos abertos;
      fluência a 465 °C + ácido sulfúrico -> alma >= 6 mm (5 + 1 de corrosão);
      as nervuras triangulares (ideia do isogrid dos tanques de foguetões) rigidificam a
      alma e dividem os rebaixos em células pequenas e abertas (drenam).

Cada secção é dimensionada com as MESMAS cargas e FS do planeta (joelho3d.envolvente).
O módulo é numpy puro: o Rhino só constrói a geometria (rhino_familias.py).
==============================================================================
"""
import numpy as np
from matplotlib.path import Path
from scipy.ndimage import binary_opening, label, distance_transform_edt

import gerador_variantes as gv
import joelho3d as j3
import joelho3d_I as jI
import nurbs_dados as nd

FAMILIA = {'Lua': 'fechada', 'Mercúrio': 'fechada', 'Marte': 'fechada',
           'Europa': 'trelica', 'Titã': 'trelica', 'Io': 'trelica',
           'Vénus': 'isogrid'}
NOME_FAMILIA = {'fechada': 'Secção fechada (tubo oco)', 'trelica': 'Treliça aberta',
                'isogrid': 'Nervuras triangulares'}

L_PONTA = 30.0          # mm, junto às faces verdes a secção fica cheia (transição)
R_FRAC = 0.30           # raio dos cantos do tubo = R_FRAC * min(t, b)
CAV_MIN = 6.0           # mm, cavidade mínima (abaixo disto a secção fica cheia)
PAREDE_MIN = {'CNC': 3.0, 'L-PBF': 1.5}     # parede do tubo (CNC = 2 metades unidas)
BANZO_MIN = {'CNC': 6.0, 'L-PBF': 4.0}      # banzos da treliça
DIAG_MIN = {'CNC': 5.0, 'L-PBF': 3.0}       # diagonais da treliça
JANELA_MIN = 14.0       # mm, altura livre mínima para abrir janela
R_JANELA = 4.0          # mm, raio dos cantos das janelas / células
ALMA_MIN_VENUS = 6.0    # mm (5 + 1 de margem de corrosão)
ISO_PASSO = 30.0        # mm, distância entre nervuras paralelas do isogrid
ISO_NERVURA = 4.0       # mm, largura das nervuras do isogrid
PIX = 0.5               # mm, resolução das máscaras em planta


# ------------------------------------------------------------------------------
# utilitários
# ------------------------------------------------------------------------------
def planeta_de(cenario):
    k = gv.chave_cenario(cenario)
    return gv.CENARIOS[k].get('planeta')


def _envolvente(s, v):
    return nd._b_envolvente(s, np.asarray(v, float))


def _peso_ponta(s):
    """1 nas pontas (faces verdes) -> 0 a L_PONTA de distância."""
    d = np.minimum(s - s[0], s[-1] - s)
    return np.clip(1.0 - d / L_PONTA, 0.0, 1.0)


def _contornos(mask, x0, y0, pix, area_min=30.0):
    """Polígonos (em mm) das regiões True de uma máscara (contourpy)."""
    from contourpy import contour_generator
    lab, n = label(mask)
    polis = []
    ny, nx = mask.shape
    X = x0 + np.arange(nx) * pix
    Y = y0 + np.arange(ny) * pix
    for i in range(1, n + 1):
        m = (lab == i)
        if m.sum() * pix * pix < area_min:
            continue
        z = np.pad(m.astype(float), 1)
        Xp = np.r_[X[0] - pix, X, X[-1] + pix]
        Yp = np.r_[Y[0] - pix, Y, Y[-1] + pix]
        linhas = contour_generator(Xp, Yp, z).lines(0.5)
        if not linhas:
            continue
        P = max(linhas, key=len)
        if len(P) >= 8:
            polis.append(nd._suavizar_poligono(P, it=2))
    return polis


def _raster_planta(sk, pix=PIX, margem=2.0):
    lo = sk.min(0) - margem
    hi = sk.max(0) + margem
    x = np.arange(lo[0], hi[0], pix)
    y = np.arange(lo[1], hi[1], pix)
    X, Y = np.meshgrid(x, y)
    dentro = Path(sk).contains_points(np.c_[X.ravel(), Y.ravel()]).reshape(X.shape)
    return x, y, X, Y, dentro


def _disco(r_mm, pix=PIX):
    r = int(np.ceil(r_mm / pix))
    yy, xx = np.mgrid[-r:r + 1, -r:r + 1]
    return (xx ** 2 + yy ** 2) <= r * r


# ==============================================================================
# 1. FECHADA: tubo oco de cantos arredondados
# ==============================================================================
def _canto():
    """Constantes do 'canto' removido por um arredondamento de raio 1."""
    n = 1200
    u = (np.arange(n) + 0.5) / n
    X, Y = np.meshgrid(u, u)
    m = (X - 1) ** 2 + (Y - 1) ** 2 > 1
    a = m.mean()
    c = Y[m].mean()
    I = ((Y[m] - c) ** 2).mean() * a
    return a, c, I


_A_C, _C_C, _I_C = _canto()


def _ret_arred(t, b, r):
    """Área e inércias de um retângulo t (em n) x b (em z) com cantos de raio r."""
    r = np.minimum(r, 0.5 * np.minimum(t, b))
    A = b * t - 4 * _A_C * r ** 2
    Iz = b * t ** 3 / 12 - 4 * (_I_C * r ** 4 + _A_C * r ** 2 * (t / 2 - _C_C * r) ** 2)
    In = t * b ** 3 / 12 - 4 * (_I_C * r ** 4 + _A_C * r ** 2 * (b / 2 - _C_C * r) ** 2)
    return A, Iz, In


def caixa_props(t, b, e, r):
    """Tubo: exterior (t, b, r) menos interior (t-2e, b-2e, r-e). e >= min/2 -> cheio."""
    A0, Iz0, In0 = _ret_arred(t, b, r)
    ti, bi = t - 2 * e, b - 2 * e
    oco = (ti >= CAV_MIN) & (bi >= CAV_MIN)
    tiv, biv = np.where(oco, ti, 0.0), np.where(oco, bi, 0.0)
    A1, Iz1, In1 = _ret_arred(tiv, biv, np.maximum(r - e, 0.0))
    A1 = np.where(oco, A1, 0.0); Iz1 = np.where(oco, Iz1, 0.0); In1 = np.where(oco, In1, 0.0)
    return A0 - A1, Iz0 - Iz1, In0 - In1, oco


E_MAT, SY_MAT = None, None      # definidos em _fechada (encurvadura local)

# ------------------------------------------------------------------------------
# CORREÇÃO DE BLEICH: banzos finos em vigas CURVAS
#   A tensão circunferencial puxa o banzo para o centro de curvatura; o banzo
#   (placa fina) dobra-se ("curling"): só uma largura efetiva alfa*b trabalha e
#   aparece uma tensão TRANSVERSAL de flexão gama*sigma na ligação à alma.
#   Parâmetro: q = b^2 / (r t)  (b = meia-largura livre do banzo, r = raio do
#   banzo, t = espessura do banzo). Tabela obtida resolvendo a equação clássica
#   da faixa de placa sobre fundação elástica (Bleich 1933; Timoshenko):
#       phi'''' + 4 phi = 4 , junto à alma phi = phi' = 0
#       I (banzo em consola):           bordo livre phi'' = phi''' = 0
#       CX (tubo: banzo entre 2 paredes): meio do banzo phi' = phi''' = 0
#   (nu = 0.3; os valores de gama coincidem com os tabelados por Bleich/Roark)
# ------------------------------------------------------------------------------
_BQ = np.array([0.0000, 0.0500, 0.1000, 0.2000, 0.3000, 0.4000, 0.5000, 0.6000, 0.8000, 1.0000,
                1.2500, 1.5000, 2.0000, 2.5000, 3.0000, 4.0000, 5.0000, 6.0000, 8.0000])
_ALFA = {'I': np.array([1.0000, 0.9986, 0.9946, 0.9789, 0.9545, 0.9234, 0.8880, 0.8505, 0.7758, 0.7081,
                        0.6378, 0.5826, 0.5058, 0.4564, 0.4218, 0.3742, 0.3406, 0.3141, 0.2744]),
         'CX': np.array([1.0000, 0.9994, 0.9976, 0.9904, 0.9788, 0.9632, 0.9442, 0.9223, 0.8729, 0.8197,
                         0.7537, 0.6926, 0.5912, 0.5167, 0.4624, 0.3913, 0.3471, 0.3164, 0.2745])}
_GAMA = {'I': np.array([0.0000, 0.1497, 0.2977, 0.5817, 0.8408, 1.0673, 1.2576, 1.4120, 1.6251, 1.7413,
                        1.8027, 1.8157, 1.7941, 1.7685, 1.7553, 1.7572, 1.7734, 1.7892, 1.8079]),
         'CX': np.array([0.0000, 0.0999, 0.1994, 0.3951, 0.5837, 0.7622, 0.9282, 1.0802, 1.3387, 1.5370,
                         1.7102, 1.8179, 1.9089, 1.9179, 1.8993, 1.8547, 1.8275, 1.8155, 1.8115])}
_K_BLEICH = np.sqrt(3 * (1 - 0.3 ** 2))


def bleich(q, tipo='CX'):
    """(alfa, gama) para q = b^2/(r t). Acima da tabela: alfa ~ 1/m (assíntota), gama ~ 1.81."""
    q = np.nan_to_num(np.asarray(q, float), nan=0.0, posinf=0.0)
    a = np.interp(q, _BQ, _ALFA[tipo])
    a = np.where(q > _BQ[-1], 1.0 / np.sqrt(np.maximum(q, 1e-9) * _K_BLEICH), a)
    g = np.interp(q, _BQ, _GAMA[tipo])
    return a, g


def _raio(rho):
    r = np.abs(np.asarray(rho, float))
    return np.where(np.isfinite(r) & (r > 0), r, np.inf)


def bleich_tensao(t, b, e_banzo, b_livre, rho, N, M, fc, Iz, A, tipo):
    """Tensão equivalente no banzo de uma viga curva com a correção de Bleich:
    inércia reduzida (largura efetiva) + tensão transversal gama*sigma combinada
    (Von Mises, sinais opostos: fator sqrt(1 + gama + gama^2))."""
    r = _raio(rho)
    q_in = b_livre ** 2 / (np.maximum(r - t / 2 + e_banzo / 2, 1e-6) * e_banzo)
    q_out = b_livre ** 2 / ((r + t / 2 - e_banzo / 2) * e_banzo)
    a_in, g_in = bleich(np.where(np.isfinite(r), q_in, 0.0), tipo)
    a_out, _ = bleich(np.where(np.isfinite(r), q_out, 0.0), tipo)
    braco2 = (t / 2 - e_banzo / 2) ** 2
    largura = 2 * b_livre                         # largura do banzo que pode enrolar
    dI = ((1 - a_in) + (1 - a_out)) * largura * e_banzo * braco2
    Iz_red = np.maximum(Iz - dI, 0.2 * Iz)
    sN = np.abs(N) / A
    sM = fc * np.abs(M) * (t / 2) / Iz_red
    return (sN + sM) * np.sqrt(1 + g_in + g_in ** 2), g_in


def caixa_sigma(t, b, e, r, N, V, M, fc, Mn, T, rho=None):
    """Tensão equivalente máxima (no plano e fora do plano) do tubo.
    rho: raio do eixo (para a correção de Bleich nas curvas)."""
    A, Iz, In, oco = caixa_props(t, b, e, r)
    sN = np.abs(N) / A
    sM = fc * np.abs(M) * (t / 2) / Iz
    Q = b * e * (t / 2 - e / 2) + 2 * e * np.maximum(t / 2 - e, 0) ** 2 / 2
    tauV = np.where(oco, np.abs(V) * Q / (Iz * 2 * e), 1.5 * np.abs(V) / A)
    plano = np.maximum(sN + sM, np.sqrt(sN ** 2 + 3 * tauV ** 2))
    sb = np.abs(Mn) * (b / 2) / In
    Am = (t - e) * (b - e) - (4 - np.pi) * np.maximum(r - e / 2, 0) ** 2
    a_, c_ = np.maximum(t, b), np.minimum(t, b)
    tauT = np.where(oco, np.abs(T) / (2 * np.maximum(Am, 1e-9) * e),
                    np.abs(T) * (3 * a_ + 1.8 * c_) / (a_ ** 2 * c_ ** 2))
    fora = np.sqrt(sb ** 2 + 3 * tauT ** 2)
    # encurvadura local das paredes do tubo (placa simplesmente apoiada, k = 4):
    #   sigma_cr = 3.62 E (e / largura)^2 ; entra como tensão equivalente sigma * sy / sigma_cr
    if E_MAT is not None:
        cr_z = 3.62 * E_MAT * (e / np.maximum(b - e, 1e-6)) ** 2      # paredes de largura b
        cr_n = 3.62 * E_MAT * (e / np.maximum(t - e, 1e-6)) ** 2      # paredes de largura t
        plano = np.where(oco, np.maximum(plano, (sN + sM) * SY_MAT / cr_z), plano)
        fora = np.where(oco, np.maximum(fora, sb * SY_MAT / cr_n), fora)
    # Bleich: as paredes interior/exterior da curva enrolam entre as duas paredes laterais
    if rho is not None:
        b_livre = np.maximum(b / 2 - e, 0.0)
        sb_, _ = bleich_tensao(t, b, e, b_livre, rho, N, M, fc, Iz, A, 'CX')
        plano = np.where(oco, np.maximum(plano, sb_), plano)
    return plano, fora, A, oco


def _fechada(r, cen, mat, proc):
    env = r['env']
    s, t = env['s'], env['t']
    FS, adm = cen['FS'], mat['sy']
    e_min = PAREDE_MIN[proc]
    global E_MAT, SY_MAT
    E_MAT, SY_MAT = mat['E'], mat['sy']
    n = len(s)
    b_out, e_out = np.zeros(n), np.zeros(n)
    fb = np.linspace(0, 1, 28)
    fe = np.linspace(0, 1, 16)
    for k in range(n):
        bmax = max(j3.B_INTERFACE, r['b'][k]) * 1.3
        B = j3.B_MIN + fb * (bmax - j3.B_MIN)
        Bg, Fg = np.meshgrid(B, fe, indexing='ij')
        meia = 0.5 * np.minimum(t[k], Bg)
        E = np.minimum(e_min + Fg * (meia - e_min), meia)
        R = R_FRAC * np.minimum(t[k], Bg)
        smax = np.zeros(Bg.shape)
        for _, N, V, M, fc in env['casos_plano']:
            pl_, fo, A, oco = caixa_sigma(t[k], Bg, E, R, N[k], V[k], M[k], fc[k],
                                           env['Mn'][k], env['T'][k], rho=env['rho'][k])
            smax = np.maximum(smax, np.maximum(pl_, fo))
        A = caixa_props(t[k], Bg, E, R)[0]
        ok = FS * smax <= adm
        if not ok.any():                        # não cumpre nem cheio: fica o mais forte
            i = np.unravel_index(np.argmin(smax), smax.shape)
        else:
            Am = np.where(ok, A, np.inf)
            i = np.unravel_index(np.argmin(Am), Am.shape)
        b_out[k], e_out[k] = Bg[i], E[i]
    # alisar (envolvente superior: nunca menos) + pontas cheias com a profundidade das faces verdes
    b_s = _envolvente(s, b_out)
    e_s = _envolvente(s, e_out)
    w = _peso_ponta(s)
    b_s = w * j3.B_INTERFACE + (1 - w) * b_s
    meia = 0.5 * np.minimum(t, b_s)
    e_s = np.where(w > 0, meia, np.minimum(e_s, meia))
    R = R_FRAC * np.minimum(t, b_s) * (1 - w) + 0.5 * w
    # FS final
    smax = np.zeros(n)
    for _, N, V, M, fc in env['casos_plano']:
        pl_, fo, A, oco = caixa_sigma(t, b_s, e_s, R, N, V, M, fc, env['Mn'], env['T'], rho=env['rho'])
        smax = np.maximum(smax, np.maximum(pl_, fo))
    A, _, _, oco = caixa_props(t, b_s, e_s, R)
    massa = float(np.trapezoid(A, s) if hasattr(np, 'trapezoid') else np.trapz(A, s)) \
        * mat['rho'] * 1e-9
    return dict(familia='fechada', b=b_s, e=e_s, R=R, oco=oco, FS=adm / smax,
                FS_min=float((adm / smax).min()), massa_kg=massa)


def estacoes_fechada(r, f, n_est=48):
    """Secções para o loft no Rhino: centro, normal, t, b, raio, parede, oco.
    As duas pontas ficam EXATAMENTE nas faces verdes (x = x_s)."""
    env = r['env']
    s, S, tg, t = env['s'], env['S'], env['tang'], env['t']
    anc = gv._NS['ancoras_verdes']           # (x_s, y_cima_sup, y_cima_inf, x_s, y_baixo_sup, y_baixo_inf)
    u = np.r_[0, 0.5 * (1 - np.cos(np.linspace(0, np.pi, n_est)))[1:-1], 1] * s[-1]
    est = []
    for k, sv in enumerate(u):
        i = int(np.argmin(np.abs(s - sv)))
        est.append(dict(c=S[i].copy(), tg=tg[i].copy(), t=float(t[i]), b=float(f['b'][i]),
                        R=float(f['R'][i]), e=float(f['e'][i]), oco=bool(f['oco'][i])))
    # pontas exatas nas faces verdes
    xs = anc[0]
    lados = [(anc[1], anc[2]), (anc[4], anc[5])]
    for idx, (ya, yb) in zip((0, -1), lados):
        P = est[idx]
        P['c'] = np.array([xs, 0.5 * (ya + yb)])
        P['tg'] = np.array([1.0, 0.0]) if idx == -1 else np.array([-1.0, 0.0])
        P['t'] = abs(ya - yb); P['b'] = j3.B_INTERFACE; P['R'] = 0.5; P['oco'] = False
    # secções coladas umas às outras (junto às pontas) fazem dobrar o loft: mínimo 4 mm
    filtradas = [est[0]]
    for P in est[1:-1]:
        if np.linalg.norm(P['c'] - filtradas[-1]['c']) >= 4.0 and \
                np.linalg.norm(P['c'] - est[-1]['c']) >= 4.0:
            filtradas.append(P)
    filtradas.append(est[-1])
    est = filtradas
    for P in est:
        P['n'] = np.array([-P['tg'][1], P['tg'][0]])
    _desdobrar(est)
    return est


def _dobras(est):
    """Índices onde o loft dobra sobre si próprio: a aresta de uma secção fica para trás
    da aresta da secção anterior (eixo muito curvo para a largura da secção)."""
    maus = []
    for i in range(len(est) - 1):
        a, b = est[i], est[i + 1]
        avanco = np.linalg.norm(b['c'] - a['c'])
        ref = a['tg'] + b['tg']
        ref = ref / max(np.linalg.norm(ref), 1e-9)
        for lado in (-1.0, 1.0):
            pa = a['c'] + lado * a['n'] * a['t'] / 2
            pb = b['c'] + lado * b['n'] * b['t'] / 2
            if np.dot(pb - pa, ref) <= 0.05 * avanco:
                maus.append(i)
                break
    return maus


def _desdobrar(est, max_it=400):
    """Corrige as dobras do loft (30/10): nas curvas apertadas do eixo, as secções largas
    cruzavam-se do lado interior e o sólido ficava auto-intersectado (o Intact dava aí
    tensões absurdas). Suaviza a direção das secções vizinhas da dobra (as secções ficam
    no mesmo sítio e com a mesma largura, só rodam um pouco) até não haver cruzamentos.
    As pontas (faces verdes) não rodam."""
    ang = np.unwrap(np.array([np.arctan2(P['tg'][1], P['tg'][0]) for P in est]))
    for _ in range(max_it):
        maus = _dobras(est)
        if not maus:
            break
        for i in maus:
            for j in (i - 1, i, i + 1, i + 2):
                if 0 < j < len(est) - 1:
                    ang[j] = (ang[j - 1] + 2 * ang[j] + ang[j + 1]) / 4.0
        for j in range(1, len(est) - 1):
            est[j]['tg'] = np.array([np.cos(ang[j]), np.sin(ang[j])])
            est[j]['n'] = np.array([-est[j]['tg'][1], est[j]['tg'][0]])
    # o que ainda dobrar (junto às pontas, onde a direção está presa): tira-se a secção
    # interior envolvida; o loft passa mais suave entre as vizinhas
    for _ in range(len(est)):
        maus = _dobras(est)
        if not maus or len(est) <= 4:
            break
        i = maus[0]
        k = i + 1 if i + 1 < len(est) - 1 else i
        if k <= 0:
            break
        del est[k]
    return est


# ==============================================================================
# 2. TRELIÇA: banzos de borda + diagonais (Warren), janelas passantes
# ==============================================================================
def _banzos(env, t, b, FS, adm, wc_min):
    """Menor largura de banzo que cumpre em cada secção (vetorizado)."""
    n = len(t)
    F = np.linspace(0, 1, 60)[None, :]
    W = wc_min + F * np.maximum(t[:, None] / 2 - wc_min, 0)
    bb = b[:, None]
    hc = np.maximum(t[:, None] - W, 1e-6)
    smax = np.zeros(W.shape)
    for _, N, V, M, fc in env['casos_plano']:
        sc = np.abs(N)[:, None] / (2 * W * bb) + fc[:, None] * np.abs(M)[:, None] / (hc * W * bb)
        smax = np.maximum(smax, sc)
    sb = 3 * env['Mn'][:, None] / (W * bb ** 2)
    L1, c1 = np.maximum(W, bb), np.minimum(W, bb)
    J = 2 * jI._beta(c1, L1) * L1 * c1 ** 3
    tau = env['T'][:, None] * c1 / J
    smax = np.maximum(smax, np.sqrt(sb ** 2 + 3 * tau ** 2))
    ok = FS * smax <= adm
    i = np.where(ok.any(1), np.argmax(ok, axis=1), W.shape[1] - 1)
    return W[np.arange(n), i], ok.any(1)


def _vaos(s, t, wc, janela):
    n = len(s)
    vaos, i = [], 0
    while i < n:
        if janela[i]:
            j = i
            while j + 1 < n and janela[j + 1]:
                j += 1
            if s[j] - s[i] > 1.5 * np.mean(t[i:j + 1] - wc[i:j + 1]):
                vaos.append((i, j))
            i = j + 1
        else:
            i += 1
    return vaos


def _diagonais(env, t, wc, vaos):
    s, S = env['s'], env['S']
    nrm = np.c_[-env['tang'][:, 1], env['tang'][:, 0]]
    diag, F_d, L_d = [], [], []
    for i0, i1 in vaos:
        hc = np.mean(t[i0:i1 + 1] - wc[i0:i1 + 1])
        npn = max(2, int(round((s[i1] - s[i0]) / (1.0 * hc))))
        sn = np.linspace(s[i0], s[i1], npn + 1)
        lado = 1
        for a, c in zip(sn[:-1], sn[1:]):
            ia, ic = int(np.argmin(np.abs(s - a))), int(np.argmin(np.abs(s - c)))
            Pa = S[ia] + lado * nrm[ia] * (t[ia] / 2 - wc[ia])
            Pc = S[ic] - lado * nrm[ic] * (t[ic] / 2 - wc[ic])
            Ld = float(np.hypot(*(Pc - Pa)))
            hcm = 0.5 * ((t[ia] - wc[ia]) + (t[ic] - wc[ic]))
            sen = min(1.0, hcm / max(Ld, 1e-6))
            V = max(np.max(np.abs(c_[2][ia:ic + 1])) for c_ in env['casos_plano'])
            diag.append((Pa, Pc)); F_d.append(V / sen); L_d.append(Ld)
            lado = -lado
    return diag, np.array(F_d), np.array(L_d)


def _largura_diag(F_d, L_d, bmin, FS, adm, E, wd_min):
    if not len(F_d):
        return wd_min
    for wd in np.arange(wd_min, 60.0, 0.25):
        Imin = np.minimum(bmin * wd ** 3, wd * bmin ** 3) / 12.0
        if ((FS * F_d / (wd * bmin) <= adm) & (FS * F_d <= np.pi ** 2 * E * Imin / L_d ** 2)).all():
            return float(wd)
    return 60.0


def _trelica(r, cen, mat, proc):
    """Treliça plana: profundidade constante b_t no vão (a mais pequena que dá a
    menor massa), transição para a profundidade das faces verdes nas pontas."""
    env = r['env']
    s, t = env['s'], env['t']
    FS, adm, E = cen['FS'], mat['sy'], mat['E']
    wc_min, wd_min = BANZO_MIN[proc], DIAG_MIN[proc]
    w = _peso_ponta(s)
    melhor = None
    for bt in np.arange(16.0, j3.B_INTERFACE + 0.1, 4.0):
        b = w * j3.B_INTERFACE + (1 - w) * bt
        wc, ok = _banzos(env, t, b, FS, adm, wc_min)
        wc = _envolvente(s, wc)
        if not ok[w == 0].all():
            continue
        janela = (t - 2 * wc >= JANELA_MIN) & (w == 0)
        vaos = _vaos(s, t, wc, janela)
        diag, F_d, L_d = _diagonais(env, t, wc, vaos)
        wd = _largura_diag(F_d, L_d, bt, FS, adm, E, wd_min)
        # fora dos vãos a secção é cheia: precisa da profundidade da secção cheia
        em_vao = np.zeros(len(s), bool)
        for i0, i1 in vaos:
            em_vao[i0:i1 + 1] = True
        b = _envolvente(s, np.where(em_vao, b, np.maximum(b, r['b'])))
        # massa aproximada: secção cheia - janelas + diagonais
        A = np.where(em_vao, 2 * wc * b, b * t)
        m = np.trapezoid(A, s) if hasattr(np, 'trapezoid') else np.trapz(A, s)
        m += np.sum(L_d) * wd * bt if len(L_d) else 0.0
        if melhor is None or m < melhor[0]:
            melhor = (m, bt, b, wc, vaos, diag, F_d, L_d, wd)
    if melhor is None:
        return None
    _, bt, b, wc, vaos, diag, F_d, L_d, wd = melhor
    # --- máscara das janelas em planta (só nos vãos com diagonais) ---
    sk = r['sketch']
    x, y, X, Y, dentro = _raster_planta(sk)
    dist = distance_transform_edt(dentro) * PIX
    from scipy.spatial import cKDTree
    S = env['S']
    ki = cKDTree(S).query(np.c_[X.ravel(), Y.ravel()])[1].reshape(X.shape)
    em_vao = np.zeros(len(s), bool)
    for i0, i1 in vaos:
        em_vao[i0:i1 + 1] = True
    livre = dentro & (dist >= wc[ki]) & em_vao[ki]
    for Pa, Pc in diag:
        d = Pc - Pa
        L2 = max(d @ d, 1e-9)
        tt = np.clip(((X - Pa[0]) * d[0] + (Y - Pa[1]) * d[1]) / L2, 0, 1)
        dd = np.hypot(X - (Pa[0] + tt * d[0]), Y - (Pa[1] + tt * d[1]))
        livre &= dd > wd / 2
    livre = binary_opening(livre, structure=_disco(R_JANELA))
    janelas = _contornos(livre, x[0], y[0], PIX, area_min=150.0)
    # --- FS (banzos nos vãos, secção cheia fora deles, diagonais) e massa ---
    hc = np.maximum(t - wc, 1e-6)
    fs = np.full(len(s), np.inf)
    for _, N, V, M, fc in env['casos_plano']:
        sc = np.abs(N) / (2 * wc * b) + fc * np.abs(M) / (hc * wc * b)
        fs = np.minimum(fs, adm / np.maximum(sc, 1e-9))
    sb = 3 * env['Mn'] / (wc * b ** 2)
    L1, c1 = np.maximum(wc, b), np.minimum(wc, b)
    tau = env['T'] * c1 / (2 * jI._beta(c1, L1) * L1 * c1 ** 3)
    fs = np.minimum(fs, adm / np.maximum(np.sqrt(sb ** 2 + 3 * tau ** 2), 1e-9))
    fs_banzo = float(fs[em_vao].min()) if em_vao.any() else np.inf
    # fora dos vãos a secção é cheia t x b(s)
    fs_c = np.minimum(adm / np.maximum(env['sigb'] / b, 1e-9),
                      adm / np.maximum(j3.sigma_fora_plano(env, b), 1e-9))
    fs_cheia = float(fs_c[~em_vao].min()) if (~em_vao).any() else np.inf
    fs_diag = np.inf
    if len(F_d):
        Imin = np.minimum(bt * wd ** 3, wd * bt ** 3) / 12.0
        fs_diag = float(min(np.min(adm * wd * bt / F_d), np.min(np.pi ** 2 * E * Imin / L_d ** 2 / F_d)))
    area_jan = float(livre.sum()) * PIX * PIX
    # volume: profundidade b(s) da secção mais próxima, menos janelas
    bmap = b[ki]
    vol = float(np.sum(np.where(dentro & ~livre, bmap, 0.0))) * PIX * PIX
    return dict(familia='trelica', b=b, b_vao=float(bt), wc=wc, wd=float(wd), janelas=janelas,
                diagonais=diag, FS_banzos=fs_banzo, FS_diagonais=fs_diag, FS_cheia=fs_cheia,
                FS_min=float(min(fs_banzo, fs_diag, fs_cheia)),
                massa_kg=vol * mat['rho'] * 1e-9, n_janelas=len(janelas), vaos=vaos)


def _trelica_melhor(params, cenario, material, cen, mat, proc):
    """A treliça precisa de altura em planta: experimenta perfis mais largos e
    fica com o mais leve que é geometricamente válido (pneu, degraus...)."""
    melhor = None
    base_sup = params['espessura_sup']
    cands = []
    for esp in (None, 45.0, 55.0, 65.0, 75.0, 85.0, 95.0):
        p = dict(params)
        if esp is not None:
            if esp <= base_sup:
                continue
            # alarga PARA FORA (a face interior, junto ao pneu, fica onde estava)
            d = esp - base_sup
            p['espessura_sup'] = min(esp, gv.LIMITES['espessura_sup'][1])
            p['espessura_inf'] = min(esp, gv.LIMITES['espessura_inf'][1])
            p['largura_ombro'] = min(params['largura_ombro'] + d, gv.LIMITES['largura_ombro'][1])
            if not gv.avaliar(p)['valido']:
                continue
        r = j3.gerar(p, cenario, material, 'variavel', com_malha=False)
        f = _trelica(r, cen, mat, proc)
        if f is None or f['FS_min'] < cen['FS'] * (1 - 1e-3):
            continue
        cands.append((r, f, p))
    if not cands:
        return None
    # é a família TRELIÇA: preferem-se soluções com janelas a sério (>= 3)
    com_janelas = [c for c in cands if c[1]['n_janelas'] >= 3]
    return min(com_janelas or cands, key=lambda c: c[1]['massa_kg'])


# ==============================================================================
# 3. ISOGRID (Vénus): secção em I com alma >= 6 mm + malha de nervuras a 60°
# ==============================================================================
def _isogrid(params, cenario, material, mat):
    guard = {k: dict(v) for k, v in jI.FABRICO.items()}
    try:
        for v in jI.FABRICO.values():
            v['alma_min'] = max(v['alma_min'], ALMA_MIN_VENUS)
        rI = jI.gerar(params, cenario, material)
    finally:
        for k, v in guard.items():
            jI.FABRICO[k].update(v)
    sk = rI['sketch']
    x, y, X, Y, dentro = _raster_planta(sk)
    bolsa = np.zeros(X.shape, bool)
    for po in rI.get('polis', []):
        bolsa |= Path(np.vstack([po, po[:1]])).contains_points(
            np.c_[X.ravel(), Y.ravel()]).reshape(X.shape)
    # nervuras triangulares que seguem o eixo: ziguezague de banzo a banzo dentro
    # de cada rebaixo (como uma treliça, mas com a alma no fundo: nada atravessa)
    env = rI['env']
    t, wf, reb = env['t'], np.asarray(rI['wf']), np.asarray(rI['rebaixo'], bool)
    vaos = _vaos(env['s'], t, wf, reb)
    diag, _, _ = _diagonais(env, t, wf, vaos)
    nerv = np.zeros(X.shape, bool)
    for Pa, Pc in diag:
        dv = Pc - Pa
        L2 = max(dv @ dv, 1e-9)
        tt = np.clip(((X - Pa[0]) * dv[0] + (Y - Pa[1]) * dv[1]) / L2, 0, 1)
        dd = np.hypot(X - (Pa[0] + tt * dv[0]), Y - (Pa[1] + tt * dv[1]))
        nerv |= dd < ISO_NERVURA / 2
    celulas = binary_opening(bolsa & ~nerv, structure=_disco(R_JANELA * 0.6))
    polis = _contornos(celulas, x[0], y[0], PIX, area_min=25.0)
    d = nd.preparar(rI, j3.B_INTERFACE)
    d['rebaixos'] = [dict(pts=p) for p in polis]
    massa = nd.volume(d) * mat['rho'] * 1e-9
    return dict(familia='isogrid', r_I=rI, dados_nurbs=d, n_celulas=len(polis),
                FS_min=float(rI['FS_min']), massa_kg=massa,
                alma_min=float(np.min(rI['tw'])))


def _alargar(params, esp):
    """Perfil mais alto em planta, a crescer PARA FORA (face junto ao pneu fica)."""
    p = dict(params)
    d = esp - params['espessura_sup']
    p['espessura_sup'] = min(esp, gv.LIMITES['espessura_sup'][1])
    p['espessura_inf'] = min(esp, gv.LIMITES['espessura_inf'][1])
    p['largura_ombro'] = min(params['largura_ombro'] + d, gv.LIMITES['largura_ombro'][1])
    return p


def _isogrid_melhor(params, cenario, material, mat):
    cands = []
    for esp in (None, 55.0, 70.0, 85.0):
        if esp is None:
            p = dict(params)
        else:
            if esp <= params['espessura_sup']:
                continue
            p = _alargar(params, esp)
            if not gv.avaliar(p)['valido']:
                continue
        try:
            f = _isogrid(p, cenario, material, mat)
        except Exception:
            continue
        f['params'] = p
        cands.append(f)
    bons = [f for f in cands if f['n_celulas'] >= 6]
    return min(bons or cands, key=lambda f: f['massa_kg'])


# ==============================================================================
# FUNÇÃO PRINCIPAL
# ==============================================================================
def gerar(params, cenario, material, familia=None):
    gv._init()
    planeta = planeta_de(cenario)
    familia = familia or FAMILIA.get(planeta, 'fechada')
    r = j3.gerar(params, cenario, material, 'variavel', com_malha=False)
    cn = r['cenario']
    cen, mat = gv.CENARIOS[cn], gv.material(cn, material)
    proc = jI.processo(material)
    if familia == 'fechada':
        f = _fechada(r, cen, mat, proc)
        f['estacoes'] = estacoes_fechada(r, f)
    elif familia == 'trelica':
        res = _trelica_melhor(params, cenario, material, cen, mat, proc)
        if res is None:
            raise Exception('nenhuma treliça válida para ' + str(planeta))
        r, f, f['params'] = res[0], res[1], res[2]
    elif familia == 'isogrid':
        f = _isogrid_melhor(params, cenario, material, mat)
        r = j3.gerar(f['params'], cenario, material, 'variavel', com_malha=False)
    else:
        raise ValueError(familia)
    f.update(base=r, planeta=planeta, material=material, FS_req=cen['FS'],
             nome_familia=NOME_FAMILIA[familia], processo=proc)
    return f


if __name__ == '__main__':
    import csv
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    gv._init()
    res = []
    for planeta in ['Mercúrio', 'Vénus', 'Lua', 'Marte', 'Titã', 'Europa', 'Io']:
        k = gv.chave_cenario(planeta).replace('\n', ' ')
        L = sorted([l for l in csv.DictReader(open('diag/planetas/designs_otimos.csv',
                    encoding='utf-8-sig'), delimiter=';')
                    if l['cenario'] == k and l['massa_kg'] not in ('', 'nan')],
                   key=lambda l: float(l['massa_kg']))[0]
        p = {n_: float(L[n_]) for n_ in gv.NOMES}
        f = gerar(p, planeta, L['material'])
        extra = ''
        if f['familia'] == 'trelica':
            extra = f'| janelas {f["n_janelas"]} | diag {f["wd"]:.1f} mm | FS banzos {f["FS_banzos"]:.2f} diag {f["FS_diagonais"]:.2f}'
        elif f['familia'] == 'fechada':
            extra = f'| parede {f["e"][f["oco"]].min() if f["oco"].any() else 0:.1f}-{f["e"][f["oco"]].max() if f["oco"].any() else 0:.1f} mm | oco {100*f["oco"].mean():.0f}% do comprimento'
        else:
            extra = f'| células {f["n_celulas"]} | alma mín {f["alma_min"]:.1f} mm'
        print(f'{planeta:9s} {f["nome_familia"]:28s} {L["material"]:20s} {f["massa_kg"]:5.2f} kg '
              f'FS {f["FS_min"]:.2f} (req {f["FS_req"]}) {extra}')
        res.append((planeta, f))
    # figura em planta
    fig, axs = plt.subplots(1, len(res), figsize=(3.3 * len(res), 6))
    ns = gv._NS
    for ax, (planeta, f) in zip(axs, res):
        ax.fill(ns['cima_x'], ns['cima_y'], 'limegreen', alpha=.8)
        ax.fill(ns['baixo_x'], ns['baixo_y'], 'limegreen', alpha=.8)
        r = f['base']
        sk = r['sketch']
        if f['familia'] == 'fechada':
            for P in f['estacoes']:
                a = P['c'] + P['n'] * P['t'] / 2; c = P['c'] - P['n'] * P['t'] / 2
                ax.plot([a[0], c[0]], [a[1], c[1]], color='steelblue', lw=.8)
            S, nr, t = r['env']['S'], np.c_[-r['env']['tang'][:, 1], r['env']['tang'][:, 0]], r['env']['t']
            for sg in (1, -1):
                ax.plot(*(S + sg * nr * (t[:, None] / 2)).T, color='navy', lw=1.5)
        elif f['familia'] == 'trelica':
            ax.fill(*sk.T, color='#9ecae1', ec='navy')
            for J in f['janelas']:
                ax.fill(*J.T, color='white', ec='navy', lw=.8)
        else:
            ax.fill(*sk.T, color='#fdd0a2', ec='saddlebrown')
            for J in f['dados_nurbs']['rebaixos']:
                ax.fill(*J['pts'].T, color='#d94801', alpha=.6, lw=0)
        ax.set_aspect('equal'); ax.set_xticks([]); ax.set_yticks([])
        ax.set_title(f'{planeta}\n{f["nome_familia"]}\n{f["material"]}\n'
                     f'{f["massa_kg"]:.2f} kg | FS {f["FS_min"]:.2f}', fontsize=9)
    fig.suptitle('Famílias estruturais por planeta (vista em planta)', fontweight='bold')
    fig.savefig('diag/planetas/familias_planta.png', dpi=100, bbox_inches='tight')
    print('[OK] diag/planetas/familias_planta.png')
