"""
==============================================================================
 GERAÇÃO DE POPULAÇÕES  (M1: design generativo + parametrização, sem otimização)
==============================================================================
Cada família estrutural é descrita por GENES (parâmetros com significado de
projeto). Para cada planeta gera-se uma POPULAÇÃO de variantes espalhadas por
todo o espaço de soluções (amostragem Latin Hypercube) e cada uma é avaliada:

    genes -> geometria -> massa, FS (teoria de vigas curvas + correção de Bleich nos
                          banzos finos), rigidez, nº de elementos
                          -> passa / não passa no filtro rápido (nível 1)

Não se procura "a melhor": explora-se o espaço e o FILTRO decide o que fica.
As finalistas (explorador.py) são construídas no Rhino a partir dos genes.

  FECHADA  genes: largura em planta, profundidade, conicidade, parede, raio dos cantos, raio interior do C, material
  TRELIÇA  genes: largura em planta, profundidade, nº de painéis, banzo, diagonal,
                  montantes (sim/não), material
  NERVURAS genes: largura em planta, profundidade, alma, banzo, nº de painéis,
                  largura das nervuras, material

Uso:  python populacoes.py              (todos os planetas, 150 variantes cada)
      python populacoes.py Vénus 60     (um planeta, 60 variantes)
Saída: diag/populacoes/<planeta>.csv  e  diag/populacoes/todas.csv
==============================================================================
"""
import os
import sys
import csv
import time
import numpy as np
from matplotlib.path import Path
from scipy.stats import qmc
from scipy.ndimage import binary_opening, distance_transform_edt
from scipy.spatial import cKDTree

import gerador_variantes as gv
import joelho3d as j3
import joelho3d_I as jI
import nurbs_dados as nd
import planetas as pl
import familias as fa
import degradacao as dg

N_POP = 150
SEMENTE = 11
PIX_POP = 1.0          # mm, resolução das máscaras em planta na população (rápido)
PASTA = 'diag/populacoes'

# ------------------------------------------------------------------------------
# GENES: (mínimo, máximo).  None = depende do planeta / do processo de fabrico
# ------------------------------------------------------------------------------
GENES = {
    'fechada': dict(largura=(None, 95.0), prof=(12.0, 110.0), conicidade=(-0.4, 0.4),
                    parede=(None, 9.0), r_cantos=(0.10, 0.50), r_int=(0.0, 110.0)),
    'trelica': dict(largura=(45.0, 95.0), prof=(8.0, 70.0), paineis=(3, 12),
                    banzo=(None, 22.0), diagonal=(None, 16.0), montantes=(0, 1),
                    r_int=(0.0, 110.0)),
    'isogrid': dict(largura=(None, 90.0), prof=(40.0, 81.6), alma=(6.0, 26.0),
                    banzo=(6.0, 40.0), paineis=(3, 14), nervura=(4.0, 10.0),
                    r_int=(0.0, 110.0)),
}
INTEIROS = {'paineis', 'montantes'}
DESCRICAO_GENES = {
    'largura': 'altura do braço em planta (mm)', 'prof': 'profundidade da peça a meio (mm)',
    'conicidade': 'variação da profundidade de cima para baixo (-: mais fundo em baixo)',
    'parede': 'espessura da parede do tubo (mm)', 'r_cantos': 'raio dos cantos / menor lado',
    'paineis': 'nº de painéis (triângulos) ao longo do braço', 'banzo': 'largura dos banzos (mm)',
    'diagonal': 'largura das diagonais / nervuras (mm)', 'montantes': 'barras verticais (0/1)',
    'alma': 'espessura da alma (mm)',
    'r_int': 'raio pedido das duas curvas interiores do C (mm); abaixo do raio base fica igual à base, acima limitado pela geometria', 'nervura': 'largura das nervuras (mm)',
    'material': 'material (só os permitidos no planeta)',
}


# ------------------------------------------------------------------------------
# base de cada planeta: o desenho ótimo 2D (para o contorno base) + materiais
# ------------------------------------------------------------------------------
_CACHE_BASE = {}


def base_planeta(planeta):
    if planeta in _CACHE_BASE:
        return _CACHE_BASE[planeta]
    gv._init()
    cn = gv.chave_cenario(planeta)
    k = cn.replace('\n', ' ')
    L = sorted([l for l in csv.DictReader(open('diag/planetas/designs_otimos.csv',
                encoding='utf-8-sig'), delimiter=';')
                if l['cenario'] == k and l['massa_kg'] not in ('', 'nan')],
               key=lambda l: float(l['massa_kg']))
    params = {n: float(L[0][n]) for n in gv.NOMES}
    mats = [l['material'] for l in L]                      # possíveis, do mais leve ao mais pesado
    _CACHE_BASE[planeta] = (cn, params, mats)
    return _CACHE_BASE[planeta]


def limites(planeta, familia):
    cn, params, mats = base_planeta(planeta)
    proc = 'CNC'
    out = {}
    for g, (lo, hi) in GENES[familia].items():
        if lo is None:
            lo = {'largura': max(params['espessura_sup'], 22.0),
                  'parede': fa.PAREDE_MIN[proc], 'banzo': fa.BANZO_MIN[proc],
                  'diagonal': fa.DIAG_MIN[proc]}[g]
        d = dg.de(planeta)                       # regras de degradação (raios / parede mínimos)
        extra = {'r_cantos': d['r_cantos_min'], 'r_int': d['r_int_min'], 'parede': d['parede_min']}.get(g)
        if extra is not None:
            lo = max(lo, extra)
        out[g] = (float(lo), float(max(hi, lo + 1e-6)))
    return out


# ------------------------------------------------------------------------------
# geometria comum: contorno em planta + eixo médio + esforços do planeta
# ------------------------------------------------------------------------------
def _esqueleto(planeta, largura, r_int=None):
    cn, params, _ = base_planeta(planeta)
    p = dict(params) if largura <= params['espessura_sup'] + 1e-6 else fa._alargar(params, largura)
    if r_int is not None:
        # curvas interiores do C abertas (gerador_variantes._curvas_interiores_abertas)
        p['r_int'] = float(r_int)
    av = gv.avaliar(p)
    if not av['valido']:
        return None, av.get('motivo', 'geometria inválida')
    sk, _ = gv.construir_sketch_v2(gv._NS['ancoras_verdes'], p)
    env = j3.envolvente(sk, gv.CENARIOS[cn])
    return dict(sketch=sk, env=env, params=p, cn=cn), None


def _rigidez(env, planeta, E, Iz):
    """Rotação do cubo [graus] sob o peso estático local (caso 'queda' / fator de queda)."""
    f_q = pl.fatores(planeta)['queda']
    for nome, N, V, M, fc in env['casos_plano']:
        if nome.endswith(':queda'):
            integ = np.trapezoid if hasattr(np, 'trapezoid') else np.trapz
            return float(np.degrees(integ(np.abs(M / f_q) / (E * Iz), env['s'])))
    return np.nan


# ==============================================================================
# FECHADA
# ==============================================================================
def avaliar_fechada(planeta, g, mat, proc='CNC'):
    esq, motivo = _esqueleto(planeta, g['largura'], g.get('r_int'))
    if esq is None:
        return dict(valido=False, motivo=motivo)
    env = esq['env']
    s, t = env['s'], env['t']
    w = fa._peso_ponta(s)
    u = (s - s[0]) / (s[-1] - s[0])
    b_meio = g['prof'] * (1.0 + g['conicidade'] * (2 * u - 1))
    b = w * j3.B_INTERFACE + (1 - w) * np.maximum(b_meio, j3.B_MIN)
    meia = 0.5 * np.minimum(t, b)
    e = np.where(w > 0, meia, np.minimum(g['parede'], meia))
    R = g['r_cantos'] * np.minimum(t, b) * (1 - w) + 0.5 * w
    fa.E_MAT, fa.SY_MAT = mat['E'], mat['sy']
    # fim de vida: a pele exterior perde delta em cada face (cavidade selada não gasta)
    dl = dg.de(planeta)['delta']
    t_g, b_g = np.maximum(t - 2 * dl, 1.0), np.maximum(b - 2 * dl, 1.0)
    meia_g = 0.5 * np.minimum(t_g, b_g)
    e_g = np.where(e < meia - 1e-9, np.minimum(np.maximum(e - dl, 0.3), meia_g), meia_g)
    R_g = np.maximum(R - dl, 0.0)
    smax = np.zeros(len(s))
    for _, N, V, M, fc in env['casos_plano']:
        p_, f_, A, oco = fa.caixa_sigma(t_g, b_g, e_g, R_g, N, V, M, fc, env['Mn'], env['T'], rho=env['rho'])
        smax = np.maximum(smax, np.maximum(p_, f_))
    A, Iz, _, oco = fa.caixa_props(t, b, e, R)
    integ = np.trapezoid if hasattr(np, 'trapezoid') else np.trapz
    massa = float(integ(A, s)) * mat['rho'] * 1e-9
    FS = mat['sy'] / np.maximum(smax, 1e-9)
    f = dict(familia='fechada', b=b, e=e, R=R, oco=oco, FS=FS)
    f['estacoes'] = fa.estacoes_fechada(dict(env=env), f)
    return dict(valido=True, massa_kg=massa, FS_min=float(FS.min()),
                rotacao_graus=_rigidez(env, planeta, mat['E'], Iz),
                n_elementos=int(oco.any()), esq=esq, geo=f)


# ==============================================================================
# TRELIÇA e NERVURAS: diagonais com nº de painéis imposto
# ==============================================================================
def _diagonais_n(env, t, wc, vaos, n_total, montantes=False):
    s, S = env['s'], env['S']
    nrm = np.c_[-env['tang'][:, 1], env['tang'][:, 0]]
    comp = np.array([s[j] - s[i] for i, j in vaos], float)
    if not len(comp):
        return [], np.array([]), np.array([]), []
    npn = np.maximum(2, np.round(n_total * comp / comp.sum()).astype(int))
    diag, F_d, L_d, mont = [], [], [], []
    for (i0, i1), n in zip(vaos, npn):
        sn = np.linspace(s[i0], s[i1], n + 1)
        lado = 1
        for k, (a, c) in enumerate(zip(sn[:-1], sn[1:])):
            ia, ic = int(np.argmin(np.abs(s - a))), int(np.argmin(np.abs(s - c)))
            Pa = S[ia] + lado * nrm[ia] * (t[ia] / 2 - wc[ia])
            Pc = S[ic] - lado * nrm[ic] * (t[ic] / 2 - wc[ic])
            Ld = float(np.hypot(*(Pc - Pa)))
            hcm = 0.5 * ((t[ia] - wc[ia]) + (t[ic] - wc[ic]))
            sen = min(1.0, hcm / max(Ld, 1e-6))
            V = max(np.max(np.abs(c_[2][ia:ic + 1])) for c_ in env['casos_plano'])
            diag.append((Pa, Pc)); F_d.append(V / sen); L_d.append(Ld)
            if montantes and k > 0:
                mont.append((S[ia] + nrm[ia] * (t[ia] / 2 - wc[ia]),
                             S[ia] - nrm[ia] * (t[ia] / 2 - wc[ia])))
            lado = -lado
    return diag, np.array(F_d), np.array(L_d), mont


def _faixa(X, Y, Pa, Pc, larg):
    d = Pc - Pa
    L2 = max(d @ d, 1e-9)
    tt = np.clip(((X - Pa[0]) * d[0] + (Y - Pa[1]) * d[1]) / L2, 0, 1)
    return np.hypot(X - (Pa[0] + tt * d[0]), Y - (Pa[1] + tt * d[1])) <= larg / 2


def avaliar_trelica(planeta, g, mat, proc='CNC', pix=PIX_POP, contornos=False):
    esq, motivo = _esqueleto(planeta, g['largura'], g.get('r_int'))
    if esq is None:
        return dict(valido=False, motivo=motivo)
    env, sk = esq['env'], esq['sketch']
    s, t = env['s'], env['t']
    cn = esq['cn']
    FS_req, adm, E = gv.CENARIOS[cn]['FS'], mat['sy'], mat['E']
    w = fa._peso_ponta(s)
    b = w * j3.B_INTERFACE + (1 - w) * g['prof']
    wc = np.minimum(np.full(len(s), g['banzo']), t / 2)
    janela = (t - 2 * wc >= fa.JANELA_MIN) & (w == 0)
    vaos = fa._vaos(s, t, wc, janela)
    diag, F_d, L_d, mont = _diagonais_n(env, t, wc, vaos, int(g['paineis']), bool(g['montantes']))
    wd = g['diagonal']
    em_vao = np.zeros(len(s), bool)
    for i0, i1 in vaos:
        em_vao[i0:i1 + 1] = True
    # --- fim de vida: todas as faces expostas perdem delta (geometria nova fica para a massa) ---
    dl = dg.de(planeta)['delta']
    wc_n, b_n, wd_n = wc, b, wd
    wc, b, wd = np.maximum(wc - 2 * dl, 0.5), np.maximum(b - 2 * dl, 0.5), max(wd - 2 * dl, 0.5)
    # --- FS: banzos (vãos), secção cheia (fora), diagonais (tração/compressão + Euler) ---
    hc = np.maximum(t - wc, 1e-6)
    fs = np.full(len(s), np.inf)
    for _, N, V, M, fc in env['casos_plano']:
        sc = np.abs(N) / (2 * wc * b) + fc * np.abs(M) / (hc * wc * b)
        fs = np.minimum(fs, adm / np.maximum(sc, 1e-9))
    sb = 3 * env['Mn'] / (wc * b ** 2)
    L1, c1 = np.maximum(wc, b), np.minimum(wc, b)
    tau = env['T'] * c1 / (2 * jI._beta(c1, L1) * L1 * c1 ** 3)
    fs = np.minimum(fs, adm / np.maximum(np.sqrt(sb ** 2 + 3 * tau ** 2), 1e-9))
    fs_c = np.minimum(adm / np.maximum(env['sigb'] / b, 1e-9),
                      adm / np.maximum(j3.sigma_fora_plano(env, b), 1e-9))
    fs = np.where(em_vao, fs, fs_c)
    fs_d = np.inf
    if len(F_d):
        bt = max(g['prof'] - 2 * dl, 0.5)
        Imin = np.minimum(bt * wd ** 3, wd * bt ** 3) / 12.0
        fs_d = float(min(np.min(adm * wd * bt / F_d), np.min(np.pi ** 2 * E * Imin / L_d ** 2 / F_d)))
    Iz_g = 2 * wc * b * (hc / 2) ** 2
    wc, b, wd = wc_n, b_n, wd_n                     # geometria NOVA para massa e janelas
    # --- janelas em planta ---
    x, y, X, Y, dentro = fa._raster_planta(sk, pix)
    dist = distance_transform_edt(dentro) * pix
    ki = cKDTree(env['S']).query(np.c_[X.ravel(), Y.ravel()])[1].reshape(X.shape)
    livre = dentro & (dist >= wc[ki]) & em_vao[ki]
    for Pa, Pc in diag + mont:
        livre &= ~_faixa(X, Y, Pa, Pc, wd)
    livre = binary_opening(livre, structure=fa._disco(fa.R_JANELA, pix))
    from scipy.ndimage import label
    lab, n_jan = label(livre)
    vol = float(np.sum(np.where(dentro & ~livre, b[ki], 0.0))) * pix * pix
    Iz = 2 * wc * b * (hc / 2) ** 2
    geo = dict(familia='trelica', base=dict(env=env, sketch=sk), b=b, wd=float(wd), wc=wc)
    if contornos:
        geo['janelas'] = fa._contornos(livre, x[0], y[0], pix, area_min=150.0)
    return dict(valido=True, massa_kg=vol * mat['rho'] * 1e-9,
                FS_min=float(min(fs.min(), fs_d)), FS_diagonais=fs_d,
                rotacao_graus=_rigidez(env, planeta, mat['E'], np.where(em_vao, Iz, b * t ** 3 / 12)),
                n_elementos=int(n_jan), esq=esq, geo=geo)


def avaliar_isogrid(planeta, g, mat, proc='CNC', pix=PIX_POP, contornos=False):
    esq, motivo = _esqueleto(planeta, g['largura'], g.get('r_int'))
    if esq is None:
        return dict(valido=False, motivo=motivo)
    env, sk = esq['env'], esq['sketch']
    s, t = env['s'], env['t']
    fab = jI.FABRICO[proc]
    w = fa._peso_ponta(s)
    b = w * j3.B_INTERFACE + (1 - w) * g['prof']
    wf = np.minimum(np.full(len(s), g['banzo']), t / 2)
    tw = np.minimum(np.full(len(s), g['alma']), b)
    h = t - 2 * wf
    reb = (h >= fab['rebaixo_min']) & (w == 0) & (b - tw > 1.0)
    if ((b - tw) / 2 > fab['prof_max'] + 1e-6)[reb].any():
        return dict(valido=False, motivo='rebaixo demasiado fundo para CNC')
    wf_e = np.where(reb, wf, t / 2)
    tw_e = np.where(reb, tw, b)
    # fim de vida: todas as faces (alma e banzos dentro dos rebaixos abertos) perdem delta
    dl = dg.de(planeta)['delta']
    t_g, b_g = np.maximum(t - 2 * dl, 1.0), np.maximum(b - 2 * dl, 1.0)
    wf_g = np.where(reb, np.maximum(wf - 2 * dl, 0.5), t_g / 2)
    tw_g = np.where(reb, np.maximum(tw - 2 * dl, 0.5), b_g)
    s_max = np.zeros(len(s))
    for _, N, V, M, fc in env['casos_plano']:
        s_max = np.maximum(s_max, jI.sigma_plano(t_g, b_g, wf_g, tw_g, N, V, M, fc))
    s_max = np.maximum(s_max, jI.sigma_fora(t_g, b_g, wf_g, tw_g, env['Mn'], env['T']))
    # Bleich nos banzos da secção em I (onde há rebaixo): meia-largura livre (b - tw)/2
    _, A_I, Iz_I, _ = jI.propriedades(t_g, b_g, wf_g, tw_g)
    for _, N, V, M, fc in env['casos_plano']:
        sb_, _ = fa.bleich_tensao(t_g, b_g, wf_g, (b_g - tw_g) / 2, env['rho'], N, M, fc, Iz_I, A_I, 'I')
        s_max = np.maximum(s_max, np.where(reb, sb_, 0.0))
    FS = mat['sy'] / np.maximum(s_max, 1e-9)
    # rebaixos + nervuras em ziguezague
    x, y, X, Y, dentro = fa._raster_planta(sk, pix)
    dist = distance_transform_edt(dentro) * pix
    ki = cKDTree(env['S']).query(np.c_[X.ravel(), Y.ravel()])[1].reshape(X.shape)
    bolsa = dentro & (dist >= wf_e[ki]) & reb[ki]
    vaos = fa._vaos(s, t, wf_e, reb)
    diag, _, _, _ = _diagonais_n(env, t, wf_e, vaos, int(g['paineis']))
    for Pa, Pc in diag:
        bolsa &= ~_faixa(X, Y, Pa, Pc, g['nervura'])
    bolsa = binary_opening(bolsa, structure=fa._disco(fa.R_JANELA * 0.6, pix))
    from scipy.ndimage import label
    lab, n_cel = label(bolsa)
    prof_b = b[ki]
    vol = float(np.sum(np.where(dentro, prof_b, 0.0) - np.where(bolsa, prof_b - tw[ki], 0.0))) * pix * pix
    _, A, Iz, _ = jI.propriedades(t, b, wf_e, tw_e)
    geo = None
    if contornos:
        polis = fa._contornos(bolsa, x[0], y[0], pix, area_min=25.0)
        d = nd.preparar(dict(env=env, b=b, sketch=sk, tw=tw_e, rebaixo=reb,
                             polis=polis), j3.B_INTERFACE)
        d['rebaixos'] = [dict(pts=p) for p in polis]
        geo = dict(familia='isogrid', dados_nurbs=d, n_celulas=len(polis),
                   alma_min=float(g['alma']))
    return dict(valido=True, massa_kg=vol * mat['rho'] * 1e-9, FS_min=float(FS.min()),
                rotacao_graus=_rigidez(env, planeta, mat['E'], Iz),
                n_elementos=int(n_cel), esq=esq, geo=geo)


AVALIAR = {'fechada': avaliar_fechada, 'trelica': avaliar_trelica, 'isogrid': avaliar_isogrid}


def avaliar(planeta, genes, contornos=False):
    """Avalia UMA variante a partir dos genes (inclui genes['material'])."""
    familia = fa.FAMILIA[planeta]
    cn, _, mats = base_planeta(planeta)
    mat = dg.material_gasto(gv.material(cn, genes['material']), planeta)   # k_mat da degradação
    proc = jI.processo(genes['material'])
    fn = AVALIAR[familia]
    genes = dg.engrossar(genes, familia, planeta)      # peça NOVA = estrutura + pele sacrificial
    if familia == 'fechada':
        r = fn(planeta, genes, mat, proc)
    else:
        r = fn(planeta, genes, mat, proc, contornos=contornos,
               pix=fa.PIX if contornos else PIX_POP)
    r.update(familia=familia, planeta=planeta, FS_req=gv.CENARIOS[cn]['FS'],
             delta_mm=dg.de(planeta)['delta'], k_deg=dg.de(planeta)['k_mat'])
    if r['valido']:
        r['passa'] = bool(r['FS_min'] >= r['FS_req'])
    else:
        r['passa'] = False
    return r


# ------------------------------------------------------------------------------
# POPULAÇÃO
# ------------------------------------------------------------------------------
def amostrar(planeta, n=N_POP, semente=SEMENTE):
    familia = fa.FAMILIA[planeta]
    lim = limites(planeta, familia)
    _, _, mats = base_planeta(planeta)
    nomes = list(lim)
    X = qmc.LatinHypercube(d=len(nomes) + 1, seed=semente).random(n)
    pop = []
    for x in X:
        gvec = {}
        for k, nome in enumerate(nomes):
            lo, hi = lim[nome]
            v = lo + x[k] * (hi - lo)
            gvec[nome] = int(round(v)) if nome in INTEIROS else round(float(v), 2)
        gvec['material'] = mats[min(int(x[-1] * len(mats)), len(mats) - 1)]
        pop.append(gvec)
    return pop


def _avaliar_um(args):
    planeta, i, genes = args
    try:
        r = avaliar(planeta, genes)
    except Exception as e:                                   # geometria impossível
        r = dict(valido=False, motivo=str(e)[:60], passa=False)
    lin = dict(planeta=planeta, id=f'{planeta[:3].upper()}-{i:03d}',
               familia=fa.FAMILIA[planeta], **genes)
    lin.update(valido=r.get('valido', False), passa=r.get('passa', False),
               motivo=r.get('motivo', ''),
               massa_kg=round(r.get('massa_kg', np.nan), 4) if r.get('valido') else '',
               FS_min=round(r.get('FS_min', np.nan), 3) if r.get('valido') else '',
               FS_req=r.get('FS_req', ''),
               rotacao_graus=round(r.get('rotacao_graus', np.nan), 5) if r.get('valido') else '',
               n_elementos=r.get('n_elementos', '') if r.get('valido') else '',
               delta_mm=r.get('delta_mm', ''), k_deg=r.get('k_deg', ''))
    return lin


def gerar_populacao(planeta, n=N_POP, pool=None):
    pop = amostrar(planeta, n)
    args = [(planeta, i, gvec) for i, gvec in enumerate(pop)]
    linhas = pool.map(_avaliar_um, args, chunksize=4) if pool else list(map(_avaliar_um, args))
    os.makedirs(PASTA, exist_ok=True)
    campos = []
    for l in linhas:
        campos += [k for k in l if k not in campos]
    with open(f'{PASTA}/{planeta}.csv', 'w', newline='', encoding='utf-8-sig') as f:
        wr = csv.DictWriter(f, fieldnames=campos, delimiter=';', restval='')
        wr.writeheader(); wr.writerows(linhas)
    return linhas


def ler_populacao(planeta):
    return list(csv.DictReader(open(f'{PASTA}/{planeta}.csv', encoding='utf-8-sig'), delimiter=';'))


def genes_de_linha(lin):
    familia = lin['familia']
    g = {}
    for k in GENES[familia]:
        if lin.get(k, '') in ('', None):          # gene acrescentado depois (catálogos antigos)
            continue
        g[k] = int(float(lin[k])) if k in INTEIROS else float(lin[k])
    g['material'] = lin['material']
    return g


if __name__ == '__main__':
    from multiprocessing import Pool
    gv._init()
    alvo = [sys.argv[1]] if len(sys.argv) > 1 else list(fa.FAMILIA)
    n = int(sys.argv[2]) if len(sys.argv) > 2 else N_POP
    todas = []
    t0 = time.time()
    with Pool(initializer=gv._init) as pool:
        for planeta in alvo:
            linhas = gerar_populacao(planeta, n, pool)
            val = [l for l in linhas if l['valido']]
            ok = [l for l in val if l['passa']]
            leve = min(ok, key=lambda l: l['massa_kg']) if ok else None
            print(f'{planeta:9s} {fa.NOME_FAMILIA[fa.FAMILIA[planeta]]:24s} {len(linhas)} variantes | '
                  f'válidas {len(val)} | passam FS {len(ok)} | mais leve que passa: '
                  f'{(str(leve["id"]) + " " + format(leve["massa_kg"], ".2f") + " kg") if leve else "-"}'
                  f'   ({time.time() - t0:.0f} s)')
            todas += linhas
    campos = []
    for l in todas:
        campos += [k for k in l if k not in campos]
    with open(f'{PASTA}/todas.csv', 'w', newline='', encoding='utf-8-sig') as f:
        wr = csv.DictWriter(f, fieldnames=campos, delimiter=';', restval='')
        wr.writeheader(); wr.writerows(todas)
    print(f'[OK] {PASTA}/todas.csv')
