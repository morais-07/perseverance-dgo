

import cv2
import numpy as np
import matplotlib.pyplot as plt

# ==============================================================================
# 1. TABELA DE PARÂMETROS CAD BASE (Design Original)
# ==============================================================================
parametros_base = {
    'largura_ombro':    192.0,  # Distância da face verde até à extrema esquerda
    'espessura_sup':    80.0,   # Espessura da coluna vertical superior
    'espessura_inf':    75.0,   # Espessura do braço inferior
    'degrau_topo_y':    31.0,   # Desnível do chanfro no topo
    'topo_reto_x':      55.0,   # Reta horizontal superior antes do chanfro
    'chanfro_larg_x':   45.0,   # Largura horizontal da rampa do chanfro
    'altura_bloco_sup': 135.0,  # Altura do bloco superior
    'altura_reta_inf':  85.0,   # Descida vertical antes de inclinar para baixo
    'recuo_curva_inf':  95.0,   # Posição X onde o braço inclinado encontra a base
    'R_int_sup':        88.0,   # Raio interior superior (R88)
    'R_int_meio':       50.0,   # Raio interior da dobra média (R50)
    'R_int_inf':        53.0,   # Raio interior inferior (R53)
    'R_ext_meio':       41.0,   # Raio exterior da dobra média (R41)
    'R_ext_inf':        108.0   # Raio exterior inferior (R108)
}

# ==============================================================================
# 2. MOTOR CAD 2D: GERADOR DE RETAS E ARCOS TANGENTES (FILLETS)
# ==============================================================================
def gerar_fillet_cad(p_ant, p_canto, p_prox, raio, num_pts=25):
    """Calcula um arco circular perfeito e tangente entre duas linhas retas."""
    if raio <= 0:
        return np.array([p_canto])
    
    v1 = p_ant - p_canto
    v2 = p_prox - p_canto
    d1, d2 = np.linalg.norm(v1), np.linalg.norm(v2)
    
    if d1 == 0 or d2 == 0:
        return np.array([p_canto])
        
    u1, u2 = v1 / d1, v2 / d2
    cos_ang = np.clip(np.dot(u1, u2), -1.0, 1.0)
    ang = np.arccos(cos_ang)
    
    if ang <= 0.01 or ang >= np.pi - 0.01:
        return np.array([p_canto])
        
    dist_tangente = raio / np.tan(ang / 2.0)
    
    # Limite de segurança geométrica para evitar auto-interseções nos designs aleatórios
    max_dist = 0.45 * min(d1, d2)
    if dist_tangente > max_dist:
        dist_tangente = max_dist
        raio = dist_tangente * np.tan(ang / 2.0)
        
    t1 = p_canto + u1 * dist_tangente
    t2 = p_canto + u2 * dist_tangente
    
    bissetriz = u1 + u2
    bissetriz /= np.linalg.norm(bissetriz)
    centro = p_canto + bissetriz * (raio / np.sin(ang / 2.0))
    
    ang1 = np.arctan2(t1[1] - centro[1], t1[0] - centro[0])
    ang2 = np.arctan2(t2[1] - centro[1], t2[0] - centro[0])
    
    delta = (ang2 - ang1 + np.pi) % (2 * np.pi) - np.pi
    angulos = np.linspace(ang1, ang1 + delta, num_pts)
    
    arco_x = centro[0] + raio * np.cos(angulos)
    arco_y = centro[1] + raio * np.sin(angulos)
    
    return np.column_stack([arco_x, arco_y])


def construir_sketch_parametrico(ancoras, params):
    """Constrói o polígono base com retas e aplica os Fillets nos cantos definidos."""
    x_c, y_c_sup, y_c_inf, x_b, y_b_sup, y_b_inf = ancoras
    
    x_esq_80 = x_c - params['largura_ombro']
    y_ombro  = y_c_sup - params['degrau_topo_y']
    y_meio   = y_ombro - params['altura_bloco_sup']
    x_esq_75 = x_esq_80 + (params['espessura_sup'] - params['espessura_inf'])
    y_dobra  = y_meio - params['altura_reta_inf']
    x_dir_in = x_esq_80 + params['espessura_sup']
    x_base_curva = x_b - params['recuo_curva_inf']

    vertices_e_raios = [
        ([x_c, y_c_sup], 0.0),
        ([x_c - params['topo_reto_x'], y_c_sup], 0.0),
        ([x_c - params['topo_reto_x'] - params['chanfro_larg_x'], y_ombro], 0.0),
        ([x_esq_80, y_ombro], 0.0),
        ([x_esq_80, y_meio], 0.0),
        ([x_esq_75, y_meio], 0.0),
        ([x_esq_75, y_dobra], params['R_ext_meio']),
        ([x_base_curva, y_b_inf], params['R_ext_inf']),
        ([x_b, y_b_inf], 0.0),
        ([x_b, y_b_sup], 0.0),
        ([x_base_curva + params['espessura_inf']*0.6, y_b_sup], params['R_int_inf']),
        ([x_dir_in, y_dobra + 25.0], params['R_int_meio']),
        ([x_dir_in, y_c_inf], params['R_int_sup']),
        ([x_c, y_c_inf], 0.0)
    ]
    
    pts = np.array([v[0] for v in vertices_e_raios], dtype=float)
    raios = [v[1] for v in vertices_e_raios]
    
    sketch_final = []
    n = len(pts)
    for i in range(n):
        p_ant = pts[(i - 1) % n]
        p_atual = pts[i]
        p_prox = pts[(i + 1) % n]
        segmento = gerar_fillet_cad(p_ant, p_atual, p_prox, raios[i])
        sketch_final.append(segmento)
        
    sketch_final = np.vstack(sketch_final)
    sketch_final = np.vstack([sketch_final, sketch_final[0]])
    return sketch_final, pts


def calcular_area_poligono(pts):
    """Fórmula de Shoelace para calcular a área 2D (proporcional à massa da peça)."""
    x, y = pts[:, 0], pts[:, 1]
    return 0.5 * np.abs(np.dot(x, np.roll(y, 1)) - np.dot(y, np.roll(x, 1)))


def gerar_parametros_aleatorios():
    """Gera um conjunto de parâmetros aleatórios dentro de limites geométricos coerentes."""
    esp_sup = np.random.uniform(45.0, 105.0)
    # Garante que a espessura inferior acompanha de forma coerente a superior
    esp_inf = np.clip(esp_sup + np.random.uniform(-20.0, 10.0), 35.0, 95.0)
    
    return {
        'largura_ombro':    np.random.uniform(155.0, 235.0),
        'espessura_sup':    esp_sup,
        'espessura_inf':    esp_inf,
        'degrau_topo_y':    np.random.uniform(15.0, 45.0),
        'topo_reto_x':      np.random.uniform(30.0, 75.0),
        'chanfro_larg_x':   np.random.uniform(25.0, 65.0),
        'altura_bloco_sup': np.random.uniform(100.0, 165.0),
        'altura_reta_inf':  np.random.uniform(55.0, 115.0),
        'recuo_curva_inf':  np.random.uniform(65.0, 130.0),
        'R_int_sup':        np.random.uniform(25.0, 120.0),
        'R_int_meio':       np.random.uniform(20.0, 85.0),
        'R_int_inf':        np.random.uniform(20.0, 85.0),
        'R_ext_meio':       np.random.uniform(15.0, 80.0),
        'R_ext_inf':        np.random.uniform(50.0, 150.0)
    }


# ==============================================================================
# 3. LEITURA DA IMAGEM E CALIBRAÇÃO PARA MILÍMETROS
#    Estratégia melhorada: segmentação por cor do fundo (HSV) + suavização
#    por Descritores de Fourier para contorno limpo e preciso.
# ==============================================================================

def suavizar_contorno_fourier(contorno, n_descritores=60):
    """
    Suaviza um contorno usando Descritores de Fourier.
    Mantém apenas as N frequências mais baixas, eliminando ruído de alta
    frequência e produzindo um contorno suave de qualidade CAD.
    
    Args:
        contorno: array Nx1x2 (formato OpenCV) ou Nx2
        n_descritores: número de coeficientes de Fourier a manter (mais = mais detalhe)
    Returns:
        contorno suavizado no formato Nx1x2 (OpenCV)
    """
    pts = contorno.reshape(-1, 2).astype(float)
    # Representar como sinal complexo: z(t) = x(t) + j*y(t)
    z = pts[:, 0] + 1j * pts[:, 1]
    
    # FFT do sinal complexo
    Z = np.fft.fft(z)
    
    # Filtro passa-baixo: manter apenas n_descritores/2 de cada lado
    n = len(Z)
    n_manter = min(n_descritores, n)
    Z_filtrado = np.zeros_like(Z)
    # Frequências baixas positivas (início) e negativas (fim)
    Z_filtrado[:n_manter // 2] = Z[:n_manter // 2]
    Z_filtrado[-(n_manter // 2):] = Z[-(n_manter // 2):]
    
    # Reconstruir contorno suavizado
    z_suave = np.fft.ifft(Z_filtrado)
    pts_suaves = np.column_stack([z_suave.real, z_suave.imag]).astype(np.int32)
    return pts_suaves.reshape(-1, 1, 2)


# --- Leitura e validação da imagem ---
imagem = cv2.imread('peca_rover.jpg.jpg')
if imagem is None:
    raise FileNotFoundError(
        "Não foi possível ler 'peca_rover.jpg.jpg'. "
        "Verifica se o ficheiro existe na pasta de trabalho."
    )

imagem_cinza = cv2.cvtColor(imagem, cv2.COLOR_BGR2GRAY)
hsv = cv2.cvtColor(imagem, cv2.COLOR_BGR2HSV)
kernel = np.ones((5, 5), np.uint8)

# --- Deteção das zonas verdes (referência dimensional) ---
mascara_verde = cv2.inRange(hsv, np.array([40, 50, 50]), np.array([80, 255, 255]))
mascara_verde = cv2.morphologyEx(mascara_verde, cv2.MORPH_OPEN, kernel, iterations=1)
mascara_verde = cv2.morphologyEx(mascara_verde, cv2.MORPH_CLOSE, kernel, iterations=2)

contornos_verdes, _ = cv2.findContours(mascara_verde, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
contornos_verdes_reais = [c for c in contornos_verdes if cv2.contourArea(c) > 1000]

if len(contornos_verdes_reais) < 2:
    raise ValueError(
        f"Esperadas pelo menos 2 zonas verdes, encontradas {len(contornos_verdes_reais)}. "
        "Ajusta os thresholds HSV da máscara verde."
    )

peca_cima = min(contornos_verdes_reais, key=lambda c: cv2.boundingRect(c)[1])
peca_baixo = max(contornos_verdes_reais, key=lambda c: cv2.boundingRect(c)[1])

# --- Calibração px → mm (face esquerda da zona verde inferior = 81 mm) ---
baixo_px_x, baixo_px_y = peca_baixo[:, 0, 0], -peca_baixo[:, 0, 1]
pts_face_baixo = baixo_px_y[baixo_px_x < np.min(baixo_px_x) + 15]
altura_verde_px = np.max(pts_face_baixo) - np.min(pts_face_baixo)
escala_mm = 81.0 / altura_verde_px
print(f"[Calibracao] Escala: {escala_mm:.4f} mm/px  ({1/escala_mm:.1f} px/mm)")

# ==============================================================================
# EXTRAÇÃO DO CONTORNO GLOBAL: Segmentação por cor do fundo (substituiu Canny)
#
# Porquê esta mudança:
#   - O Canny dependia do contraste local (gradiente) e perdia arestas em zonas
#     de baixo contraste entre o cinza da peça e o azul escuro do fundo.
#   - A segmentação por cor identifica directamente o que é fundo (azul escuro)
#     e inverte para obter a silhueta completa da peça.
# ==============================================================================

# Passo 1: Máscara do fundo azul escuro (H ~ 95-135, S > 25, V > 20)
mascara_fundo = cv2.inRange(hsv, np.array([95, 25, 20]), np.array([135, 255, 200]))
mascara_fundo = cv2.morphologyEx(mascara_fundo, cv2.MORPH_CLOSE, kernel, iterations=3)
mascara_fundo = cv2.morphologyEx(mascara_fundo, cv2.MORPH_OPEN, kernel, iterations=1)

# Passo 2: Inverter → tudo que NÃO é fundo é peça
mascara_peca = cv2.bitwise_not(mascara_fundo)

# Passo 3: Limpeza morfológica — remover ruído e fechar buracos internos
mascara_peca = cv2.morphologyEx(mascara_peca, cv2.MORPH_OPEN, kernel, iterations=2)
mascara_peca = cv2.morphologyEx(mascara_peca, cv2.MORPH_CLOSE, kernel, iterations=4)

# Passo 4: Flood-fill para preencher eventuais buracos interiores
mascara_flood = mascara_peca.copy()
h_img, w_img = mascara_flood.shape
flood_mask = np.zeros((h_img + 2, w_img + 2), np.uint8)
cv2.floodFill(mascara_flood, flood_mask, (0, 0), 255)
mascara_interior = cv2.bitwise_not(mascara_flood)
mascara_peca = cv2.bitwise_or(mascara_peca, mascara_interior)

# Passo 5: Encontrar o contorno externo principal
contornos_globais, _ = cv2.findContours(mascara_peca, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
contorno_global = max(contornos_globais, key=cv2.contourArea)

# Passo 6: Suavização por Descritores de Fourier (contorno limpo, sem ruído)
#   n_descritores controla o nível de detalhe:
#     - 40-60 → contorno muito suave (bom para sketch paramétrico)
#     - 80-120 → preserva mais detalhe dos cantos
#     - 150+ → quase sem suavização
contorno_global_suave = suavizar_contorno_fourier(contorno_global, n_descritores=80)

print(f"[Contorno] {len(contorno_global):d} pts brutos -> "
      f"{len(contorno_global_suave):d} pts suavizados (Fourier, n=80)")

# --- Conversão para coordenadas em mm (Y invertido para sistema CAD) ---
global_x = np.append(contorno_global_suave[:, 0, 0], contorno_global_suave[0, 0, 0]) * escala_mm
global_y = np.append(-contorno_global_suave[:, 0, 1], -contorno_global_suave[0, 0, 1]) * escala_mm

cima_x, cima_y = peca_cima[:, 0, 0] * escala_mm, -peca_cima[:, 0, 1] * escala_mm
baixo_x, baixo_y = baixo_px_x * escala_mm, baixo_px_y * escala_mm

# --- Âncoras verdes: pontos fixos que ligam o sketch paramétrico à imagem ---
x_int_cima = np.min(cima_x)
pts_y_cima = cima_y[cima_x < x_int_cima + 10]
y_cima_sup, y_cima_inf = np.max(pts_y_cima), np.min(pts_y_cima)

x_int_baixo = np.min(baixo_x)
pts_y_baixo = baixo_y[baixo_x < x_int_baixo + 10]
y_baixo_sup, y_baixo_inf = np.max(pts_y_baixo), np.min(pts_y_baixo)

ancoras_verdes = (x_int_cima, y_cima_sup, y_cima_inf, x_int_baixo, y_baixo_sup, y_baixo_inf)

sketch_cad_base, vertices_base = construir_sketch_parametrico(ancoras_verdes, parametros_base)
area_base = calcular_area_poligono(sketch_cad_base)


# ==============================================================================
# 4. JANELA 1: MAPEAMENTO E SKETCH BASE
# ==============================================================================
fig1, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 7))
fig1.canvas.manager.set_window_title('Janela 1: Engenharia Inversa e Sketch Base')

ax1.plot(global_x, global_y, 'b-', linewidth=2.5, label="Contorno Global Extraído")
ax1.fill(global_x, global_y, 'lightblue', alpha=0.35)
ax1.fill(cima_x, cima_y, 'limegreen', edgecolor='darkgreen', lw=2, label="Zonas Verdes (Preserve)")
ax1.fill(baixo_x, baixo_y, 'limegreen', edgecolor='darkgreen', lw=2)
ax1.set_title("Figura 1: Extração Vetorial Calibrada (mm)", fontsize=12, fontweight='bold')
ax1.axis('equal')
ax1.grid(True, linestyle='--', alpha=0.5)
ax1.legend(loc='lower left')

ax2.fill(cima_x, cima_y, 'limegreen', edgecolor='darkgreen', lw=2, alpha=0.85, label="Preserve Geometry (Fixo)")
ax2.fill(baixo_x, baixo_y, 'limegreen', edgecolor='darkgreen', lw=2, alpha=0.85)
ax2.plot(sketch_cad_base[:, 0], sketch_cad_base[:, 1], color='#D35400', linewidth=2.5, label="Sketch Base")
ax2.fill(sketch_cad_base[:, 0], sketch_cad_base[:, 1], color='#F5B041', alpha=0.45)
ax2.plot(vertices_base[:, 0], vertices_base[:, 1], 'k--', lw=1, alpha=0.4, label="Polígono Construção")
ax2.set_title(f"Figura 2: Sketch Base | Área: {area_base/100:.1f} cm²", fontsize=12, fontweight='bold')
ax2.axis('equal')
ax2.grid(True, linestyle='--', alpha=0.5)
ax2.legend(loc='lower left')
plt.tight_layout()


# ==============================================================================
# 5. JANELA 2: GERAÇÃO DE 5 DESIGNS ALEATÓRIOS (EXPLORAÇÃO PARAMÉTRICA)
# ==============================================================================
fig2, axes = plt.subplots(2, 3, figsize=(18, 10))
fig2.canvas.manager.set_window_title('Janela 2: Geração Aleatória de Designs (Pré-Design Generativo)')
axes = axes.flatten()

cores_designs = ['#2980B9', '#8E44AD', '#C0392B', '#16A085', '#D35400']
sketches_gerados = []

print("\n" + "="*65)
print("   EXPLORAÇÃO DO ESPAÇO DE DESIGN: 5 VARIAÇÕES ALEATÓRIAS")
print("="*65)

for i in range(5):
    params_rand = gerar_parametros_aleatorios()
    sketch_rand, pts_rand = construir_sketch_parametrico(ancoras_verdes, params_rand)
    area_rand = calcular_area_poligono(sketch_rand)
    diff_massa = ((area_rand - area_base) / area_base) * 100
    
    sketches_gerados.append((sketch_rand, params_rand, area_rand, diff_massa))
    
    # Imprimir resumo dos parâmetros gerados no terminal
    print(f"Design #{i+1} -> Ombro: {params_rand['largura_ombro']:.0f}mm | "
          f"Esp.Sup: {params_rand['espessura_sup']:.0f}mm | "
          f"Esp.Inf: {params_rand['espessura_inf']:.0f}mm | "
          f"R_int: {params_rand['R_int_sup']:.0f}mm | "
          f"Massa/Área: {diff_massa:+.1f}%")
    
    ax = axes[i]
    # Desenhar Zonas Verdes Fixas
    ax.fill(cima_x, cima_y, 'limegreen', edgecolor='darkgreen', lw=1.5, alpha=0.85)
    ax.fill(baixo_x, baixo_y, 'limegreen', edgecolor='darkgreen', lw=1.5, alpha=0.85)
    
    # Sombra tracejada do Design Original por baixo para comparação visual
    ax.plot(sketch_cad_base[:, 0], sketch_cad_base[:, 1], 'k:', lw=1.2, alpha=0.5, label="Original")
    
    # Desenhar Novo Design Aleatório
    cor = cores_designs[i]
    ax.plot(sketch_rand[:, 0], sketch_rand[:, 1], color=cor, lw=2.5, label=f"Design #{i+1}")
    ax.fill(sketch_rand[:, 0], sketch_rand[:, 1], color=cor, alpha=0.35)
    
    # Polígono de controlo
    ax.plot(pts_rand[:, 0], pts_rand[:, 1], 'ko--', markersize=3, lw=0.6, alpha=0.3)
    
    ax.set_title(
        f"Design Aleatório #{i+1} ({diff_massa:+.1f}% Massa)\n"
        f"Esp.Sup: {params_rand['espessura_sup']:.0f}mm | Esp.Inf: {params_rand['espessura_inf']:.0f}mm | L: {params_rand['largura_ombro']:.0f}mm",
        fontsize=10, fontweight='bold'
    )
    ax.axis('equal')
    ax.grid(True, linestyle='--', alpha=0.4)
    ax.legend(loc='lower left', fontsize=8)

# --- 6º SUBPLOT: SOBREPOSIÇÃO DE TODOS OS DESIGNS (ENVELOPE DE SOLUÇÕES) ---
ax_comp = axes[5]
ax_comp.fill(cima_x, cima_y, 'limegreen', edgecolor='darkgreen', lw=1.5, alpha=0.9, label="Preserve Geometry")
ax_comp.fill(baixo_x, baixo_y, 'limegreen', edgecolor='darkgreen', lw=1.5, alpha=0.9)
ax_comp.plot(sketch_cad_base[:, 0], sketch_cad_base[:, 1], 'k--', lw=2, label="Base Original")

for i, (sk_r, _, _, diff_m) in enumerate(sketches_gerados):
    ax_comp.plot(sk_r[:, 0], sk_r[:, 1], color=cores_designs[i], lw=2, alpha=0.85, label=f"D#{i+1} ({diff_m:+.0f}%)")

ax_comp.set_title("Comparação: Envelope dos 5 Designs vs. Base", fontsize=11, fontweight='bold')
ax_comp.axis('equal')
ax_comp.grid(True, linestyle='--', alpha=0.4)
ax_comp.legend(loc='lower left', fontsize=8)

plt.suptitle("Exploração Algorítmica do Espaço de Design (Variação Estocástica de Parâmetros CAD)", fontsize=14, fontweight='bold')
plt.tight_layout()
plt.show()