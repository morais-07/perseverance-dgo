"""
==============================================================================
 JOELHO 3D - FASE 1: PROFUNDIDADE VARIÁVEL GUIADA PELA TENSÃO  b(s)
==============================================================================
Passagem do perfil 2D a um sólido 3D em que a 3.ª dimensão (profundidade b)
é DECIDIDA PELA FÍSICA, secção a secção ("fully stressed design"):

  Numa secção retangular t x b, todas as tensões são proporcionais a 1/b:
      sigma = N/(b t) + 6 M/(b t^2)   (e Winkler nos cotovelos, também ~1/b)
  Logo, com (sigma*b)(s) calculado para b = 1 mm (analise_esforcos.py):
      b_necessario(s) = FS * max_casos (sigma*b)(s) / sigma_admissivel

  Depois aplicam-se regras de projeto/fabrico:
      - b >= B_MIN (espessura mínima de fabrico)
      - nas faces de ligação, b = profundidade das zonas verdes (B_INTERFACE)
      - variação suave: |db/ds| <= DECLIVE_MAX (sem degraus = sem entalhes)
      - cenário de rigidez (D): se o camber passar o limite, b é escalado

A geometria é gerada só com numpy/scipy (sem depender do Rhino), como uma
malha triangular fechada -> pode ir para o Rhino, para STL (Fusion) ou para
o Grasshopper.

Uso isolado:  python joelho3d.py   (compara b constante vs b(s) nos ótimos)
==============================================================================
"""
import csv
import numpy as np
from matplotlib.path import Path
from scipy.spatial import Delaunay
from scipy.ndimage import gaussian_filter1d

import analise_esforcos as ae
import gerador_variantes as gv

# ==============================================================================
# 1. PARÂMETROS 3D
# ==============================================================================
B_INTERFACE = gv.B_MM   # mm, profundidade das zonas verdes (= b do 2D; PROVISÓRIO)
B_MIN = 8.0             # mm, profundidade mínima (fabrico / robustez)
DECLIVE_MAX = 0.5       # |db/ds| máximo (~27°): transições suaves
L_TRANSICAO = 25.0      # mm, comprimento da transição junto às faces verdes
PASSO_MALHA = 4.0       # mm, tamanho dos triângulos

# ------------------------------------------------------------------------------
# Cargas FORA DO PLANO (direção de marcha, Z). No 2D eram ignoradas; com b
# variável tornam-se críticas (flexão lateral ~1/b^2 e torção da secção).
# Força longitudinal no ponto de contacto roda-solo:
# ------------------------------------------------------------------------------
FORA_PLANO = {
    'A': ('tração (fadiga)',      0.3 * 1.5 * gv.W),     # tração repetida
    'B': ('subir rocha (3W)',     gv.F_ARESTA * gv.W),   # roda contra degrau de rocha
    'C': ('subir rocha (3W)',     gv.F_ARESTA * gv.W),
    'D': ('tração (estática)',    0.3 * gv.W),
}


# ==============================================================================
# 2. ENVOLVENTE DE TENSÕES DE UM CENÁRIO (por secção, b = 1 mm)
# ==============================================================================
def envolvente(sk, cen):
    """sigma*b (N/mm) máximo de todos os casos do cenário, em cada secção,
    e integrando de rigidez 12 M / t^3 de cada caso de rigidez."""
    gv._init()
    anc = gv._NS['ancoras_verdes']
    s, S, tang, t, rho = ae.eixo_medio(sk, anc, res=0.5, n_pts=400)
    pts = gv.pontos_roda()
    y_rocha = gv._P[1] + gv.H_ROCHA
    perto = np.abs(sk[:, 1] - y_rocha) < 6
    Pj = sk[perto][np.argmin(sk[perto][:, 0])] if perto.any() else None

    def caso(nome):
        c = gv.CASOS[nome]
        if c['onde'] == 'joelho':
            if Pj is None:
                return np.zeros(len(s))
            k0 = int(np.argmin(np.hypot(*(S - Pj).T)))
            return ae.esforcos(S, tang, Pj, c['F'], k_aplic=k0)
        return ae.esforcos(S, tang, pts[c['onde']], c['F'])

    sigb = np.zeros(len(s))
    crit = np.full(len(s), '', dtype=object)
    casos_plano = []          # (nome, N, V, M, fator_curva) -> usado pela secção em I
    for nome in cen['casos']:
        r = caso(nome)
        if isinstance(r, np.ndarray):
            continue
        vm, _, _, fc = ae.tensoes(*r, t, rho, b=1.0)
        casos_plano.append((nome, *r, fc))
        maior = vm > sigb
        sigb[maior] = vm[maior]; crit[maior] = nome
    rig = [12.0 * caso(n)[2] / t ** 3 for n in cen['casos_rigidez']]

    # --- fora do plano: força Fz (marcha) no ponto de contacto ---
    #   M = r x F = (ry Fz, -rx Fz, 0)  ->  torção T = M.tang, flexão Mn = M.n
    if 'Fz' in cen:                                   # cenário de planeta
        nome_fp, Fz = cen['nome_fp'], cen['Fz']
    else:                                             # cenários de missão A-D
        letra = next(k for k in FORA_PLANO if cen_nome(cen).startswith(k + '.'))
        nome_fp, Fz = FORA_PLANO[letra]
    r = pts['plano'] - S
    T = (r[:, 1] * tang[:, 0] - r[:, 0] * tang[:, 1]) * Fz
    Mn = -(r[:, 0] * tang[:, 0] + r[:, 1] * tang[:, 1]) * Fz
    return dict(s=s, S=S, tang=tang, t=t, rho=rho, sigb=sigb, crit=crit, rig=rig,
                T=np.abs(T), Mn=np.abs(Mn), nome_fp=nome_fp, Fz=Fz,
                casos_plano=casos_plano)


def cen_nome(cen):
    return next(k for k, v in gv.CENARIOS.items() if v is cen)


def sigma_fora_plano(env, b):
    """Von Mises da flexão lateral + torção numa secção retangular t x b."""
    t = env['t']
    sb = 6.0 * env['Mn'] / (t * b ** 2)
    a, c = np.maximum(t, b), np.minimum(t, b)
    tau = env['T'] * (3 * a + 1.8 * c) / (a ** 2 * c ** 2)   # Roark/Young
    return np.sqrt(sb ** 2 + 3 * tau ** 2)


def b_fora_plano(env, FS, adm, b_max=400.0):
    """Menor b com FS * sigma_fora_plano(b) <= adm (bisseção, secção a secção)."""
    lo = np.full(len(env['s']), 0.5); hi = np.full(len(env['s']), b_max)
    for _ in range(50):
        mid = 0.5 * (lo + hi)
        ok = FS * sigma_fora_plano(env, mid) <= adm
        hi = np.where(ok, mid, hi); lo = np.where(ok, lo, mid)
    return hi


# ==============================================================================
# 3. LEI DA PROFUNDIDADE b(s)
# ==============================================================================
def _regras_b(b_nec, s):
    """Regras de projeto/fabrico (só aumentam b): suavizar, mínimo, transição
    para a profundidade das zonas verdes nas pontas, declive máximo."""
    b = gaussian_filter1d(b_nec, 2.0, mode='nearest')
    b = np.maximum(b, b_nec)                      # suavizar sem baixar
    b = np.maximum(b, B_MIN)
    d_ponta = np.minimum(s - s[0], s[-1] - s)
    w = np.clip(1 - d_ponta / L_TRANSICAO, 0, 1)
    w = w * w * (3 - 2 * w)                       # curva suave
    b = np.maximum(b, w * B_INTERFACE + (1 - w) * b)
    b[d_ponta < 1e-6] = max(B_INTERFACE, b[d_ponta < 1e-6].max())
    ds = np.diff(s)
    for i in range(1, len(b)):
        b[i] = max(b[i], b[i - 1] - DECLIVE_MAX * ds[i - 1])
    for i in range(len(b) - 2, -1, -1):
        b[i] = max(b[i], b[i + 1] - DECLIVE_MAX * ds[i])
    return b


def lei_profundidade(env, cen, mat, modo='variavel', b_const=B_INTERFACE):
    s = env['s']
    adm = mat['sf'] if cen['criterio'] == 'fadiga' else mat['sy']
    integ = np.trapezoid if hasattr(np, 'trapezoid') else np.trapz
    rigidez = cen['theta_max'] is not None and env['rig']

    def cam(bb):            # camber [graus] = int 12M/(E b t^3) ds
        return np.degrees(max(abs(integ(r / bb, s)) for r in env['rig']) / mat['E'])

    if modo == 'constante':
        b = np.full(len(s), float(b_const))
    else:
        b_res = cen['FS'] * env['sigb'] / adm                    # resistência no plano
        b_res = np.maximum(b_res, b_fora_plano(env, cen['FS'], adm))   # e fora do plano
        b = _regras_b(b_res, s)
        if rigidez and cam(b) > cen['theta_max']:
            # rigidez (cenário D): distribuição ÓTIMA por multiplicadores de Lagrange
            #   min int b t ds  s.a.  int k/b ds = theta_max ,  k = 12|M|/(E t^3)
            #   -> b(s) = max(b_res, lambda sqrt(k/t)), com lambda tal que o camber
            #      FINAL (já com as regras de fabrico) fica exatamente no limite.
            forma = np.sqrt((np.max(np.abs(env['rig']), axis=0) / mat['E']) / env['t'])
            def b_de(lam):
                return _regras_b(np.maximum(b_res, lam * forma), s)
            lo, hi = 0.0, 1.0
            while cam(b_de(hi)) > cen['theta_max']:
                hi *= 2.0
            for _ in range(60):                                  # bisseção em lambda
                mid = 0.5 * (lo + hi)
                if cam(b_de(mid)) > cen['theta_max']:
                    lo = mid
                else:
                    hi = mid
            b = b_de(hi)
    camber = cam(b) if rigidez else 0.0
    fs_plano = adm / np.maximum(env['sigb'] / b, 1e-9)
    fs_fora = adm / np.maximum(sigma_fora_plano(env, b), 1e-9)
    fs = np.minimum(fs_plano, fs_fora)
    return b, fs, camber


# ==============================================================================
# 4. MALHA 3D FECHADA (numpy, sem Rhino)
# ==============================================================================
def _contorno_ccw(sk, passo):
    poly = sk[:-1] if np.allclose(sk[0], sk[-1]) else sk
    x, y = poly[:, 0], poly[:, 1]
    if 0.5 * (np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1))) < 0:
        poly = poly[::-1]
    fechado = np.vstack([poly, poly[:1]])
    B = gv.densificar(fechado, passo)[:-1]
    manter = np.r_[True, np.hypot(*np.diff(B, axis=0).T) > 1e-6]
    return B[manter]


def malha(sk, env, b, passo=PASSO_MALHA):
    """Devolve vértices V (n x 3), faces F (m x 3) e, por vértice, o índice
    da secção do eixo médio que o governa."""
    B = _contorno_ccw(sk, passo * 0.75)
    nb = len(B)
    caminho = Path(np.vstack([B, B[:1]]))
    xmin, ymin = B.min(0); xmax, ymax = B.max(0)
    gx, gy = np.meshgrid(np.arange(xmin, xmax, passo), np.arange(ymin, ymax, passo))
    G = np.c_[gx.ravel(), gy.ravel()]
    G[1::2] += [passo / 2, 0]                         # grelha em quincôncio
    G = G[caminho.contains_points(G)]
    if len(G):
        dmin = np.array([np.min(np.hypot(*(B - g).T)) for g in G])
        G = G[dmin > 0.45 * passo]
    P2 = np.vstack([B, G])
    tri = Delaunay(P2).simplices
    cen = P2[tri].mean(axis=1)
    tri = tri[caminho.contains_points(cen)]
    # orientar todos os triângulos no sentido direto (normal +z)
    a, bb, c = P2[tri[:, 0]], P2[tri[:, 1]], P2[tri[:, 2]]
    cruz = (bb[:, 0] - a[:, 0]) * (c[:, 1] - a[:, 1]) - (bb[:, 1] - a[:, 1]) * (c[:, 0] - a[:, 0])
    tri[cruz < 0] = tri[cruz < 0][:, [0, 2, 1]]
    tri = tri[np.abs(cruz) > 1e-9]

    # profundidade de cada vértice = b da secção do eixo mais próxima
    S = env['S']
    idx = np.array([int(np.argmin(np.hypot(*(S - p).T))) for p in P2])
    bv = b[idx]
    zc = B_INTERFACE / 2.0                            # plano médio = das zonas verdes
    n = len(P2)
    V = np.vstack([np.c_[P2, zc + bv / 2], np.c_[P2, zc - bv / 2]])
    topo = tri
    fundo = tri[:, [0, 2, 1]] + n
    i = np.arange(nb); j = (i + 1) % nb
    lado = np.vstack([np.c_[i + n, j + n, j], np.c_[i + n, j, i]])
    F = np.vstack([topo, fundo, lado])
    return V, F, np.r_[idx, idx]


def volume_malha(V, F):
    a, b, c = V[F[:, 0]], V[F[:, 1]], V[F[:, 2]]
    return float(np.sum(np.einsum('ij,ij->i', a, np.cross(b, c))) / 6.0)


def malha_estanque(F):
    """Cada aresta tem de pertencer a exatamente 2 triângulos (com sentidos opostos)."""
    E = np.vstack([F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]])
    dirigidas = {tuple(e) for e in E}
    return len(dirigidas) == len(E) and all((b, a) in dirigidas for a, b in dirigidas)


def gravar_stl(caminho, V, F, nome='joelho'):
    with open(caminho, 'w') as f:
        f.write(f'solid {nome}\n')
        for t in F:
            p = V[t]
            nrm = np.cross(p[1] - p[0], p[2] - p[0])
            nrm = nrm / (np.linalg.norm(nrm) + 1e-12)
            f.write(f' facet normal {nrm[0]:.6e} {nrm[1]:.6e} {nrm[2]:.6e}\n  outer loop\n')
            for q in p:
                f.write(f'   vertex {q[0]:.6e} {q[1]:.6e} {q[2]:.6e}\n')
            f.write('  endloop\n endfacet\n')
        f.write(f'endsolid {nome}\n')


# ==============================================================================
# 5. FUNÇÃO PRINCIPAL
# ==============================================================================
def gerar(params=None, cenario=None, material='Al 7075-T6 (CNC)', modo='variavel',
          sketch=None, b_const=B_INTERFACE, com_malha=True):
    """params: dict dos 14 parâmetros (None + sketch=None -> peça original).
    cenario: chave (ou início da chave) de gv.CENARIOS."""
    gv._init()
    if sketch is None:
        if params is None:
            sketch = gv._NS['sketch_cad_base']
        else:
            sketch, _ = gv.construir_sketch_v2(gv._NS['ancoras_verdes'], params)
    cn = gv.chave_cenario(cenario) if cenario else list(gv.CENARIOS)[1]
    cen, mat = gv.CENARIOS[cn], gv.material(cn, material)   # corrigido pela temperatura
    env = envolvente(sketch, cen)
    b, fs, camber = lei_profundidade(env, cen, mat, modo, b_const)
    out = dict(sketch=sketch, env=env, b=b, fs=fs, camber=camber, cenario=cn,
               material=material, modo=modo, FS_min=float(fs.min()),
               FS_req=cen['FS'], theta_max=cen['theta_max'])
    if com_malha:
        V, F, idx = malha(sketch, env, b)
        vol = volume_malha(V, F)
        out.update(V=V, F=F, idx=idx, volume_mm3=vol,
                   massa_kg=vol * mat['rho'] * 1e-9,
                   utilizacao=(cen['FS'] / fs)[idx])      # 1.0 = no limite
    return out


# ==============================================================================
# 6. COMPARAÇÃO: b constante vs b(s) nos designs ótimos
# ==============================================================================
if __name__ == '__main__':
    import sys
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import os
    os.makedirs('diag', exist_ok=True)

    linhas = list(csv.DictReader(open('diag/designs_otimos.csv', encoding='utf-8-sig'),
                                 delimiter=';'))
    print(f'{"Cenário":28s}{"Material":24s}{"b const kg":>11s}{"b(s) kg":>9s}'
          f'{"ganho":>8s}{"FS min":>8s}{"b min-max mm":>15s}')
    res = []
    for l in linhas:
        if l['massa_kg'] in ('', 'nan'):
            continue
        p = {k: float(l[k]) for k in gv.NOMES}
        cn = l['cenario'][:2]
        c = gerar(p, cn, l['material'], 'constante')
        v = gerar(p, cn, l['material'], 'variavel')
        ganho = 100 * (1 - v['massa_kg'] / c['massa_kg'])
        res.append((l, c, v))
        print(f'{l["cenario"][:27]:28s}{l["material"]:24s}{c["massa_kg"]:11.2f}'
              f'{v["massa_kg"]:9.2f}{-ganho:+7.0f}%{v["FS_min"]:8.2f}'
              f'{v["b"].min():8.1f}-{v["b"].max():5.1f}')

    # figura: um exemplo (B, Al) em 3D + lei b(s)
    l, c, v = next(r for r in res if r[0]['cenario'].startswith('B') and
                   r[0]['material'].startswith('Al 7075'))
    fig = plt.figure(figsize=(16, 6.5))
    ax = fig.add_subplot(1, 2, 1, projection='3d')
    V, F = v['V'], v['F']
    cores = plt.cm.turbo(np.clip(v['utilizacao'][F].mean(axis=1), 0, 1))
    ax.plot_trisurf(V[:, 0], V[:, 1], V[:, 2], triangles=F, color='w', lw=0, alpha=0)
    from mpl_toolkits.mplot3d.art3d import Poly3DCollection
    pc = Poly3DCollection(V[F], facecolors=cores, edgecolor='none')
    ax.add_collection3d(pc)
    lo, hi = V.min(0), V.max(0)
    ax.set_xlim(lo[0], hi[0]); ax.set_ylim(lo[1], hi[1]); ax.set_zlim(lo[2], hi[2])
    ax.set_box_aspect(hi - lo)                       # escala real nos 3 eixos
    ax.view_init(35, -60)
    ax.set_title(f'B. Terreno acidentado | Al 7075 | b(s) guiado pela tensão\n'
                 f'{v["massa_kg"]:.2f} kg (b const: {c["massa_kg"]:.2f} kg) | '
                 f'cor = utilização (vermelho = no limite FS {v["FS_req"]})', fontsize=10)
    ax2 = fig.add_subplot(1, 2, 2)
    s = v['env']['s']
    ax2.plot(s, v['FS_req'] * v['env']['sigb'] / gv.MATERIAIS[l['material']]['sy'],
             'r:', label='b necessário só no plano (FS 2)')
    ax2.plot(s, v['b'], 'b-', lw=2.5, label='b(s) adotado')
    ax2.axhline(B_INTERFACE, color='k', ls='--', lw=1, label=f'b constante = {B_INTERFACE:.0f} mm')
    ax2.set_xlabel('s ao longo do eixo médio [mm] (0 = direção → cubo)')
    ax2.set_ylabel('profundidade b [mm]')
    ax2.grid(ls='--', alpha=.4); ax2.legend()
    ax2.set_title('Lei da profundidade: física + regras de fabrico', fontweight='bold')
    plt.tight_layout()
    fig.savefig('diag/joelho3d_exemplo.png', dpi=120, bbox_inches='tight')
    gravar_stl('diag/joelho3d_B_Al7075.stl', v['V'], v['F'])
    print('[OK] diag/joelho3d_exemplo.png, diag/joelho3d_B_Al7075.stl')
