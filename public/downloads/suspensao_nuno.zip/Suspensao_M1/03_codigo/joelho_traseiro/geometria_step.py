"""
==============================================================================
 GEOMETRIA DO JOELHO A PARTIR DO STEP  (substitui o print + segmentação + escala)
==============================================================================
Do assembly STEP exportado do Fusion tira-se, para o joelho:
  1. o PLANO 2D certo: eixo da roda (u) x vertical (w), com origem no centro
     da roda (a roda pode estar rodada pela direção -> o plano acompanha);
  2. a SILHUETA exata do joelho nesse plano (projeção de todas as faces);
  3. as ZONAS A PRESERVAR, por uma regra física: tudo o que fica dentro da
     largura da roda (face interior do pneu + folga) é interface (braço por
     cima do pneu até à direção e cubo dentro da roda);
  4. os DADOS DA RODA: raio exterior/interior do pneu, largura, centro;
  5. a PROFUNDIDADE real do braço (dimensão perpendicular ao plano).
Grava diag/geometria_joelho.json, que o analise_esforcos.py passa a usar.

Uso:  python geometria_step.py "C:/.../suspensao_v1.step" ["joelho traserio:1"] ["roda:1"]
==============================================================================
"""
import sys
import json
import numpy as np
import cv2

import leitor_step as ls

RES = 0.25            # mm por píxel na rasterização da silhueta
FOLGA_PNEU = 20.0     # mm: a zona a preservar começa na face interior do pneu + folga


def _ciclo(P, eps):
    """Simplifica um contorno fechado (Douglas-Peucker) mantendo a forma."""
    c = cv2.approxPolyDP(P.astype(np.float32).reshape(-1, 1, 2), eps, True)
    return c.reshape(-1, 2).astype(float)


def extrair(step, nome_joelho='joelho traserio:1', nome_roda='roda:1', folga=FOLGA_PNEU):
    inv = ls.inventario(step)
    J = next(p for p in inv['pecas'] if p['nome'] == nome_joelho)
    R = next(p for p in inv['pecas'] if p['nome'] == nome_roda)

    # ---- roda: o cilindro maior (veio) = banda de rodagem; o furo = interior do pneu
    cil_r = [c for c in R['cilindros'] if c['tipo'] in ('furo', 'veio')]
    ext = max(cil_r, key=lambda c: c['raio_mm'])
    inn = min(cil_r, key=lambda c: c['raio_mm'])
    u = np.array(ext['eixo_global'], float); u[2] = 0.0; u /= np.linalg.norm(u)
    w = np.array([0, 0, 1.0])
    c_roda = np.array(ext['centro_global_mm'], float)
    # orientar u do joelho para a roda (coluna do joelho com u negativo)
    Pj = np.vstack(J['_loops_globais'])
    if ((Pj - c_roda) @ u).mean() > 0:
        u = -u
    v = np.cross(w, u)                                   # normal ao plano 2D
    largura = max(ext['comprimento_mm'], inn['comprimento_mm'])

    def p2(P):
        d = P - c_roda
        return np.c_[d @ u, d @ w]

    # ---- silhueta: projetar e pintar todas as faces (laços) do joelho
    L2 = [p2(L) for L in J['_loops_globais']]
    todos = np.vstack(L2)
    lo = todos.min(0) - 5; hi = todos.max(0) + 5
    W, H = (np.ceil((hi - lo) / RES)).astype(int) + 1
    mask = np.zeros((H, W), np.uint8)
    def px(P):
        q = (P - lo) / RES
        return np.c_[q[:, 0], H - 1 - q[:, 1]].round().astype(np.int32)   # y para cima
    for L in L2:
        if len(L) >= 3:
            cv2.fillPoly(mask, [px(L)], 255)
    # superfícies cilíndricas e cónicas: amostrar a própria superfície (as arestas
    # de um cilindro com o eixo no plano projetam-se como linhas e não cobrem nada)
    for sf in J['_superficies_globais']:
        M, R, t, esc = sf['M'], sf['R'], sf['t'], sf['escala']
        o, x, y, z = M[:3, 3] * esc, M[:3, 0], M[:3, 1], M[:3, 2]
        # intervalo angular REAL da face: desenrolar o ângulo ao longo de cada laço
        angs, vv = [], []
        ref = None
        for L in sf['loops']:
            dq = L - o
            a = np.unwrap(np.arctan2(dq @ y, dq @ x))
            if ref is None:
                ref = a.mean()
            a = a - 2 * np.pi * np.round((a.mean() - ref) / (2 * np.pi))
            angs.append(a); vv.append(dq @ z)
        angs = np.concatenate(angs); vv = np.concatenate(vv)
        a0, a1 = angs.min(), angs.max()
        if a1 - a0 > 2 * np.pi - np.radians(15):          # volta completa
            a0, a1 = 0.0, 2 * np.pi
        us = np.linspace(a0, a1, 73)
        vs = np.linspace(vv.min(), vv.max(), 3)
        UU, VV = np.meshgrid(us, vs)
        rho = (R * esc) + t * VV
        P = (o + (rho * np.cos(UU))[..., None] * x + (rho * np.sin(UU))[..., None] * y
             + VV[..., None] * z)
        Q2 = p2(P.reshape(-1, 3)).reshape(P.shape[0], P.shape[1], 2)
        for i in range(Q2.shape[0] - 1):
            for j in range(Q2.shape[1] - 1):
                quad = np.array([Q2[i, j], Q2[i, j + 1], Q2[i + 1, j + 1], Q2[i + 1, j]])
                cv2.fillPoly(mask, [px(quad)], 255)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
    def mm(c):
        c = c.reshape(-1, 2).astype(float)
        return np.c_[c[:, 0] * RES + lo[0], (H - 1 - c[:, 1]) * RES + lo[1]]

    # ---- separar: interface (dentro da largura da roda) vs zona de projeto
    x_s = -largura / 2 + folga
    col_s = int(round((x_s - lo[0]) / RES))
    cinz = mask.copy(); cinz[:, col_s:] = 0
    verde = mask.copy(); verde[:, :col_s] = 0
    cs, _ = cv2.findContours(cinz, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    cinzento = mm(max(cs, key=cv2.contourArea))
    n, lab, stats, _ = cv2.connectedComponentsWithStats(verde)
    comps = sorted(range(1, n), key=lambda i: -stats[i, cv2.CC_STAT_AREA])[:2]
    verdes = []
    for i in comps:
        cc, _ = cv2.findContours((lab == i).astype(np.uint8) * 255, cv2.RETR_EXTERNAL,
                                 cv2.CHAIN_APPROX_NONE)
        verdes.append(mm(max(cc, key=cv2.contourArea)))
    cima, baixo = sorted(verdes, key=lambda P: -P[:, 1].mean())

    # ---- âncoras: onde o cinzento encontra cada zona verde (coluna x_s)
    coluna = cinz[:, col_s - 2] > 0
    runs = np.flatnonzero(np.diff(np.r_[0, coluna.astype(int), 0]))
    trocos = [((H - 1 - b) * RES + lo[1], (H - 1 - (a)) * RES + lo[1])
              for a, b in zip(runs[::2], runs[1::2] - 1)]
    trocos = sorted(trocos, key=lambda t: -t[1])          # (y_inf, y_sup), de cima para baixo
    (yci, ycs), (ybi, ybs) = trocos[0], trocos[-1]
    ancoras = (x_s, ycs, yci, x_s, ybs, ybi)

    # ---- profundidade real do braço (perpendicular ao plano), só na zona de projeto
    Pg = np.vstack(J['_loops_globais'])
    xg = (Pg - c_roda) @ u
    prof = (Pg[xg < x_s] - c_roda) @ v
    b_real = float(np.percentile(prof, 99.5) - np.percentile(prof, 0.5))
    prof_v = (Pg[xg >= x_s] - c_roda) @ v

    out = dict(
        fonte=step, joelho=nome_joelho, roda=nome_roda,
        referencial=dict(origem_mm=c_roda.tolist(), u=u.tolist(), w=w.tolist(), v=v.tolist(),
                         nota='x2D = (P-origem).u (eixo da roda, para a roda); y2D = (P-origem).w (vertical)'),
        roda_dados=dict(raio_ext_mm=ext['raio_mm'], raio_int_mm=inn['raio_mm'],
                        largura_mm=largura, centro_2D=[0.0, 0.0],
                        x_face_interior=-largura / 2, x_plano_medio=0.0),
        folga_pneu_mm=folga, x_fronteira_preservar=x_s,
        ancoras=list(map(float, ancoras)),
        profundidade_braco_mm=b_real,
        profundidade_interfaces_mm=float(np.ptp(prof_v)),
        contorno_cinzento=_ciclo(cinzento, 0.15).tolist(),
        verde_cima=_ciclo(cima, 0.15).tolist(),
        verde_baixo=_ciclo(baixo, 0.15).tolist(),
        silhueta=_ciclo(mm(max(cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[0],
                                key=cv2.contourArea)), 0.15).tolist(),
        cilindros_joelho=[c for c in J['cilindros'] if c['tipo'] in ('furo', 'veio')],
    )
    return out


def figura(g, caminho='diag/geometria_joelho_step.png'):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(10, 11))
    r = g['roda_dados']
    from matplotlib.patches import Rectangle
    for s in (+1, -1):
        y0 = s * r['raio_int_mm']
        ax.add_patch(Rectangle((-r['largura_mm'] / 2, min(y0, y0 + s * (r['raio_ext_mm'] - r['raio_int_mm']))),
                               r['largura_mm'], r['raio_ext_mm'] - r['raio_int_mm'], color='0.6', alpha=.5))
    ax.axhline(-r['raio_ext_mm'], color='saddlebrown', lw=1.5); ax.text(-480, -r['raio_ext_mm'] + 6, 'solo')
    ax.axvline(0, color='k', ls='-.', lw=.8); ax.text(4, 260, 'plano médio da roda', fontsize=8)
    ax.axvline(g['x_fronteira_preservar'], color='g', ls='--', lw=1)
    C = np.array(g['contorno_cinzento']); ax.fill(*C.T, color='#cfcfcf', ec='k', lw=1, label='zona de projeto (cinzento)')
    for k in ('verde_cima', 'verde_baixo'):
        V = np.array(g[k]); ax.fill(*V.T, color='limegreen', ec='darkgreen', alpha=.8,
                                    label='a preservar (interfaces)' if k == 'verde_cima' else None)
    a = g['ancoras']
    ax.plot([a[0]] * 2, [a[1], a[2]], 'r-', lw=3); ax.plot([a[3]] * 2, [a[4], a[5]], 'r-', lw=3,
                                                         label='faces de ligação (âncoras)')
    ax.plot(0, -r['raio_ext_mm'], 'r^', ms=12, label='contacto roda-solo')
    ax.set_aspect('equal'); ax.grid(ls='--', alpha=.4); ax.legend(loc='upper right', fontsize=9)
    ax.set_title(f"Joelho a partir do STEP (sem prints)\n{g['joelho']} | profundidade do braço ≈ "
                 f"{g['profundidade_braco_mm']:.1f} mm | roda Ø{2*r['raio_ext_mm']:.1f}, largura {r['largura_mm']:.1f} mm",
                 fontweight='bold')
    ax.set_xlabel('x = eixo da roda [mm]  (0 = plano médio)'); ax.set_ylabel('y = vertical [mm]  (0 = eixo da roda)')
    fig.savefig(caminho, dpi=110, bbox_inches='tight'); plt.close(fig)


if __name__ == '__main__':
    import os
    os.makedirs('diag', exist_ok=True)
    step = sys.argv[1]
    nj = sys.argv[2] if len(sys.argv) > 2 else 'joelho traserio:1'
    nr = sys.argv[3] if len(sys.argv) > 3 else 'roda:1'
    g = extrair(step, nj, nr)
    with open('diag/geometria_joelho.json', 'w', encoding='utf-8') as f:
        json.dump(g, f, ensure_ascii=False, indent=1)
    figura(g)
    r = g['roda_dados']
    print(f"Joelho: {g['joelho']} | roda: {g['roda']}")
    print(f"Roda: raio ext {r['raio_ext_mm']:.2f} mm, int {r['raio_int_mm']:.2f} mm, largura {r['largura_mm']:.1f} mm")
    print(f"Fronteira da zona a preservar: x = {g['x_fronteira_preservar']:.1f} mm (face interior do pneu + {g['folga_pneu_mm']:.0f})")
    a = g['ancoras']
    print(f"Âncoras: face de cima y = [{a[2]:.1f}, {a[1]:.1f}] ({a[1]-a[2]:.1f} mm) | "
          f"face de baixo y = [{a[5]:.1f}, {a[4]:.1f}] ({a[4]-a[5]:.1f} mm)")
    print(f"Profundidade do braço (zona de projeto): {g['profundidade_braco_mm']:.1f} mm | "
          f"das interfaces: {g['profundidade_interfaces_mm']:.1f} mm")
    print('[OK] diag/geometria_joelho.json, diag/geometria_joelho_step.png')
