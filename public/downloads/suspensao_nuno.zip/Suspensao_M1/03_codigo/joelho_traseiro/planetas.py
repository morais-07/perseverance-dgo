"""
==============================================================================
 PERFIS DE PLANETA - o planeta passa a ser o "motor" das variantes
==============================================================================
Cada destino muda 4 coisas na peça:
  1. GRAVIDADE   -> todas as cargas escalam com o peso local por roda W = m g / 6
  2. TERRENO     -> fatores dos casos de carga (queda, rocha sob a aresta, atrito)
  3. TEMPERATURA -> que materiais são possíveis e quanto perdem de resistência
  4. INCERTEZA   -> fator de segurança exigido (terreno mal conhecido = FS maior)
e acrescenta o caso de ATERRAGEM, que não depende da gravidade local: em
planetas de g baixa é ele (e não o terreno) que dimensiona a peça.

A massa do rover é igual em todos (1025 kg) para comparar só o efeito do planeta.

Valores de gravidade e temperatura: dados planetários conhecidos.
Fatores de terreno, velocidades de aterragem e FS: HIPÓTESES DE PROJETO
(justificar no relatório). Propriedades a quente: valores típicos de
literatura, a confirmar nas fichas técnicas.
==============================================================================
"""
import numpy as np

M_ROVER = 1025.0          # kg, igual em todos os planetas
D_ATERRAGEM = 0.10        # m, curso que absorve o toque (roda + suspensão)
F_EMBATE = 4.0            # rocha a bater no joelho (como em Marte)

# ------------------------------------------------------------------------------
# 1. PERFIS
#   g        gravidade à superfície [m/s2]
#   T        temperatura de operação (mín, máx) [°C]
#   h, d     queda: altura do buraco/degrau e distância de paragem [mm] -> fator 1 + h/d
#   aresta   rocha concentrada sob a aresta da roda / subir degrau (x W)
#   mu       atrito roda-solo: limita a força LATERAL (x força vertical)
#   v_toque  velocidade vertical no toque da aterragem [m/s]
#   FS       fator de segurança exigido (cresce com a incerteza sobre o terreno)
# ------------------------------------------------------------------------------
PLANETAS = {
    'Mercúrio': dict(
        g=3.70, T=(-180, 430), h=200, d=30, aresta=3.5, mu=0.6, v_toque=1.5, FS=2.2,
        cor='#8E8E8E',
        ambiente='Vácuo; dia a 430 °C e noite a -180 °C (ciclo térmico enorme).',
        terreno='Regolito e crateras como na Lua, blocos soltos.',
        aterragem='Retrofoguetes (sem atmosfera).'),
    'Vénus': dict(
        g=8.87, T=(440, 465), h=150, d=30, aresta=3.0, mu=0.6, v_toque=2.0, FS=2.5,
        cor='#D4AC0D',
        ambiente='465 °C constantes, 92 bar de CO2, nuvens de ácido sulfúrico.',
        terreno='Planícies de basalto e terrenos de placas (tesserae).',
        aterragem='Paraquedas + atmosfera densa; toque mais duro.'),
    'Lua': dict(
        g=1.62, T=(-173, 127), h=200, d=30, aresta=3.5, mu=0.6, v_toque=1.5, FS=2.0,
        cor='#5D6D7E',
        ambiente='Vácuo; -173 °C à noite, +127 °C de dia.',
        terreno='Regolito abrasivo, crateras e blocos; bem conhecido (amostras Apollo).',
        aterragem='Retrofoguetes (sem atmosfera).'),
    'Marte': dict(
        g=3.71, T=(-125, 20), h=150, d=30, aresta=3.0, mu=0.6, v_toque=0.75, FS=2.0,
        cor='#C0392B',
        ambiente='CO2 rarefeito (0,6 kPa), -125 a +20 °C. Referência (Perseverance).',
        terreno='Rochas, areia e buracos (casos B/C anteriores).',
        aterragem='Sky crane, toque a ~0,75 m/s (Perseverance).'),
    'Titã': dict(
        g=1.35, T=(-180, -178), h=150, d=60, aresta=2.0, mu=0.4, v_toque=1.0, FS=2.2,
        cor='#E67E22',
        ambiente='-179 °C, 1,5 bar de azoto, chuva de metano.',
        terreno='Areia orgânica mole e seixos de gelo arredondados (Huygens).',
        aterragem='Paraquedas em atmosfera densa e g baixa: toque suave.'),
    'Europa': dict(
        g=1.31, T=(-190, -150), h=200, d=20, aresta=4.0, mu=0.5, v_toque=1.5, FS=2.5,
        cor='#5DADE2',
        ambiente='Vácuo, -160 °C, radiação intensa de Júpiter.',
        # gelo muito frio NÃO é escorregadio: a ~-100 °C mu ~ 0.5 (atrito seco); só perto
        # de -7 °C cai para ~0.01 (Weber et al., AMOLF, 'Molecular insight into the slipperiness of ice')
        terreno='Gelo duro (a -160 °C não é escorregadio: atrito ~0,5), cristas e possíveis lâminas de gelo.',
        aterragem='Retrofoguetes (sem atmosfera).'),
    'Io': dict(
        g=1.80, T=(-160, -130), h=150, d=25, aresta=3.5, mu=0.4, v_toque=1.5, FS=2.5,
        cor='#F4D03F',
        ambiente='Vácuo, ~-140 °C, geada de enxofre, vulcanismo ativo.',
        terreno='Planícies de lava arrefecida, rugosas e com arestas vivas.',
        aterragem='Retrofoguetes (sem atmosfera).'),
}


def peso_roda(p):
    """W local por roda [N]."""
    return M_ROVER * PLANETAS[p]['g'] / 6.0


def fatores(p):
    """Fatores de carga (x W local) do planeta."""
    P = PLANETAS[p]
    f_queda = 1.0 + P['h'] / P['d']
    # aterragem: F = m (g + v^2 / 2d)  ->  em unidades de W local: 1 + v^2 / (2 d g)
    f_aterr = 1.0 + P['v_toque'] ** 2 / (2 * D_ATERRAGEM * P['g'])
    return dict(queda=f_queda, aresta=P['aresta'], embate=F_EMBATE,
                aterragem=f_aterr, mu=P['mu'])


# ------------------------------------------------------------------------------
# 2. MATERIAIS EM FUNÇÃO DA TEMPERATURA
#   fator de resistência a quente (cedência e fadiga): tabela (T °C, fator)
#   T_lim: acima disto o material não serve (sobre-envelhecimento / perde tudo)
#   cryo_ok: aguenta abaixo de -150 °C sem ficar frágil (ductilidade suficiente)
# ------------------------------------------------------------------------------
TERMICO = {
    'Al 7075-T6 (CNC)':      dict(tab=[(20, 1.0), (100, 0.90), (150, 0.70), (175, 0.50)],
                                  T_lim=175, cryo_ok=True),
    'Ti-6Al-4V (CNC)':       dict(tab=[(20, 1.0), (100, 0.90), (200, 0.83), (300, 0.75),
                                       (400, 0.68), (500, 0.62)], T_lim=500, cryo_ok=True),
    'Ti-6Al-4V (L-PBF+HIP)': dict(tab=[(20, 1.0), (100, 0.90), (200, 0.83), (300, 0.75),
                                       (400, 0.68), (500, 0.62)], T_lim=500, cryo_ok=True),
    'AlSi10Mg (L-PBF)':      dict(tab=[(20, 1.0), (100, 0.90), (150, 0.75), (200, 0.55)],
                                  T_lim=200, cryo_ok=False),
    'Inconel 718 (CNC)':     dict(tab=[(20, 1.0), (200, 0.95), (400, 0.92), (500, 0.90),
                                       (650, 0.85)], T_lim=650, cryo_ok=True),
}
T_CRIO = -150.0


def material_no_planeta(nome, base, p):
    """Devolve (propriedades corrigidas, None) ou (None, motivo da exclusão)."""
    Tmin, Tmax = PLANETAS[p]['T']
    th = TERMICO[nome]
    if Tmax > th['T_lim']:
        return None, f'não aguenta {Tmax:.0f} °C'
    if Tmin < T_CRIO and not th['cryo_ok']:
        return None, f'frágil a {Tmin:.0f} °C'
    Ts, fs = zip(*th['tab'])
    f = float(np.interp(max(Tmax, 20.0), Ts, fs))
    return dict(base, sy=base['sy'] * f, sf=base['sf'] * f, fator_T=f), None


# ------------------------------------------------------------------------------
# 3. CASOS DE CARGA E CENÁRIOS (mesmo formato do gerador_variantes)
# ------------------------------------------------------------------------------
def casos_e_cenarios():
    casos, cenarios = {}, {}
    for p, P in PLANETAS.items():
        W = peso_roda(p)
        f = fatores(p)
        Fq = f['queda'] * W
        c = {
            f'{p}:queda':      dict(F=(0.0, Fq), onde='plano'),
            f'{p}:queda_lat+': dict(F=(+f['mu'] * Fq, Fq), onde='plano'),
            f'{p}:queda_lat-': dict(F=(-f['mu'] * Fq, Fq), onde='plano'),
            f'{p}:aresta_ext': dict(F=(0.0, f['aresta'] * W), onde='aresta_ext'),
            f'{p}:aresta_int': dict(F=(0.0, f['aresta'] * W), onde='aresta_int'),
            f'{p}:embate':     dict(F=(+f['embate'] * W, 0.0), onde='joelho'),
            f'{p}:aterragem':  dict(F=(0.0, f['aterragem'] * W), onde='plano'),
        }
        casos.update(c)
        chave = f'{p}\n(g {P["g"]:.2f} | {P["T"][0]:.0f} a {P["T"][1]:.0f} °C)'
        cenarios[chave] = dict(
            casos=list(c), criterio='cedencia', FS=P['FS'], theta_max=None,
            casos_rigidez=[], planeta=p,
            Fz=f['aresta'] * W, nome_fp=f'subir rocha ({f["aresta"]:.1f}W)',
            descricao=f'{P["ambiente"]} {P["terreno"]} {P["aterragem"]}')
    return casos, cenarios


def tabela():
    """Resumo dos perfis (para o relatório)."""
    print(f'{"Planeta":10s}{"g":>6s}{"W/roda":>9s}{"queda":>7s}{"aterr.":>8s}'
          f'{"aresta":>8s}{"mu":>6s}{"FS":>5s}  {"carga máx":>10s}  T (°C)')
    for p, P in PLANETAS.items():
        W = peso_roda(p); f = fatores(p)
        fmax = max(f['queda'] * np.hypot(1, f['mu']), f['aresta'], f['embate'], f['aterragem'])
        print(f'{p:10s}{P["g"]:6.2f}{W:8.0f} N{f["queda"]:7.1f}{f["aterragem"]:8.1f}'
              f'{f["aresta"]:8.1f}{f["mu"]:6.2f}{P["FS"]:5.1f}  {fmax * W * P["FS"]:8.0f} N'
              f'  {P["T"][0]:.0f} / {P["T"][1]:.0f}')


if __name__ == '__main__':
    tabela()
