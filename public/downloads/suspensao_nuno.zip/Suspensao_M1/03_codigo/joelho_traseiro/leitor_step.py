"""
==============================================================================
 LEITOR DE STEP (AP214/AP242) EM PYTHON PURO  -  inventário de um assembly
==============================================================================
Não precisa de CAD nem de bibliotecas especiais (só numpy/scipy/matplotlib).
Lê um STEP exportado do Fusion e devolve, para CADA PEÇA (pelo nome):
  - árvore do assembly, instâncias e posição global de cada uma
  - caixa envolvente (local e global), dimensões principais
  - volume e área (exatos para faces planas; aproximados se houver faces curvas)
  - furos e eixos: faces cilíndricas (raio, eixo, posição, comprimento,
    furo ou veio)
  - origem provável da geometria (modelada vs. malha convertida/facetada)
e, entre peças:
  - EIXOS COMUNS (cilindros coaxiais em peças diferentes -> articulações)
  - CONTACTOS (superfícies a menos de 0.5 mm)

Uso:   python leitor_step.py "caminho/para/assembly.step"
Saída: diag/inventario.json, diag/inventario.csv, diag/inventario_assembly.png
==============================================================================
"""
import re
import sys
import json
import math
import numpy as np

# ==============================================================================
# 1. PARSER DE ENTIDADES STEP
# ==============================================================================
class Ref(int):
    """Referência a outra entidade (#123)."""
    def __repr__(self):
        return f'#{int(self)}'


def _decode_str(s):
    """Strings STEP: '' -> ', \\X\\hh -> latin-1, \\X2\\hhhh...\\X0\\ -> UTF-16."""
    s = s.replace("''", "'")
    s = re.sub(r'\\X2\\((?:[0-9A-Fa-f]{4})+)\\X0\\',
               lambda m: ''.join(chr(int(m.group(1)[i:i + 4], 16))
                                 for i in range(0, len(m.group(1)), 4)), s)
    s = re.sub(r'\\X\\([0-9A-Fa-f]{2})', lambda m: chr(int(m.group(1), 16)), s)
    return s


_TOK = re.compile(r"""\s*(?:
    (?P<str>'(?:[^']|'')*')            |
    (?P<ref>\#\d+)                      |
    (?P<enum>\.[A-Z0-9_]+\.)            |
    (?P<num>[-+]?(?:\d+\.?\d*|\.\d+)(?:[Ee][-+]?\d+)?) |
    (?P<kw>[A-Z_][A-Z0-9_]*)            |
    (?P<p>[(),$*])
)""", re.X)


def _tokens(s):
    pos = 0
    while pos < len(s):
        m = _TOK.match(s, pos)
        if not m or m.end() == pos:
            if s[pos:].strip() == '':
                return
            raise ValueError(f'STEP: não consigo ler perto de: {s[pos:pos + 40]!r}')
        pos = m.end()
        k = m.lastgroup
        yield k, m.group(k)


def _parse_seq(it, fim=')'):
    """Lê argumentos até ')' -> lista."""
    out = []
    for k, v in it:
        if k == 'p' and v == ')':
            return out
        if k == 'p' and v == ',':
            continue
        out.append(_valor(k, v, it))
    return out


def _valor(k, v, it):
    if k == 'str':
        return _decode_str(v[1:-1])
    if k == 'ref':
        return Ref(int(v[1:]))
    if k == 'enum':
        return v
    if k == 'num':
        return float(v)
    if k == 'p' and v == '$':
        return None
    if k == 'p' and v == '*':
        return '*'
    if k == 'p' and v == '(':
        return _parse_seq(it)
    if k == 'kw':                       # valor tipado, ex.: LENGTH_MEASURE(1.)
        k2, v2 = next(it)
        assert v2 == '('
        return (v, _parse_seq(it))
    raise ValueError(f'token inesperado {k}:{v}')


def parse_entidade(corpo):
    """'TIPO(args)'  ou  '( TIPO1(args) TIPO2(args) )' (entidade complexa)."""
    it = _tokens(corpo)
    k, v = next(it)
    if k == 'p' and v == '(':                      # complexa
        partes = {}
        for k, v in it:
            if k == 'p' and v == ')':
                break
            assert k == 'kw'
            next(it)                               # '('
            partes[v] = _parse_seq(it)
        return 'COMPLEXA', partes
    assert k == 'kw'
    next(it)
    return v, _parse_seq(it)


def ler_step(caminho):
    txt = open(caminho, encoding='latin-1').read()
    dados = txt[txt.index('DATA;') + 5: txt.rindex('ENDSEC')]
    dados = re.sub(r'/\*.*?\*/', '', dados, flags=re.S)
    E = {}
    for m in re.finditer(r"#(\d+)\s*=\s*((?:[^;']|'(?:[^']|'')*')*);", dados):
        E[int(m.group(1))] = parse_entidade(m.group(2))
    return E


# ==============================================================================
# 2. GEOMETRIA BÁSICA
# ==============================================================================
def _ponto(E, r):
    return np.array(E[r][1][1], float)


def _dir(E, r):
    d = np.array(E[r][1][1], float)
    return d / np.linalg.norm(d)


def placement(E, r):
    """AXIS2_PLACEMENT_3D -> matriz 4x4 (local -> contexto)."""
    _, a = E[r]
    o = _ponto(E, a[1])
    z = _dir(E, a[2]) if a[2] is not None else np.array([0, 0, 1.0])
    x = _dir(E, a[3]) if len(a) > 3 and a[3] is not None else \
        (np.array([1.0, 0, 0]) if abs(z[0]) < 0.9 else np.array([0, 1.0, 0]))
    x = x - z * (x @ z); x /= np.linalg.norm(x)
    y = np.cross(z, x)
    M = np.eye(4); M[:3, 0], M[:3, 1], M[:3, 2], M[:3, 3] = x, y, z, o
    return M


def _amostrar_aresta(E, ec_ref, passo_ang=math.radians(2)):
    """EDGE_CURVE -> polilinha do vértice inicial ao final (sentido da aresta)."""
    _, a = E[ec_ref]
    p0 = _ponto(E, E[a[1]][1][1]); p1 = _ponto(E, E[a[2]][1][1])
    curva = a[3]; mesmo = a[4] == '.T.'
    tipo, ca = E[curva]
    if tipo in ('SURFACE_CURVE', 'SEAM_CURVE'):
        curva = ca[1]; tipo, ca = E[curva]
    if tipo == 'CIRCLE' or tipo == 'ELLIPSE':
        M = placement(E, ca[1])
        c, x, y = M[:3, 3], M[:3, 0], M[:3, 1]
        ra = ca[2]; rb = ca[3] if tipo == 'ELLIPSE' else ca[2]
        def ang(p):
            d = p - c
            return math.atan2((d @ y) / rb, (d @ x) / ra)
        t0, t1 = ang(p0), ang(p1)
        if mesmo:
            dt = (t1 - t0) % (2 * math.pi)
        else:
            dt = -((t0 - t1) % (2 * math.pi))
        if abs(dt) < 1e-9:
            dt = 2 * math.pi if mesmo else -2 * math.pi
        n = max(2, int(abs(dt) / passo_ang) + 1)
        ts = t0 + np.linspace(0, dt, n + 1)
        P = c + np.outer(ra * np.cos(ts), x) + np.outer(rb * np.sin(ts), y)
        P[0], P[-1] = p0, p1
        return P
    if tipo == 'COMPLEXA' and 'B_SPLINE_CURVE' in ca:
        cps = [_ponto(E, r) for r in ca['B_SPLINE_CURVE'][1]]
        P = np.array(cps)
        if not mesmo:
            P = P[::-1]
        P[0], P[-1] = p0, p1
        return P
    if tipo == 'B_SPLINE_CURVE_WITH_KNOTS':
        P = np.array([_ponto(E, r) for r in ca[2]])
        if not mesmo:
            P = P[::-1]
        P[0], P[-1] = p0, p1
        return P
    return np.array([p0, p1])                     # LINE e outras: segmento


class Peca:
    """Geometria de uma definição de peça (referencial local)."""
    def __init__(self):
        self.solidos = 0
        self.faces = {}            # tipo -> nº
        self.loops = []            # polilinhas fechadas (orientadas)
        self.face_loops = []       # [(tipo_superficie, [loops], info)]
        self.cilindros = []        # dicts no referencial local
        self.area_plana = 0.0
        self.vol6 = 0.0            # 6 x volume (parte exata das faces planas)
        self.curvas = 0
        self.superficies = []      # cilindros/cones: geometria para amostrar a superfície


def ler_brep(E, solido_ref, peca, cache_aresta):
    tipo, a = E[solido_ref]
    if tipo != 'MANIFOLD_SOLID_BREP':
        return
    peca.solidos += 1
    for f_ref in E[a[1]][1][1]:
        ft, fa = E[f_ref]
        if ft != 'ADVANCED_FACE':
            continue
        sup_tipo, sup = E[fa[2]]
        sup_nome = sup_tipo if sup_tipo != 'COMPLEXA' else \
            next((k for k in sup if 'SURFACE' in k and k != 'SURFACE'), 'COMPLEXA')
        peca.faces[sup_nome] = peca.faces.get(sup_nome, 0) + 1
        loops = []
        for b_ref in fa[1]:
            bt, ba = E[b_ref]
            el = E[ba[1]][1][1]
            pts = []
            for oe_ref in el:
                _, oa = E[oe_ref]
                ec, ori = oa[3], oa[4] == '.T.'
                if ec not in cache_aresta:
                    cache_aresta[ec] = _amostrar_aresta(E, ec)
                P = cache_aresta[ec] if ori else cache_aresta[ec][::-1]
                pts.append(P[:-1])
            L = np.vstack(pts)
            if ba[2] == '.F.':
                L = L[::-1]
            loops.append(L)
        peca.face_loops.append((sup_nome, loops, fa[3] == '.T.'))
        if sup_nome == 'PLANE':
            for L in loops:
                Av = 0.5 * np.cross(L, np.roll(L, -1, axis=0)).sum(axis=0)
                peca.area_plana += np.linalg.norm(Av) * (1 if L is loops[0] else -1)
                peca.vol6 += 2.0 * (L[0] @ Av)
        elif sup_nome in ('CYLINDRICAL_SURFACE', 'CONICAL_SURFACE'):
            # EXATO (teorema de Green no espaço paramétrico (u, v) da superfície):
            #   r(u,v) = o + rho(v) e(u) + v z,  rho = R + t v  (t = tan(semi-ângulo); cilindro t = 0)
            #   r.(r_u x r_v) = rho [o.e + rho - t (oz + v)]
            #   (1/3) int r.n dA = (1/3) [ sum_L int_L G du-antiderivada dv  -  2 pi sum_L k_L H(v_L) ]
            #   G = rho [ox sin u - oy cos u + (rho - t(oz+v)) u],  H(v) = (R - t oz)(R v + t v^2/2)
            M = placement(E, sup[1]); R = float(sup[2])
            t = math.tan(float(sup[3])) if sup_nome == 'CONICAL_SURFACE' else 0.0
            peca.superficies.append(dict(M=M, R=R, t=t, loops=loops))
            o, x, y, zax = M[:3, 3], M[:3, 0], M[:3, 1], M[:3, 2]
            ox, oy, oz = o @ x, o @ y, o @ zax
            tot = 0.0
            for L in loops:
                d = L - o
                u = np.unwrap(np.arctan2(d @ y, d @ x))
                v = d @ zax
                # fechar o laço em (u, v): último -> primeiro ponto (pode dar a volta)
                u_fim = u[-1] + (np.angle(np.exp(1j * (u[0] - u[-1]))))
                k = round((u_fim - u[0]) / (2 * np.pi))
                uf = np.r_[u, u_fim]; vf = np.r_[v, v[0]]
                rho = R + t * vf
                G = rho * (ox * np.sin(uf) - oy * np.cos(uf) + (rho - t * (oz + vf)) * uf)
                tot += np.sum(0.5 * (G[1:] + G[:-1]) * np.diff(vf))
                H = (R - t * oz) * (R * v[0] + t * v[0] ** 2 / 2)
                tot -= 2 * np.pi * k * H
            peca.vol6 += 2.0 * tot
        else:
            peca.curvas += 1
            for L in loops:
                Av = 0.5 * np.cross(L, np.roll(L, -1, axis=0)).sum(axis=0)
                peca.vol6 += 2.0 * (L[0] @ Av)          # aproximação
        if sup_nome == 'CYLINDRICAL_SURFACE':
            M = placement(E, sup[1])
            eixo, c = M[:3, 2], M[:3, 3]
            todos = np.vstack(loops)
            z = (todos - c) @ eixo
            # sentido da face: normal da face = normal da superfície (para fora do eixo)
            # se same_sense .T. -> superfície convexa (veio/ressalto); .F. -> furo
            # ângulo coberto pela face (bins de 10°): furo/veio só se >= ~170°
            dl = todos - c
            ang = np.degrees(np.arctan2(dl @ M[:3, 1], dl @ M[:3, 0])) % 360
            cobertura = 10.0 * len(np.unique((ang // 10).astype(int)))
            if cobertura >= 170:
                tipo_c = 'veio' if fa[3] == '.T.' else 'furo'
            else:
                tipo_c = 'arredondamento' if fa[3] == '.F.' else 'superficie curva'
            peca.cilindros.append(dict(raio=float(sup[2]), eixo=eixo, centro=c + eixo * z.mean(),
                                       comprimento=float(z.max() - z.min()),
                                       cobertura_graus=cobertura, tipo=tipo_c))
        peca.loops.extend(loops)


# ==============================================================================
# 3. ÁRVORE DO ASSEMBLY
# ==============================================================================
def montar(E):
    pd_nome, pd_prod = {}, {}
    for k, (t, a) in E.items():
        if t == 'PRODUCT_DEFINITION':
            prod = E[E[a[2]][1][2]][1]
            pd_nome[k] = prod[1] or prod[0]
    # PDS -> definição (PD ou NAUO)
    pds_def = {k: a[2] for k, (t, a) in E.items() if t == 'PRODUCT_DEFINITION_SHAPE'}
    # PD -> SHAPE_REPRESENTATION
    pd_rep = {}
    for k, (t, a) in E.items():
        if t == 'SHAPE_DEFINITION_REPRESENTATION':
            d = pds_def.get(a[0])
            if d in pd_nome:
                pd_rep[d] = a[1]
    # SR -> ADVANCED_BREP (sem transformação)
    rep_brep = {}
    for k, (t, a) in E.items():
        if t == 'SHAPE_REPRESENTATION_RELATIONSHIP':
            r1, r2 = a[2], a[3]
            for x, y in ((r1, r2), (r2, r1)):
                if E[y][0] in ('ADVANCED_BREP_SHAPE_REPRESENTATION',
                               'MANIFOLD_SURFACE_SHAPE_REPRESENTATION'):
                    rep_brep.setdefault(x, []).append(y)
    # NAUO -> transformação (via CONTEXT_DEPENDENT_SHAPE_REPRESENTATION)
    nauo_T = {}
    for k, (t, a) in E.items():
        if t == 'CONTEXT_DEPENDENT_SHAPE_REPRESENTATION':
            rel = E[a[0]][1]
            nauo = pds_def[a[1]]
            rr = rel['REPRESENTATION_RELATIONSHIP']
            tr = E[rel['REPRESENTATION_RELATIONSHIP_WITH_TRANSFORMATION'][0]][1]
            M1, M2 = placement(E, tr[2]), placement(E, tr[3])
            nauo_T[nauo] = M2 @ np.linalg.inv(M1)
    filhos = {}
    nauos = {}
    for k, (t, a) in E.items():
        if t == 'NEXT_ASSEMBLY_USAGE_OCCURRENCE':
            nauos[k] = dict(nome=a[1] or a[0], pai=a[3], filho=a[4])
            filhos.setdefault(a[3], []).append(k)
    raiz = [p for p in pd_nome if p not in {n['filho'] for n in nauos.values()}]
    return pd_nome, pd_rep, rep_brep, nauo_T, nauos, filhos, raiz


# ==============================================================================
# 4. INVENTÁRIO
# ==============================================================================
def inventario(caminho, tol_contacto=0.5):
    E = ler_step(caminho)
    unid = next((a for k, (t, a) in E.items() if t == 'COMPLEXA' and 'LENGTH_UNIT' in a), None)
    escala = 1.0
    if unid and 'SI_UNIT' in unid:
        pref = unid['SI_UNIT'][0]
        escala = {'.MILLI.': 1.0, '.CENTI.': 10.0, None: 1000.0}.get(pref, 1.0)
    pd_nome, pd_rep, rep_brep, nauo_T, nauos, filhos, raiz = montar(E)

    pecas, cache = {}, {}
    for pd, rep in pd_rep.items():
        p = Peca()
        for br in rep_brep.get(rep, []):
            for item in E[br][1][1]:
                ler_brep(E, item, p, cache)
        pecas[pd] = p

    # instâncias com transformação global (percorre a árvore)
    inst = []
    def descer(pd, M, caminho_nomes):
        p = pecas.get(pd)
        if p is not None and p.solidos:
            inst.append(dict(pd=pd, nome=caminho_nomes[-1] if caminho_nomes else pd_nome[pd],
                             caminho=' / '.join(caminho_nomes), M=M))
        for n in filhos.get(pd, []):
            descer(nauos[n]['filho'], M @ nauo_T.get(n, np.eye(4)),
                   caminho_nomes + [nauos[n]['nome']])
    for r in raiz:
        descer(r, np.eye(4), [])

    def tf(M, P):
        return P @ M[:3, :3].T + M[:3, 3]

    fichas = []
    for i in inst:
        p = pecas[i['pd']]
        Pl = np.vstack(p.loops) * escala
        Pg = tf(i['M'], np.vstack(p.loops)) * escala
        ext = Pl.max(0) - Pl.min(0)
        # dimensões "naturais": caixa orientada pelos eixos principais dos pontos
        C = Pl - Pl.mean(0)
        _, _, Vt = np.linalg.svd(C[::max(1, len(C) // 20000)], full_matrices=False)
        proj = C @ Vt.T
        dims = np.sort(proj.max(0) - proj.min(0))[::-1]
        nf = sum(p.faces.values())
        plana = p.faces.get('PLANE', 0) / max(nf, 1)
        cil = []
        for c in p.cilindros:
            eixo_g = i['M'][:3, :3] @ c['eixo']
            cil.append(dict(raio_mm=round(c['raio'] * escala, 3),
                            cobertura_graus=c['cobertura_graus'],
                            diametro_mm=round(2 * c['raio'] * escala, 3),
                            comprimento_mm=round(c['comprimento'] * escala, 2),
                            tipo=c['tipo'],
                            eixo_global=[round(float(v), 4) for v in eixo_g],
                            centro_global_mm=[round(float(v), 2) for v in tf(i['M'], c['centro'][None])[0] * escala]))
        loops_g = [tf(i['M'], L) * escala for L in p.loops]
        sups_g = []
        for sf in p.superficies:
            Mg = i['M'] @ sf['M']
            sups_g.append(dict(M=Mg, R=sf['R'], t=sf['t'],
                               loops=[tf(i['M'], L) * escala for L in sf['loops']], escala=escala))
        fichas.append(dict(
            nome=i['nome'], peca=pd_nome[i['pd']], caminho=i['caminho'],
            solidos=p.solidos, faces=nf, tipos_faces=p.faces,
            fracao_faces_planas=round(plana, 3),
            origem=('malha convertida (facetada)' if plana > 0.9 and nf > 200 else 'modelada (B-rep)'),
            volume_mm3=round(abs(p.vol6) / 6 * escala ** 3, 1),
            volume_exato=(p.curvas == 0),  # planos, cilindros e cones são exatos
            caixa_local_mm=[round(float(v), 2) for v in ext],
            dimensoes_principais_mm=[round(float(v), 2) for v in dims],
            caixa_global_min_mm=[round(float(v), 2) for v in Pg.min(0)],
            caixa_global_max_mm=[round(float(v), 2) for v in Pg.max(0)],
            centro_global_mm=[round(float(v), 2) for v in Pg.mean(0)],
            cilindros=cil,
            cilindros_locais=[dict(raio_mm=c['raio'] * escala, tipo=c['tipo'],
                                   cobertura_graus=c['cobertura_graus'],
                                   eixo=[float(v) for v in c['eixo']],
                                   centro_mm=[float(v) for v in c['centro'] * escala],
                                   comprimento_mm=c['comprimento'] * escala) for c in p.cilindros],
            _pontos_globais=Pg, _pontos_locais=Pl, _loops=[L * escala for L in p.loops],
            _loops_globais=loops_g, _superficies_globais=sups_g))

    # --- interfaces: eixos comuns e contactos ---
    from scipy.spatial import cKDTree
    eixos, contactos = [], []
    for a in range(len(fichas)):
        for b in range(a + 1, len(fichas)):
            A, B = fichas[a], fichas[b]
            for ca in [c for c in A['cilindros'] if c['tipo'] in ('furo', 'veio')]:
                for cb in [c for c in B['cilindros'] if c['tipo'] in ('furo', 'veio')]:
                    ea, eb = np.array(ca['eixo_global']), np.array(cb['eixo_global'])
                    if abs(ea @ eb) < 0.999:
                        continue
                    d = np.array(cb['centro_global_mm']) - np.array(ca['centro_global_mm'])
                    dist_eixos = np.linalg.norm(d - ea * (d @ ea))
                    if dist_eixos < 0.5 and abs(ca['raio_mm'] - cb['raio_mm']) < 1.5 and \
                            abs(d @ ea) < (ca['comprimento_mm'] + cb['comprimento_mm']) / 2 + 0.5:
                        eixos.append(dict(peca_a=A['nome'], peca_b=B['nome'],
                                          diametro_a=ca['diametro_mm'], diametro_b=cb['diametro_mm'],
                                          tipos=f"{ca['tipo']}/{cb['tipo']}",
                                          eixo=ca['eixo_global'], centro=ca['centro_global_mm']))
            ga, gb = np.array(A['caixa_global_min_mm']), np.array(A['caixa_global_max_mm'])
            ha, hb = np.array(B['caixa_global_min_mm']), np.array(B['caixa_global_max_mm'])
            if np.any(ga > hb + tol_contacto) or np.any(ha > gb + tol_contacto):
                continue
            ta = cKDTree(A['_pontos_globais'])
            d, _ = ta.query(B['_pontos_globais'], distance_upper_bound=tol_contacto * 4)
            perto = np.isfinite(d)
            if perto.sum() >= 3:
                Pc = B['_pontos_globais'][perto]
                contactos.append(dict(peca_a=A['nome'], peca_b=B['nome'], pontos=int(perto.sum()),
                                      zona_centro_mm=[round(float(v), 1) for v in Pc.mean(0)],
                                      zona_extensao_mm=[round(float(v), 1) for v in Pc.max(0) - Pc.min(0)]))
    # eixos repetidos (vários cilindros da mesma junta) -> um por par e diâmetro
    unicos = {}
    for e in eixos:
        k = (e['peca_a'], e['peca_b'], round(e['diametro_a']))
        unicos.setdefault(k, e)
    return dict(ficheiro=caminho, unidade='mm', pecas=fichas,
                eixos_comuns=list(unicos.values()), contactos=contactos)


# ==============================================================================
# 5. SAÍDAS
# ==============================================================================
def gravar(inv, pasta='diag'):
    import os
    import csv
    os.makedirs(pasta, exist_ok=True)
    limpo = dict(inv, pecas=[{k: v for k, v in f.items() if not k.startswith('_')}
                             for f in inv['pecas']])
    with open(f'{pasta}/inventario.json', 'w', encoding='utf-8') as f:
        json.dump(limpo, f, ensure_ascii=False, indent=2,
                  default=lambda o: o.tolist() if hasattr(o, 'tolist') else str(o))
    with open(f'{pasta}/inventario.csv', 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f, delimiter=';')
        w.writerow(['nome', 'peça', 'sólidos', 'faces', '% planas', 'origem', 'volume mm3',
                    'volume exato', 'dim1 mm', 'dim2 mm', 'dim3 mm', 'nº furos/veios',
                    'diâmetros (mm)'])
        for p in inv['pecas']:
            d = p['dimensoes_principais_mm']
            diams = sorted({c['diametro_mm'] for c in p['cilindros'] if c['tipo'] in ('furo', 'veio')})
            w.writerow([p['nome'], p['peca'], p['solidos'], p['faces'],
                        round(100 * p['fracao_faces_planas']), p['origem'], p['volume_mm3'],
                        'sim' if p['volume_exato'] else 'aprox.', *d,
                        sum(c['tipo'] in ('furo', 'veio') for c in p['cilindros']),
                        ' '.join(f'{x:g}' for x in diams[:8])])


def figura(inv, caminho='diag/inventario_assembly.png'):
    """Vista de lado (Y-Z) e de topo (Y-X) do assembly, com as arestas das peças."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    pecas = inv['pecas']
    cores = plt.cm.tab20(np.linspace(0, 1, len(pecas)))
    fig, axs = plt.subplots(2, 1, figsize=(22, 15), gridspec_kw={'height_ratios': [1.25, 1]})
    for ax, (tit, i, j) in zip(axs, [('Vista de lado (Y-Z)', 1, 2), ('Vista de topo (Y-X)', 1, 0)]):
        for cor, p in zip(cores, pecas):
            for L in p['_loops_globais']:
                ax.plot(*np.r_[L, L[:1]][:, [i, j]].T, color=cor, lw=0.5)
            c = np.array(p['centro_global_mm'])
            ax.annotate(p['nome'], (c[i], c[j]), fontsize=8, ha='center', color='k',
                        bbox=dict(boxstyle='round,pad=0.2', fc='white', ec=cor, lw=1.5, alpha=.85))
        for e in inv['eixos_comuns']:
            c = e['centro']
            ax.plot(c[i], c[j], 'k+', ms=14, mew=2.5)
        ax.set_aspect('equal'); ax.grid(ls='--', alpha=.35); ax.set_title(tit, fontweight='bold', fontsize=13)
        ax.set_xlabel('XYZ'[i] + ' [mm]'); ax.set_ylabel('XYZ'[j] + ' [mm]')
    fig.suptitle(f'Inventário automático do STEP: {len(pecas)} instâncias | '
                 f'{len(inv["eixos_comuns"])} eixos comuns (+ = articulação) | '
                 f'{len(inv["contactos"])} contactos', fontsize=15, fontweight='bold')
    plt.tight_layout()
    fig.savefig(caminho, dpi=100, bbox_inches='tight')
    plt.close(fig)


def fichas_visuais(inv, pasta='diag/fichas'):
    """Uma imagem por peça (definições únicas): 3 vistas nos eixos principais
    da peça, dimensões, furos (vermelho) e veios (azul)."""
    import os
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    os.makedirs(pasta, exist_ok=True)
    feitas = set()
    for p in inv['pecas']:
        if p['peca'] in feitas:
            continue
        feitas.add(p['peca'])
        Pl = p['_pontos_locais']
        c0 = Pl.mean(0)
        _, _, Vt = np.linalg.svd((Pl - c0)[::max(1, len(Pl) // 20000)], full_matrices=False)
        def pr(P):
            return (P - c0) @ Vt.T
        Q = pr(Pl); lo, hi = Q.min(0), Q.max(0); dim = hi - lo
        fig, axs = plt.subplots(1, 3, figsize=(18, 6.5))
        for ax, (i, j, tit) in zip(axs, [(0, 1, 'vista 1-2'), (0, 2, 'vista 1-3'), (1, 2, 'vista 2-3')]):
            for L in p['_loops']:
                q = pr(np.r_[L, L[:1]])
                ax.plot(q[:, i], q[:, j], color='0.25', lw=0.6)
            for c in [c for c in p['cilindros_locais'] if c['tipo'] in ('furo', 'veio')]:
                q = pr(np.array([c['centro_mm']]))[0]
                cor = 'tab:red' if c['tipo'] == 'furo' else 'tab:blue'
                ax.plot(q[i], q[j], 'o', color=cor, ms=5)
                eixo_l = np.array(c['eixo']) @ Vt.T
                if abs(eixo_l[i]) < 0.3 and abs(eixo_l[j]) < 0.3:      # eixo ~perpendicular à vista
                    ax.add_patch(plt.Circle((q[i], q[j]), c['raio_mm'], fill=False, color=cor, lw=1.2))
                    ax.annotate(f"Ø{2 * c['raio_mm']:.1f}", (q[i] + c['raio_mm'], q[j]), fontsize=7, color=cor)
            ax.set_aspect('equal'); ax.grid(ls='--', alpha=.3)
            ax.set_title(f'{tit}:  {dim[i]:.1f} x {dim[j]:.1f} mm', fontsize=10)
        furos = sorted({round(2 * c['raio_mm'], 1) for c in p['cilindros_locais'] if c['tipo'] == 'furo'})
        veios = sorted({round(2 * c['raio_mm'], 1) for c in p['cilindros_locais'] if c['tipo'] == 'veio'})
        fig.suptitle(f"{p['peca']}   |   {dim[0]:.1f} x {dim[1]:.1f} x {dim[2]:.1f} mm   |   "
                     f"volume {p['volume_mm3'] / 1e3:.1f} cm³{'' if p['volume_exato'] else ' (aprox.)'}   |   "
                     f"{p['faces']} faces ({p['origem']})\n"
                     f"furos Ø: {', '.join(map(str, furos)) or '-'}   |   veios Ø: {', '.join(map(str, veios)) or '-'}",
                     fontsize=12, fontweight='bold')
        plt.tight_layout()
        nome = re.sub(r'[^A-Za-z0-9_-]+', '_', p['peca'].encode('ascii', 'ignore').decode()).strip('_')
        fig.savefig(f'{pasta}/{nome}.png', dpi=90, bbox_inches='tight')
        plt.close(fig)
    return len(feitas)


if __name__ == '__main__':
    import time
    t0 = time.time()
    caminho = sys.argv[1]
    inv = inventario(caminho)
    gravar(inv)
    figura(inv)
    n_fichas = fichas_visuais(inv)
    print(f'{len(inv["pecas"])} instâncias lidas em {time.time() - t0:.1f} s\n')
    print(f'{"Nome":34s}{"sól.":>5s}{"faces":>7s}{"%plan":>6s}{"volume cm3":>12s}  '
          f'{"dimensões principais (mm)":28s}{"furos/veios":>12s}  origem')
    for p in inv['pecas']:
        d = p['dimensoes_principais_mm']
        print(f'{p["nome"][:33]:34s}{p["solidos"]:5d}{p["faces"]:7d}'
              f'{100 * p["fracao_faces_planas"]:6.0f}{p["volume_mm3"] / 1e3:11.1f}'
              f'{"" if p["volume_exato"] else "~"} {d[0]:7.1f} x{d[1]:7.1f} x{d[2]:7.1f}      '
              f'{sum(c["tipo"] in ("furo", "veio") for c in p["cilindros"]):12d}  {p["origem"]}')
    print(f'\nEIXOS COMUNS (articulações prováveis): {len(inv["eixos_comuns"])}')
    for e in inv['eixos_comuns']:
        print(f'  {e["peca_a"][:28]:28s} <-> {e["peca_b"][:28]:28s}  Ø {e["diametro_a"]:.1f}/{e["diametro_b"]:.1f} mm ({e["tipos"]})')
    print(f'\nCONTACTOS (superfícies a < 0.5 mm): {len(inv["contactos"])}')
    for c in inv['contactos']:
        print(f'  {c["peca_a"][:28]:28s} <-> {c["peca_b"][:28]:28s}  zona {c["zona_extensao_mm"]} mm')
    print(f'\n[OK] diag/inventario.json, diag/inventario.csv, diag/inventario_assembly.png, '
          f'diag/fichas/ ({n_fichas} peças)')
