# Joelho traseiro – processo a partir do STEP (trabalho atual)

Esta pasta tem **só** o processo atual: a geometria vem do STEP exportado do Fusion
(sem prints, sem medidas à mão). O trabalho antigo (método do print + segmentação por
cor) ficou na pasta `codigo` original, que deve ser renomeada para arquivo.

## Estrutura

| Pasta / ficheiro | O que é |
|---|---|
| `step\suspensao_v1.step` | Assembly da suspensão exportado do Fusion (fonte de toda a geometria) |
| `leitor_step.py` | Lê o STEP: peças, dimensões, volumes, furos/eixos, articulações, contactos |
| `geometria_step.py` | Tira do STEP o perfil 2D do joelho, as zonas a preservar e os dados reais da roda |
| `calibrar_sketch.py` | Ajusta os 16 parâmetros do sketch paramétrico ao perfil real |
| `analise_esforcos.py` | Análise 2D (viga curva): esforços, tensões, FS |
| `planetas.py` | Perfil de cada planeta: gravidade, temperatura, terreno, aterragem, FS e materiais possíveis |
| `gerador_variantes.py` | Gera e escolhe variantes por planeta e material (ou pelos cenários antigos A–D com `--missoes`) |
| `familias.py` | As 3 famílias estruturais (o planeta escolhe: tubo fechado, treliça, nervuras) |
| `populacoes.py` | Genes de cada família e geração de 150 variantes por planeta (exploração, sem otimização) |
| `explorador.py` | Filtro 2D (teoria de vigas), finalistas A (leve) e B (rígida), gráfico de dispersão |
| `explorador_html.py` | Gera o explorador interativo `diag\populacoes\explorador.html` (abre no browser) |
| `rhino_nurbs.py`, `rhino_familias.py`, `nurbs_dados.py` | Construção NURBS limpa no Rhino |
| `gh_joelho.py` | Componente Python 3 do Grasshopper: sliders dos genes -> peça ao vivo |
| `gh_intact.py` + `GUIA_INTACT.md` | Grasshopper -> Intact.Simulation: peça, faces de ligação, forças, momentos e material para a verificação 3D |
| `HIPOTESES.md` | Todas as hipóteses (planetas, materiais, modelo) com justificação e fontes, para o relatório |
| `planetas_3d.py` | Faz o 3D de todas as combinações planeta × material e escolhe a mais leve |
| `joelho3d.py` | 3D: profundidade variável b(s) guiada pela tensão |
| `joelho3d_I.py` | 3D: secção em I (rebaixos + nervuras); escolhe a mais leve |
| `codigov1.py` | Só são usadas as funções do sketch (fillets); não precisa da imagem |
| `rhino_joelho3d.py` | Rhino: grelha de variantes 3D coloridas pela utilização |
| `rhino_joelho_completo.py` | Rhino: joelho completo = variante + zonas verdes exatas cortadas do STEP |
| `diag\` | Resultados (JSON, CSV, figuras, STL, cache) |
| `diag\fichas\` | Uma ficha visual por peça da suspensão |
| `diag\planetas\` | Resultados por planeta: tabelas, grelha 2D, Pareto, figura 3D, STL |

## Ordem de execução (terminal dentro desta pasta)

```
python leitor_step.py step\suspensao_v1.step
python geometria_step.py step\suspensao_v1.step "joelho traserio:1" "roda:1"
python calibrar_sketch.py
python analise_esforcos.py --salvar
python planetas.py                            (tabela das cargas por planeta)
python gerador_variantes.py --salvar          (≈8 min; --reusar usa o cálculo já feito)
python planetas_3d.py                         (≈7 min)
python populacoes.py                          (≈4 min, 1050 variantes)
python explorador.py                          (filtro 2D + finalistas + dispersão)
python explorador_html.py                     (explorador interativo)
```

No Rhino (Editor de Scripts, `_ScriptEditor`): `rhino_joelho_completo.py` (importar antes o STEP
da pasta `step`). Opções: `CENARIO` (planeta) e `VARIANTE` ("A", "B", "regra" ou um código do
catálogo, ex. "MAR-004").

## Finalistas por planeta (análise 2D com correção de Bleich, 28/10)
| Planeta | Família | A (leve) | B (rígida) |
|---|---|---|---|
| Lua | Tubo fechado | LUA-106 · Ti-6Al-4V · 2,53 kg | LUA-081 · Al 7075 · 2,98 kg |
| Mercúrio | Tubo fechado | MER-085 · Inconel 718 · 6,55 kg | MER-140 · Inconel 718 · 6,96 kg |
| Marte | Tubo fechado | MAR-079 · Ti-6Al-4V · 2,96 kg | MAR-084 · Ti-6Al-4V · 3,51 kg |
| Europa | Treliça | EUR-027 · Al 7075 · 3,15 kg | EUR-015 · Ti-6Al-4V AM · 3,72 kg |
| Titã | Treliça | TIT-107 · Al 7075 · 2,21 kg | TIT-129 · Al 7075 · 2,29 kg |
| Io | Treliça | IO-027 · Al 7075 · 3,21 kg | IO-015 · Ti-6Al-4V · 3,78 kg |
| Vénus | Nervuras | VÉN-050 · Ti-6Al-4V · 9,78 kg | — |

Original (zona de projeto): ~9,3 kg. Próximo passo: verificar no Intact (GUIA_INTACT.md).
Nota: o desenho "regra" (VARIANTE = "regra") de Mercúrio não cumpre o FS com a correção de
Bleich (1,83 < 2,2); usar as finalistas do catálogo.
Cenários antigos em Marte (A–D): `diag\designs_otimos.csv`. Resultados de `planetas_3d.py`
(secção em I, antes das famílias) em `diag\planetas\resumo_3d.csv` — só histórico.
