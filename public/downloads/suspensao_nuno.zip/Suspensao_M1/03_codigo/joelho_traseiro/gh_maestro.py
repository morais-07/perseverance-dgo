# r: numpy, scipy, matplotlib
"""
GRASSHOPPER - MAESTRO DA VERIFICAÇÃO 3D (automático, um planeta de cada vez)
(componente "Python 3 Script" do Rhino 8, ao lado da definição do gh_intact.py)

    população 2D do planeta  ->  N mais leves que passam no filtro 2D
        -> para cada uma, todos os casos de carga no Intact (sozinho)
        -> Danger Level de cada caso (máximo e percentis)
        -> passa em 3D se, em TODOS os casos, o percentil 99,9 % < 1 / FS exigido
        -> as 3 mais leves que passam -> montadas no assembly da suspensão (STEP)

ENTRADAS (botão direito -> "+"; nomes exatos):
  correr   (bool)  Boolean Toggle. True = começa / continua; False = para.
  planeta  (str)   Panel com o planeta, ex. "Lua", ou "todos" (corre os que não têm <planeta>_FEITO.txt)
  N        (int)   quantas variantes vão ao 3D (por defeito 10)
  nomes    (list)  bloco Solution Sampler: 1.ª saída (nomes das grandezas). Botão direito -> List Access
  valores  (tree)  bloco Solution Sampler: 2.ª saída (valores nos pontos). Botão direito -> Tree Access
  (alternativa antiga: v = saída V do Visualize em Danger Level, List Access)
  montar   (bool)  True = no fim monta as 2 melhores no assembly (precisa do STEP importado)

SAÍDAS:
  estado      Panel: o que está a fazer agora
  resultados  Panel: tabela final (por variante: pior caso, FS 3D, passa / não passa)

PONTOS E PERCENTIL: o Solution Sampler só lê pontos longe das faces de ligação e da carga
(gh_intact.py, saída 'pontos'). Mesmo assim usa-se o percentil 99,9 % e não o máximo:
  o máximo do Danger Level fica sempre num pico artificial (canto vivo onde a peça
  encontra a face de ligação, face encastrada, carga aplicada numa face). Esses picos
  crescem quando a malha fica mais fina e não são tensões reais. O máximo também é
  guardado no CSV, para o relatório.

Resultados: diag/intact/<planeta>_casos.csv, <planeta>_resumo.csv, <planeta>_top3.csv
"""
import os
import sys
import csv
import time

PASTA = r"C:\Mestrado\designD\m1\joelho_traseiro_STEP"
os.chdir(PASTA)
if PASTA not in sys.path:
    sys.path.insert(0, PASTA)
import matplotlib
matplotlib.use("Agg")
import scriptcontext as sc
import Grasshopper

import gerador_variantes as gv
import populacoes as po
import familias as fa

gv._init()
SAIDA = os.path.join(PASTA, "diag", "intact")
CHAVE_ST = "maestro"

# ---- v2 (31/10): só os CASOS CRÍTICOS a partir da 2.ª variante ----
#   A 1.ª variante do planeta corre TODOS os casos. Depois ficam só os casos cujo percentil
#   99,9 % chegou a >= CORTE x o pior caso dessa variante (+ os que falharam: sem valor não se
#   pode excluir). A decisão fica em diag/intact/<planeta>_casos_criticos.csv (para o relatório).
#   Mesma família estrutural em todas as variantes do planeta -> a ordem dos casos mantém-se.
SO_CRITICOS = True
CORTE = 0.25


def _entrada(nome, defeito):
    v = globals().get(nome, None)
    return defeito if v is None else v


def _nome_planeta(v):
    import unicodedata
    tira = lambda s: unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode().strip().lower()
    for nome in fa.FAMILIA:
        if tira(nome) == tira(v):
            return nome
    raise Exception("Planeta desconhecido: {!r}. Usa um destes: {}".format(v, ", ".join(fa.FAMILIA)))


def _valores(x):
    if x is None:
        return []
    try:
        lst = list(x)
    except TypeError:
        lst = [x]
    out = []
    for e in lst:
        try:
            out.append(float(e))
        except Exception:
            pass
    return out


def _num(x):
    try:
        return float(x)
    except Exception:
        try:
            return float(x.Value)
        except Exception:
            return None


def _ramos(tree):
    """DataTree do Grasshopper (ou lista) -> lista de listas."""
    if tree is None:
        return []
    if hasattr(tree, "Branches"):
        return [list(b) for b in tree.Branches]
    try:
        lst = list(tree)
    except TypeError:
        return [[tree]]
    return [list(e) if hasattr(e, "__iter__") and not isinstance(e, str) else [e] for e in lst]


def _danger_do_sampler(nomes, valores, sy):
    """Danger Level nos pontos a partir do Solution Sampler. Se o Intact não der o Danger Level
    diretamente, usa a tensão de Von Mises / cedência (é a mesma definição para materiais dúcteis)."""
    nomes = [str(n) for r in _ramos(nomes) for n in r]          # aceita lista ou árvore
    if not nomes:
        return [], None
    idx, div = None, 1.0
    for i, n in enumerate(nomes):
        if "danger" in n.lower():
            idx, div = i, 1.0
            break
    if idx is None:
        for i, n in enumerate(nomes):
            if "mises" in n.lower():
                idx, div = i, float(sy)
                break
    if idx is None:
        return [], "o Solution Sampler não tem Danger Level nem Von Mises: " + ", ".join(nomes)
    ramos = _ramos(valores)
    if len(ramos) == len(nomes):
        brutos = ramos[idx]                         # um ramo por grandeza
    else:
        brutos = [r[idx] for r in ramos if len(r) > idx]   # um ramo por ponto
    out = [x / div for x in (_num(b) for b in brutos) if x is not None]
    return out, nomes[idx]


def _n_casos(planeta):
    cen = gv.CENARIOS[gv.chave_cenario(planeta)]
    return len(cen["casos"]) + (1 if "Fz" in cen else 0)


def _candidatos(planeta, n):
    pop = [l for l in po.ler_populacao(planeta) if l.get("passa") == "True" and l.get("valido") == "True"]
    pop.sort(key=lambda l: float(l["massa_kg"]))
    return [l["id"] for l in pop[:n]]


def _correr_de_novo(atraso=1500):
    """Agenda uma nova solução do Grasshopper que volta a calcular o gh_intact.
    O atraso (ms) dá tempo ao Intact para acabar de escrever a solução anterior."""
    comp = sc.sticky.get("intact_comp")
    doc = ghenv.Component.OnPingDocument()
    if comp is None or doc is None:
        return False

    def cb(d):
        comp.ExpireSolution(False)
    doc.ScheduleSolution(int(atraso), Grasshopper.Kernel.GH_Document.GH_ScheduleDelegate(cb))
    return True


def _sondar(atraso=3000):
    """Enquanto o Intact calcula (processo à parte), volta a ler o resultado de X em X ms:
    expira o Solution Sampler (as fontes das entradas 'nomes' / 'valores'), que relê a solução
    do Stress; como o maestro está a jusante, também volta a correr. NÃO expira o Stress
    (isso recomeçava a simulação). Se não houver Sampler ligado, expira só o maestro."""
    me = ghenv.Component
    doc = me.OnPingDocument()
    if doc is None:
        return
    alvos, vistos = [], set()
    for p in me.Params.Input:
        if p.NickName in ("nomes", "valores", "v"):
            for s in p.Sources:
                obj = s.Attributes.GetTopLevel.DocObject
                if obj is not None and obj.InstanceGuid not in vistos:
                    vistos.add(obj.InstanceGuid)
                    alvos.append(obj)
    if not alvos:
        alvos = [me]

    def cb(d):
        for o in alvos:
            o.ExpireSolution(False)
    doc.ScheduleSolution(int(atraso), Grasshopper.Kernel.GH_Document.GH_ScheduleDelegate(cb))


def _sonda_tick(sender, e):
    """Corre de 3 em 3 s (temporizador do Rhino, fora do Grasshopper). Enquanto o maestro está
    à espera do Intact, expira o Solution Sampler e pede uma nova solução: o Sampler relê o
    resultado do Stress e o maestro (a jusante) volta a correr. Não toca no Stress."""
    try:
        if not (sc.sticky.get("maestro_a_esperar") and sc.sticky.get("lote_ativo")):
            return
        me = sc.sticky.get("maestro_comp")
        doc = me.OnPingDocument() if me is not None else None
        if doc is None or doc.SolutionState == Grasshopper.Kernel.GH_ProcessStep.Process:
            return                                   # o Grasshopper está a calcular: tenta no próximo tick
        alvos = sc.sticky.get("maestro_alvos") or [me]
        # O Stress do Intact acaba o cálculo (mensagem "Done") mas a saída Ss continua a ser a
        # simulação antiga: o Sampler só lê se o Stress for recalculado. Por isso, quando o
        # Stress diz "Done" e o Sampler continua com erro, recalcula-se o Stress UMA vez por
        # simulação (os dados de entrada não mudaram: deve só carregar o resultado).
        stress = None
        for o in alvos:
            for p in o.Params.Input:
                if p.NickName == "S":
                    for s in p.Sources:
                        stress = s.Attributes.GetTopLevel.DocObject
        msg = (stress.Message or "") if stress is not None else ""
        sc.sticky["maestro_msg_stress"] = msg
        erro_sampler = any(o.RuntimeMessageLevel == Grasshopper.Kernel.GH_RuntimeMessageLevel.Error
                           for o in alvos if o is not me)
        k = sc.sticky.get("maestro_k")
        # registo (saída L) do Stress, para diagnóstico no Panel 'estado'
        try:
            lg = [str(g) for g in stress.Params.Output[1].VolatileData.AllData(True)]
            sc.sticky["maestro_log_stress"] = lg[-1][-120:] if lg else ""
        except Exception:
            pass
        # Pode recalcular-se o Stress VÁRIAS vezes por simulação (o "Done" visto logo no início
        # ainda pode ser o da simulação anterior), mas com 20 s entre tentativas e no máx. 6.
        agora = time.time()
        rec = sc.sticky.get("maestro_stress_rec")
        if not rec or rec[0] != k:
            rec = [k, 0, 0.0]                        # [simulação, n.º de recálculos, hora do último]
        if (stress is not None and erro_sampler and "done" in msg.lower()
                and agora - sc.sticky.get("maestro_t_espera", 0) > 5
                and agora - rec[2] > 20 and rec[1] < 6):
            rec[1] += 1
            rec[2] = agora
            sc.sticky["maestro_stress_rec"] = rec
            stress.ExpireSolution(False)             # expira também o Sampler e o maestro
        else:
            for o in alvos:
                o.ExpireSolution(False)
        sc.sticky["maestro_sondagens"] = sc.sticky.get("maestro_sondagens", 0) + 1
        doc.NewSolution(False)
    except Exception as ex:
        sc.sticky["maestro_erro_sonda"] = str(ex)


def _sonda_ligar():
    """Liga (uma só vez) o temporizador e atualiza os blocos a expirar (fontes de nomes/valores)."""
    me = ghenv.Component
    alvos, vistos = [], set()
    for p in me.Params.Input:
        if p.NickName in ("nomes", "valores", "v"):
            for s in p.Sources:
                obj = s.Attributes.GetTopLevel.DocObject
                if obj is not None and obj.InstanceGuid not in vistos:
                    vistos.add(obj.InstanceGuid)
                    alvos.append(obj)
    sc.sticky["maestro_comp"] = me
    sc.sticky["maestro_alvos"] = alvos or [me]
    sc.sticky["maestro_a_esperar"] = True
    if sc.sticky.get("maestro_timer") is None:
        import Eto.Forms
        t = Eto.Forms.UITimer()
        t.Interval = 3.0                             # segundos
        t.Elapsed += _sonda_tick
        t.Start()
        sc.sticky["maestro_timer"] = t


def _rever_maestro():
    """Agenda uma nova corrida deste componente (para mostrar o fim / montar)."""
    me = ghenv.Component
    doc = me.OnPingDocument()
    if doc is None:
        return

    def cb(d):
        me.ExpireSolution(False)
    doc.ScheduleSolution(200, Grasshopper.Kernel.GH_Document.GH_ScheduleDelegate(cb))


def _chaves_pts():
    pts_ = sc.sticky.get("intact_pontos_loc") or []
    return [(round(p.X, 1), round(p.Y, 1), round(p.Z, 1)) for p in pts_]


def _solucao_velha(st, vals):
    """31/10: True se os valores, nos pontos em comum, são iguais aos de um dos últimos casos
    gravados -> o Sampler leu a solução ANTERIOR (o Intact ainda não acabou o caso novo).
    A verificação antiga (n.º de valores + soma) falhava quando os pontos mudam (embate)."""
    ch = _chaves_pts()
    if len(ch) != len(vals):
        return False
    for h in st.get("hist", []):
        comuns = iguais = 0
        for k_, v_ in zip(ch, vals):
            hv = h.get(k_)
            if hv is None:
                continue
            comuns += 1
            if abs(hv - v_) <= 1e-9 + 1e-6 * abs(v_):
                iguais += 1
        if comuns >= 100 and iguais >= 0.98 * comuns:
            return True
    return False


def _guardar_hist(st, vals):
    ch = _chaves_pts()
    if len(ch) == len(vals):
        st.setdefault("hist", []).append(dict(zip(ch, vals)))
        st["hist"] = st["hist"][-3:]


def _repetir_pedidos(planeta, st):
    """Ficheiro diag/intact/REPETIR.txt com linhas 'LUA-122;5' -> esses casos saem dos
    resultados e voltam a correr (na repescagem do fim, ou já a seguir se ela já passou)."""
    f_ = os.path.join(SAIDA, "REPETIR.txt")
    if not os.path.exists(f_):
        return
    try:
        pedidos = []
        for l_ in open(f_, encoding="utf-8-sig"):
            p_ = l_.strip().split(";")
            if len(p_) >= 2 and p_[1].strip().isdigit():
                pedidos.append((p_[0].strip(), int(p_[1])))
        os.remove(f_)
    except Exception:
        return
    for vid_, c_ in pedidos:
        st["registos"] = [r for r in st["registos"] if not (r["id"] == vid_ and r["caso"] == c_)]
        if st.get("repescagem_feita"):
            st["fila"].append((vid_, c_))
        else:
            st.setdefault("saltados", []).append((vid_, c_))
    _escrever(planeta, st)


def _esperados(st, vid):
    """N.º de casos diferentes que esta variante tem de correr (8, ou só os críticos)."""
    return len(set(c for (v, c) in st["fila"] if v == vid)) or st["n_casos"]


def _filtrar_casos(planeta, st):
    """Depois de a 1.ª variante ter todos os casos, tira da fila (para as outras) os não críticos."""
    if not SO_CRITICOS or st.get("filtro_feito") or not st.get("ids"):
        return
    v0 = st["ids"][0]
    rs0 = [r for r in st["registos"] if r["id"] == v0]
    if len(set(r["caso"] for r in rs0)) < st["n_casos"]:
        return
    ok0 = [r for r in rs0 if not r.get("falhou")]
    pior = max([r["p999"] for r in ok0] or [0.0])
    manter = set(r["caso"] for r in rs0 if r.get("falhou"))
    manter |= set(r["caso"] for r in ok0 if r["p999"] >= CORTE * pior)
    st["filtro_feito"] = True
    st["casos_criticos"] = sorted(manter)
    st["fila"] = st["fila"][:st["k"]] + [(v, c) for (v, c) in st["fila"][st["k"]:] if v == v0 or c in manter]
    try:
        with open(os.path.join(SAIDA, planeta + "_casos_criticos.csv"), "w", newline="", encoding="utf-8-sig") as f:
            f.write("variante_referencia;caso;nome_caso;p999;fracao_do_pior;critico\n")
            for r in sorted(rs0, key=lambda r: r["caso"]):
                p_ = r.get("p999")
                fr = "" if r.get("falhou") or not pior else "{:.3f}".format(p_ / pior)
                f.write("{};{};{};{};{};{}\n".format(v0, r["caso"], r["nome_caso"],
                                                     "falhou" if r.get("falhou") else p_, fr,
                                                     r["caso"] in manter))
            f.write("# critério: crítico se p999 >= {:.2f} x pior caso da variante de referência\n".format(CORTE))
    except Exception:
        pass


def _solucao_fresca(st):
    """31/10 14h30: True só se o Intact gravou um grasshopper_solution.vtu DEPOIS de o caso ter
    sido pedido (st['t_pedido']). Apanha as leituras da solução anterior que escapavam à
    comparação de valores (sonda a recarregar o Stress antes de o Intact acabar)."""
    t0 = st.get("t_pedido")
    if not t0:
        return True
    try:
        base = os.path.join(os.environ.get("APPDATA", ""), "Intact.Simulation For Grasshopper")
        pastas = sorted(d for d in os.listdir(base) if os.path.isdir(os.path.join(base, d)))
        for d in reversed(pastas[-6:]):
            f = os.path.join(base, d, "grasshopper_solution.vtu")
            if os.path.exists(f):
                return os.path.getmtime(f) > t0
        return False
    except Exception:
        return True


def _avancar(planeta, st):
    """Passa ao caso seguinte da fila. No fim da fila faz UMA repescagem dos casos falhados
    (st['saltados']). Devolve True se há mais um caso para correr, False se o lote acabou."""
    _filtrar_casos(planeta, st)
    if st["k"] >= len(st["fila"]) and st.get("saltados") and not st.get("repescagem_feita"):
        st["fila"].extend(tuple(x) for x in st["saltados"])
        st["saltados"] = []
        st["repescagem_feita"] = True
    if st["k"] < len(st["fila"]):
        sc.sticky["lote_alvo"] = (planeta,) + tuple(st["fila"][st["k"]])
        st["t_pedido"] = time.time()
        return True
    st["t_fim"] = time.time()
    sc.sticky["lote_ativo"] = False
    return False


def _percentil(vals, q):
    return vals[min(len(vals) - 1, int(q * len(vals)))]


def _escrever(planeta, st):
    os.makedirs(SAIDA, exist_ok=True)
    reg = st["registos"]
    campos = ["planeta", "id", "material", "massa_2d", "massa_3d", "FS_2d", "caso", "nome_caso",
              "n_pontos", "max", "p99", "p999", "perigo_max", "passa_caso", "grandeza",
              "p999_transicao", "max_transicao", "n_pontos_total", "p50", "p90", "falhou"]
    with open(os.path.join(SAIDA, planeta + "_casos.csv"), "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=campos, delimiter=";", extrasaction="ignore")
        w.writeheader(); w.writerows(reg)
    resumo = []
    for vid in st["ids"]:
        rs_ = [r for r in reg if r["id"] == vid]
        if not rs_:
            continue
        ok_ = [r for r in rs_ if not r.get("falhou")]
        if not ok_:
            continue
        pior = max(ok_, key=lambda r: r["p999"])
        resumo.append(dict(planeta=planeta, id=vid, material=rs_[0]["material"],
                           massa_2d=rs_[0]["massa_2d"], massa_3d=round(rs_[0]["massa_3d"], 3),
                           FS_2d=rs_[0]["FS_2d"], casos_corridos=len(rs_),
                           pior_caso=pior["nome_caso"], pior_p999=pior["p999"],
                           FS_3d=round(1.0 / max(pior["p999"], 1e-9), 2),
                           casos_falhados=len(rs_) - len(ok_),
                           max_absoluto=round(max(r["max"] for r in ok_), 3),
                           FS_transicao=round(1.0 / max(max(r.get("p999_transicao", 0) for r in ok_), 1e-9), 2),
                           casos_esperados=_esperados(st, vid),
                           passa_3d=all(r["passa_caso"] for r in rs_) and
                           len(set(r["caso"] for r in rs_)) >= _esperados(st, vid)))
    with open(os.path.join(SAIDA, planeta + "_resumo.csv"), "w", newline="", encoding="utf-8-sig") as f:
        if resumo:
            w = csv.DictWriter(f, fieldnames=list(resumo[0]), delimiter=";")
            w.writeheader(); w.writerows(resumo)
    top = sorted([r for r in resumo if r["passa_3d"]], key=lambda r: r["massa_3d"])[:2]   # 01/11: só as 2 melhores (2 peças, 2 suspensões)
    with open(os.path.join(SAIDA, planeta + "_top3.csv"), "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(resumo[0]) if resumo else ["id"], delimiter=";")
        w.writeheader(); w.writerows(top)
    return resumo, top


def _tabela(resumo, top, n_casos=8):
    if not resumo:
        return "(ainda sem resultados)"
    linhas = ["{:9s} {:18s} {:>7s} {:>6s} {:>6s} {:>7s}  {:13s} {}".format(
        "variante", "material", "massa", "FS 2D", "FS 3D", "FS lig.", "pior caso", "3D")]
    for r in resumo:
        n_esp = r.get("casos_esperados", n_casos)
        if r["casos_corridos"] < n_esp:
            res = "{}/{} casos".format(r["casos_corridos"], n_esp)
        elif r.get("casos_falhados"):
            res = "{} caso(s) sem resultado".format(r["casos_falhados"])
        else:
            res = "PASSA" if r["passa_3d"] else "não passa"
        linhas.append("{:9s} {:18s} {:6.2f}kg {:6.2f} {:6.2f} {:7.2f}  {:13s} {}".format(
            r["id"], r["material"][:18], r["massa_3d"], r["FS_2d"], r["FS_3d"], r["FS_transicao"],
            r["pior_caso"][:13], res))
    linhas.append("")
    linhas.append("FS 3D = corpo da peça (critério). FS lig. = zona de transição junto às ligações "
                  "(cantos ainda sem boleado: só informativo).")
    linhas.append("3 melhores (mais leves que passam em 3D): " +
                  (", ".join("{} ({:.2f} kg)".format(t["id"], t["massa_3d"]) for t in top) or "nenhuma"))
    return "\n".join(linhas)


# =============================================================================
sc.sticky["maestro_a_esperar"] = False      # só volta a True no ramo "o Intact está a calcular"
correr_ = bool(_entrada("correr", False))
# planeta = "todos" -> corre os planetas seguidos pela ORDEM abaixo (cada um acabado fica marcado
# com diag/intact/<planeta>_FEITO.txt; apaga esse ficheiro para repetir um planeta)
ORDEM_TODOS = ["Lua", "Marte", "Mercúrio", "Europa", "Titã", "Io", "Vénus"]
_pl_in = _entrada("planeta", "Lua")
CADEIA = str(_pl_in).strip().lower() in ("todos", "todas", "all")
if CADEIA:
    _pend = [p for p in ORDEM_TODOS if not os.path.exists(os.path.join(SAIDA, p + "_FEITO.txt"))]
    planeta_ = _pend[0] if _pend else ORDEM_TODOS[-1]
else:
    planeta_ = _nome_planeta(_pl_in)
N_ = int(_entrada("N", 10) or 10)
montar_ = bool(_entrada("montar", True))
_e0 = sc.sticky.get("intact_estado") or {}
_rv = _ramos(_entrada("valores", None))
_rn = [str(n) for r in _ramos(_entrada("nomes", None)) for n in r]
DIAG = "\n[Sampler: {} nomes ({}) | valores: {} ramos, 1.º ramo com {} itens: {}]".format(
    len(_rn), ", ".join(_rn[:8]), len(_rv), len(_rv[0]) if _rv else 0,
    ", ".join(str(x)[:10] for x in (_rv[0][:6] if _rv else [])))
if _entrada("nomes", None) is not None:
    vals, grandeza = _danger_do_sampler(_entrada("nomes", None), _entrada("valores", None),
                                        _e0.get("sy_MPa", 1.0))
else:
    vals, grandeza = _valores(_entrada("v", None)), "Visualize"
st = sc.sticky.get(CHAVE_ST)

if not correr_:
    sc.sticky["lote_ativo"] = False
    if st:
        st["tentativas"] = 0                     # ao recomeçar, volta a dar tempo ao gh_intact
        st["refazer"] = 0
    if st and st["k"] >= len(st["fila"]):
        st["acabou_e_recomecar"] = True          # da próxima vez que 'correr' = True, começa do zero
    if st and st.get("planeta") == planeta_:
        resumo, top = _escrever(planeta_, st) if st["registos"] else ([], [])
        estado = "PARADO ({} de {} simulações feitas). Põe 'correr' em True para continuar.".format(
            st["k"], len(st["fila"]))
        resultados = _tabela(resumo, top, st["n_casos"] if st else 8)
    else:
        estado = "PARADO. Põe 'correr' em True para verificar em 3D as {} variantes mais leves de {}.".format(
            N_, planeta_)
        resultados = ""
else:
    # recomeçar do zero: basta existir o ficheiro diag/intact/RECOMECAR.txt (o maestro apaga-o
    # e guarda uma cópia dos resultados anteriores em diag/intact/anteriores/)
    _flag = os.path.join(SAIDA, "RECOMECAR.txt")
    _recomecar = os.path.exists(_flag)
    if _recomecar:
        try:
            os.remove(_flag)
            import shutil
            _ant = os.path.join(SAIDA, "anteriores", time.strftime("%Y%m%d_%H%M%S"))
            os.makedirs(_ant, exist_ok=True)
            for _f in os.listdir(SAIDA):
                if _f.startswith(planeta_ + "_") and _f.endswith(".csv"):
                    shutil.copy2(os.path.join(SAIDA, _f), _ant)
        except Exception:
            pass
        for _k in ("lote_alvo", "maestro_k", "maestro_t_espera", "maestro_stress_rec"):
            sc.sticky.pop(_k, None)
    if (_recomecar or not st or st.get("versao") != 7 or st.get("planeta") != planeta_ or st.get("N") != N_
            or st.get("acabou_e_recomecar")):
        ids = _candidatos(planeta_, N_)
        if not ids:
            raise Exception("Nenhuma variante de {} passa no filtro 2D (diag/populacoes/{}.csv).".format(
                planeta_, planeta_))
        nc = _n_casos(planeta_)
        st = dict(versao=7, impressao=None, t_primeiro=None, planeta=planeta_, N=N_, ids=ids, n_casos=nc,
                  fila=[(vid, c) for vid in ids for c in range(nc)], k=0, registos=[],
                  ultimo_contador=sc.sticky.get("intact_contador", 0), t0=time.time(), montado=False)
        sc.sticky[CHAVE_ST] = st
    if st["k"] >= len(st["fila"]):
        resumo, top = _escrever(planeta_, st)
        sc.sticky["lote_ativo"] = False
        estado = "ACABOU: {} variantes x {} casos em {:.0f} min. Resultados em diag/intact/.".format(
            len(st["ids"]), st["n_casos"], (st.get("t_fim", time.time()) - st["t0"]) / 60)
        if montar_ and top and not st["montado"]:
            st["montado"] = True
            try:
                import Rhino
                import rhino_montar_top3 as mt
                doc_gh = sc.doc
                sc.doc = Rhino.RhinoDoc.ActiveDoc
                try:
                    msg = mt.montar(planeta_)
                finally:
                    sc.doc = doc_gh
                estado += "\nMontagem: " + msg
            except Exception as e:
                estado += "\nMontagem falhou: {} (corre rhino_montar_top3.py no Editor de Scripts)".format(e)
        resultados = _tabela(resumo, top, st["n_casos"] if st else 8)
        st["acabou_e_recomecar"] = False
        if CADEIA:
            try:
                os.makedirs(SAIDA, exist_ok=True)
                with open(os.path.join(SAIDA, planeta_ + "_FEITO.txt"), "w", encoding="utf-8") as f_:
                    f_.write(time.strftime("%d/%m %H:%M") + "\n")
            except Exception:
                pass
            _pend = [p for p in ORDEM_TODOS if not os.path.exists(os.path.join(SAIDA, p + "_FEITO.txt"))]
            if _pend:
                estado += "\nModo 'todos': a seguir {} (faltam {}).".format(_pend[0], len(_pend))
                _rever_maestro()
            else:
                estado += "\nModo 'todos': os 7 planetas estão feitos."
    else:
        vid, caso = st["fila"][st["k"]]
        sc.sticky["lote_ativo"] = True
        sc.sticky["lote_alvo"] = (planeta_, vid, caso)
        e = sc.sticky.get("intact_estado") or {}
        pronto = (e.get("id") == vid and e.get("caso") == caso and e.get("planeta") == planeta_
                  and e.get("contador", 0) > st["ultimo_contador"])
        _repetir_pedidos(planeta_, st)
        if pronto and vals and (not _solucao_fresca(st) or _solucao_velha(st, vals)):
            vals = []                    # trata como "ainda sem resultado": espera pelo Intact
        impressao = (len(vals), round(sum(vals), 6)) if vals else None
        repetido = pronto and vals and impressao == st.get("impressao")
        if repetido:
            # os valores são iguais aos do caso anterior: o Stress não voltou a calcular
            st["aviso"] = ("\nO Stress não recalculou (valores iguais ao caso anterior): põe o Toggle "
                           "ligado à entrada SM do Stress em True. O maestro continua sozinho.")
        elif pronto and vals:
            st["impressao"] = impressao
            if st.get("t_primeiro") is None:
                st["t_primeiro"] = time.time()
            zona = sc.sticky.get("intact_zona") or []
            if len(zona) == len(vals):
                corpo = [x for x, z in zip(vals, zona) if not z] or vals
                trans = sorted(x for x, z in zip(vals, zona) if z) or [0.0]
            else:
                corpo, trans = vals, [0.0]
            sv = sorted(corpo)
            st["t_espera_k"] = None
            if caso == 0:
                # diagnóstico: pontos e Danger Level do 1.º caso de cada variante (para ver onde estão os picos)
                try:
                    pts_ = sc.sticky.get("intact_pontos_loc") or []
                    if len(pts_) == len(vals):
                        os.makedirs(SAIDA, exist_ok=True)
                        with open(os.path.join(SAIDA, "pontos_{}_{}.csv".format(vid, caso)), "w", encoding="utf-8") as f_:
                            f_.write("x;y;z;zona;danger\n")
                            for P_, z_, v_ in zip(pts_, zona if len(zona) == len(vals) else [0] * len(vals), vals):
                                f_.write("{:.2f};{:.2f};{:.2f};{:d};{:.5g}\n".format(P_.X, P_.Y, P_.Z, int(bool(z_)), v_))
                except Exception:
                    pass
            p999 = _percentil(sv, 0.999)
            # repescagem: se este caso tinha falhado antes, a linha "falhou" sai e entra esta
            st["registos"] = [r for r in st["registos"]
                              if not (r.get("falhou") and r["id"] == vid and r["caso"] == caso)]
            st["registos"].append(dict(
                planeta=planeta_, id=vid, material=e["material"], massa_2d=e["massa_2d"],
                massa_3d=e["massa_3d"], FS_2d=e["FS_2d"], caso=caso, nome_caso=e["nome_caso"],
                n_pontos=len(sv), max=round(sv[-1], 4), p99=round(_percentil(sv, 0.99), 4),
                p999=round(p999, 4), perigo_max=e["perigo_max"], passa_caso=p999 < e["perigo_max"],
                grandeza=grandeza, p50=round(_percentil(sv, 0.5), 4), p90=round(_percentil(sv, 0.9), 4),
                p999_transicao=round(_percentil(trans, 0.999), 4),
                max_transicao=round(trans[-1], 4), n_pontos_total=len(vals)))
            st["ultimo_contador"] = e["contador"]
            _guardar_hist(st, vals)
            st["k"] += 1
            _escrever(planeta_, st)
            st["tentativas"] = 0
            st["refazer"] = 0
            if _avancar(planeta_, st):
                vid, caso = st["fila"][st["k"]]
                _correr_de_novo()
            else:
                _rever_maestro()
        elif pronto and not vals:
            if _entrada("nomes", None) is not None:
                estado_extra = "\nO Solution Sampler não deu valores ({}). Vê se o bloco tem erros.".format(grandeza)
            else:
                estado_extra = ("\nO Visualize não deu valores: clica nele com o botão direito, escolhe "
                                "'Danger Level' e o maestro continua sozinho.")
            # O solver do Intact corre num processo à parte (a janela de comandos que abre): enquanto
            # está a calcular, o Stress diz "Unable to read solution" e o Sampler fica sem valores.
            # Quando acaba, o próprio Stress volta a correr e o maestro recebe os valores. Por isso
            # aqui só se ESPERA; só se volta a simular se passarem mais de 3 minutos sem resultado.
            agora = time.time()
            if st.get("t_espera_k") != st["k"]:
                st["t_espera_k"] = st["k"]
                st["t_espera"] = agora
            espera = agora - st["t_espera"]
            # 31/10: se o gh_intact preparou 0 pontos de amostragem, o Sampler nunca dará valores:
            # não vale a pena esperar 3 x 3 min, marca logo como falhado
            sem_pontos = e.get("n_pontos", 1) == 0 and espera > 20
            if sem_pontos:
                st["refazer"], espera = 2, 999
            if espera > 180 and st.get("refazer", 0) < 2:
                st["refazer"] = st.get("refazer", 0) + 1
                st["t_espera"] = agora
                _correr_de_novo(500)
                estado_extra = "\nSem resultado ao fim de 3 min: a repetir esta simulação."
            elif st.get("refazer", 0) >= 2 and espera > 180:
                # 31/10: em vez de ficar preso para sempre, marca o caso como falhado e avança
                st.setdefault("saltados", []).append((vid, caso))
                st["registos"].append(dict(
                    planeta=planeta_, id=vid, material=e.get("material", ""), massa_2d=e.get("massa_2d", 0),
                    massa_3d=e.get("massa_3d", 0), FS_2d=e.get("FS_2d", 0), caso=caso,
                    nome_caso=e.get("nome_caso", ""), passa_caso=False, falhou=True, grandeza=grandeza))
                st["ultimo_contador"] = e.get("contador", st["ultimo_contador"])
                st["k"] += 1
                st["refazer"] = 0
                st["t_espera_k"] = None
                _escrever(planeta_, st)
                if _avancar(planeta_, st):
                    _correr_de_novo()
                else:
                    _rever_maestro()
                estado_extra = "\nSem resultado ao fim de 2 repetições: caso {} de {} marcado como FALHOU e saltado.".format(
                    caso, vid)
            else:
                estado_extra = "\nO Intact está a calcular ({:.0f} s)... o maestro continua quando acabar.".format(espera)
            st["aviso"] = estado_extra
            # ANTES: aqui só se esperava que o Stress voltasse a correr sozinho. Na 2.ª simulação
            # isso não acontece (o Stress fica "Done" mas o Sampler não relê) e nada voltava a
            # chamar o maestro -> ficava parado. Agora um temporizador do Rhino sonda de 3 em 3 s
            # (o ScheduleSolution do Grasshopper perdia-se quando o Intact lançava a sua solução).
            sc.sticky["maestro_k"] = (st["k"], st.get("refazer", 0))
            sc.sticky["maestro_t_espera"] = st["t_espera"]
            _sonda_ligar()
            rec_ = sc.sticky.get("maestro_stress_rec") or [None, 0]
            st["aviso"] += " [sondagens: {} | Stress: '{}' | Stress recalculado: {}x | log: {}{}]".format(
                sc.sticky.get("maestro_sondagens", 0), sc.sticky.get("maestro_msg_stress", ""),
                rec_[1] if rec_[0] == sc.sticky["maestro_k"] else 0,
                sc.sticky.get("maestro_log_stress", ""),
                ", erro: " + sc.sticky["maestro_erro_sonda"] if sc.sticky.get("maestro_erro_sonda") else "")
        else:
            # o gh_intact ainda não preparou esta variante/caso: pede-lhe que volte a correr
            st["tentativas"] = st.get("tentativas", 0) + 1
            if st["tentativas"] <= 8:
                _correr_de_novo()
            else:
                sc.sticky["lote_ativo"] = False
                st["tentativas"] = 0
                raise Exception("O gh_intact não respondeu para {} caso {} (8 tentativas). Vê se tem erros "
                                "(balão vermelho) e põe 'correr' em False e outra vez em True. "
                                "[diagnóstico: gh_intact registado={}, último estado dele={}/{}/caso {}/contador {}, "
                                "contador esperado > {}]".format(
                                    vid, caso, sc.sticky.get("intact_comp") is not None, e.get("planeta"),
                                    e.get("id"), e.get("caso"), e.get("contador"), st["ultimo_contador"]))
        feito = st["k"]
        total = len(st["fila"])
        t1 = st.get("t_primeiro")
        resta = ((time.time() - t1) / (feito - 1) * (total - feito) / 60
                 if t1 and feito > 1 else float("nan"))
        estado = "A CORRER {}: simulação {} de {} | variante {} caso {} | faltam ~{:.0f} min".format(
            planeta_, min(feito + 1, total), total, vid, caso, resta) + DIAG
        if (pronto and not vals) or repetido:
            estado += st.get("aviso", "")
        resumo, top = _escrever(planeta_, st) if st["registos"] else ([], [])
        resultados = _tabela(resumo, top, st["n_casos"] if st else 8)
