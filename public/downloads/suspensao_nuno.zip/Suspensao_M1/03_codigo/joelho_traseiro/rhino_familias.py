# -*- coding: utf-8 -*-
"""
Construção no Rhino (RhinoCommon) das FAMÍLIAS ESTRUTURAIS (familias.py).

  fechada  -> loft de secções retangulares de cantos arredondados (tubo liso)
              menos loft da cavidade (pontas em ogiva) + furo de respiro
  trelica  -> corpo de profundidade b(s) (superfícies lisas, rhino_nurbs)
              menos janelas passantes
  isogrid  -> corpo + rebaixos em células triangulares com fundo na alma (rhino_nurbs)

Tudo no referencial LOCAL (x eixo da roda, y vertical, z profundidade) e no fim
transformado para a posição real do rover (como em rhino_nurbs.construir).
"""
import math
import Rhino.Geometry as rg
import rhino_nurbs as rn
import nurbs_dados as nd


def _seccao(c, nrm, t, b, r, zc):
    """Retângulo t (direção nrm) x b (direção z) com cantos de raio r, no plano da
    secção. Começa sempre a meio do lado +n e roda no mesmo sentido (loft limpo)."""
    r = max(min(r, 0.49 * t, 0.49 * b), 0.3)
    O = rg.Point3d(float(c[0]), float(c[1]), zc)
    N = rg.Vector3d(float(nrm[0]), float(nrm[1]), 0.0)
    Z = rg.Vector3d(0, 0, 1)

    def P(u, v):
        return O + N * u + Z * v

    a, h = t / 2.0, b / 2.0
    pc = rg.PolyCurve()
    pc.Append(rg.Line(P(a, 0), P(a, h - r)))
    pc.Append(rg.Arc(P(a, h - r), P(a - r * (1 - math.cos(math.pi / 4)), h - r * (1 - math.sin(math.pi / 4))), P(a - r, h)))
    pc.Append(rg.Line(P(a - r, h), P(-a + r, h)))
    pc.Append(rg.Arc(P(-a + r, h), P(-a + r * (1 - math.cos(math.pi / 4)), h - r * (1 - math.sin(math.pi / 4))), P(-a, h - r)))
    pc.Append(rg.Line(P(-a, h - r), P(-a, -h + r)))
    pc.Append(rg.Arc(P(-a, -h + r), P(-a + r * (1 - math.cos(math.pi / 4)), -h + r * (1 - math.sin(math.pi / 4))), P(-a + r, -h)))
    pc.Append(rg.Line(P(-a + r, -h), P(a - r, -h)))
    pc.Append(rg.Arc(P(a - r, -h), P(a - r * (1 - math.cos(math.pi / 4)), -h + r * (1 - math.sin(math.pi / 4))), P(a, -h + r)))
    pc.Append(rg.Line(P(a, -h + r), P(a, 0)))
    return pc.ToNurbsCurve()


def _loft(curvas, p0=None, p1=None):
    ini = p0 if p0 is not None else rg.Point3d.Unset
    fim = p1 if p1 is not None else rg.Point3d.Unset
    r = rg.Brep.CreateFromLoft(rn._lista(rg.Curve, curvas), ini, fim, rg.LoftType.Normal, False)
    return r[0] if r else None


def _para_mundo(corpo, origem, U, W, zc):
    corpo.Translate(rg.Vector3d(0, 0, -zc))
    plano = rg.Plane(rg.Point3d(*[float(c) for c in origem]),
                     rg.Vector3d(*[float(c) for c in U]), rg.Vector3d(*[float(c) for c in W]))
    corpo.Transform(rg.Transform.PlaneToPlane(rg.Plane.WorldXY, plano))
    if corpo.SolidOrientation == rg.BrepSolidOrientation.Inward:
        corpo.Flip()
    return corpo


ESTADO_CAVIDADE = ""   # "oca ..." / "MACIÇA ..." (última peça feita por fechada)


# ------------------------------------------------------------------------------
# 02/11: na treliça e nas nervuras o contorno é UMA curva suave (Fit) extrudida -> a parede
# toda à volta fica uma só face e o troço reto em x = x_interface (ligação às zonas verdes)
# desaparece dentro dela -> o gh_intact não encontrava face_fixa / face_carga e o Intact
# não arrancava (Europa EUR-029, 01/11 22h20). Parte-se a face nos cantos vivos; se mesmo
# assim não houver face plana na ligação, corta-se 0,2 mm com uma caixa (face plana garantida).
def _faces_ligacao(corpo, x_interface):
    n = 0
    for fc in corpo.Faces:
        amp = rg.AreaMassProperties.Compute(fc.DuplicateFace(False))
        if amp is not None and abs(amp.Centroid.X - x_interface) < 0.5 and fc.IsPlanar(0.1):
            n += 1
    return n


def _garantir_faces_ligacao(corpo, x_interface, tol, log=print):
    """corpo no referencial LOCAL (x = eixo da análise). Devolve o corpo com faces planas
    em x = x_interface (em cima e em baixo)."""
    if _faces_ligacao(corpo, x_interface) >= 2:
        return corpo
    c = corpo.DuplicateBrep()
    try:
        c.Faces.SplitKinkyFaces(math.radians(5.0), True)
        c.Compact()
    except Exception:
        pass
    if c.IsSolid and _faces_ligacao(c, x_interface) >= 2:
        log("  LIGAÇÃO: parede partida nos cantos -> {} faces planas em x = {:.1f}".format(
            _faces_ligacao(c, x_interface), x_interface))
        return c
    bb = corpo.GetBoundingBox(True)
    x1 = x_interface - 0.2
    caixa = rg.Box(rg.BoundingBox(rg.Point3d(bb.Min.X - 10, bb.Min.Y - 10, bb.Min.Z - 10),
                                  rg.Point3d(x1, bb.Max.Y + 10, bb.Max.Z + 10))).ToBrep()
    r = rg.Brep.CreateBooleanIntersection(corpo, caixa, tol)
    if r:
        novo = max(r, key=lambda x: x.GetVolume())
        if novo.IsSolid and _faces_ligacao(novo, x1) >= 2:
            log("  LIGAÇÃO: corte plano a {:.1f} (0,2 mm) -> faces de ligação OK".format(x1))
            return novo
    log("  LIGAÇÃO: AVISO - não consegui criar faces planas de ligação")
    return c if c.IsSolid else corpo


# ------------------------------------------------------------------------------
def fechada(f, origem, U, W, zc, tol, log=print):
    est = f['estacoes']
    ext = [_seccao(P['c'], P['n'], P['t'], P['b'], P['R'], zc) for P in est]
    tubo = _loft(ext)
    if tubo is None:
        raise Exception("loft exterior falhou")
    corpo = tubo.CapPlanarHoles(tol)
    if corpo is None or not corpo.IsSolid:
        raise Exception("o tubo exterior não fechou")
    if corpo.SolidOrientation == rg.BrepSolidOrientation.Inward:
        corpo.Flip()
    log("  FECHADA: superfície exterior (loft de {} secções): OK".format(len(ext)))
    # cavidade(s): troços contínuos de secções ocas, pontas em ogiva
    trocos, atual = [], []
    for P in est:
        if P['oco']:
            atual.append(P)
        elif atual:
            trocos.append(atual); atual = []
    if atual:
        trocos.append(atual)
    cavs = []
    for tr in trocos:
        if len(tr) < 3:
            continue
        cin = [_seccao(P['c'], P['n'], P['t'] - 2 * P['e'], P['b'] - 2 * P['e'],
                       max(P['R'] - P['e'], 0.5), zc) for P in tr]
        a, z = tr[0], tr[-1]
        p0 = rg.Point3d(a['c'][0] - a['tg'][0] * 8.0, a['c'][1] - a['tg'][1] * 8.0, zc)
        p1 = rg.Point3d(z['c'][0] + z['tg'][0] * 8.0, z['c'][1] + z['tg'][1] * 8.0, zc)
        cav = _loft(cin, p0, p1)
        if cav is not None and cav.IsSolid:
            if cav.SolidOrientation == rg.BrepSolidOrientation.Inward:
                cav.Flip()
            cavs.append((cav, tr))
    global ESTADO_CAVIDADE
    ESTADO_CAVIDADE = "maciça (sem troços ocos)"
    if cavs:
        # 31/10: a cavidade fica TODA dentro da peça (não cruza a pele) e o Rhino não consegue
        # subtrair sólidos que não se intersetam -> a peça ficava maciça. Solução: juntar primeiro
        # o furo de respiro Ø3 (necessário no vácuo) à cavidade; essa "ferramenta" já fura a
        # parede de cima e a subtração passa a funcionar. Reserva: cavidade como vazio interior.
        V0 = corpo.GetVolume()
        ferramentas = []
        for cav, tr in cavs:
            m = tr[len(tr) // 2]
            base = rg.Point3d(float(m['c'][0]), float(m['c'][1]), zc)
            cil = rg.Cylinder(rg.Circle(rg.Plane(base, rg.Vector3d(0, 0, 1)), 1.5), m['b'] / 2 + 5).ToBrep(True, True)
            u = rg.Brep.CreateBooleanUnion(rn._lista(rg.Brep, [cav, cil]), tol)
            ferramentas.append(max(u, key=lambda x: x.GetVolume()) if u else cav)
        r = rg.Brep.CreateBooleanDifference(rn._lista(rg.Brep, [corpo]), rn._lista(rg.Brep, ferramentas), tol)
        novo = max(r, key=lambda x: x.GetVolume()) if r else None
        if novo is not None and novo.IsSolid and novo.GetVolume() < 0.98 * V0:
            corpo = novo
            ESTADO_CAVIDADE = "oca ({} cavidade(s) + respiro Ø3)".format(len(cavs))
            log("  FECHADA: {} cavidade(s) interior(es) (tubo oco) + furo de respiro Ø3 mm".format(len(cavs)))
        else:
            # reserva: cavidade como vazio interior (segunda casca virada para dentro), sem respiro
            oco = corpo.DuplicateBrep()
            for cav, _ in cavs:
                c = cav.DuplicateBrep()
                c.Flip()
                oco.Append(c)
            if oco.IsValid and oco.IsSolid and 0 < oco.GetVolume() < 0.98 * V0:
                corpo = oco
                ESTADO_CAVIDADE = "oca (vazio interior, sem respiro)"
                log("  FECHADA: subtração falhou; cavidade como vazio interior (sem respiro)")
            else:
                ESTADO_CAVIDADE = "MACIÇA (cavidade falhou)"
                log("  FECHADA: AVISO - não consegui abrir a cavidade; peça fica maciça (mais pesada)")
    return _para_mundo(corpo, origem, U, W, zc)


# ------------------------------------------------------------------------------
def trelica(f, origem, U, W, zc, tol, B_interface, x_interface, log=print):
    r = f['base']
    d = nd.preparar(dict(env=r['env'], b=f['b'], sketch=r['sketch']), B_interface)
    d['rebaixos'] = []
    corpo, _ = rn.construir(d, x_interface, (0, 0, 0), (1, 0, 0), (0, 1, 0), 0.0,
                            tol, raio_boleado=0.0, log=log, mundo=False)
    H = d['H']
    furos = []
    for J in f['janelas']:
        e = rn._extrusao(rn._curva_fechada(J, tol), zc - H, zc + H, tol)
        if e is not None:
            furos.append(e)
    if furos:
        res = rg.Brep.CreateBooleanDifference(rn._lista(rg.Brep, [corpo]), rn._lista(rg.Brep, furos), tol)
        if res:
            corpo = max(res, key=lambda x: x.GetVolume())
            log("  TRELIÇA: {} janelas passantes, diagonais de {:.1f} mm".format(len(furos), f['wd']))
        else:
            log("  TRELIÇA: AVISO - corte das janelas falhou")
    corpo = _garantir_faces_ligacao(corpo, x_interface, tol, log)
    return _para_mundo(corpo, origem, U, W, zc)


# ------------------------------------------------------------------------------
def isogrid(f, origem, U, W, zc, tol, x_interface, log=print):
    corpo, _ = rn.construir(f['dados_nurbs'], x_interface, (0, 0, 0), (1, 0, 0), (0, 1, 0), 0.0,
                            tol, raio_boleado=0.0, log=log, mundo=False)
    log("  NERVURAS: {} células triangulares abertas, alma >= {:.0f} mm".format(
        f['n_celulas'], f['alma_min']))
    corpo = _garantir_faces_ligacao(corpo, x_interface, tol, log)
    return _para_mundo(corpo, origem, U, W, zc)
