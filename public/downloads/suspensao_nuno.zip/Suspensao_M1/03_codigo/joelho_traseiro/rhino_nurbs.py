# -*- coding: utf-8 -*-
"""
Construção NURBS limpa da variante, dentro do Rhino (RhinoCommon).
Usado por rhino_joelho_completo.py quando GEOMETRIA = "nurbs".

  corpo   = extrusão do contorno em planta  ∩  laje entre z_topo(x,y) e z_fundo(x,y)
  rebaixo = extrusão do contorno do rebaixo ∩  laje entre a alma e o exterior
  peça    = corpo - rebaixos  (+ boleado das arestas, se o Rhino conseguir)

Tudo é feito no referencial LOCAL da análise (x eixo da roda, y vertical,
z profundidade) e só no fim é transformado para a posição real do rover.
"""
import math
import System
from System.Collections.Generic import List
import Rhino.Geometry as rg


def _lista(tipo, itens):
    l = List[tipo]()
    for i in itens:
        l.Add(i)
    return l


def _superficie(gx, gy, Z):
    """Superfície NURBS cúbica que passa pela grelha (gy linhas x gx colunas)."""
    pts = [rg.Point3d(float(gx[j]), float(gy[i]), float(Z[i][j]))
           for i in range(len(gy)) for j in range(len(gx))]
    return rg.NurbsSurface.CreateThroughPoints(_lista(rg.Point3d, pts), len(gy), len(gx),
                                               3, 3, False, False)


def _laje(gx, gy, Ztopo, Zfundo, tol):
    """Sólido fechado entre duas superfícies da mesma grelha (paredes regradas nos bordos)."""
    st, sf = _superficie(gx, gy, Ztopo), _superficie(gx, gy, Zfundo)
    if st is None or sf is None:
        return None
    bt, bf = rg.Brep.CreateFromSurface(st), rg.Brep.CreateFromSurface(sf)
    pecas = [bt, bf]
    for et, ef in zip(bt.Edges, bf.Edges):
        rs_ = rg.NurbsSurface.CreateRuledSurface(et.DuplicateCurve(), ef.DuplicateCurve())
        if rs_ is None:
            return None
        pecas.append(rg.Brep.CreateFromSurface(rs_))
    j = rg.Brep.JoinBreps(_lista(rg.Brep, pecas), tol)
    if not j or len(j) != 1 or not j[0].IsSolid:
        return None
    laje = j[0]
    if laje.SolidOrientation == rg.BrepSolidOrientation.Inward:
        laje.Flip()
    return laje


def _curva_fechada(pts2d, tol, suave=True):
    pl = [rg.Point3d(float(x), float(y), 0.0) for x, y in pts2d]
    if pl[0].DistanceTo(pl[-1]) > 1e-6:
        pl.append(pl[0])
    c = rg.PolylineCurve(_lista(rg.Point3d, pl))
    if suave:
        f = c.Fit(3, 0.05, math.radians(20.0))      # mantém cantos vivos > 20°
        if f is not None and f.IsClosed:
            return f
    return c


def _extrusao(curva, z0, z1, tol):
    c = curva.DuplicateCurve()
    c.Translate(rg.Vector3d(0, 0, z0))
    s = rg.Surface.CreateExtrusion(c, rg.Vector3d(0, 0, z1 - z0))
    b = s.ToBrep().CapPlanarHoles(tol)
    if b is not None and b.SolidOrientation == rg.BrepSolidOrientation.Inward:
        b.Flip()
    return b


def _intersecao(a, b, tol):
    r = rg.Brep.CreateBooleanIntersection(a, b, tol)
    if not r:
        return None
    return max(r, key=lambda x: x.GetVolume()) if len(r) > 1 else r[0]


def _boleado(brep, x_interface, raio, tol):
    """Boleia as arestas que NÃO estão nas faces de ligação às zonas verdes."""
    idx = []
    for e in brep.Edges:
        xs = [e.PointAtStart.X, e.PointAtEnd.X, e.PointAt(e.Domain.Mid).X]
        if min(xs) > x_interface - 0.3:          # aresta na face de ligação: fica viva
            continue
        if e.GetLength() < 1.0:
            continue
        idx.append(e.EdgeIndex)
    if not idx:
        return brep, 0
    try:
        r = rg.Brep.CreateFilletEdges(brep, _lista(System.Int32, idx),
                                      _lista(System.Double, [raio] * len(idx)),
                                      _lista(System.Double, [raio] * len(idx)),
                                      rg.BlendType.Fillet, rg.RailType.RollingBall, tol)
    except Exception:
        r = None
    if r and len(r) == 1 and r[0].IsSolid:
        return r[0], len(idx)
    return brep, 0


def construir(d, x_interface, origem, U, W, zc, tol, raio_boleado=2.0, log=print, mundo=True):
    """d: dict de nurbs_dados.preparar. Devolve (brep na posição real, info)."""
    gx, gy = list(d['gx']), list(d['gy'])
    H = d['H']
    zc = d['zc'] if not mundo else zc
    info = {}
    # 1. corpo
    contorno = _curva_fechada(d['contorno'], tol, suave=True)
    A = _extrusao(contorno, zc - H, zc + H, tol)
    laje = _laje(gx, gy, d['z_topo'].tolist(), d['z_fundo'].tolist(), tol)
    if A is None or laje is None:
        raise Exception("NURBS: não consegui criar a extrusão ou a laje de profundidade")
    corpo = _intersecao(A, laje, tol)
    if corpo is None:
        raise Exception("NURBS: a interseção extrusão ∩ laje falhou")
    log("  NURBS: corpo com profundidade variável lisa: OK")

    # 2. rebaixos (secção em I)
    cavs = []
    if d['rebaixos']:
        zsup = [[zc + H] * len(gx) for _ in gy]
        zinf = [[zc - H] * len(gx) for _ in gy]
        laje_sup = _laje(gx, gy, zsup, d['z_alma_topo'].tolist(), tol)
        laje_inf = _laje(gx, gy, d['z_alma_fundo'].tolist(), zinf, tol)
        for rb in d['rebaixos']:
            P = _extrusao(_curva_fechada(rb['pts'], tol), zc - H, zc + H, tol)
            for lj in (laje_sup, laje_inf):
                if P is None or lj is None:
                    continue
                c = _intersecao(P, lj, tol)
                if c is not None:
                    cavs.append(c)
        if cavs:
            r = rg.Brep.CreateBooleanDifference(_lista(rg.Brep, [corpo]), _lista(rg.Brep, cavs), tol)
            if r and len(r) >= 1:
                corpo = max(r, key=lambda x: x.GetVolume())
                log("  NURBS: {} rebaixo(s) cortado(s) (fundo segue a alma)".format(len(cavs)))
            else:
                log("  NURBS: AVISO - corte dos rebaixos falhou; peça fica cheia (mais pesada)")
    info['rebaixos'] = len(cavs)

    # 3. boleado
    n = 0
    if raio_boleado and raio_boleado > 0:
        corpo, n = _boleado(corpo, x_interface, raio_boleado, tol)
        log("  NURBS: " + ("{} arestas boleadas (r = {} mm)".format(n, raio_boleado) if n
                           else "boleado não aplicado (o Rhino não conseguiu; peça sem boleado)"))
    info['arestas_boleadas'] = n
    if not mundo:
        return corpo, info

    # 4. para a posição real: z local -> centrado em zc, plano (U, W) na origem
    corpo.Translate(rg.Vector3d(0, 0, -zc))
    plano = rg.Plane(rg.Point3d(*[float(c) for c in origem]),
                     rg.Vector3d(*[float(c) for c in U]), rg.Vector3d(*[float(c) for c in W]))
    corpo.Transform(rg.Transform.PlaneToPlane(rg.Plane.WorldXY, plano))
    if corpo.SolidOrientation == rg.BrepSolidOrientation.Inward:
        corpo.Flip()
    info['volume_mm3'] = corpo.GetVolume()
    return corpo, info
