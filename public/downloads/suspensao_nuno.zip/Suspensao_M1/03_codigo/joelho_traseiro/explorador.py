"""
==============================================================================
 FILTRO + ESCOLHA DE FINALISTAS + DADOS PARA O EXPLORADOR DE VARIANTES
==============================================================================
Lê as populações (populacoes.py) e:
  1. FILTRO (nível 1, teoria de vigas): passa = FS >= FS exigido pelo planeta
  2. FINALISTAS por planeta (regras claras, sem otimização):
       A "leve"    : a variante mais leve que passa com margem de 5 %
       B "rígida"  : entre as que pesam até +20 % da A, a que menos roda o cubo (mais rígida)
  3. Gráficos de dispersão massa x FS (um por planeta)  -> diag/populacoes/dispersao.png
  4. Dados para o explorador interativo (HTML)        -> diag/populacoes/explorador.json
       (contornos em planta de cada variante válida, genes, massa, FS, rigidez)

Uso:  python explorador.py
==============================================================================
"""
import os
import csv
import json
import numpy as np

import gerador_variantes as gv
import familias as fa
import populacoes as po

MARGEM_LEVE = 1.05
FOLGA_ROBUSTA = 1.20


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return np.nan


def finalistas(linhas):
    ok = [l for l in linhas if l['passa'] in (True, 'True') and _num(l['FS_min']) >= _num(l['FS_req']) * MARGEM_LEVE]
    if not ok:
        ok = [l for l in linhas if l['passa'] in (True, 'True')]
    if not ok:
        return None, None
    A = min(ok, key=lambda l: _num(l['massa_kg']))
    perto = [l for l in ok if _num(l['massa_kg']) <= _num(A['massa_kg']) * FOLGA_ROBUSTA and l['id'] != A['id']]
    B = min(perto, key=lambda l: _num(l['rotacao_graus'])) if perto else None
    return A, B


def _simplificar(P, n=70):
    P = np.asarray(P, float)
    if len(P) > n:
        P = P[np.linspace(0, len(P) - 1, n).astype(int)]
    return [[round(float(x), 1), round(float(y), 1)] for x, y in P]


def desenho(planeta, lin):
    """Contornos em planta para a miniatura: exterior, aberturas/cavidades."""
    g = po.genes_de_linha(lin)
    r = po.avaliar(planeta, g, contornos=True)
    if not r.get('valido'):
        return None
    esq, geo = r['esq'], r['geo']
    env = esq['env']
    out = dict(ext=_simplificar(esq['sketch'], 110), furos=[], tracejado=[])
    if r['familia'] == 'fechada':
        S, t = env['S'], env['t']
        nrm = np.c_[-env['tang'][:, 1], env['tang'][:, 0]]
        ext = np.vstack([S + nrm * (t[:, None] / 2), (S - nrm * (t[:, None] / 2))[::-1]])
        out['ext'] = _simplificar(ext, 110)
        e, oco = geo['e'], geo['oco']
        if oco.any():
            i = np.flatnonzero(oco)
            a = S[i] + nrm[i] * (t[i, None] / 2 - e[i, None])
            b = S[i] - nrm[i] * (t[i, None] / 2 - e[i, None])
            out['tracejado'] = [_simplificar(np.vstack([a, b[::-1], a[:1]]), 120)]
    elif r['familia'] == 'trelica':
        out['furos'] = [_simplificar(J, 32) for J in geo.get('janelas', [])]
    else:
        out['bolsas'] = [_simplificar(c['pts'], 32) for c in geo['dados_nurbs']['rebaixos']]
    return out


def figura_dispersao(por_planeta, fins):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    n = len(por_planeta)
    fig, axs = plt.subplots(1, n, figsize=(3.6 * n, 4.2))
    for ax, (planeta, linhas) in zip(axs, por_planeta.items()):
        v = [l for l in linhas if l['valido'] in (True, 'True')]
        m = np.array([_num(l['massa_kg']) for l in v]); fs = np.array([_num(l['FS_min']) for l in v])
        ok = np.array([l['passa'] in (True, 'True') for l in v])
        ax.scatter(m[~ok], fs[~ok], s=12, c='#c0c0c0', label='não passa')
        ax.scatter(m[ok], fs[ok], s=14, c='#2a6fbb', label='passa')
        req = _num(v[0]['FS_req'])
        ax.axhline(req, color='#c0392b', ls='--', lw=1)
        A, B = fins[planeta]
        for F, cor, nome in ((A, '#e67e22', 'A leve'), (B, '#27ae60', 'B rígida')):
            if F:
                ax.scatter(_num(F['massa_kg']), _num(F['FS_min']), s=140, marker='*', c=cor,
                           edgecolors='k', zorder=5, label=nome)
        ax.set_yscale('log'); ax.set_xlabel('massa [kg]')
        ax.set_title(f'{planeta}\n{fa.NOME_FAMILIA[fa.FAMILIA[planeta]]}', fontsize=9)
        ax.grid(alpha=.3, which='both')
    axs[0].set_ylabel('FS mínimo (log)')
    axs[0].legend(fontsize=7, loc='upper right')
    fig.suptitle('População de variantes por planeta: massa x FS  (linha vermelha = FS exigido)',
                 fontweight='bold')
    fig.tight_layout()
    fig.savefig(f'{po.PASTA}/dispersao.png', dpi=100, bbox_inches='tight')


def main():
    from multiprocessing import Pool
    gv._init()
    por_planeta, fins = {}, {}
    for planeta in fa.FAMILIA:
        por_planeta[planeta] = po.ler_populacao(planeta)
        fins[planeta] = finalistas(por_planeta[planeta])
    figura_dispersao(por_planeta, fins)
    # finalistas.csv
    lin_f = []
    for planeta, (A, B) in fins.items():
        for tag, F in (('A leve', A), ('B rígida', B)):
            if F:
                lin_f.append(dict(F, escolha=tag))
    campos = []
    for l in lin_f:
        campos += [k for k in l if k not in campos]
    with open(f'{po.PASTA}/finalistas.csv', 'w', newline='', encoding='utf-8-sig') as f:
        wr = csv.DictWriter(f, fieldnames=campos, delimiter=';', restval='')
        wr.writeheader(); wr.writerows(lin_f)
    # dados do explorador (com desenhos das variantes válidas)
    tarefas = [(p, l) for p, ls in por_planeta.items() for l in ls if l['valido'] in (True, 'True')]
    with Pool(initializer=gv._init) as pool:
        desenhos = pool.starmap(desenho, tarefas, chunksize=4)
    dmap = {l['id']: d for (p, l), d in zip(tarefas, desenhos)}
    ns = gv._NS
    dados = dict(
        verdes=[_simplificar(np.c_[ns['cima_x'], ns['cima_y']], 80),
                _simplificar(np.c_[ns['baixo_x'], ns['baixo_y']], 80)],
        genes={f: list(gs) + ['material'] for f, gs in po.GENES.items()},
        descricao_genes=po.DESCRICAO_GENES,
        familias=fa.NOME_FAMILIA,
        planetas={})
    import planetas as pl
    for planeta, linhas in por_planeta.items():
        A, B = fins[planeta]
        P = pl.PLANETAS[planeta]
        vs = []
        for l in linhas:
            item = {k: l[k] for k in l}
            for k in ('massa_kg', 'FS_min', 'FS_req', 'rotacao_graus', 'n_elementos'):
                item[k] = None if l.get(k, '') in ('', None) else _num(l[k])
            item['valido'] = l['valido'] in (True, 'True')
            item['passa'] = l['passa'] in (True, 'True')
            item['desenho'] = dmap.get(l['id'])
            item['finalista'] = 'A' if A and l['id'] == A['id'] else ('B' if B and l['id'] == B['id'] else '')
            vs.append(item)
        dados['planetas'][planeta] = dict(
            familia=fa.FAMILIA[planeta], g=P['g'], T=P['T'], FS=P['FS'], ambiente=P['ambiente'],
            terreno=P['terreno'], variantes=vs)
    with open(f'{po.PASTA}/explorador.json', 'w', encoding='utf-8') as f:
        json.dump(dados, f, ensure_ascii=False, separators=(',', ':'))
    print('FINALISTAS (nível 1, teoria de vigas):')
    for planeta, (A, B) in fins.items():
        txt = []
        for tag, F in (('A', A), ('B', B)):
            if F:
                txt.append(f'{tag}: {F["id"]} {F["material"].split(" (")[0]} {_num(F["massa_kg"]):.2f} kg FS {_num(F["FS_min"]):.2f}')
        print(f'  {planeta:9s} ' + ' | '.join(txt))
    print(f'[OK] {po.PASTA}/dispersao.png, finalistas.csv, explorador.json '
          f'({os.path.getsize(po.PASTA + "/explorador.json") / 1e6:.1f} MB)')


if __name__ == '__main__':
    main()
