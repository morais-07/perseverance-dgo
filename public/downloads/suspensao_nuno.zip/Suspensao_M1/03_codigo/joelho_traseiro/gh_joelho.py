# r: numpy, scipy, matplotlib
"""
GRASSHOPPER - JOELHO PARAMÉTRICO POR PLANETA  (componente "Python 3 Script" do Rhino 8)

Cola este código num componente Python 3 Script e cria estas ENTRADAS
(botão direito no componente -> "+" para acrescentar; o nome tem de ser igual):

  planeta    (str)    "Lua", "Mercúrio", "Marte", "Europa", "Titã", "Io" ou "Vénus"
  variante   (str)    vazio = usa os SLIDERS ; "A"/"B" = finalista (leve / rígida) ;
                      "MAR-004"... = variante do catálogo
  largura    (float)  slider 20..95     altura do braço em planta (mm)
  prof       (float)  slider 8..110     profundidade a meio (mm)
  conicidade (float)  slider -0.4..0.4  (só tubo fechado)
  parede     (float)  slider 3..9       (só tubo fechado)
  r_cantos   (float)  slider 0.1..0.5   (só tubo fechado)
  paineis    (int)    slider 3..14      (treliça e nervuras)
  banzo      (float)  slider 6..40      (treliça e nervuras)
  diagonal   (float)  slider 5..16      (só treliça)
  montantes  (int)    slider 0..1       (só treliça)
  alma       (float)  slider 6..26      (só nervuras)
  nervura    (float)  slider 4..10      (só nervuras)
  material   (int)    slider 0..3       0 = o mais leve possível no planeta, 1 = o seguinte...

e estas SAÍDAS:  peca, info, massa, FS_vigas, familia

Cada planeta usa só os genes da SUA família (os outros sliders são ignorados).
Liga 'peca' a um Custom Preview para ver; 'info' a um Panel.
"""
import os
import sys
import importlib

PASTA = r"C:\Mestrado\designD\m1\joelho_traseiro_STEP"
os.chdir(PASTA)
if PASTA not in sys.path:
    sys.path.insert(0, PASTA)
import matplotlib
matplotlib.use("Agg")
import numpy as np
import Rhino.Geometry as rg
import scriptcontext as sc

import gerador_variantes as gv
import joelho3d as j3
import familias as fa
import populacoes as po
import rhino_familias as rf

gv._init()
TOL = 0.01
G = gv._NS["geometria"]
O, U, W = (np.array(G["referencial"][k], float) for k in ("origem_mm", "u", "w"))
X_S = G["x_fronteira_preservar"]
ZC = j3.B_INTERFACE / 2.0


def _entrada(nome, defeito):
    v = globals().get(nome, None)
    return defeito if v is None else v


def _nome_planeta(v):
    """Aceita 'marte', 'Marte ', 'Venus', 'Titã\n'... e devolve o nome exato."""
    import unicodedata
    tira = lambda s: unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode().strip().lower()
    for nome in fa.FAMILIA:
        if tira(nome) == tira(v):
            return nome
    raise Exception("Planeta desconhecido: {!r}. Usa um destes: {}".format(v, ", ".join(fa.FAMILIA)))


planeta_ = _nome_planeta(_entrada("planeta", "Marte"))
var_ = (_entrada("variante", "") or "").strip()
fam = fa.FAMILIA[planeta_]
cn, _, mats = po.base_planeta(planeta_)
lim = po.limites(planeta_, fam)

if var_:
    if var_ in ("A", "B"):
        import csv
        sel = [l for l in csv.DictReader(open("diag/populacoes/finalistas.csv",
               encoding="utf-8-sig"), delimiter=";")
               if l["planeta"] == planeta_ and l["escolha"].startswith(var_)]
    else:
        sel = [l for l in po.ler_populacao(planeta_) if l["id"] == var_]
    genes = po.genes_de_linha(sel[0])
else:
    genes = {}
    for g_ in po.GENES[fam]:
        lo, hi = lim[g_]
        v = float(_entrada(g_, 0.5 * (lo + hi)))
        v = min(max(v, lo), hi)                       # respeita o espaço de design do planeta
        genes[g_] = int(round(v)) if g_ in po.INTEIROS else v
    genes["material"] = mats[min(int(_entrada("material", 0)), len(mats) - 1)]

# ---- geometria (cache: só refaz quando os genes mudam) ----
chave = (planeta_, tuple(sorted(genes.items())))
cache = sc.sticky.get("joelho_gh", {})
if cache.get("chave") != chave:
    rv = po.avaliar(planeta_, genes, contornos=True)
    if not rv.get("valido"):
        cache = dict(chave=chave, peca=None, rv=rv)
    else:
        f = dict(rv["geo"], base=rv["esq"], planeta=planeta_)
        if fam == "fechada":
            b = rf.fechada(f, O, U, W, ZC, TOL, log=lambda *_: None)
        elif fam == "trelica":
            b = rf.trelica(f, O, U, W, ZC, TOL, j3.B_INTERFACE, X_S, log=lambda *_: None)
        else:
            b = rf.isogrid(f, O, U, W, ZC, TOL, X_S, log=lambda *_: None)
        cache = dict(chave=chave, peca=b, rv=rv)
    sc.sticky["joelho_gh"] = cache

rv = cache["rv"]
peca = cache.get("peca")
familia = fa.NOME_FAMILIA[fam]
if not rv.get("valido"):
    info = "INVÁLIDA: {}".format(rv.get("motivo"))
    massa, FS_vigas = None, None
else:
    massa = round(peca.GetVolume() * gv.MATERIAIS[genes["material"]]["rho"] * 1e-9, 3) if peca else rv["massa_kg"]
    FS_vigas = round(rv["FS_min"], 2)
    req = gv.CENARIOS[cn]["FS"]
    info = "{} | {} | {}\n".format(planeta_, familia, genes["material"])
    info += "massa {:.2f} kg | FS vigas {:.2f} (exigido {}) -> {}\n".format(
        massa, FS_vigas, req, "passa" if FS_vigas >= req else "NÃO passa")
    info += "genes: " + ", ".join("{}={}".format(k, round(v, 2) if isinstance(v, float) else v)
                                  for k, v in genes.items())
