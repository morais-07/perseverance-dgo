"""
==============================================================================
 GERADOR DE VARIANTES DE DESIGN - JOELHO DA RODA (Perseverance, M1)
==============================================================================
Ideia: o MESMO sketch paramétrico (codigov1.py) é projetado para FUNÇÕES
diferentes (cenários de missão) e MATERIAIS diferentes. Cada combinação
cenário x material dá um design ótimo diferente: o mais leve que cumpre
TODOS os requisitos desse cenário.

  1. Amostragem do espaço de design (Latin Hypercube nos 14 parâmetros CAD)
  2. Para cada amostra: validade geométrica -> eixo médio -> esforços
     (analise_esforcos.py) para TODOS os casos de carga de todos os cenários
  3. Para cada cenário x material: tensões absolutas (b), FS, rigidez,
     filtro de requisitos -> design mais leve + fronteira de Pareto
  4. Figuras + tabela CSV com os parâmetros para reconstruir no Fusion

Uso:  python gerador_variantes.py            (gera e mostra)
      python gerador_variantes.py --salvar   (grava figuras em diag/)
      python gerador_variantes.py --reusar   (usa resultados já calculados)
==============================================================================
"""
import os
import sys
import csv
import time
import numpy as np
from scipy.stats import qmc

import analise_esforcos as ae

# ==============================================================================
# 1. HIPÓTESES GLOBAIS
# ==============================================================================
B_MM = 40.0          # profundidade da peça (2D -> extrusão). Valor antigo (sem STEP)
LARGURA_RODA = 400.0  # mm. Valor antigo (sem STEP)
FOLGA_PNEU = 20.0     # mm, folga mínima entre o joelho e o pneu (pedras, deformação)
if ae._G is not None:                 # com o STEP: valores REAIS medidos na geometria
    B_MM = round(ae._G['profundidade_braco_mm'], 1)
    LARGURA_RODA = round(ae._G['roda_dados']['largura_mm'], 1)
    FOLGA_PNEU = ae._G['folga_pneu_mm']
N_AMOSTRAS = 1500
SEMENTE = 7

# ==============================================================================
# 2. MATERIAIS (valores típicos de literatura - confirmar nas fichas técnicas)
#    sigma_y: cedência | sigma_f: resistência à fadiga (~1e7 ciclos)
# ==============================================================================
MATERIAIS = {
    'Al 7075-T6 (CNC)':        dict(rho=2810, E=71.7e3,  sy=503, sf=159, cor='#2E86C1'),
    'Ti-6Al-4V (CNC)':         dict(rho=4430, E=113.8e3, sy=880, sf=510, cor='#7D3C98'),
    'Ti-6Al-4V (L-PBF+HIP)':   dict(rho=4430, E=110e3,   sy=850, sf=300, cor='#C0392B'),
    'AlSi10Mg (L-PBF)':        dict(rho=2670, E=70e3,    sy=200, sf=90,  cor='#D68910'),
    'Inconel 718 (CNC)':       dict(rho=8190, E=200e3,   sy=1030, sf=450, cor='#1E8449'),
}
MATERIAIS_MISSAO = ['Al 7075-T6 (CNC)', 'Ti-6Al-4V (CNC)', 'Ti-6Al-4V (L-PBF+HIP)',
                    'AlSi10Mg (L-PBF)']   # conjunto usado nos cenários de missão A-D

# ==============================================================================
# 3. CASOS DE CARGA ELEMENTARES (N, no referencial 2D: X = eixo da roda, Y = vertical)
#    onde: 'plano'      -> contacto roda-solo no plano médio da roda
#          'aresta_ext' -> contacto na aresta EXTERIOR da roda (rocha sob a aresta)
#          'aresta_int' -> contacto na aresta INTERIOR da roda
#          'joelho'     -> rocha a bater DIRETAMENTE no contorno exterior do joelho
# ==============================================================================
W = 1025.0 * 3.71 / 6           # peso por roda em Marte (N)
F_QUEDA = 6.0                   # 1 + h/d  (h = 150 mm, d = 30 mm)
F_ARESTA = 3.0                  # rocha sob a aresta (carga concentrada, rolar)
F_EMBATE = 4.0                  # rocha contra o joelho (deslize lateral)
H_ROCHA = 300.0                 # mm, altura da rocha que bate no joelho
SALIENCIA_MAX = 150.0           # mm, cenário C: saliência lateral máxima do joelho

CASOS = {
    # --- serviço / fadiga ---
    'nominal':          dict(F=(0.0, 1.5 * W),               onde='plano'),
    'nominal_lat+':     dict(F=(+0.3 * 1.5 * W, 1.5 * W),    onde='plano'),
    'nominal_lat-':     dict(F=(-0.3 * 1.5 * W, 1.5 * W),    onde='plano'),
    # --- queda num buraco ---
    'queda':            dict(F=(0.0, F_QUEDA * W),           onde='plano'),
    'queda_lat+':       dict(F=(+0.6 * F_QUEDA * W, F_QUEDA * W), onde='plano'),
    'queda_lat-':       dict(F=(-0.6 * F_QUEDA * W, F_QUEDA * W), onde='plano'),
    # --- rocha sob a aresta da roda ---
    'aresta_ext':       dict(F=(0.0, F_ARESTA * W),          onde='aresta_ext'),
    'aresta_int':       dict(F=(0.0, F_ARESTA * W),          onde='aresta_int'),
    # --- rocha a bater no joelho ---
    'embate_joelho':    dict(F=(+F_EMBATE * W, 0.0),         onde='joelho'),
    # --- rigidez de direção (estático) ---
    'estatico':         dict(F=(0.0, W),                     onde='plano'),
    'estatico_lat+':    dict(F=(+0.3 * W, W),                onde='plano'),
    'estatico_lat-':    dict(F=(-0.3 * W, W),                onde='plano'),
}

# ==============================================================================
# 4. CENÁRIOS DE MISSÃO = FUNÇÕES DIFERENTES PARA A PEÇA
# ==============================================================================
CENARIOS = {
    'A. Travessia longa\n(fadiga, máx. leveza)': dict(
        casos=['nominal', 'nominal_lat+', 'nominal_lat-'],
        criterio='fadiga', FS=1.5, theta_max=None, casos_rigidez=[],
        descricao='Milhares de km em terreno moderado: cargas de serviço repetidas. '
                  'Limita a tensão à resistência à fadiga.'),
    'B. Terreno acidentado\n(queda + rocha sob a roda)': dict(
        casos=['queda', 'queda_lat+', 'queda_lat-', 'aresta_ext', 'aresta_int'],
        criterio='cedencia', FS=2.0, theta_max=None, casos_rigidez=[],
        descricao='Queda num buraco (6W) com e sem carga lateral, e rocha concentrada '
                  'sob as arestas da roda (3W) que aumenta o braço do momento.'),
    'C. Campo de rochas\n(perfil estreito + embate)': dict(
        casos=['queda', 'aresta_ext', 'embate_joelho'],
        criterio='cedencia', FS=2.0, theta_max=None, casos_rigidez=[],
        saliencia_max=SALIENCIA_MAX,
        descricao='Passar entre rochas: o joelho não pode sobressair mais de '
                  f'{SALIENCIA_MAX:.0f} mm para fora da face de ligação (original: ~193 mm), '
                  'e tem de aguentar uma rocha de 300 mm a bater no contorno (4W).'),
    'D. Precisão de direção\n(rigidez, camber < 0.05°)': dict(
        casos=['queda'],
        criterio='cedencia', FS=2.0, theta_max=0.05,
        casos_rigidez=['estatico', 'estatico_lat+', 'estatico_lat-'],
        descricao='Navegação autónoma precisa: a roda não pode rodar mais de 0.05° '
                  '(camber) sob carga estática. Governado pela rigidez E*I.'),
}
CENARIOS_MISSAO = list(CENARIOS)

# ==============================================================================
# 4b. CENÁRIOS POR PLANETA (planetas.py): gravidade, terreno, temperatura, FS
# ==============================================================================
import planetas as pl
_casos_pl, _cen_pl = pl.casos_e_cenarios()
CASOS.update(_casos_pl)
CENARIOS.update(_cen_pl)
CENARIOS_PLANETAS = list(_cen_pl)


def chave_cenario(nome):
    """Aceita 'B', 'Vénus', 'Venus', 'Marte'... e devolve a chave de CENARIOS."""
    import unicodedata
    def simples(s):
        return ''.join(c for c in unicodedata.normalize('NFD', s.replace('\n', ' '))
                       if unicodedata.category(c) != 'Mn').lower().strip()
    for k in CENARIOS:
        if simples(k).startswith(simples(nome)):
            return k
    raise KeyError(f'cenário/planeta desconhecido: {nome}')


def materiais_do_cenario(cn):
    """{nome: propriedades} dos materiais possíveis nesse cenário (com a
    resistência corrigida pela temperatura do planeta) e {nome: motivo} dos excluídos."""
    cen = CENARIOS[cn]
    if 'planeta' not in cen:
        return {m: MATERIAIS[m] for m in MATERIAIS_MISSAO}, {}
    ok, fora = {}, {}
    for m, base in MATERIAIS.items():
        props, motivo = pl.material_no_planeta(m, base, cen['planeta'])
        if props is None:
            fora[m] = motivo
        else:
            ok[m] = props
    return ok, fora


def material(cn, nome):
    """Propriedades do material NAQUELE cenário/planeta."""
    ok, fora = materiais_do_cenario(cn)
    if nome not in ok:
        raise ValueError(f'{nome} não serve em {cn.splitlines()[0]}: {fora.get(nome, "?")}')
    return ok[nome]

# ==============================================================================
# 5. ESPAÇO DE DESIGN (limites dos 14 parâmetros do sketch)
# ==============================================================================
LIMITES = {
    'largura_ombro':    (50.0, 235.0),
    'espessura_sup':    (22.0, 105.0),
    'espessura_inf':    (18.0, 95.0),
    'degrau_topo_y':    (5.0, 50.0),
    'topo_reto_x':      (20.0, 80.0),
    'chanfro_larg_x':   (20.0, 70.0),
    'altura_bloco_sup': (90.0, 170.0),
    'altura_reta_inf':  (45.0, 120.0),
    'recuo_curva_inf':  (55.0, 135.0),
    'R_int_sup':        (20.0, 120.0),
    'R_int_meio':       (15.0, 90.0),
    'R_int_inf':        (15.0, 90.0),
    'R_ext_meio':       (10.0, 85.0),
    'R_ext_inf':        (40.0, 150.0),
    # antes eram números fixos no sketch (25 e 0.6*esp_inf): agora são parâmetros
    'dobra_int_dy':     (0.0, 90.0),    # subida do vértice interior da dobra média
    'base_int_dx':      (10.0, 130.0),  # recuo do vértice interior junto ao cubo
}
NOMES = list(LIMITES)
T_MIN_ABS = 12.0   # mm, espessura mínima de qualquer secção (fabrico + robustez)
DEGRAU_MAX = 12.0  # mm, degrau vivo máximo na face exterior da coluna (concentração de tensões)


# ==============================================================================
# 6. GEOMETRIA AUXILIAR
# ==============================================================================
def auto_intersecta(poly):
    """True se o polígono fechado se cruzar a si próprio."""
    p = poly[:-1] if np.allclose(poly[0], poly[-1]) else poly
    a = p; b = np.roll(p, -1, axis=0)
    n = len(a)
    d = b - a
    i, j = np.triu_indices(n, k=2)
    m = ~((i == 0) & (j == n - 1))          # segmentos adjacentes (fecho)
    i, j = i[m], j[m]
    def cruz(u, v): return u[:, 0] * v[:, 1] - u[:, 1] * v[:, 0]
    den = cruz(d[i], d[j])
    ok = np.abs(den) > 1e-12
    w = a[j] - a[i]
    t = np.where(ok, cruz(w, d[j]) / np.where(ok, den, 1), -1)
    u = np.where(ok, cruz(w, d[i]) / np.where(ok, den, 1), -1)
    eps = 1e-6
    return bool(np.any(ok & (t > eps) & (t < 1 - eps) & (u > eps) & (u < 1 - eps)))


def construir_sketch_v2(ancoras, params):
    """Igual ao construir_sketch_parametrico do codigov1.py, com UMA alteração:
    o degrau na face exterior da coluna (espessura_sup != espessura_inf) deixa
    de ser um canto vivo (entalhe -> concentração de tensões) e passa a ser uma
    rampa de inclinação 1:3. Os dois números fixos do sketch original (25 mm e
    0.6*espessura_inf) passam a ser os parâmetros 'dobra_int_dy' e 'base_int_dx'."""
    x_c, y_c_sup, y_c_inf, x_b, y_b_sup, y_b_inf = ancoras
    p = params
    x_esq_80 = x_c - p['largura_ombro']
    y_ombro = y_c_sup - p['degrau_topo_y']
    y_meio = y_ombro - p['altura_bloco_sup']
    degrau = p['espessura_sup'] - p['espessura_inf']
    x_esq_75 = x_esq_80 + degrau
    y_rampa = y_meio - 3.0 * abs(degrau)
    y_dobra = y_meio - p['altura_reta_inf']
    x_dir_in = x_esq_80 + p['espessura_sup']
    x_base_curva = x_b - p['recuo_curva_inf']
    vr = [
        ([x_c, y_c_sup], 0.0),
        ([x_c - p['topo_reto_x'], y_c_sup], 0.0),
        ([x_c - p['topo_reto_x'] - p['chanfro_larg_x'], y_ombro], 0.0),
        ([x_esq_80, y_ombro], 0.0),
        ([x_esq_80, y_meio], 0.0),
        ([x_esq_75, y_rampa], 0.0),
        ([x_esq_75, y_dobra], p['R_ext_meio']),
        ([x_base_curva, y_b_inf], p['R_ext_inf']),
        ([x_b, y_b_inf], 0.0),
        ([x_b, y_b_sup], 0.0),
        ([x_base_curva + p.get('base_int_dx', 0.6 * p['espessura_inf']), y_b_sup], p['R_int_inf']),
        ([x_dir_in, y_dobra + p.get('dobra_int_dy', 25.0)], p['R_int_meio']),
        ([x_dir_in, y_c_inf], p['R_int_sup']),
        ([x_c, y_c_inf], 0.0),
    ]
    pts = np.array([v[0] for v in vr], float)
    fillet = _NS['gerar_fillet_cad']
    n = len(pts)
    abertas = {}
    if p.get('r_int') is not None:
        abertas = _curvas_interiores_abertas(pts, [v[1] for v in vr], float(p['r_int']))
    sk = np.vstack([_fillet_livre(pts[(i - 1) % n], pts[i], pts[(i + 1) % n], abertas[i])
                    if i in abertas else
                    fillet(pts[(i - 1) % n], pts[i], pts[(i + 1) % n], vr[i][1])
                    for i in range(n)])
    return np.vstack([sk, sk[0]]), pts


# ------------------------------------------------------------------------------
# CURVAS INTERIORES DO "C" ABERTAS (gene r_int, 30/10)
#   No sketch original o arredondamento de cada canto só pode usar 45 % do lado
#   mais curto. Nas duas dobras interiores do C (vértices 10 = em baixo, junto ao
#   cubo, e 12 = em cima, junto ao braço) os lados curtos acabam na fronteira das
#   zonas verdes, onde não há outro arredondamento a disputar o espaço; por isso
#   o raio ficava preso a ~14 mm (em baixo) e ~27 mm (em cima) qualquer que fosse
#   o valor pedido. Com o gene r_int, esses dois cantos podem usar até 95 % do
#   lado que acaba na zona verde (e o que sobra do lado partilhado). Nunca ficam
#   mais fechados do que no desenho base. A folga ao pneu e a espessura mínima
#   continuam a ser verificadas em avaliar().
# ------------------------------------------------------------------------------
CANTOS_INT = {10: 9, 12: 13}      # canto interior -> vizinho fixo (fronteira verde)
FRAC_LIVRE = 0.95


def _angulo(p_ant, p, p_prox):
    u1 = (p_ant - p) / np.linalg.norm(p_ant - p)
    u2 = (p_prox - p) / np.linalg.norm(p_prox - p)
    return float(np.arccos(np.clip(u1 @ u2, -1.0, 1.0)))


def _curvas_interiores_abertas(pts, raios, r_pedido):
    """Raio efetivo de cada canto interior aberto {índice: raio}."""
    n = len(pts)
    out = {}
    for i, fixo in CANTOS_INT.items():
        a, b = (i - 1) % n, (i + 1) % n
        ang = _angulo(pts[a], pts[i], pts[b])
        if ang <= 0.01 or ang >= np.pi - 0.01:
            continue
        tg = np.tan(ang / 2.0)
        d_a, d_b = np.linalg.norm(pts[a] - pts[i]), np.linalg.norm(pts[b] - pts[i])
        cap = []
        for viz, d in ((a, d_a), (b, d_b)):
            if viz == fixo:
                cap.append(FRAC_LIVRE * d)
            else:                       # lado partilhado: desconta o arredondamento do vizinho
                ang_v = _angulo(pts[(viz - 1) % n], pts[viz], pts[(viz + 1) % n])
                L_v = raios[viz] / np.tan(ang_v / 2.0) if 0.01 < ang_v < np.pi - 0.01 else 0.0
                L_v = min(L_v, 0.45 * d)
                cap.append(FRAC_LIVRE * (d - L_v))
        r_base = min(raios[i] / tg, 0.45 * min(d_a, d_b)) * tg     # o que o sketch base dava
        r_max = min(cap) * tg
        out[i] = float(max(r_base, min(r_pedido, r_max)))
    return out


def _fillet_livre(p_ant, p_canto, p_prox, raio, num_pts=25):
    """Arco tangente de raio dado (sem o limite de 45 % do gerar_fillet_cad)."""
    v1, v2 = p_ant - p_canto, p_prox - p_canto
    u1, u2 = v1 / np.linalg.norm(v1), v2 / np.linalg.norm(v2)
    ang = np.arccos(np.clip(u1 @ u2, -1.0, 1.0))
    L = raio / np.tan(ang / 2.0)
    t1, t2 = p_canto + u1 * L, p_canto + u2 * L
    bis = (u1 + u2) / np.linalg.norm(u1 + u2)
    c = p_canto + bis * (raio / np.sin(ang / 2.0))
    a1 = np.arctan2(t1[1] - c[1], t1[0] - c[0])
    a2 = np.arctan2(t2[1] - c[1], t2[0] - c[0])
    d = (a2 - a1 + np.pi) % (2 * np.pi) - np.pi
    a = np.linspace(a1, a1 + d, num_pts)
    return np.column_stack([c[0] + raio * np.cos(a), c[1] + raio * np.sin(a)])


def densificar(poly, passo=1.0):
    seg = np.diff(poly, axis=0)
    L = np.hypot(*seg.T)
    out = [p0 + np.outer(np.arange(max(int(l / passo), 1)) / max(int(l / passo), 1), d)
           for p0, d, l in zip(poly[:-1], seg, L)]
    return np.vstack(out + [poly[-1:]])


def area(poly):
    x, y = poly[:, 0], poly[:, 1]
    return 0.5 * abs(np.dot(x, np.roll(y, 1)) - np.dot(y, np.roll(x, 1)))


# ==============================================================================
# 7. AVALIAÇÃO DE UMA AMOSTRA (todos os casos de carga de uma vez)
# ==============================================================================
_NS = None


def _init():
    global _NS, _P, _XF, _YE
    if _NS is None:
        import matplotlib
        matplotlib.use('Agg')
        _NS = ae.carregar_geometria()
        _P, _XF, _YE = ae.ponto_de_carga(_NS)


def pontos_roda():
    xp = _P[0]
    return {'plano': _P.copy(),
            'aresta_ext': np.array([xp + LARGURA_RODA / 2, _P[1]]),
            'aresta_int': np.array([xp - LARGURA_RODA / 2, _P[1]])}


def avaliar(params, sketch=None, fino=False):
    """Devolve dict com área, t_min, sigma*b máx por caso e theta*E*b por caso."""
    _init()
    if sketch is not None:
        sk = sketch                       # design original (sketch do codigov1)
    else:
        sk, _ = construir_sketch_v2(_NS['ancoras_verdes'], params)
    out = dict(valido=False, area=area(sk), sketch=sk,
               saliencia=float(_NS['ancoras_verdes'][0] - sk[:, 0].min()))
    if sketch is None and (params['topo_reto_x'] + params['chanfro_larg_x']
                           > params['largura_ombro'] - 5.0):
        out['motivo'] = 'chanfro do topo passa a coluna (bico)'; return out
    if sketch is None and abs(params['espessura_sup'] - params['espessura_inf']) > DEGRAU_MAX + 0.01:
        out['motivo'] = 'degrau exterior vivo'; return out
    if auto_intersecta(sk):
        out['motivo'] = 'auto-interseção'; return out
    try:
        res_, n_ = (0.5, 400) if fino else (1.0, 200)
        s, S, tang, t, rho = ae.eixo_medio(sk, _NS['ancoras_verdes'], res=res_, n_pts=n_)
    except Exception as e:
        out['motivo'] = str(e); return out
    # --- folga ao pneu: o joelho não pode entrar na banda do pneu ---
    #     (pode entrar no interior do tambor, por onde passa o cubo)
    skd = densificar(sk, 1.0)            # arestas retas também têm de ser testadas
    dy = np.abs(skd[:, 1] - _YE)
    x_pneu = _P[0] - LARGURA_RODA / 2
    R_int = ae.DADOS['raio_roda_int']; R_ext = ae.DADOS['raio_roda_ext']
    na_banda = (dy >= R_int - FOLGA_PNEU) & (dy <= R_ext + FOLGA_PNEU)
    folga = np.min(x_pneu - skd[na_banda, 0]) if na_banda.any() else np.inf
    out['folga_pneu'] = float(folga)
    if folga < FOLGA_PNEU:
        out['motivo'] = 'interfere com o pneu'; return out
    if t.min() < T_MIN_ABS:
        out['motivo'] = 'parede fina'; out['t_min'] = t.min(); return out
    # o eixo tem de ligar mesmo as duas faces (comprimento plausível)
    if s[-1] < 300:
        out['motivo'] = 'eixo inválido'; return out

    pts = pontos_roda()
    # ponto de embate da rocha: contorno mais à esquerda à altura da rocha
    y_rocha = _P[1] + H_ROCHA
    perto = np.abs(sk[:, 1] - y_rocha) < 6
    if perto.any():
        Pj = sk[perto][np.argmin(sk[perto][:, 0])]
    else:  # a rocha passa abaixo da peça
        Pj = None
    sig, the, kcrit = {}, {}, {}
    for nome, c in CASOS.items():
        if c['onde'] == 'joelho':
            if Pj is None:
                sig[nome] = 0.0; the[nome] = 0.0; kcrit[nome] = 0; continue
            k0 = int(np.argmin(np.hypot(*(S - Pj).T)))
            N, V, M = ae.esforcos(S, tang, Pj, c['F'], k_aplic=k0)
        else:
            N, V, M = ae.esforcos(S, tang, pts[c['onde']], c['F'])
        vm, *_ = ae.tensoes(N, V, M, t, rho, b=1.0)
        k = int(np.argmax(vm))
        sig[nome] = float(vm[k]); kcrit[nome] = k
        # rotação do cubo (relativa ao encastramento): theta = int M/(E I) ds
        # com I = b t^3 / 12  ->  guarda theta*E*b
        the[nome] = float(np.trapezoid(12.0 * M / t ** 3, s)) if hasattr(np, 'trapezoid') \
            else float(np.trapz(12.0 * M / t ** 3, s))
    out.update(valido=True, t_min=float(t.min()), sig=sig, theta=the,
               kcrit=kcrit, S=S, Pj=Pj)
    return out


# ==============================================================================
# 8. AVALIAR UM DESIGN NUM CENÁRIO x MATERIAL
# ==============================================================================
MARGEM_TRIAGEM = 1.10   # a triagem rápida (resolução 1 mm) exige +10% de FS/rigidez


def desempenho(r, cen, mat, margem=1.0):
    """massa [kg], FS mínimo, camber [graus], cumpre?, caso crítico"""
    massa = mat['rho'] * r['area'] * B_MM * 1e-9
    if not r['valido']:
        return massa, 0.0, np.inf, False, '-'
    adm = mat['sf'] if cen['criterio'] == 'fadiga' else mat['sy']
    fs_casos = {c: adm / max(r['sig'][c] / B_MM, 1e-9) for c in cen['casos']}
    caso_crit = min(fs_casos, key=fs_casos.get)
    fs = fs_casos[caso_crit]
    cumpre = fs >= cen['FS'] * margem
    if cen.get('saliencia_max') is not None:
        cumpre &= r['saliencia'] <= cen['saliencia_max']
    cam = 0.0
    if cen['theta_max'] is not None:
        cam = max(abs(r['theta'][c]) for c in cen['casos_rigidez']) / (mat['E'] * B_MM)
        cam = np.degrees(cam)
        cumpre &= cam * margem <= cen['theta_max']
    return massa, fs, cam, bool(cumpre), caso_crit


# ==============================================================================
# 9. EXECUÇÃO
# ==============================================================================
def amostrar(n, semente):
    lhs = qmc.LatinHypercube(d=len(NOMES), seed=semente).random(n)
    lo = np.array([LIMITES[k][0] for k in NOMES])
    hi = np.array([LIMITES[k][1] for k in NOMES])
    X = lo + lhs * (hi - lo)
    # a espessura inferior é amostrada RELATIVA à superior (degrau <= DEGRAU_MAX)
    i_s, i_i = NOMES.index('espessura_sup'), NOMES.index('espessura_inf')
    X[:, i_i] = np.clip(X[:, i_s] + (2 * lhs[:, i_i] - 1) * DEGRAU_MAX,
                        LIMITES['espessura_inf'][0], LIMITES['espessura_inf'][1])
    return [dict(zip(NOMES, x)) for x in X]


def vizinhos(params, sigma, n, rng):
    """Perturbações gaussianas à volta de um design (espaço normalizado)."""
    lo = np.array([LIMITES[k][0] for k in NOMES])
    hi = np.array([LIMITES[k][1] for k in NOMES])
    x0 = (np.array([params[k] for k in NOMES]) - lo) / (hi - lo)
    X = np.clip(x0 + rng.normal(0, sigma, (n, len(NOMES))), 0, 1)
    X = lo + X * (hi - lo)
    i_s, i_i = NOMES.index('espessura_sup'), NOMES.index('espessura_inf')
    X[:, i_i] = np.clip(X[:, i_i], X[:, i_s] - DEGRAU_MAX + 0.005, X[:, i_s] + DEGRAU_MAX - 0.005)
    return [dict(zip(NOMES, x)) for x in X]


def refinar(pool, params0, perf0, cen, mat, rng, rondas=(0.08, 0.04, 0.02), n=48):
    """Pesquisa local (estratégia evolutiva simples): à volta do melhor
    design viável, amostra vizinhos, fica com o mais leve que cumpre, e
    reduz o raio de pesquisa."""
    melhor_p, melhor_perf, melhor_r = params0, perf0, None
    for sg in rondas:
        cand = vizinhos(melhor_p, sg, n, rng)
        for pc, rc in zip(cand, pool.map(avaliar, cand, chunksize=4)):
            pf = desempenho(rc, cen, mat, MARGEM_TRIAGEM)
            if pf[3] and pf[0] < melhor_perf[0]:
                melhor_p, melhor_perf, melhor_r = pc, pf, rc
    return melhor_p, melhor_perf, melhor_r


def correr(n=N_AMOSTRAS, semente=SEMENTE):
    from multiprocessing import Pool
    amostras = amostrar(n, semente)
    t0 = time.time()
    with Pool(initializer=_init) as pool:
        res = []
        for i, r in enumerate(pool.imap(avaliar, amostras, chunksize=8)):
            res.append(r)
            if (i + 1) % 250 == 0:
                print(f'  {i+1}/{n} designs avaliados ({time.time()-t0:.0f} s)')
    return amostras, res


if __name__ == '__main__':
    salvar = '--salvar' in sys.argv
    import matplotlib
    if salvar:
        matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import pickle
    MISSOES = '--missoes' in sys.argv          # por defeito: planetas
    CONJ = CENARIOS_MISSAO if MISSOES else CENARIOS_PLANETAS
    PASTA_OUT = 'diag' if MISSOES else 'diag/planetas'
    os.makedirs(PASTA_OUT, exist_ok=True)
    cache = 'diag/variantes_cache_v2.pkl'       # tem os casos de missão E de planetas
    MATS = [m for m in MATERIAIS if any(m in materiais_do_cenario(c)[0] or
                                        m in materiais_do_cenario(c)[1] for c in CONJ)]

    _init()
    base = avaliar(_NS['parametros_base'], sketch=_NS['sketch_cad_base'])
    base_fino = avaliar(_NS['parametros_base'], sketch=_NS['sketch_cad_base'], fino=True)
    amostras = None
    if '--reusar' in sys.argv and os.path.exists(cache):
        with open(cache, 'rb') as f:
            amostras, res = pickle.load(f)
        if not all(set(CASOS) <= set(r['sig']) for r in res if r['valido']):
            print('Cache sem todos os casos de carga: a recalcular.')
            amostras = None
    if amostras is None:
        print(f'A avaliar {N_AMOSTRAS} designs (Latin Hypercube, {len(NOMES)} parâmetros)...')
        amostras, res = correr()
        with open(cache, 'wb') as f:
            pickle.dump((amostras, res), f)
    validos = sum(r['valido'] for r in res)
    print(f'Designs geometricamente válidos: {validos}/{len(res)}')

    # ---------------- seleção + refinamento do ótimo por cenário x material ----------------
    from multiprocessing import Pool
    rng = np.random.default_rng(SEMENTE)
    linhas = []
    otimos = {}
    m_ref = desempenho(base, list(CENARIOS.values())[0], MATERIAIS['Al 7075-T6 (CNC)'])[0]
    print('A refinar o ótimo de cada cenário x material (pesquisa local)...')
    with Pool(initializer=_init) as pool:
        for cn in CONJ:
            cen = CENARIOS[cn]
            mats_ok, mats_fora = materiais_do_cenario(cn)
            for mn in MATS:
                if mn not in mats_ok:
                    otimos[(cn, mn)] = ('excluido', mats_fora.get(mn, 'não usado'), None)
                    linhas.append(dict(cenario=cn.replace('\n', ' '), material=mn, n_viaveis=0,
                                       massa_kg=np.nan, caso_critico='excluído: ' +
                                       mats_fora.get(mn, 'não usado')))
                    print(f'  {cn.splitlines()[0][:28]:28s} {mn:24s} excluído '
                          f'({mats_fora.get(mn, "não usado")})')
                    continue
                mat = mats_ok[mn]
                perf = [desempenho(r, cen, mat, MARGEM_TRIAGEM) for r in res]
                ok = [i for i, p in enumerate(perf) if p[3]]
                mb, fsb, camb, okb, ccb = desempenho(base_fino, cen, mat)
                escolhido = None
                if ok:
                    i = min(ok, key=lambda i: perf[i][0])
                    pr, pf, rr = refinar(pool, amostras[i], perf[i], cen, mat, rng)
                    # candidatos por ordem de massa: refinado + melhores globais
                    cands = [pr] + [amostras[j] for j in sorted(ok, key=lambda j: perf[j][0])[:15]]
                    for pc in cands:
                        rf = avaliar(pc, fino=True)          # confirmação em resolução fina
                        pff = desempenho(rf, cen, mat)
                        if pff[3]:
                            escolhido = (rf, pff, pc); break
                if escolhido:
                    otimos[(cn, mn)] = escolhido
                    rr, pf, pr = escolhido
                    print(f'  {cn.splitlines()[0][:28]:28s} {mn:24s} {pf[0]:.2f} kg  '
                          f'(FS confirmado {pf[1]:.2f})')
                else:
                    otimos[(cn, mn)] = (None, None, None)
                    ok = []
                lin = dict(cenario=cn.replace('\n', ' '), material=mn, n_viaveis=len(ok))
                if ok:
                    lin.update(massa_kg=pf[0],
                               reducao_vs_original_Al_pct=100 * (1 - pf[0] / m_ref),
                               FS=pf[1], camber_graus=pf[2], caso_critico=pf[4],
                               saliencia_mm=rr['saliencia'])
                else:
                    lin.update(massa_kg=np.nan, reducao_vs_original_Al_pct=np.nan, FS=np.nan,
                               camber_graus=np.nan, caso_critico='-', saliencia_mm=np.nan)
                lin.update(original_FS=fsb, original_cumpre=okb, original_massa_kg=mb)
                if ok:
                    lin.update({k: round(float(v), 3) for k, v in pr.items()})
                linhas.append(lin)

    # ---------------- tabela ----------------
    print('\n' + '=' * 100)
    print(f'  DESIGNS ÓTIMOS (mínima massa que cumpre o cenário)   b = {B_MM:.1f} mm '
          f'({"medido no STEP" if ae._G is not None else "provisório"})')
    print('=' * 100)
    print(f'{"Cenário":42s}{"Material":24s}{"viáveis":>8s}{"massa kg":>10s}'
          f'{"vs orig.":>9s}{"FS":>6s}  {"crítico":14s}{"original":>10s}')
    for l in linhas:
        if str(l.get('caso_critico', '')).startswith('excluído'):
            print(f'{l["cenario"][:41]:42s}{l["material"]:24s}  -- {l["caso_critico"]}')
            continue
        orig = f'FS {l["original_FS"]:.1f} ' + ('OK' if l['original_cumpre'] else 'FALHA')
        if l['n_viaveis']:
            print(f'{l["cenario"][:41]:42s}{l["material"]:24s}{l["n_viaveis"]:8d}'
                  f'{l["massa_kg"]:10.2f}{-l["reducao_vs_original_Al_pct"]:+8.0f}%'
                  f'{l["FS"]:6.1f}  {l["caso_critico"]:14s}{orig:>12s}')
        else:
            print(f'{l["cenario"][:41]:42s}{l["material"]:24s}{0:8d}  -- nenhum design cumpre --   {orig}')
    with open(f'{PASTA_OUT}/designs_otimos.csv', 'w', newline='', encoding='utf-8-sig') as f:
        campos = []
        for l in linhas:
            campos += [k for k in l if k not in campos]
        campos += [k for k in NOMES if k not in campos]
        wr = csv.DictWriter(f, fieldnames=campos, delimiter=';', restval='')
        wr.writeheader(); wr.writerows(linhas)
    print(f'[OK] {PASTA_OUT}/designs_otimos.csv')

    ns = _NS
    def verdes(ax):
        ax.fill(ns['cima_x'], ns['cima_y'], 'limegreen', ec='darkgreen', lw=.8, alpha=.85)
        ax.fill(ns['baixo_x'], ns['baixo_y'], 'limegreen', ec='darkgreen', lw=.8, alpha=.85)

    # ---------------- FIGURA 1: grelha cenário x material ----------------
    todos_x = np.r_[ns['cima_x'], ns['baixo_x'], base['sketch'][:, 0]]
    todos_y = np.r_[ns['cima_y'], ns['baixo_y'], base['sketch'][:, 1]]
    LIM_X = (todos_x.min() - 60, max(todos_x.max(), _P[0] + LARGURA_RODA / 2) + 20)
    LIM_Y = (_YE - ae.DADOS['raio_roda_ext'] - 25, todos_y.max() + 40)
    nc, nm = len(CONJ), len(MATS)
    fig, axs = plt.subplots(nc, nm, figsize=(4.4 * nm, 3.9 * nc), squeeze=False)
    for a, cn in enumerate(CONJ):
        for b, mn in enumerate(MATS):
            mat = MATERIAIS[mn]
            ax = axs[a, b]
            verdes(ax)
            ax.plot(base['sketch'][:, 0], base['sketch'][:, 1], 'k:', lw=1)
            ri, p, _ = otimos[(cn, mn)]
            if isinstance(ri, str):
                ax.set_facecolor('0.92')
                ax.set_title(f'excluído:\n{p}', fontsize=9, color='0.4')
            elif ri is not None:
                sk = ri['sketch']
                ax.fill(sk[:, 0], sk[:, 1], color=mat['cor'], alpha=.45)
                ax.plot(sk[:, 0], sk[:, 1], color=mat['cor'], lw=1.8)
                if CENARIOS[cn]['casos'] and 'embate_joelho' in CENARIOS[cn]['casos'] \
                        and ri['Pj'] is not None:
                    Pj = ri['Pj']
                    ax.annotate('', xy=Pj, xytext=(Pj[0] - 70, Pj[1]),
                                arrowprops=dict(arrowstyle='->', color='r', lw=2))
                extra = f' | {p[2]:.3f}°' if CENARIOS[cn]['theta_max'] else ''
                ax.set_title(f'{p[0]:.2f} kg ({100*(p[0]/m_ref-1):+.0f}% vs orig. Al)\n'
                             f'FS {p[1]:.1f}{extra} | crít.: {p[4]}', fontsize=9)
            else:
                ax.set_title('nenhum design cumpre', fontsize=9, color='r')
            if CENARIOS[cn].get('saliencia_max'):
                ax.axvline(ns['ancoras_verdes'][0] - CENARIOS[cn]['saliencia_max'],
                           color='r', ls='--', lw=1)
            xp = _P[0] - LARGURA_RODA / 2
            for sg in (+1, -1):
                y0 = _YE + sg * ae.DADOS['raio_roda_int']
                ax.add_patch(plt.Rectangle((xp, min(y0, y0 + sg * 20.7)), LARGURA_RODA, 20.7,
                                           color='0.35', alpha=.5, lw=0))
            ax.set_xlim(*LIM_X); ax.set_ylim(*LIM_Y)
            ax.set_aspect('equal'); ax.set_xticks([]); ax.set_yticks([])
            if a == 0:
                ax.annotate(mn, (0.5, 1.28), xycoords='axes fraction', ha='center',
                            fontsize=11, fontweight='bold', color=mat['cor'])
            if b == 0:
                ax.set_ylabel(cn, fontsize=10, fontweight='bold')
    fig.suptitle(f'Design ótimo por {"FUNÇÃO" if MISSOES else "PLANETA"} (linhas) e MATERIAL (colunas) - '
                 f'{N_AMOSTRAS} variantes avaliadas | b = {B_MM:.1f} mm | ··· original'
                 f'{" (geometria do STEP)" if ae._G is not None else ""}',
                 fontsize=13, fontweight='bold')
    fig.tight_layout(rect=(0, 0, 1, 0.96))

    # ---------------- FIGURA 2: espaço de soluções (massa vs FS) ----------------
    fig2, axs2 = plt.subplots(1, nc, figsize=(5.2 * nc, 5.2), sharey=False, squeeze=False)
    axs2 = axs2[0]
    for a, cn in enumerate(CONJ):
        cen = CENARIOS[cn]
        ax = axs2[a]
        for mn, mat in materiais_do_cenario(cn)[0].items():
            mat = dict(mat, cor=MATERIAIS[mn]['cor'])
            perf = np.array([desempenho(r, cen, mat)[:4] for r in res if r['valido']], float)
            m, fs, ok = perf[:, 0], perf[:, 1], perf[:, 3] > 0
            ax.scatter(m[~ok], fs[~ok], s=5, color=mat['cor'], alpha=.12)
            ax.scatter(m[ok], fs[ok], s=7, color=mat['cor'], alpha=.55, label=mn)
            # fronteira de Pareto (min massa, max FS)
            o = np.argsort(m); best = -np.inf; px, py = [], []
            for j in o:
                if fs[j] > best:
                    best = fs[j]; px.append(m[j]); py.append(fs[j])
            ax.plot(px, py, '-', color=mat['cor'], lw=1.2)
            ri, p, _ = otimos[(cn, mn)]
            if ri is not None:
                ax.plot(p[0], p[1], '*', ms=15, mec='k', color=mat['cor'])
            mb, fsb, *_ = desempenho(base_fino, cen, mat)
            ax.plot(mb, fsb, 'D', ms=8, mec='k', color=mat['cor'])
        ax.axhline(cen['FS'], color='r', ls='--', lw=1.2)
        ax.text(ax.get_xlim()[0], cen['FS'], f'  FS mín = {cen["FS"]}', color='r', va='bottom')
        ax.set_yscale('log')
        ax.set_xlabel('massa [kg]'); ax.set_ylabel('FS mínimo (log)')
        ax.set_title(cn, fontsize=10, fontweight='bold')
        ax.grid(ls='--', alpha=.4, which='both')
        if a == 0:
            ax.legend(fontsize=7, loc='upper left', markerscale=2)
    fig2.suptitle('Espaço de soluções: massa vs fator de segurança  '
                  '(★ ótimo do cenário, ◆ peça original, linha = Pareto)',
                  fontsize=13, fontweight='bold')
    fig2.tight_layout(rect=(0, 0, 1, 0.94))

    if salvar:
        fig.savefig(f'{PASTA_OUT}/variantes_grelha.png', dpi=100, bbox_inches='tight')
        fig2.savefig(f'{PASTA_OUT}/variantes_pareto.png', dpi=100, bbox_inches='tight')
        print(f'[OK] {PASTA_OUT}/variantes_grelha.png, {PASTA_OUT}/variantes_pareto.png')
    else:
        plt.show()
