"""
==============================================================================
 DEGRADAÇÃO POR PLANETA  (erosão, desgaste, corrosão, ciclo térmico, radiação)
==============================================================================
O ambiente não só carrega a peça: também a GASTA ao longo da missão. Cada
condição de degradação vira uma REGRA DE GEOMETRIA na geração 2D:

  1. SOBRE-ESPESSURA SACRIFICIAL  delta [mm por face exposta]
       abrasão do regolito, jato de areia, gelo duro, corrosão química.
       A peça é dimensionada no FIM DE VIDA: o FS é calculado com a secção
       GASTA (cada face exposta perde delta), mas a massa conta a secção NOVA.
       -> peças mais grossas onde o ambiente é agressivo.
  2. REDUÇÃO DA RESISTÊNCIA  k_mat [-]  (sy e sf x k_mat)
       fadiga térmica (ciclo dia/noite), fluência, radiação, fragilização
       criogénica. Soma-se à perda a quente de planetas.material_no_planeta.
  3. RAIOS MÍNIMOS  r_cantos_min [-], r_int_min [mm]
       ciclo térmico grande / tenacidade baixa -> cantos vivos proibidos
       (concentração de tensões arranca fissuras de fadiga térmica).
  4. PAREDE MÍNIMA  parede_min [mm]  (só tubo fechado)
       perfuração por rochas aguçadas (como as rodas do Curiosity).

Faces expostas por família:
  fechada  - só a pele exterior (a cavidade é selada; o respiro Ø3 é pequeno)
  treliça  - todas (banzos e diagonais têm as duas faces ao ambiente)
  nervuras - todas (alma e banzos dentro de rebaixos abertos)

Todos os valores são HIPÓTESES DE PROJETO (ver HIPOTESES.md, secção
"Degradação"); servem para mostrar o efeito de cada ambiente, não são dados
de certificação.
==============================================================================
"""

DEGRADACAO = {
    'Lua': dict(
        delta=0.50, k_mat=0.95, r_cantos_min=None, r_int_min=None, parede_min=None,
        condicoes='Regolito abrasivo (grãos vítreos aguçados) + ciclo térmico de 300 °C.',
        regra='+0,5 mm de pele sacrificial; -5 % de resistência (fadiga térmica).'),
    'Mercúrio': dict(
        delta=0.50, k_mat=0.85, r_cantos_min=0.30, r_int_min=40.0, parede_min=None,
        condicoes='Regolito tipo lunar + ciclo térmico enorme (-180 a +430 °C, 610 °C).',
        regra='+0,5 mm de pele; -15 % (fadiga térmica); cantos e curvas do C com raio grande.'),
    'Marte': dict(
        delta=0.25, k_mat=1.00, r_cantos_min=None, r_int_min=None, parede_min=4.0,
        condicoes='Vento rarefeito com poeira fina (abrasão lenta) + rochas aguçadas.',
        regra='+0,25 mm de pele; parede do tubo >= 4 mm (perfuração, como nas rodas do Curiosity).'),
    'Vénus': dict(
        delta=1.00, k_mat=0.85, r_cantos_min=None, r_int_min=None, parede_min=None,
        condicoes='Ácido sulfúrico / compostos de enxofre a 465 °C e 92 bar; fluência.',
        regra='+1 mm de corrosão em todas as faces; -15 % (fluência a longo prazo).'),
    'Europa': dict(
        delta=0.30, k_mat=0.90, r_cantos_min=None, r_int_min=30.0, parede_min=None,
        condicoes='Gelo a -160 °C (duro e abrasivo) + radiação intensa de Júpiter.',
        regra='+0,3 mm de desgaste; -10 % (radiação + tenacidade baixa a frio); curvas do C >= 30 mm.'),
    'Io': dict(
        delta=0.50, k_mat=0.90, r_cantos_min=None, r_int_min=30.0, parede_min=None,
        condicoes='Geada de enxofre/SO2, partículas vulcânicas, radiação de Júpiter.',
        regra='+0,5 mm (corrosão por enxofre + abrasão); -10 % (radiação); curvas do C >= 30 mm.'),
    'Titã': dict(
        delta=0.10, k_mat=1.00, r_cantos_min=None, r_int_min=None, parede_min=None,
        condicoes='Metano/azoto inertes, areia orgânica mole: o ambiente mais benigno.',
        regra='+0,1 mm (quase nada): referência sem degradação.'),
}

LIGADA = True     # False -> gera como antes (para comparar com/sem degradação)


def de(planeta):
    """Parâmetros de degradação do planeta (todos neutros se LIGADA=False)."""
    if not LIGADA:
        return dict(delta=0.0, k_mat=1.0, r_cantos_min=None, r_int_min=None, parede_min=None)
    return DEGRADACAO[planeta]


# quanto cada gene engrossa: nº de faces expostas x delta
FACES = {
    'fechada': dict(largura=2, prof=2, parede=1),
    'trelica': dict(largura=2, prof=2, banzo=2, diagonal=2),
    'isogrid': dict(largura=2, prof=2, banzo=2, alma=2, nervura=2),
}


def engrossar(genes, familia, planeta):
    """Genes ESTRUTURAIS -> genes da peça NOVA: o planeta acrescenta a pele sacrificial.
    O mesmo gene dá peças diferentes em planetas diferentes."""
    dl = de(planeta)['delta']
    g = dict(genes)
    for k, n in FACES[familia].items():
        if k in g:
            g[k] = float(g[k]) + n * dl
    return g


def material_gasto(mat, planeta):
    k = de(planeta)['k_mat']
    out = dict(mat, sy=mat['sy'] * k, k_deg=k)
    if 'sf' in mat:
        out['sf'] = mat['sf'] * k
    return out


if __name__ == '__main__':
    for p, d in DEGRADACAO.items():
        print(f"{p:9s} delta={d['delta']:.2f} mm  k={d['k_mat']:.2f}  {d['regra']}")
