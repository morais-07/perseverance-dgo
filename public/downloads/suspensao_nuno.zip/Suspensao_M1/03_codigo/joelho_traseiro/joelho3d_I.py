"""
==============================================================================
 JOELHO 3D - FASE 1b: SECÇÃO EM I (rebaixos dos dois lados + nervuras)
==============================================================================
Cada secção do joelho deixa de ser um retângulo cheio t x b e passa a ser:

        z ^          banzo         banzo
          |   ┌──┐               ┌──┐      b  = profundidade total
          |   │  │───────────────│  │      wf = largura do banzo (no plano)
          |   │  │     alma      │  │      tw = espessura da alma (em z)
          |   │  │───────────────│  │      h  = t - 2 wf (largura do rebaixo)
          |   └──┘               └──┘
          +---------------- t (no plano) ----------------> n

Em cada secção escolhe-se (b, wf, tw) com a MENOR ÁREA (= menor massa) que:
  - aguenta todos os casos de carga NO PLANO do cenário (N, V, M, Winkler);
  - aguenta a carga FORA DO PLANO (flexão lateral + TORÇÃO de secção aberta,
    que é o ponto fraco de um I);
  - no cenário D, mantém a rigidez: Iz >= Iz da Fase 1 (camber igual);
  - respeita o processo de fabrico (CNC vs impressão L-PBF).
Depois aplicam-se regras que SÓ AUMENTAM material (logo nunca reduzem o FS):
suavidade, zonas cheias junto às faces verdes, extremos dos rebaixos
arredondados e rebaixos que cabem nas curvas.

Uso isolado:  python joelho3d_I.py    (compara cheia -> b(s) -> b(s)+I)
==============================================================================
"""
import numpy as np
from matplotlib.path import Path
from scipy.spatial import Delaunay
from scipy.ndimage import maximum_filter1d, gaussian_filter1d

import gerador_variantes as gv
import joelho3d as j3

# ==============================================================================
# 1. REGRAS DE FABRICO
# ==============================================================================
FABRICO = {
    #            alma mín | banzo mín | largura mín do rebaixo | profundidade máx de cada rebaixo
    'CNC':   dict(alma_min=3.0, banzo_min=4.0, rebaixo_min=10.0, prof_max=30.0),
    'L-PBF': dict(alma_min=1.5, banzo_min=2.5, rebaixo_min=5.0,  prof_max=1e9),
}
COMPRIMENTO_MIN_REBAIXO = 20.0    # mm, rebaixos mais curtos não compensam
FOLGA_CURVA = 0.85                # o rebaixo tem de caber na curvatura do eixo


def processo(material):
    return 'L-PBF' if 'L-PBF' in material else 'CNC'


# ==============================================================================
# 2. PROPRIEDADES E TENSÕES DA SECÇÃO EM I (vetorizadas)
# ==============================================================================
def _beta(c, L):
    """Constante de torção de um retângulo L x c (L >= c): J = beta L c^3 (Roark)."""
    r = c / np.maximum(L, 1e-9)
    return 1 / 3 - 0.21 * r * (1 - r ** 4 / 12)


def propriedades(t, b, wf, tw):
    h = np.maximum(t - 2 * wf, 0.0)
    A = b * t - (b - tw) * h
    Iz = (b * t ** 3 - (b - tw) * h ** 3) / 12.0           # flexão no plano
    In = (2 * wf * b ** 3 + h * tw ** 3) / 12.0            # flexão fora do plano
    return h, A, Iz, In


H_LIM = 5.0   # mm: abaixo disto (pontas arredondadas) o rebaixo é só um sulco ->
              # corte e torção como secção cheia (a fórmula de secção aberta
              # trataria os banzos como separados, o que é irrealista)


def sigma_plano(t, b, wf, tw, N, V, M, fc):
    h, A, Iz, _ = propriedades(t, b, wf, tw)
    sN = np.abs(N) / A
    sM = fc * np.abs(M) * (t / 2) / Iz
    # corte na alma: tau = V Q / (Iz tw), Q = momento estático de meia secção
    Q = b * wf * (t - wf) / 2 + tw * (h / 2) * (h / 4)
    tau = np.where(h >= H_LIM, np.abs(V) * Q / (Iz * tw),                 # alma (I)
                   1.5 * np.abs(V) / A)                                    # cheia
    return np.maximum(sN + sM, np.sqrt(sN ** 2 + 3 * tau ** 2))


def sigma_fora(t, b, wf, tw, Mn, T):
    h, A, Iz, In = propriedades(t, b, wf, tw)
    sb = Mn * (b / 2) / In
    # torção: cheia -> Roark ; aberta (I) -> soma dos retângulos, tau = T c / J
    a, c = np.maximum(t, b), np.minimum(t, b)
    tau_cheia = T * (3 * a + 1.8 * c) / (a ** 2 * c ** 2)
    L1, c1 = np.maximum(wf, b), np.minimum(wf, b)
    Lw, cw = np.maximum(h, tw), np.minimum(h, tw)
    J = 2 * _beta(c1, L1) * L1 * c1 ** 3 + _beta(cw, Lw) * Lw * cw ** 3
    tau_aberta = T * np.maximum(c1, cw) / np.maximum(J, 1e-9)
    tau = np.where(h >= H_LIM, tau_aberta, tau_cheia)
    return np.sqrt(sb ** 2 + 3 * tau ** 2)


def fs_seccoes(env, b, wf, tw, adm):
    """FS em cada secção (mínimo entre casos no plano e fora do plano)."""
    t = env['t']
    s_max = np.zeros(len(t))
    for _, N, V, M, fc in env['casos_plano']:
        s_max = np.maximum(s_max, sigma_plano(t, b, wf, tw, N, V, M, fc))
    s_max = np.maximum(s_max, sigma_fora(t, b, wf, tw, env['Mn'], env['T']))
    return adm / np.maximum(s_max, 1e-9)


# ==============================================================================
# 3. DIMENSIONAMENTO SECÇÃO A SECÇÃO (menor área que cumpre tudo)
# ==============================================================================
def dimensionar(env, b_ret, cen, mat, fab, tipo=None):
    """tipo: None (livre), ou array de 'cheia'/'I' por secção."""
    t_all = env['t']
    FS = cen['FS']
    adm = mat['sf'] if cen['criterio'] == 'fadiga' else mat['sy']
    rigidez = cen['theta_max'] is not None
    n = len(t_all)
    b_o, wf_o, tw_o = b_ret.copy(), t_all / 2, b_ret.copy()        # partida: Fase 1 (cheia)
    fr = np.linspace(0, 1, 14)
    for k in range(n):
        t = t_all[k]
        bmax = max(j3.B_INTERFACE, b_ret[k])
        bs = np.unique(np.r_[np.linspace(j3.B_MIN, bmax, 26), b_ret[k]])
        wfs = np.unique(np.r_[np.linspace(fab['banzo_min'], t / 2, 22), t / 2])
        B, WF, FR = np.meshgrid(bs, wfs, fr, indexing='ij')
        TW = np.minimum(fab['alma_min'] + FR * (B - fab['alma_min']), B)
        h = t - 2 * WF
        valido = (h >= fab['rebaixo_min']) & ((B - TW) / 2 <= fab['prof_max']) & (B - TW > 1.0)
        WF = np.where(valido, WF, t / 2)                     # inválido -> cheia
        TW = np.where(valido, TW, B)
        ok = np.ones(B.shape, bool)
        if tipo is not None:
            ok &= valido if tipo[k] == 'I' else ~valido
        for _, N, V, M, fc in env['casos_plano']:
            ok &= FS * sigma_plano(t, B, WF, TW, N[k], V[k], M[k], fc[k]) <= adm
        ok &= FS * sigma_fora(t, B, WF, TW, env['Mn'][k], env['T'][k]) <= adm
        _, A, Iz, _ = propriedades(t, B, WF, TW)
        if rigidez:
            ok &= Iz >= b_ret[k] * t ** 3 / 12 * (1 - 1e-9)
        if ok.any():
            i = np.argmin(np.where(ok, A, np.inf))
            b_o[k], wf_o[k], tw_o[k] = B.flat[i], WF.flat[i], TW.flat[i]
    return b_o, wf_o, tw_o


def _declive(x, s, d):
    """Limita |dx/ds| <= d só AUMENTANDO x."""
    x = x.copy(); ds = np.diff(s)
    for i in range(1, len(x)):
        x[i] = max(x[i], x[i - 1] - d * ds[i - 1])
    for i in range(len(x) - 2, -1, -1):
        x[i] = max(x[i], x[i + 1] - d * ds[i])
    return x


def _intervalos(mascara):
    idx = np.flatnonzero(np.diff(np.r_[0, mascara.astype(int), 0]))
    return list(zip(idx[::2], idx[1::2] - 1))


def _limpar_mascara(mascara, s, comprimento):
    """Remove rebaixos curtos e une rebaixos separados por pontes curtas."""
    m = mascara.copy()
    cheios = _intervalos(~m)
    for i0, i1 in cheios:                       # pontes cheias curtas entre rebaixos
        if i0 > 0 and i1 < len(m) - 1 and s[i1] - s[i0] < comprimento:
            m[i0:i1 + 1] = True
    for i0, i1 in _intervalos(m):               # rebaixos curtos
        if s[i1] - s[i0] < comprimento:
            m[i0:i1 + 1] = False
    return m


def regras_projeto(env, b_ret, b, wf, tw, cen, mat, fab):
    """1) decide ONDE há rebaixo (zonas contínuas); 2) redimensiona cada secção
    com o tipo fixo; 3) regras que só acrescentam material."""
    s, t, S = env['s'], env['t'], env['S']
    d_ponta = np.minimum(s - s[0], s[-1] - s)
    perto_verde = d_ponta < j3.L_TRANSICAO + 0.5 * np.median(t)
    # curvatura do eixo (o rebaixo tem de caber nas curvas)
    dx, dy = np.gradient(S[:, 0], s), np.gradient(S[:, 1], s)
    ddx, ddy = np.gradient(dx, s), np.gradient(dy, s)
    kap = gaussian_filter1d(np.abs(dx * ddy - dy * ddx) / np.hypot(dx, dy) ** 3, 2)
    rho_eixo = 1 / np.maximum(kap, 1e-9)
    # 1) onde há rebaixo
    mascara = (t - 2 * wf >= fab['rebaixo_min']) & ~perto_verde
    mascara = _limpar_mascara(mascara, s, COMPRIMENTO_MIN_REBAIXO)
    # 2) redimensionar com o tipo fixo
    tipo = np.where(mascara, 'I', 'cheia')
    b, wf, tw = dimensionar(env, b_ret, cen, mat, fab, tipo)
    # 3) regras que só acrescentam material
    for _ in range(3):
        wf = np.where(mascara, np.maximum(wf, (t - 2 * FOLGA_CURVA * rho_eixo) / 2), t / 2)
        b = np.maximum(b, np.clip(1 - d_ponta / j3.L_TRANSICAO, 0, 1) * j3.B_INTERFACE)
        b = _declive(b, s, j3.DECLIVE_MAX)
        for i0, i1 in _intervalos(mascara):
            sl = slice(i0, i1 + 1)
            wf[sl] = _declive(wf[sl], s[sl], 0.5)
            tw[sl] = _declive(tw[sl], s[sl], 0.5)
            for k in range(i0, i1 + 1):          # pontas arredondadas (raio = h/2)
                d = min(s[k] - s[i0], s[i1] - s[k])
                R = (t[k] - 2 * wf[k]) / 2
                if d < R:
                    h_ok = 2 * np.sqrt(max(0.0, R ** 2 - (R - d) ** 2))
                    wf[k] = max(wf[k], (t[k] - h_ok) / 2)
        wf = np.minimum(wf, t / 2)
        tw = np.where(mascara, np.minimum(tw, b - 1.0), b)
        mascara = _limpar_mascara(mascara & (t - 2 * wf > 1e-6), s, COMPRIMENTO_MIN_REBAIXO)
    wf = np.where(mascara, wf, t / 2)
    tw = np.where(mascara, tw, b)
    return b, wf, tw, mascara


# ==============================================================================
# 4. GEOMETRIA DOS REBAIXOS + MALHA 3D ESTANQUE
# ==============================================================================
def contornos_rebaixos(env, wf, rebaixo, sk, fab, passo):
    """Polígonos 2D dos rebaixos (um por intervalo). Valida que ficam dentro
    da peça com o banzo mínimo; se não, o rebaixo é eliminado."""
    S, tang, t = env['S'], env['tang'], env['t']
    nrm = np.c_[-tang[:, 1], tang[:, 0]]
    h = t - 2 * wf
    contorno = Path(sk)
    skd = gv.densificar(sk, 1.0)
    polis = []
    for i0, i1 in _intervalos(rebaixo):
        ks = np.arange(max(i0 - 1, 0), min(i1 + 2, len(S)))
        esq = S[ks] + nrm[ks] * (h[ks, None] / 2)
        dir_ = S[ks] - nrm[ks] * (h[ks, None] / 2)
        P = np.vstack([esq, dir_[::-1]])
        P = P[np.r_[True, np.hypot(*np.diff(P, axis=0).T) > 0.3]]
        if len(P) < 6:
            continue
        fechado = np.vstack([P, P[:1]])
        if gv.auto_intersecta(fechado):
            continue
        dist = np.array([np.min(np.hypot(*(skd - p).T)) for p in P])
        if not contorno.contains_points(P).all() or dist.min() < fab['banzo_min'] - 0.05:
            continue
        Pd = gv.densificar(fechado, passo * 0.75)[:-1]
        manter = [0]                                   # sem pontos quase coincidentes
        for i in range(1, len(Pd)):
            if np.hypot(*(Pd[i] - Pd[manter[-1]])) > 0.3:
                manter.append(i)
        Pd = Pd[manter]
        if np.hypot(*(Pd[-1] - Pd[0])) <= 0.3:        # fecho
            Pd = Pd[:-1]
        polis.append(Pd)
    return polis


def ajustar_banzos(env, wf, rebaixo, sk, fab, iteracoes=5):
    """Impõe a largura mínima de banzo MEDIDA na geometria (distância real do
    bordo do rebaixo ao contorno da peça), alargando o banzo onde faltar."""
    S, tang, t = env['S'], env['tang'], env['t']
    nrm = np.c_[-tang[:, 1], tang[:, 0]]
    skd = gv.densificar(sk, 0.5)
    wf = wf.copy()
    for _ in range(iteracoes):
        h = t - 2 * wf
        ks = np.flatnonzero(rebaixo & (h > 0))
        if not len(ks):
            break
        defice = np.zeros(len(t))
        for k in ks:
            for sinal in (1, -1):
                q = S[k] + sinal * nrm[k] * h[k] / 2
                d = np.min(np.hypot(*(skd - q).T))
                defice[k] = max(defice[k], fab['banzo_min'] + 0.25 - d)
        if (defice <= 0).all():
            break
        wf = np.minimum(np.where(defice > 0, wf + defice, wf), t / 2)
    return wf


def _orientar(P2, tri):
    a, b, c = P2[tri[:, 0]], P2[tri[:, 1]], P2[tri[:, 2]]
    cruz = (b[:, 0] - a[:, 0]) * (c[:, 1] - a[:, 1]) - (b[:, 1] - a[:, 1]) * (c[:, 0] - a[:, 0])
    tri = tri.copy()
    tri[cruz < 0] = tri[cruz < 0][:, [0, 2, 1]]
    return tri[np.abs(cruz) > 1e-9]


def _grelha(caminho_dentro, fronteiras, lo, hi, passo, excluir=()):
    gx, gy = np.meshgrid(np.arange(lo[0], hi[0], passo), np.arange(lo[1], hi[1], passo))
    G = np.c_[gx.ravel(), gy.ravel()]
    G[1::2] += [passo / 2, 0]
    G = G[caminho_dentro.contains_points(G)]
    for e in excluir:
        G = G[~e.contains_points(G)]
    if len(G) and len(fronteiras):
        F = np.vstack(fronteiras)
        dmin = np.array([np.min(np.hypot(*(F - g).T)) for g in G])
        G = G[dmin > 0.45 * passo]
    return G


def _arestas_fronteira(F):
    E = np.vstack([F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]])
    chave = {}
    for a, b in E:
        chave[(a, b)] = chave.get((a, b), 0) + 1
    return [(a, b) for (a, b) in chave if (b, a) not in chave]


def triangulacao_conforme(P, lacos, max_iter=12):
    """Delaunay CONFORME: enquanto uma aresta de fronteira (lacos = listas
    ordenadas de índices, fechadas) não existir na triangulação, insere-se o
    seu ponto médio. No fim, todas as fronteiras são arestas de triângulos."""
    P = [np.asarray(p, float) for p in P]
    lacos = [list(l) for l in lacos]
    for _ in range(max_iter):
        A = np.array(P)
        tri = Delaunay(A).simplices
        ar = set()
        for x, y, z in tri:
            ar.update({(min(x, y), max(x, y)), (min(y, z), max(y, z)), (min(x, z), max(x, z))})
        mudou = False
        for L in lacos:
            novo = []
            for i in range(len(L)):
                a, c = L[i], L[(i + 1) % len(L)]
                novo.append(a)
                if (min(a, c), max(a, c)) not in ar:
                    P.append(0.5 * (P[a] + P[c])); novo.append(len(P) - 1); mudou = True
            L[:] = novo
        if not mudou:
            return A, tri, lacos
    raise RuntimeError('triangulação conforme não convergiu')


def malha_I(sk, env, b, tw, polis, passo=j3.PASSO_MALHA):
    """Malha fechada: moldura (profundidade b) + fundos dos rebaixos (alma tw)
    + paredes exteriores e dos rebaixos. Uma única triangulação conforme."""
    Bc = j3._contorno_ccw(sk, passo * 0.75)
    exterior = Path(np.vstack([Bc, Bc[:1]]))
    furos = [Path(np.vstack([p, p[:1]])) for p in polis]
    lo, hi = Bc.min(0), Bc.max(0)
    G = _grelha(exterior, [Bc] + polis, lo, hi, passo)        # inclui dentro dos furos
    pts = [Bc] + list(polis) + [G]
    P0 = np.vstack(pts)
    lacos, off = [], 0
    for blk in [Bc] + list(polis):
        lacos.append(list(range(off, off + len(blk)))); off += len(blk)
    P2, tri, lacos = triangulacao_conforme(P0, lacos)
    cen = P2[tri].mean(axis=1)
    dentro = exterior.contains_points(cen)
    no_furo = np.zeros(len(tri), bool)
    for fu in furos:
        no_furo |= fu.contains_points(cen)
    TF = _orientar(P2, tri[dentro & ~no_furo])              # moldura
    TP = _orientar(P2, tri[dentro & no_furo])               # fundos
    exterior_idx = set(lacos[0])
    furo_idx = set(i for L in lacos[1:] for i in L)

    S = env['S']
    sec = np.array([int(np.argmin(np.hypot(*(S - q).T))) for q in P2], int)
    zc = j3.B_INTERFACE / 2
    n = len(P2)
    oFT, oFB, oPT, oPB = 0, n, 2 * n, 3 * n
    V = np.vstack([np.c_[P2, zc + b[sec] / 2], np.c_[P2, zc - b[sec] / 2],
                   np.c_[P2, zc + tw[sec] / 2], np.c_[P2, zc - tw[sec] / 2]])
    faces = [TF + oFT, TF[:, [0, 2, 1]] + oFB]
    if len(TP):
        faces += [TP + oPT, TP[:, [0, 2, 1]] + oPB]
    paredes = []
    for a, c in _arestas_fronteira(TF):                     # arestas do topo da moldura
        if a in exterior_idx and c in exterior_idx:         # parede exterior (topo -> fundo)
            paredes += [(c + oFT, a + oFT, a + oFB), (c + oFT, a + oFB, c + oFB)]
        elif a in furo_idx and c in furo_idx:               # parede do rebaixo de cima
            paredes += [(c + oFT, a + oFT, a + oPT), (c + oFT, a + oPT, c + oPT)]
    for a, c in _arestas_fronteira(TF[:, [0, 2, 1]]):       # base da moldura
        if a in furo_idx and c in furo_idx:                 # parede do rebaixo de baixo
            paredes += [(c + oFB, a + oFB, a + oPB), (c + oFB, a + oPB, c + oPB)]
    if paredes:
        faces.append(np.array(paredes))
    F = np.vstack(faces).astype(int)
    # compactar (remover vértices não usados)
    usados = np.unique(F)
    novo = -np.ones(len(V), int); novo[usados] = np.arange(len(usados))
    idx_sec = np.r_[sec, sec, sec, sec][usados]
    return V[usados], novo[F], idx_sec


def reparar(env, b_ret, b, wf, tw, rebaixo, cen, adm):
    """Garante FS >= requisito em TODAS as secções depois das regras de
    projeto: 1) engrossar a alma; 2) aumentar a profundidade; 3) se ainda
    falhar, encher esse rebaixo inteiro (volta à secção cheia da Fase 1)."""
    t, FS = env['t'], cen['FS']
    b, wf, tw, rebaixo = b.copy(), wf.copy(), tw.copy(), rebaixo.copy()

    def falha():
        return fs_seccoes(env, b, wf, tw, adm) < FS * (1 - 1e-6)

    for k in np.flatnonzero(falha() & rebaixo):
        for _ in range(40):                                  # 1) alma
            if fs_seccoes({**env, **_fatia(env, k)}, b[k:k+1], wf[k:k+1], tw[k:k+1], adm)[0] >= FS:
                break
            tw[k] = min(tw[k] * 1.15 + 0.2, b[k] - 1.0)
            if tw[k] >= b[k] - 1.0:
                b[k] = min(b[k] + 1.0, max(b_ret[k], j3.B_INTERFACE) * 1.5)   # 2) profundidade
    ruins = falha()
    for i0, i1 in _intervalos(rebaixo):                       # 3) encher o rebaixo
        if ruins[i0:i1 + 1].any():
            sl = slice(i0, i1 + 1)
            b[sl] = np.maximum(b[sl], b_ret[sl]); wf[sl] = t[sl] / 2; tw[sl] = b[sl]
            rebaixo[sl] = False
    ruins = falha() & ~rebaixo                                # secções cheias: b da Fase 1
    b[ruins] = np.maximum(b[ruins], b_ret[ruins]); tw[ruins] = b[ruins]
    return b, wf, tw, rebaixo


def _fatia(env, k):
    """env reduzido a uma secção (para recalcular o FS só aí)."""
    return dict(t=env['t'][k:k+1], Mn=env['Mn'][k:k+1], T=env['T'][k:k+1],
                casos_plano=[(n, N[k:k+1], V[k:k+1], M[k:k+1], fc[k:k+1])
                             for n, N, V, M, fc in env['casos_plano']])


# ==============================================================================
# 5. FUNÇÃO PRINCIPAL
# ==============================================================================
def gerar(params=None, cenario='B', material='Al 7075-T6 (CNC)', sketch=None,
          com_malha=True):
    base = j3.gerar(params, cenario, material, 'variavel', sketch=sketch, com_malha=False)
    env, b_ret = base['env'], base['b']
    cen, mat = gv.CENARIOS[base['cenario']], gv.material(base['cenario'], material)
    fab = FABRICO[processo(material)]
    adm = mat['sf'] if cen['criterio'] == 'fadiga' else mat['sy']
    b, wf, tw = dimensionar(env, b_ret, cen, mat, fab)
    b, wf, tw, rebaixo = regras_projeto(env, b_ret, b, wf, tw, cen, mat, fab)
    wf = ajustar_banzos(env, wf, rebaixo, base['sketch'], fab)
    b, wf, tw, rebaixo = reparar(env, b_ret, b, wf, tw, rebaixo, cen, adm)
    polis = contornos_rebaixos(env, wf, rebaixo, base['sketch'], fab, j3.PASSO_MALHA)
    # secções cujo rebaixo foi eliminado na validação geométrica -> cheias (Fase 1)
    if len(polis) < len(_intervalos(rebaixo)):
        P_ok = [Path(np.vstack([p, p[:1]])) for p in polis]
        for i0, i1 in _intervalos(rebaixo):
            meio = env['S'][(i0 + i1) // 2]
            if not any(pk.contains_point(meio) for pk in P_ok):
                sl = slice(i0, i1 + 1)
                b[sl] = np.maximum(b[sl], b_ret[sl])
                wf[sl] = env['t'][sl] / 2
                tw[sl] = b[sl]
                rebaixo[sl] = False
    fs = fs_seccoes(env, b, wf, tw, adm)
    camber = 0.0
    if cen['theta_max'] is not None and env['rig']:
        _, _, Iz, _ = propriedades(env['t'], b, wf, tw)
        integ = np.trapezoid if hasattr(np, 'trapezoid') else np.trapz
        camber = np.degrees(max(abs(integ(r * env['t'] ** 3 / 12 / Iz, env['s']))
                                for r in env['rig']) / mat['E'])
    out = dict(base, b=b, wf=wf, tw=tw, rebaixo=rebaixo, polis=polis, fs=fs,
               FS_min=float(fs.min()), camber=camber, processo=processo(material),
               modo='I')
    if com_malha:
        V, F, idx = malha_I(base['sketch'], env, b, tw, polis)
        vol = j3.volume_malha(V, F)
        out.update(V=V, F=F, idx=idx, volume_mm3=vol, massa_kg=vol * mat['rho'] * 1e-9,
                   utilizacao=(cen['FS'] / fs)[idx], estanque=j3.malha_estanque(F))
    return out


def gerar_melhor(params=None, cenario='B', material='Al 7075-T6 (CNC)', sketch=None):
    """Decisão de projeto: entre a secção cheia com b(s) (Fase 1) e a secção
    em I (Fase 1b), fica a mais LEVE (ambas cumprem todos os requisitos)."""
    ri = gerar(params, cenario, material, sketch=sketch)
    rv = j3.gerar(params, cenario, material, 'variavel', sketch=sketch)
    if ri['massa_kg'] <= rv['massa_kg']:
        return dict(ri, escolha='b(s) + secção em I', alternativa_kg=rv['massa_kg'])
    return dict(rv, escolha='b(s) cheia', alternativa_kg=ri['massa_kg'], polis=[],
                processo=processo(material))


# ==============================================================================
# 6. COMPARAÇÃO: cheia (b const) -> b(s) -> b(s) + secção em I
# ==============================================================================
if __name__ == '__main__':
    import csv
    import os
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    os.makedirs('diag', exist_ok=True)
    linhas = [l for l in csv.DictReader(open('diag/designs_otimos.csv', encoding='utf-8-sig'),
                                        delimiter=';') if l['massa_kg'] not in ('', 'nan')]
    print(f'{"Cenário":22s}{"Material":24s}{"cheia":>8s}{"b(s)":>8s}{"b(s)+I":>8s}'
          f'{"vs cheia":>9s}{"FS":>6s}{"camber":>8s}  estanque  escolha')
    res = []
    for l in linhas:
        p = {k: float(l[k]) for k in gv.NOMES}
        c = l['cenario'][:2]
        rc = j3.gerar(p, c, l['material'], 'constante')
        rv = j3.gerar(p, c, l['material'], 'variavel')
        ri = gerar(p, c, l['material'])
        res.append((l, rc, rv, ri))
        cam = f'{ri["camber"]:.3f}°' if ri['theta_max'] else ''
        print(f'{l["cenario"][:21]:22s}{l["material"]:24s}{rc["massa_kg"]:8.2f}{rv["massa_kg"]:8.2f}'
              f'{ri["massa_kg"]:8.2f}{100*(ri["massa_kg"]/rc["massa_kg"]-1):+8.0f}%'
              f'{ri["FS_min"]:6.2f}{cam:>8s}  {str(ri["estanque"]):8s}  '
              f'{"I" if ri["massa_kg"] <= rv["massa_kg"] else "cheia b(s)"}')

    # figura: vista de cima com rebaixos + 3D para 2 exemplos
    exemplos = [r for r in res if (r[0]['cenario'][0], r[0]['material'][:5]) in
                (('A', 'Al 70'), ('B', 'Al 70'), ('C', 'Al 70'), ('D', 'Al 70'))][:4]
    from mpl_toolkits.mplot3d.art3d import Poly3DCollection
    fig = plt.figure(figsize=(20, 10))
    for i, (l, rc, rv, ri) in enumerate(exemplos):
        ax = fig.add_subplot(2, 4, i + 1)
        sk = ri['sketch']
        ax.fill(sk[:, 0], sk[:, 1], color='#d6dbe0', ec='k', lw=1)
        for pl in ri['polis']:
            ax.fill(pl[:, 0], pl[:, 1], color='#6c8ebf', alpha=.85)
        sc = ax.scatter(*ri['env']['S'].T, c=ri['FS_req'] / ri['fs'], cmap='turbo', s=6,
                        vmin=0, vmax=1)
        ax.set_aspect('equal'); ax.set_xticks([]); ax.set_yticks([])
        ax.set_title(f'{l["cenario"][:20]}\n{l["material"]}\n'
                     f'{rc["massa_kg"]:.2f} → {rv["massa_kg"]:.2f} → {ri["massa_kg"]:.2f} kg',
                     fontsize=9)
        ax3 = fig.add_subplot(2, 4, i + 5, projection='3d')
        V, F = ri['V'], ri['F']
        cores = plt.cm.turbo(np.clip(ri['utilizacao'][F].mean(axis=1), 0, 1))
        ax3.add_collection3d(Poly3DCollection(V[F], facecolors=cores, edgecolor='none'))
        lo, hi = V.min(0), V.max(0)
        ax3.set_xlim(lo[0], hi[0]); ax3.set_ylim(lo[1], hi[1]); ax3.set_zlim(lo[2], hi[2])
        ax3.set_box_aspect(hi - lo); ax3.view_init(35, -60); ax3.set_axis_off()
    fig.suptitle('Fase 1b - secção em I: rebaixos (azul) definidos pela física e pelo fabrico  '
                 '| massa: cheia → b(s) → b(s)+I | cor = utilização', fontsize=13,
                 fontweight='bold')
    plt.tight_layout()
    fig.savefig('diag/joelho3d_I_exemplos.png', dpi=110, bbox_inches='tight')
    l, rc, rv, ri = exemplos[3]
    j3.gravar_stl('diag/joelho3d_I_D_Al7075.stl', ri['V'], ri['F'])
    print('[OK] diag/joelho3d_I_exemplos.png, diag/joelho3d_I_D_Al7075.stl')
