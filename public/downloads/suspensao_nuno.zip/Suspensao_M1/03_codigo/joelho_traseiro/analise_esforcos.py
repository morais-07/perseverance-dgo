"""
==============================================================================
 ANÁLISE ANALÍTICA 2D DE ESFORÇOS - JOELHO DA RODA (Perseverance, M1)
==============================================================================
Modelo: viga curva em consola.
  - Encastramento: face de ligação ao verde SUPERIOR (encaixe da direção).
  - Carga: força roda-solo aplicada no PONTO DE CONTACTO da roda, transmitida
    ao joelho pelo cubo (verde INFERIOR).
  - Plano 2D da vista: X = eixo da roda (horizontal), Y = vertical.
    Esforços fora do plano (tração / embate frontal -> torção) NÃO entram.

Para cada secção do eixo médio do joelho (centro S, tangente t):
    N = F . t                       (esforço normal)
    V = F . n                       (esforço transverso)
    M = (P - S) x F                 (momento fletor, componente z)
Tensões (secção retangular t x b, b = profundidade constante):
    reta  : sigma = |N|/A + 6|M|/(b t^2)
    curva : Winkler-Bach (quando raio do eixo < 5 t)
    corte : tau = 1.5 |V| / A
    Von Mises = max(sigma_fibra, sqrt(sigma_N^2 + 3 tau^2))

A profundidade b ainda não é conhecida -> tudo é calculado com b = 1 mm
(sigma*b em N/mm). Daqui sai:
    - comparação entre designs: sigma_max / sigma_max_original (b cancela)
    - profundidade mínima para o FS:  b_min = FS * (sigma*b)_max / sigma_y
==============================================================================
"""
import numpy as np
import cv2
import matplotlib.pyplot as plt
from matplotlib.path import Path
from scipy.ndimage import distance_transform_edt, gaussian_filter1d
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import dijkstra

# ==============================================================================
# 1. DADOS DO PROBLEMA (alterar aqui)
# ==============================================================================
DADOS = {
    # --- Rover / Marte ---
    'massa_rover_kg':   1025.0,   # Perseverance
    'g_marte':          3.71,     # m/s^2
    'n_rodas':          6,
    # --- Roda (medido no Fusion) ---
    'dist_flange_plano_medio': 88.0,   # mm, da flange do cubo para DENTRO do C (-X)
    'raio_roda_ext':           253.3,  # mm, ponto de contacto com o solo
    'raio_roda_int':           232.6,  # mm (informativo)
    # --- Queda num buraco (método da energia, desaceleração constante) ---
    #   F = W_roda * (1 + h / d)
    'h_queda_mm':       150.0,    # profundidade do buraco / altura de queda
    'd_paragem_mm':     30.0,     # distância de paragem (flexão roda + suspensão)
    # --- Lateral ---
    'mu_lateral':       0.6,      # F_lateral = mu * F_vertical (atrito / embate em rocha)
    # --- Material e critério ---
    'sigma_y_MPa':      503.0,    # Al 7075-T6 (Ti-6Al-4V ~ 880 MPa)
    'FS':               2.0,
    'b_mm':             1.0,      # profundidade (2D -> 1 mm por defeito)
}


def casos_de_carga(d=DADOS):
    """Devolve {nome: (F_horizontal, F_vertical)} em N, no ponto de contacto.
    F_horizontal > 0 aponta para +X (para dentro do rover, lado da roda)."""
    W = d['massa_rover_kg'] * d['g_marte'] / d['n_rodas']
    fator = 1.0 + d['h_queda_mm'] / d['d_paragem_mm']
    Fq = W * fator
    mu = d['mu_lateral']
    return {
        '1. Estatico':                  (0.0,          W),
        '2. Queda no buraco':           (0.0,          Fq),
        '3. Lateral (+X)':              (+mu * W,      W),
        '3. Lateral (-X)':              (-mu * W,      W),
        '4. Queda + lateral (+X)':      (+mu * Fq,     Fq),
        '4. Queda + lateral (-X)':      (-mu * Fq,     Fq),
    }, W, fator


# ==============================================================================
# 2. GEOMETRIA: reutiliza o pipeline do codigov1.py (sem o alterar)
# ==============================================================================
# Fonte da geometria do joelho:
#   'step'   -> diag/geometria_joelho.json (gerado por geometria_step.py a partir do STEP)
#   'imagem' -> print do Fusion + segmentação por cor (codigov1.py, método antigo)
#   'auto'   -> STEP se o JSON existir, senão imagem
FONTE_GEOMETRIA = 'auto'
JSON_STEP = 'diag/geometria_joelho.json'


def _fonte():
    import os
    if FONTE_GEOMETRIA != 'auto':
        return FONTE_GEOMETRIA
    return 'step' if os.path.exists(JSON_STEP) else 'imagem'


def geometria_step():
    """Dados do joelho tirados do STEP (ou None se não existir)."""
    import os
    import json
    if _fonte() != 'step' or not os.path.exists(JSON_STEP):
        return None
    with open(JSON_STEP, encoding='utf-8') as f:
        return json.load(f)


_G = geometria_step()
if _G is not None:                      # a roda real substitui as medidas à mão
    DADOS['raio_roda_ext'] = _G['roda_dados']['raio_ext_mm']
    DADOS['raio_roda_int'] = _G['roda_dados']['raio_int_mm']


def carregar_geometria(ficheiro='codigov1.py'):
    """Devolve as variáveis de geometria do joelho (mesmos nomes do codigov1):
    - fonte 'imagem': corre a parte de leitura/calibração/sketch do codigov1.py;
    - fonte 'step'  : só as FUNÇÕES do codigov1 (fillets, sketch) + a geometria
      exata do STEP (zonas verdes, âncoras, contorno real, dados da roda)."""
    with open(ficheiro, 'r', encoding='utf-8') as f:
        src = f.read()
    ns = {}
    g = geometria_step()
    if g is None:
        exec(src.split('# 4. JANELA 1')[0], ns)
        return ns
    exec(src.split('# --- Leitura e validação da imagem ---')[0], ns)   # só definições
    cima = np.array(g['verde_cima']); baixo = np.array(g['verde_baixo'])
    C = np.array(g['contorno_cinzento'])
    x_c, ycs, yci, x_b, ybs, ybi = g['ancoras']
    ns.update(
        fonte='step', escala_mm=1.0,
        cima_x=cima[:, 0], cima_y=cima[:, 1], baixo_x=baixo[:, 0], baixo_y=baixo[:, 1],
        x_int_cima=x_c, y_cima_sup=ycs, y_cima_inf=yci,
        x_int_baixo=x_b, y_baixo_sup=ybs, y_baixo_inf=ybi,
        ancoras_verdes=tuple(g['ancoras']),
        sketch_cad_base=np.vstack([C, C[:1]]),          # peça ORIGINAL real (do STEP)
        roda=g['roda_dados'], b_real=g['profundidade_braco_mm'], geometria=g)
    if g.get('parametros_calibrados'):
        ns['parametros_base'] = dict(g['parametros_calibrados'])
    ns['area_base'] = ns['calcular_area_poligono'](ns['sketch_cad_base'])
    return ns


def ponto_de_carga(ns, d=DADOS):
    """Ponto de contacto roda-solo, em mm, no referencial do sketch."""
    if ns.get('fonte') == 'step':       # roda real: plano médio x=0, eixo y=0
        r = ns['roda']
        return np.array([r['x_plano_medio'], -r['raio_ext_mm']]), float(np.max(ns['baixo_x'])), 0.0
    # Centro do cubo: meio da face de 81 mm do verde inferior
    y_eixo = 0.5 * (ns['y_baixo_sup'] + ns['y_baixo_inf'])
    # Flange: coluna mais alta do verde inferior -> face direita da flange
    bx, by = ns['baixo_x'], ns['baixo_y']
    xs = np.round(bx).astype(int)
    alturas = {x: by[xs == x].max() - by[xs == x].min() for x in np.unique(xs)}
    h_max = max(alturas.values())
    x_flange = max(x for x, h in alturas.items() if h >= 0.9 * h_max)
    # o plano médio da roda fica do lado do joelho (a roda está envolvida pelo C)
    x_plano = x_flange - d['dist_flange_plano_medio']
    P = np.array([x_plano, y_eixo - d['raio_roda_ext']])
    return P, x_flange, y_eixo


# ==============================================================================
# 3. EIXO MÉDIO E ESPESSURA (válido para QUALQUER variante do sketch)
# ==============================================================================
def eixo_medio(sketch, ancoras, res=0.5, n_pts=300, p=8):
    """Eixo médio da peça = caminho de máxima folga (crista da distance
    transform) entre o centro da face superior e o centro da face inferior.
    Devolve s, centros S, tangentes, espessura t, raio de curvatura rho."""
    x_c, ycs, yci, x_b, ybs, ybi = ancoras
    ext = 60.0   # prolongar as faces de ligação para dentro do verde (só para a DT)
    poly = Path(sketch)
    xmin, ymin = sketch.min(0) - 5
    xmax, ymax = sketch.max(0) + 5
    xmax = max(xmax, x_c + ext + 5)
    gx = np.arange(xmin, xmax, res)
    gy = np.arange(ymin, ymax, res)
    XX, YY = np.meshgrid(gx, gy)
    pts = np.c_[XX.ravel(), YY.ravel()]
    dentro = poly.contains_points(pts).reshape(XX.shape)
    # prolongamentos (as faces verdes não são fronteira livre)
    dentro |= (XX >= x_c - 1) & (XX <= x_c + ext) & (YY <= ycs) & (YY >= yci)
    dentro |= (XX >= x_b - 1) & (XX <= x_b + ext) & (YY <= ybs) & (YY >= ybi)
    D = distance_transform_edt(dentro) * res

    # grafo 8-conectado, custo forte fora da crista
    idx = -np.ones(dentro.shape, int)
    ij = np.argwhere(dentro)
    idx[dentro] = np.arange(len(ij))
    # custo muito alto longe da crista -> o caminho segue o centro da peça
    custo = (D.max() / (D[dentro] + res)) ** p
    linhas, cols, pesos = [], [], []
    for di, dj in [(0, 1), (1, 0), (1, 1), (1, -1)]:
        i2, j2 = ij[:, 0] + di, ij[:, 1] + dj
        ok = (i2 >= 0) & (i2 < dentro.shape[0]) & (j2 >= 0) & (j2 < dentro.shape[1])
        a = np.where(ok)[0]
        b = idx[i2[ok], j2[ok]]
        v = b >= 0
        a, b = a[v], b[v]
        L = np.hypot(di, dj) * res
        w = 0.5 * (custo[a] + custo[b]) * L
        linhas += [a, b]; cols += [b, a]; pesos += [w, w]
    G = coo_matrix((np.concatenate(pesos), (np.concatenate(linhas), np.concatenate(cols))),
                   shape=(len(ij), len(ij))).tocsr()

    def no_mais_proximo(x, y):
        i = np.argmin(np.abs(gy - y)); j = np.argmin(np.abs(gx - x))
        return idx[i, j]
    ini = no_mais_proximo(x_c + ext * 0.5, 0.5 * (ycs + yci))
    fim = no_mais_proximo(x_b + ext * 0.5, 0.5 * (ybs + ybi))
    if ini < 0 or fim < 0:
        raise ValueError('faces de ligação fora do domínio')
    _, pred = dijkstra(G, indices=ini, return_predecessors=True)
    if pred[fim] < 0:
        raise ValueError('peça desligada: não há caminho entre as duas faces verdes')
    caminho = [fim]
    while caminho[-1] != ini:
        caminho.append(pred[caminho[-1]])
    caminho = np.array(caminho[::-1])
    C = np.c_[gx[ij[caminho, 1]], gy[ij[caminho, 0]]]
    esp = 2.0 * D[ij[caminho, 0], ij[caminho, 1]]

    # cortar ao domínio cinzento (entre as duas faces)
    fora_cima = (C[:, 0] > x_c) & (C[:, 1] >= yci - 1)
    fora_baixo = (C[:, 0] > x_b) & (C[:, 1] <= ybs + 1)
    m = ~(fora_cima | fora_baixo)
    C, esp = C[m], esp[m]

    # reamostrar uniformemente e suavizar
    ds = np.r_[0, np.cumsum(np.hypot(*np.diff(C, axis=0).T))]
    s = np.linspace(0, ds[-1], n_pts)
    Cx = gaussian_filter1d(np.interp(s, ds, C[:, 0]), 3, mode='nearest')
    Cy = gaussian_filter1d(np.interp(s, ds, C[:, 1]), 3, mode='nearest')
    t = gaussian_filter1d(np.interp(s, ds, esp), 2, mode='nearest')
    dx, dy = np.gradient(Cx, s), np.gradient(Cy, s)
    nrm = np.hypot(dx, dy)
    tang = np.c_[dx / nrm, dy / nrm]
    ddx, ddy = np.gradient(dx, s), np.gradient(dy, s)
    kappa_s = (dx * ddy - dy * ddx) / nrm ** 3          # curvatura com sinal
    passo = s[1] - s[0]
    kappa_s = gaussian_filter1d(kappa_s, max(1.0, 0.25 * np.median(t) / passo), mode='nearest')
    S = np.c_[Cx, Cy]
    rho = raio_fibra_interior(sketch, S, tang, t, kappa_s)
    return s, S, tang, t, rho


def _circulo(pts):
    """Ajuste algébrico de círculo (Kasa). Devolve centro, raio."""
    x, y = pts[:, 0], pts[:, 1]
    A = np.c_[2 * x, 2 * y, np.ones_like(x)]
    sol, *_ = np.linalg.lstsq(A, x ** 2 + y ** 2, rcond=None)
    c = sol[:2]
    return c, np.sqrt(max(sol[2] + c @ c, 0.0))


def raio_fibra_interior(sketch, S, tang, t, kappa_s, densidade=1.0):
    """Raio do eixo (rho) para Winkler, obtido a partir do RAIO REAL do
    contorno do lado côncavo (o fillet interior), e não da curvatura do eixo
    médio (que dobra bruscamente junto a cantos exteriores vivos).
        rho = r_fibra_interior + t/2   ;   secção reta -> rho = inf"""
    # contorno denso
    seg = np.diff(sketch, axis=0)
    L = np.hypot(*seg.T)
    dens = []
    for p0, d, l in zip(sketch[:-1], seg, L):
        n = max(int(l / densidade), 1)
        dens.append(p0 + np.outer(np.arange(n) / n, d))
    B = np.vstack(dens)
    rho = np.full(len(S), np.inf)
    nrm = np.c_[-tang[:, 1], tang[:, 0]]
    for k in range(len(S)):
        # testar as DUAS fibras: a que estiver num fillet côncavo é a interior
        for lado in (nrm[k], -nrm[k]):
            Q = S[k] + lado * t[k] / 2
            viz = B[np.hypot(*(B - Q).T) < 0.35 * t[k]]
            if len(viz) < 6:
                continue
            c, r = _circulo(viz)
            if not (1.0 <= r < 5.0 * t[k]):
                continue
            # 1) ajuste de círculo bom (um canto entre duas retas NÃO é um arco)
            resid = np.sqrt(np.mean((np.hypot(*(viz - c).T) - r) ** 2))
            if resid > 0.08 * r:
                continue
            # 2) côncavo: centro de curvatura FORA do material, para lá da fibra
            if (c - S[k]) @ lado < 0.8 * t[k] / 2:
                continue
            rho[k] = min(rho[k], r + t[k] / 2)
    return rho


# ==============================================================================
# 4. ESFORÇOS E TENSÕES
# ==============================================================================
def esforcos(S, tang, P, F, k_aplic=None):
    """N, V, M em cada secção para força F=(Fh,Fv) aplicada em P.
    Encastramento em s=0 (direção). Uma secção só 'vê' as cargas aplicadas
    do lado livre (s maior). Cargas na roda: k_aplic=None (todas as secções).
    Carga aplicada no próprio joelho: k_aplic = índice do eixo onde atua."""
    F = np.asarray(F, float)
    nrm = np.c_[-tang[:, 1], tang[:, 0]]
    N = tang @ F
    V = nrm @ F
    r = P - S
    M = r[:, 0] * F[1] - r[:, 1] * F[0]          # N.mm
    if k_aplic is not None:
        fora = np.arange(len(S)) >= k_aplic
        N[fora] = 0.0; V[fora] = 0.0; M[fora] = 0.0
    return N, V, M


def tensoes(N, V, M, t, rho, b=1.0):
    """Tensão máxima (Von Mises simplificado) por secção, em MPa."""
    A = b * t
    sN = np.abs(N) / A
    # reta
    sM_reta = 6.0 * np.abs(M) / (b * t ** 2)
    # curva (Winkler-Bach) onde rho < 5t
    sM = sM_reta.copy()
    curva = np.isfinite(rho) & (rho < 5.0 * t)
    ri = rho[curva] - t[curva] / 2
    ro = rho[curva] + t[curva] / 2
    ok = ri > 0
    rc, tc, Mc, Ac = rho[curva][ok], t[curva][ok], np.abs(M[curva][ok]), A[curva][ok]
    ri, ro = ri[ok], ro[ok]
    rn = tc / np.log(ro / ri)
    e = rc - rn
    s_in = Mc * (rn - ri) / (Ac * e * ri)
    s_out = Mc * (ro - rn) / (Ac * e * ro)
    tmp = sM[curva]
    tmp[ok] = np.maximum(s_in, s_out)
    sM[curva] = tmp
    sigma_fibra = sN + sM
    tau = 1.5 * np.abs(V) / A
    vm = np.maximum(sigma_fibra, np.sqrt(sN ** 2 + 3 * tau ** 2))
    fator_curva = sM / np.maximum(sM_reta, 1e-12)
    return vm, sigma_fibra, tau, fator_curva


def analisar(sketch, ancoras, P, casos, d=DADOS):
    s, S, tang, t, rho = eixo_medio(sketch, ancoras)
    res = {}
    for nome, F in casos.items():
        N, V, M = esforcos(S, tang, P, F)
        vm, sf, tau, fc = tensoes(N, V, M, t, rho, b=d['b_mm'])
        k = int(np.argmax(vm))
        res[nome] = dict(F=F, N=N, V=V, M=M, vm=vm, k=k, vm_max=vm[k],
                         b_min=d['FS'] * vm[k] * d['b_mm'] / d['sigma_y_MPa'],
                         fator_curva=fc)
    return dict(s=s, S=S, tang=tang, t=t, rho=rho, casos=res)


# ==============================================================================
# 5. EXECUÇÃO NO DESIGN BASE
# ==============================================================================
if __name__ == '__main__':
    import sys
    salvar = '--salvar' in sys.argv
    if salvar:
        import matplotlib
        matplotlib.use('Agg')
        import os
        os.makedirs('diag', exist_ok=True)

    ns = carregar_geometria()
    P, x_flange, y_eixo = ponto_de_carga(ns)
    casos, W, fator = casos_de_carga()
    R = analisar(ns['sketch_cad_base'], ns['ancoras_verdes'], P, casos)

    print('\n' + '=' * 72)
    print('  ANÁLISE DE ESFORÇOS 2D - JOELHO (DESIGN BASE)')
    print('=' * 72)
    print(f'Peso por roda (Marte): W = {W:.0f} N   | fator de queda 1+h/d = {fator:.1f}')
    print(f'Flange x = {x_flange:.0f} mm | plano médio roda x = {P[0]:.0f} mm | '
          f'eixo y = {y_eixo:.0f} mm | contacto y = {P[1]:.0f} mm')
    print(f'Espessura do eixo médio: min {R["t"].min():.0f} mm, max {R["t"].max():.0f} mm')
    print('-' * 72)
    print(f'{"Caso":28s}{"Fh [N]":>9s}{"Fv [N]":>9s}{"Mmax [N.m]":>12s}'
          f'{"sig*b [N/mm]":>14s}{"b_min FS2 [mm]":>16s}')
    for nome, r in R['casos'].items():
        print(f'{nome:28s}{r["F"][0]:9.0f}{r["F"][1]:9.0f}{np.abs(r["M"]).max()/1e3:12.1f}'
              f'{r["vm_max"]:14.1f}{r["b_min"]:16.1f}')
    pior = max(R['casos'], key=lambda n: R['casos'][n]['vm_max'])
    print('-' * 72)
    print(f'Caso crítico: {pior}  -> secção crítica em s = {R["s"][R["casos"][pior]["k"]]:.0f} mm '
          f'(t = {R["t"][R["casos"][pior]["k"]]:.0f} mm)')

    # ---------------- FIGURA ----------------
    caso_plot = '2. Queda no buraco'
    r = R['casos'][caso_plot]
    fig, axs = plt.subplots(1, 3, figsize=(20, 7.5),
                            gridspec_kw={'width_ratios': [1.25, 1, 1]})
    ax = axs[0]
    ax.fill(ns['cima_x'], ns['cima_y'], 'limegreen', ec='darkgreen', alpha=.8)
    ax.fill(ns['baixo_x'], ns['baixo_y'], 'limegreen', ec='darkgreen', alpha=.8)
    sk = ns['sketch_cad_base']
    ax.fill(sk[:, 0], sk[:, 1], color='#dddddd', ec='k', lw=1)
    sc = ax.scatter(R['S'][:, 0], R['S'][:, 1], c=r['vm'], cmap='turbo', s=14, zorder=3)
    plt.colorbar(sc, ax=ax, label='σ_VM · b  [N/mm]  (b = 1 mm)')
    k = r['k']
    ax.plot(*R['S'][k], 'r*', ms=18, zorder=4, label='Secção crítica')
    # roda e carga
    th = np.linspace(0, 2 * np.pi, 200)
    ax.plot(P[0] + 0 * th, np.linspace(y_eixo - 260, y_eixo + 260, 200), 'k-.', lw=.8)
    larg = ns['roda']['largura_mm'] if ns.get('fonte') == 'step' else 120.0
    ax.add_patch(plt.Rectangle((P[0] - larg / 2, y_eixo - DADOS['raio_roda_ext']), larg,
                               2 * DADOS['raio_roda_ext'], fill=False, ls='--', ec='gray'))
    ax.annotate('', xy=P, xytext=(P[0], P[1] - 90),
                arrowprops=dict(arrowstyle='->', lw=3, color='red'))
    ax.text(P[0] + 8, P[1] - 80, f'F = {r["F"][1]:.0f} N', color='red', fontweight='bold')
    if ns.get('fonte') != 'step':          # cota medida à mão no método antigo
        ax.plot([x_flange, P[0]], [y_eixo, y_eixo], 'b-', lw=1)
        ax.text(P[0] + 5, y_eixo + 8, '88 mm', color='b')
    ax.axhline(P[1], color='saddlebrown', lw=1.5)
    ax.text(ns['cima_x'].min(), P[1] + 6, 'solo', color='saddlebrown')
    ax.set_title(f'{caso_plot}: tensão ao longo do eixo médio', fontweight='bold')
    ax.axis('equal'); ax.grid(ls='--', alpha=.4); ax.legend(loc='upper right')

    ax = axs[1]
    for nome, rr in R['casos'].items():
        if 'Lateral' in nome and '(-X)' in nome: continue
        ax.plot(R['s'], rr['M'] / 1e3, lw=2, label=nome)
    ax.axhline(0, color='k', lw=.8)
    ax.set_xlabel('s ao longo do eixo médio [mm]  (0 = encaixe direção  →  cubo)')
    ax.set_ylabel('Momento fletor M [N·m]')
    ax.set_title('Diagrama de momentos fletores', fontweight='bold')
    ax.grid(ls='--', alpha=.4); ax.legend(fontsize=8)

    ax = axs[2]
    ax.plot(R['s'], r['vm'], 'r-', lw=2, label='σ_VM · b (queda)')
    ax.set_xlabel('s [mm]'); ax.set_ylabel('σ · b [N/mm]', color='r')
    ax2 = ax.twinx()
    ax2.plot(R['s'], R['t'], 'k--', lw=1.5, label='espessura t(s)')
    ax2.set_ylabel('espessura t [mm]')
    ax.set_title('Tensão e espessura ao longo da peça', fontweight='bold')
    ax.grid(ls='--', alpha=.4)
    h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, loc='upper right')
    plt.suptitle('Joelho da roda - Análise analítica 2D (viga curva em consola)',
                 fontsize=14, fontweight='bold')
    plt.tight_layout()
    if salvar:
        fig.savefig('diag/esforcos_base.png', dpi=130, bbox_inches='tight')
        print('[OK] diag/esforcos_base.png')
    else:
        plt.show()
