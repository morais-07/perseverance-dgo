"""
==============================================================================
 CALIBRAÇÃO AUTOMÁTICA DO SKETCH PARAMÉTRICO AO PERFIL REAL (STEP)
==============================================================================
Engenharia inversa: em vez de medir à mão as 14 cotas do sketch (192, 80, 75,
R88, ...), um otimizador ajusta-as até o sketch paramétrico coincidir ao
máximo com o contorno real do joelho tirado do STEP.

  objetivo = 1 - IoU(sketch(parâmetros), contorno real)
  IoU = área da interseção / área da união   (1.0 = coincidência perfeita)

O resultado fica em diag/geometria_joelho.json ("parametros_calibrados") e
passa a ser o design BASE das variantes.

Uso:  python calibrar_sketch.py
==============================================================================
"""
import json
import numpy as np
import cv2
from scipy.optimize import minimize

import analise_esforcos as ae
import gerador_variantes as gv

RES = 0.5   # mm por píxel


def main():
    gv._init()
    ns = gv._NS
    if ns.get('fonte') != 'step':
        raise SystemExit('Primeiro corre geometria_step.py (não há diag/geometria_joelho.json).')
    real = ns['sketch_cad_base']
    lo = real.min(0) - 60; hi = real.max(0) + 60
    W, H = (np.ceil((hi - lo) / RES)).astype(int) + 1

    def raster(P):
        m = np.zeros((H, W), np.uint8)
        q = ((P - lo) / RES).round().astype(np.int32)
        cv2.fillPoly(m, [q], 1)
        return m.astype(bool)

    R = raster(real)
    nomes = gv.NOMES
    lo_p = np.array([gv.LIMITES[k][0] for k in nomes]) * 0.6
    hi_p = np.array([gv.LIMITES[k][1] for k in nomes]) * 1.4

    def custo(x):
        p = dict(zip(nomes, x))
        try:
            sk, _ = gv.construir_sketch_v2(ns['ancoras_verdes'], p)
        except Exception:
            return 1.0
        if gv.auto_intersecta(sk):
            return 1.0
        S = raster(sk)
        inter = (S & R).sum(); uniao = (S | R).sum()
        return 1 - inter / max(uniao, 1)

    base = dict(ns['parametros_base'])
    base.setdefault('dobra_int_dy', 25.0)
    base.setdefault('base_int_dx', 0.6 * base['espessura_inf'])
    x0 = np.array([base[k] for k in nomes], float)
    print(f'IoU com as cotas medidas à mão no print: {1 - custo(x0):.4f}')
    melhor = x0.copy(); f_melhor = custo(x0)
    rng = np.random.default_rng(3)
    # várias partidas + Nelder-Mead (o custo é "aos degraus", sem gradiente)
    partidas = [x0] + [np.clip(x0 * rng.uniform(0.8, 1.2, len(x0)), lo_p, hi_p) for _ in range(5)]
    for i, xs in enumerate(partidas):
        r = minimize(lambda x: custo(np.clip(x, lo_p, hi_p)), xs, method='Nelder-Mead',
                     options=dict(maxfev=2500, xatol=0.05, fatol=1e-5, adaptive=True))
        xr = np.clip(r.x, lo_p, hi_p)
        if r.fun < f_melhor:
            melhor, f_melhor = xr, r.fun
        print(f'  partida {i}: IoU = {1 - r.fun:.4f}')
    p_final = {k: round(float(v), 2) for k, v in zip(nomes, melhor)}
    print(f'IoU final: {1 - f_melhor:.4f}')
    print(f'{"parâmetro":18s}{"à mão (print)":>14s}{"calibrado (STEP)":>18s}')
    for k in nomes:
        print(f'{k:18s}{base[k]:14.1f}{p_final[k]:18.1f}')

    g = ns['geometria']
    g['parametros_calibrados'] = p_final
    g['iou_calibracao'] = round(1 - f_melhor, 4)
    with open(ae.JSON_STEP, 'w', encoding='utf-8') as f:
        json.dump(g, f, ensure_ascii=False, indent=1)

    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    sk0, _ = gv.construir_sketch_v2(ns['ancoras_verdes'], dict(zip(nomes, x0)))
    sk1, _ = gv.construir_sketch_v2(ns['ancoras_verdes'], p_final)
    fig, axs = plt.subplots(1, 2, figsize=(16, 9))
    for ax, sk, tit in zip(axs, (sk0, sk1), (f'cotas medidas à mão (IoU {1 - custo(x0):.3f})',
                                              f'calibrado ao STEP (IoU {1 - f_melhor:.3f})')):
        ax.fill(*real.T, color='#cfcfcf', label='perfil real (STEP)')
        ax.fill(ns['cima_x'], ns['cima_y'], 'limegreen', alpha=.7)
        ax.fill(ns['baixo_x'], ns['baixo_y'], 'limegreen', alpha=.7)
        ax.plot(*sk.T, 'r-', lw=2, label='sketch paramétrico')
        ax.set_aspect('equal'); ax.grid(ls='--', alpha=.4); ax.legend(); ax.set_title(tit, fontweight='bold')
    fig.suptitle('Engenharia inversa automática: sketch paramétrico ajustado ao perfil do STEP',
                 fontsize=14, fontweight='bold')
    fig.savefig('diag/calibracao_sketch.png', dpi=100, bbox_inches='tight')
    print('[OK] parâmetros gravados em diag/geometria_joelho.json; figura diag/calibracao_sketch.png')


if __name__ == '__main__':
    main()
