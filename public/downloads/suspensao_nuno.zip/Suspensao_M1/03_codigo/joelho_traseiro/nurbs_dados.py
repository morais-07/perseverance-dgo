"""
==============================================================================
 DADOS PARA A GEOMETRIA NURBS LIMPA (numpy puro; o Rhino só constrói)
==============================================================================
A variante gerada (joelho3d / joelho3d_I) é descrita por:
  - contorno em planta (sketch 2D)            -> exato
  - profundidade b(s) por secção do eixo médio -> em degraus (uma por secção)
  - rebaixos da secção em I (polígonos + alma tw)
A malha antiga usava b(s) em degraus -> superfície ondulada e facetada.

Aqui prepara-se uma versão LISA e CONSERVADORA:
  1. b(s) alisado ao longo do eixo com uma ENVOLVENTE SUPERIOR (nunca fica
     abaixo do b necessário -> o FS não baixa)
  2. campo de profundidade suave em planta z(x,y) (mistura gaussiana das
     secções vizinhas), corrigido até cumprir b >= b necessário em todas as secções
  3. rebaixos com contorno suavizado e fundo plano à alma MAIS GROSSA desse
     rebaixo (conservador)
O Rhino faz depois: extrusão do contorno  ∩  "laje" entre as superfícies
z_topo(x,y) e z_fundo(x,y)  -  rebaixos.
==============================================================================
"""
import numpy as np
from matplotlib.path import Path
from scipy.ndimage import maximum_filter1d, gaussian_filter1d

PASSO_GRELHA = 6.0     # mm, espaçamento dos pontos das superfícies de topo/fundo
SIGMA_PLANTA = 7.0    # mm, alisamento do campo em planta
SIGMA_EIXO = 5.0       # mm, alisamento de b ao longo do eixo
MARGEM = 15.0          # mm, as superfícies passam para lá do contorno
SUAV_REBAIXO = 3.0     # mm, raio aproximado dos cantos dos rebaixos


def _b_envolvente(s, b):
    """b alisado ao longo do eixo, sempre >= b."""
    ds = np.median(np.diff(s))
    n_sig = max(SIGMA_EIXO / ds, 1.0)
    w = int(np.ceil(1.0 * n_sig)) * 2 + 1
    be = gaussian_filter1d(maximum_filter1d(b, w, mode='nearest'), n_sig, mode='nearest')
    return np.maximum(be, b)


def _corrigir(s, S, alvo, bk, mascara=None, it=40):
    """Sobe bk de forma SUAVE (correção alisada) até o campo cumprir alvo nas secções."""
    ds = np.median(np.diff(s))
    n_sig = max(SIGMA_EIXO / ds, 1.0)
    for _ in range(it):
        bS = _campo(S[:, 0], S[:, 1], S, bk)
        falta = alvo / np.maximum(bS, 1e-6) - 1.0
        if mascara is not None:
            falta = np.where(mascara, falta, 0.0)
        if falta.max() <= 1e-4:
            break
        g = gaussian_filter1d(np.maximum(falta, 0), n_sig, mode='nearest')
        g *= falta.max() / max(g.max(), 1e-9)          # o pico da correção cobre o défice
        bk = bk * (1.0 + 1.05 * g)
    return bk


def _campo(PX, PY, S, bk, sigma=SIGMA_PLANTA):
    """z(x,y) = soma w_k b_k / soma w_k , w = exp(-(d/sigma)^2) (secções perto)."""
    P = np.c_[PX.ravel(), PY.ravel()]
    out = np.empty(len(P))
    for i0 in range(0, len(P), 4000):
        p = P[i0:i0 + 4000]
        d2 = ((p[:, None, :] - S[None, :, :]) ** 2).sum(-1)
        d2 -= d2.min(axis=1, keepdims=True)              # relativo à secção mais próxima
        w = np.exp(-d2 / sigma ** 2)
        out[i0:i0 + 4000] = (w * bk).sum(1) / w.sum(1)
    return out.reshape(PX.shape)


def _suavizar_poligono(P, r=SUAV_REBAIXO, it=3):
    """Corta cantos (Chaikin) -> contorno com cantos arredondados, ligeiramente para dentro."""
    P = np.asarray(P, float)
    if np.allclose(P[0], P[-1]):
        P = P[:-1]
    # reamostragem uniforme (~2.5 mm) antes de cortar os cantos
    F = np.vstack([P, P[:1]])
    L = np.r_[0, np.cumsum(np.hypot(*np.diff(F, axis=0).T))]
    n = max(int(L[-1] / 2.5), 8)
    u = np.linspace(0, L[-1], n, endpoint=False)
    P = np.c_[np.interp(u, L, F[:, 0]), np.interp(u, L, F[:, 1])]
    # alisamento gaussiano do contorno fechado (tira as ondulações) ...
    from scipy.ndimage import gaussian_filter1d as g1
    P = np.c_[g1(P[:, 0], 3.0, mode='wrap'), g1(P[:, 1], 3.0, mode='wrap')]
    # ... e recuo de 0.5 mm para dentro (o alisamento não pode comer o banzo)
    area2 = np.dot(P[:, 0], np.roll(P[:, 1], -1)) - np.dot(P[:, 1], np.roll(P[:, 0], -1))
    T = np.roll(P, -1, axis=0) - np.roll(P, 1, axis=0)
    T /= np.maximum(np.hypot(*T.T), 1e-9)[:, None]
    N = np.c_[-T[:, 1], T[:, 0]] * (1 if area2 > 0 else -1)      # normal para dentro
    P = P + 0.5 * N
    for _ in range(it):
        Q = np.roll(P, -1, axis=0)
        novo = np.empty((2 * len(P), 2))
        novo[0::2] = 0.75 * P + 0.25 * Q
        novo[1::2] = 0.25 * P + 0.75 * Q
        P = novo
    return P


def preparar(r, B_interface):
    """r: saída de joelho3d.gerar / joelho3d_I.gerar(_melhor).
    Devolve dict com tudo o que o Rhino precisa (coordenadas 2D locais + z)."""
    env, b = r['env'], np.asarray(r['b'], float)
    s, S = env['s'], env['S']
    zc = B_interface / 2.0
    sk = np.asarray(r['sketch'], float)
    if not np.allclose(sk[0], sk[-1]):
        sk = np.vstack([sk, sk[:1]])

    # 1. envolvente ao longo do eixo + 2. campo em planta corrigido
    bk = _corrigir(s, S, 1.015 * b, _b_envolvente(s, b))   # +1.5%: margem da interpolação

    lo = sk[:, :2].min(0) - MARGEM
    hi = sk[:, :2].max(0) + MARGEM
    gx = np.arange(lo[0], hi[0] + PASSO_GRELHA, PASSO_GRELHA)
    gy = np.arange(lo[1], hi[1] + PASSO_GRELHA, PASSO_GRELHA)
    GX, GY = np.meshgrid(gx, gy)
    BZ = _campo(GX, GY, S, bk)
    # nunca mais fundo do que as faces verdes onde não é preciso (evita degrau nas
    # ligações); onde o b necessário passa B_interface, fica o necessário
    idx = np.array([int(np.argmin(((S - q) ** 2).sum(1))) for q in np.c_[GX.ravel(), GY.ravel()]])
    teto = np.maximum(B_interface, b[idx]).reshape(GX.shape)
    BZ = np.minimum(BZ, teto)

    # 3. rebaixos (secção em I): o FUNDO acompanha a alma tw(s) (superfície suave,
    #    sempre >= tw); fora dos rebaixos não interessa
    rebaixos = []
    tw = r.get('tw')
    TW = None
    polis = [po for po in (r.get('polis', []) or []) if len(po) >= 3]
    if tw is not None and polis:
        tw = np.asarray(tw, float).copy()
        reb = np.asarray(r.get('rebaixo', tw < b - 1e-6), bool)
        if reb.any():   # fora dos rebaixos a alma não conta: usa o valor do rebaixo mais próximo
            i_reb = np.flatnonzero(reb)
            for i in np.flatnonzero(~reb):
                tw[i] = tw[i_reb[np.argmin(np.abs(i_reb - i))]]
        twk = _corrigir(s, S, 1.015 * tw, _b_envolvente(s, tw), mascara=reb)
        TW = _campo(GX, GY, S, twk)
        for po in polis:
            rebaixos.append(dict(pts=_suavizar_poligono(po)))

    out = dict(contorno=sk, gx=gx, gy=gy, z_topo=zc + BZ / 2, z_fundo=zc - BZ / 2,
               rebaixos=rebaixos, zc=zc, H=float(BZ.max() + 40.0),
               b_envolvente=bk, b_necessario=b)
    if TW is not None:
        out.update(z_alma_topo=zc + TW / 2, z_alma_fundo=zc - TW / 2)
    return out


def volume(d, passo=1.0):
    """Volume aproximado [mm3] do sólido final (raster), para comparar com a malha."""
    sk = d['contorno']
    lo, hi = sk.min(0), sk.max(0)
    x = np.arange(lo[0], hi[0], passo) + passo / 2
    y = np.arange(lo[1], hi[1], passo) + passo / 2
    X, Y = np.meshgrid(x, y)
    P = np.c_[X.ravel(), Y.ravel()]
    dentro = Path(sk).contains_points(P)
    from scipy.interpolate import RegularGridInterpolator
    fT = RegularGridInterpolator((d['gy'], d['gx']), d['z_topo'])
    fB = RegularGridInterpolator((d['gy'], d['gx']), d['z_fundo'])
    zt, zb = fT(P[:, ::-1]), fB(P[:, ::-1])
    h = np.where(dentro, zt - zb, 0.0)
    if d['rebaixos']:
        fA = RegularGridInterpolator((d['gy'], d['gx']), d['z_alma_topo'])
        za = fA(P[:, ::-1])
        for rb in d['rebaixos']:
            em = Path(np.vstack([rb['pts'], rb['pts'][:1]])).contains_points(P) & dentro
            cav = np.maximum(zt - za, 0) * 2
            h = np.where(em, np.maximum(h - cav, 0), h)
    return float(h.sum() * passo * passo)


def _min_ratio(d, r):
    from scipy.interpolate import RegularGridInterpolator as RGI
    bS = RGI((d['gy'], d['gx']), d['z_topo'] - d['z_fundo'])(r['env']['S'][:, ::-1])
    return float(np.min(bS / d['b_necessario']))


if __name__ == '__main__':
    import csv
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import gerador_variantes as gv
    import joelho3d as j3
    import joelho3d_I as jI
    gv._init()
    for planeta in ('Marte', 'Vénus', 'Titã'):
        k = gv.chave_cenario(planeta).replace('\n', ' ')
        L = sorted([l for l in csv.DictReader(open('diag/planetas/designs_otimos.csv',
                    encoding='utf-8-sig'), delimiter=';')
                    if l['cenario'] == k and l['massa_kg'] not in ('', 'nan')],
                   key=lambda l: float(l['massa_kg']))[0]
        p = {n: float(L[n]) for n in gv.NOMES}
        r = jI.gerar_melhor(p, planeta, L['material'])
        d = preparar(r, j3.B_INTERFACE)
        rho = gv.MATERIAIS[L['material']]['rho']
        m = volume(d) * rho * 1e-9
        print(f'{planeta:7s} {L["material"]:20s} malha {r["massa_kg"]:.2f} kg | NURBS ~{m:.2f} kg '
              f'| rebaixos {len(d["rebaixos"])} | grelha {len(d["gx"])}x{len(d["gy"])} '
              f'| b_sup/b_nec min {_min_ratio(d, r):.3f}')
        if planeta == 'Marte':
            fig, ax = plt.subplots(1, 2, figsize=(12, 6))
            ax[0].plot(r['env']['s'], d['b_necessario'], label='b necessário (degraus)')
            from scipy.interpolate import RegularGridInterpolator as RGI
            bS = RGI((d['gy'], d['gx']), d['z_topo'] - d['z_fundo'])(r['env']['S'][:, ::-1])
            ax[0].plot(r['env']['s'], bS, label='b da superfície NURBS')
            ax[0].legend(); ax[0].set_xlabel('s [mm]'); ax[0].set_ylabel('b [mm]')
            cs = ax[1].contourf(d['gx'], d['gy'], d['z_topo'] - d['z_fundo'], 30)
            ax[1].plot(*d['contorno'].T, 'k'); [ax[1].plot(*rb['pts'].T, 'w') for rb in d['rebaixos']]
            ax[1].set_aspect('equal'); plt.colorbar(cs, ax=ax[1], label='profundidade [mm]')
            fig.savefig('diag/nurbs_campo_marte.png', dpi=90, bbox_inches='tight')
